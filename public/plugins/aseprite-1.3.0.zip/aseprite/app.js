// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：Aseprite 像素圖。
 *
 *  - .aseprite／.ase 檔（App 收成「其他檔案」）在這裡才有內容可看：
 *    快速預覽（registerQuickLook）直接播動畫；詳情頁（registerDetail("local", …, { when })）有完整的預覽與資訊；
 *    側欄的「像素圖」頁面（registerView）列出全部（ctx.virtualList，只建出看得到的那幾排），滑鼠移上去就動。
 *  - 解析器照 Aseprite 公開的檔案格式文件自己寫（docs/ase-file-specs.md），不引入函式庫；zlib 用瀏覽器內建的
 *    DecompressionStream("deflate")。.ase 也是 Adobe 色票的副檔名：開頭的 magic number 不是 0xA5E0 就不是 Aseprite 檔。
 *  - 支援 RGBA、灰階、索引色（含透明色）；圖層群組、隱藏圖層、參考圖層（不畫）、圖層與 cel 的不透明度、
 *    連結 cel、壓縮與未壓縮的 cel、tilemap（含翻轉）、調色盤、tag。
 *  - 混合模式：Normal、Multiply、Screen、Overlay、Darken、Lighten、Color Dodge、Color Burn、Hard Light、
 *    Soft Light、Difference、Exclusion、Addition、Subtract、Divide。Hue、Saturation、Color、Luminosity 先當 Normal，
 *    資訊裡註明。群組的混合模式不另外合成：子圖層直接畫上去，群組的不透明度乘進去。
 *  - 卡片的像素圖封面：第一格（多格的是整段動畫，存成 APNG）用最近鄰整數倍放大到寬約 400px，交給 items.setCover 當格式封面
 *    （使用者選的封面優先）。載入時補舊作品、items-added 做新作品，一次一件；做過的記在 storage（同 audio 的波形封面）。
 *  - 只讀檔案：不寫入原檔；只改作品的格式封面（篩選值之後再做）。「複製目前畫格」放進剪貼簿，不寫檔。
 */

const EXTENSIONS = new Set(["aseprite", "ase"]);
/** 超過這個大小不解析。 */
const MAX_BYTES = 64 * 1024 * 1024;

// ---- 設定 ----

/** @typedef {{ checker: boolean; autoplay: boolean }} Settings */
/** @type {Settings} */
const settings = { checker: true, autoplay: true };
const settingsLoaded = hoard.storage.get("settings").then((saved) => {
  if (saved && typeof saved === "object") Object.assign(settings, saved);
});
/** @param {Partial<Settings>} changes */
function updateSettings(changes) {
  Object.assign(settings, changes);
  void hoard.storage.set("settings", settings);
}

// ---- 哪些作品是 Aseprite 檔 ----

/** @param {string} path */
function extOf(path) {
  const name = path.split(/[\\/]/).pop() ?? "";
  const dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : "";
}

/** 摘要看得出的：本機的單一檔案，副檔名是 .aseprite 或 .ase。 @param {HoardItemSummary} item */
function isSpriteItem(item) {
  const format = item.ext;
  return item.source_type === "local" && item.metadata.format == null && typeof format === "string" && EXTENSIONS.has(format.toLowerCase());
}

/** @param {HoardItemDetail} item */
function spriteFileOf(item) {
  return item.files.find((f) => f.kind === "file" && EXTENSIONS.has(extOf(f.path))) ?? null;
}

/**
 * 摘要裡沒有「其他檔案」的路徑，要讀整件作品；最近讀過的留著（最多 300 件），作品改了就丟掉。
 * @type {Map<number, Promise<HoardItemDetail>>}
 */
const details = new Map();
/** @param {number} id */
function detailOf(id) {
  let pending = details.get(id);
  if (pending) {
    details.delete(id); // 移到最新
  } else {
    pending = hoard.items.get(id);
    pending.catch(() => details.delete(id));
  }
  details.set(id, pending);
  if (details.size > 300) details.delete(/** @type {number} */ (details.keys().next().value));
  return pending;
}
hoard.on("items-changed", ({ ids }) => ids.forEach((id) => details.delete(id)));

// ---- 解析 ----

/**
 * @typedef {{
 *   name: string; flags: number; type: number; level: number; blend: number; opacity: number;
 *   tileset: number; parent: number; visible: boolean; reference: boolean; background: boolean;
 * }} Layer
 * @typedef {{ layer: number; x: number; y: number; opacity: number; z: number; w: number; h: number;
 *   pixels: Uint8ClampedArray | null; link: number }} Cel
 * @typedef {{ duration: number; cels: Cel[] }} Frame
 * @typedef {{ name: string; from: number; to: number; direction: number; repeat: number }} Tag
 * @typedef {{ tileW: number; tileH: number; count: number; pixels: Uint8ClampedArray | null }} Tileset
 * @typedef {{
 *   width: number; height: number; depth: number; flags: number; transparentIndex: number;
 *   palette: Uint8ClampedArray; paletteSize: number;
 *   layers: Layer[]; frames: Frame[]; tags: Tag[]; tilesets: Map<number, Tileset>;
 *   unsupported: Set<string>;
 * }} Sprite
 */

/** 不是 Aseprite 檔（例如 Adobe 色票）。 */
class NotSprite extends Error {}

const BLEND_NAMES = [
  "Normal", "Multiply", "Screen", "Overlay", "Darken", "Lighten", "Color Dodge", "Color Burn", "Hard Light",
  "Soft Light", "Difference", "Exclusion", "Hue", "Saturation", "Color", "Luminosity", "Addition", "Subtract", "Divide",
];

/** @param {Uint8Array} bytes */
async function inflate(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/**
 * 依檔案的色彩模式把像素轉成 RGBA。索引色的透明色只對非背景圖層透明。
 * @param {Uint8Array} raw @param {number} count @param {Sprite} s @param {boolean} background
 */
function toRgba(raw, count, s, background) {
  const out = new Uint8ClampedArray(count * 4);
  if (s.depth === 32) {
    out.set(raw.subarray(0, count * 4));
  } else if (s.depth === 16) {
    for (let i = 0; i < count; i++) {
      const v = raw[i * 2];
      out[i * 4] = out[i * 4 + 1] = out[i * 4 + 2] = v;
      out[i * 4 + 3] = raw[i * 2 + 1];
    }
  } else {
    for (let i = 0; i < count; i++) {
      const index = raw[i];
      if (index === s.transparentIndex && !background) continue;
      out[i * 4] = s.palette[index * 4];
      out[i * 4 + 1] = s.palette[index * 4 + 1];
      out[i * 4 + 2] = s.palette[index * 4 + 2];
      out[i * 4 + 3] = s.palette[index * 4 + 3];
    }
  }
  return out;
}

/**
 * 解析整個檔案。cel 的像素都先解成 RGBA（tilemap 先展開成一般的圖）。
 * @param {ArrayBuffer} buffer @returns {Promise<Sprite>}
 */
async function parseSprite(buffer) {
  const b = new Uint8Array(buffer);
  const view = new DataView(buffer);
  if (b.length < 128 || view.getUint16(4, true) !== 0xa5e0) throw new NotSprite("不是 Aseprite 檔");
  const frameCount = view.getUint16(6, true);
  /** @type {Sprite} */
  const s = {
    width: view.getUint16(8, true),
    height: view.getUint16(10, true),
    depth: view.getUint16(12, true),
    flags: view.getUint32(14, true),
    transparentIndex: b[28],
    palette: new Uint8ClampedArray(256 * 4),
    paletteSize: view.getUint16(32, true) || 256,
    layers: [],
    frames: [],
    tags: [],
    tilesets: new Map(),
    unsupported: new Set(),
  };
  // 調色盤預設全黑不透明（舊檔可能沒有新式的調色盤區塊）。
  for (let i = 0; i < 256; i++) s.palette[i * 4 + 3] = 255;
  /** @param {number} at */
  const string = (at) => {
    const len = view.getUint16(at, true);
    return { value: new TextDecoder().decode(b.subarray(at + 2, at + 2 + len)), end: at + 2 + len };
  };
  /** 壓縮的 cel 與 tileset 稍後一起解（解壓縮是非同步的）。 @type {Array<Promise<void>>} */
  const pending = [];
  /** tilemap cel 要等 tileset 都讀好才能展開。 @type {Array<() => void>} */
  const tilemaps = [];
  let sawNewPalette = false;

  let at = 128;
  for (let f = 0; f < frameCount && at + 16 <= b.length; f++) {
    const frameBytes = view.getUint32(at, true);
    const oldChunks = view.getUint16(at + 6, true);
    const duration = view.getUint16(at + 8, true);
    const newChunks = view.getUint32(at + 12, true);
    const chunks = newChunks === 0 ? oldChunks : newChunks;
    /** @type {Frame} */
    const frame = { duration: duration || 100, cels: [] };
    s.frames.push(frame);
    let c = at + 16;
    for (let i = 0; i < chunks && c + 6 <= at + frameBytes; i++) {
      const size = view.getUint32(c, true);
      const type = view.getUint16(c + 4, true);
      const d = c + 6;
      if (type === 0x2004) {
        const layerFlags = view.getUint16(d, true);
        const layerType = view.getUint16(d + 2, true);
        const name = string(d + 16);
        s.layers.push({
          name: name.value,
          flags: layerFlags,
          type: layerType,
          level: view.getUint16(d + 4, true),
          blend: view.getUint16(d + 10, true),
          opacity: b[d + 12],
          tileset: layerType === 2 ? view.getUint32(name.end, true) : -1,
          parent: -1,
          visible: (layerFlags & 1) !== 0,
          reference: (layerFlags & 64) !== 0,
          background: (layerFlags & 8) !== 0,
        });
      } else if (type === 0x2005) {
        /** @type {Cel} */
        const cel = {
          layer: view.getUint16(d, true),
          x: view.getInt16(d + 2, true),
          y: view.getInt16(d + 4, true),
          opacity: b[d + 6],
          z: view.getInt16(d + 9, true),
          w: 0,
          h: 0,
          pixels: null,
          link: -1,
        };
        const celType = view.getUint16(d + 7, true);
        const body = d + 16;
        frame.cels.push(cel);
        const background = () => s.layers[cel.layer]?.background ?? false;
        if (celType === 1) {
          cel.link = view.getUint16(body, true);
        } else if (celType === 0 || celType === 2) {
          cel.w = view.getUint16(body, true);
          cel.h = view.getUint16(body + 2, true);
          const data = b.subarray(body + 4, c + size);
          if (celType === 0) {
            cel.pixels = toRgba(data, cel.w * cel.h, s, background());
          } else {
            pending.push(inflate(data).then((raw) => void (cel.pixels = toRgba(raw, cel.w * cel.h, s, background()))));
          }
        } else if (celType === 3) {
          const tilesW = view.getUint16(body, true);
          const tilesH = view.getUint16(body + 2, true);
          const bits = view.getUint16(body + 4, true);
          const idMask = view.getUint32(body + 6, true);
          const xFlip = view.getUint32(body + 10, true);
          const yFlip = view.getUint32(body + 14, true);
          const dFlip = view.getUint32(body + 18, true);
          const data = b.subarray(body + 32, c + size);
          pending.push(
            inflate(data).then((raw) => {
              tilemaps.push(() => expandTilemap(s, cel, raw, tilesW, tilesH, bits, { idMask, xFlip, yFlip, dFlip }));
            }),
          );
        }
      } else if (type === 0x2018) {
        const count = view.getUint16(d, true);
        let t = d + 10;
        for (let k = 0; k < count && t + 17 <= c + size; k++) {
          const name = string(t + 17);
          s.tags.push({
            from: view.getUint16(t, true),
            to: view.getUint16(t + 2, true),
            direction: b[t + 4],
            repeat: view.getUint16(t + 5, true),
            name: name.value,
          });
          t = name.end;
        }
      } else if (type === 0x2019) {
        sawNewPalette = true;
        s.paletteSize = view.getUint32(d, true);
        const first = view.getUint32(d + 4, true);
        const last = view.getUint32(d + 8, true);
        let e = d + 20;
        for (let index = first; index <= last && index < 256; index++) {
          const entryFlags = view.getUint16(e, true);
          s.palette.set(b.subarray(e + 2, e + 6), index * 4);
          e += 6;
          if (entryFlags & 1) e = string(e).end;
        }
      } else if ((type === 0x0004 || type === 0x0011) && !sawNewPalette) {
        // 舊式調色盤：只有在沒有新式的時候才用。0x0011 是 0–63 的色階。
        const packets = view.getUint16(d, true);
        let e = d + 2;
        let index = 0;
        const scale = type === 0x0011 ? 255 / 63 : 1;
        for (let p = 0; p < packets; p++) {
          index += b[e];
          const n = b[e + 1] || 256;
          e += 2;
          for (let k = 0; k < n && index < 256; k++, index++, e += 3) {
            s.palette[index * 4] = Math.round(b[e] * scale);
            s.palette[index * 4 + 1] = Math.round(b[e + 1] * scale);
            s.palette[index * 4 + 2] = Math.round(b[e + 2] * scale);
            s.palette[index * 4 + 3] = 255;
          }
        }
      } else if (type === 0x2023) {
        const id = view.getUint32(d, true);
        const tilesetFlags = view.getUint32(d + 4, true);
        /** @type {Tileset} */
        const tileset = {
          count: view.getUint32(d + 8, true),
          tileW: view.getUint16(d + 12, true),
          tileH: view.getUint16(d + 14, true),
          pixels: null,
        };
        s.tilesets.set(id, tileset);
        let e = string(d + 32).end;
        if (tilesetFlags & 1) e += 8;
        if (tilesetFlags & 2) {
          const length = view.getUint32(e, true);
          const data = b.subarray(e + 4, e + 4 + length);
          pending.push(
            inflate(data).then((raw) => {
              tileset.pixels = toRgba(raw, tileset.tileW * tileset.tileH * tileset.count, s, false);
            }),
          );
        }
      }
      c += size;
    }
    at += frameBytes;
  }
  await Promise.all(pending);
  tilemaps.forEach((expand) => expand());

  // 群組關係：child level 比上一層多一，就是它最近的上一個群組底下。
  /** @type {number[]} */
  const stack = [];
  s.layers.forEach((layer, index) => {
    stack.length = layer.level;
    layer.parent = layer.level > 0 ? (stack[layer.level - 1] ?? -1) : -1;
    stack[layer.level] = index;
    if (layer.type !== 1 && layer.blend > 0 && !blendFunction(layer.blend)) s.unsupported.add(BLEND_NAMES[layer.blend] ?? `#${layer.blend}`);
  });
  return s;
}

/**
 * tilemap cel → 一般的圖：每格查 tileset 的那一塊，照旗標翻轉。tile 0 是空的。
 * @param {Sprite} s @param {Cel} cel @param {Uint8Array} raw @param {number} tilesW @param {number} tilesH @param {number} bits
 * @param {{ idMask: number; xFlip: number; yFlip: number; dFlip: number }} masks
 */
function expandTilemap(s, cel, raw, tilesW, tilesH, bits, masks) {
  const layer = s.layers[cel.layer];
  const tileset = layer ? s.tilesets.get(layer.tileset) : undefined;
  if (!tileset || !tileset.pixels) return;
  const { tileW, tileH } = tileset;
  cel.w = tilesW * tileW;
  cel.h = tilesH * tileH;
  const out = new Uint8ClampedArray(cel.w * cel.h * 4);
  const bytes = bits / 8;
  const view = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
  for (let ty = 0; ty < tilesH; ty++) {
    for (let tx = 0; tx < tilesW; tx++) {
      const at = (ty * tilesW + tx) * bytes;
      if (at + bytes > raw.length) continue;
      const value = bytes === 4 ? view.getUint32(at, true) : bytes === 2 ? view.getUint16(at, true) : raw[at];
      const id = (value & masks.idMask) >>> 0;
      if (id === 0 || id >= tileset.count) continue;
      const flipX = (value & masks.xFlip) !== 0;
      const flipY = (value & masks.yFlip) !== 0;
      const diagonal = (value & masks.dFlip) !== 0;
      for (let y = 0; y < tileH; y++) {
        for (let x = 0; x < tileW; x++) {
          let sx = x;
          let sy = y;
          if (diagonal) [sx, sy] = [sy, sx];
          if (flipX) sx = tileW - 1 - sx;
          if (flipY) sy = tileH - 1 - sy;
          const from = ((id * tileH + sy) * tileW + sx) * 4;
          const to = ((ty * tileH + y) * cel.w + tx * tileW + x) * 4;
          out[to] = tileset.pixels[from];
          out[to + 1] = tileset.pixels[from + 1];
          out[to + 2] = tileset.pixels[from + 2];
          out[to + 3] = tileset.pixels[from + 3];
        }
      }
    }
  }
  cel.pixels = out;
}

class TooLarge extends Error {}

/** 讀檔與解析。 @param {string} path @param {number} size */
async function loadSprite(path, size) {
  if (size > MAX_BYTES) throw new TooLarge("檔案太大，不顯示");
  const res = await fetch(hoard.fileSrc(path));
  if (!res.ok) throw new Error(`讀不到檔案（${res.status}）`);
  return parseSprite(await res.arrayBuffer());
}

/** 同一個檔案只讀一次（最多留 40 個）。 @type {Map<string, Promise<Sprite>>} */
const sprites = new Map();
/** @param {string} path @param {number} size */
function spriteOf(path, size) {
  let pending = sprites.get(path);
  if (pending) {
    sprites.delete(path);
  } else {
    pending = loadSprite(path, size);
    pending.catch(() => sprites.delete(path));
  }
  sprites.set(path, pending);
  if (sprites.size > 40) sprites.delete(/** @type {string} */ (sprites.keys().next().value));
  return pending;
}

// ---- 合成 ----

/** Aseprite 的 8 位元乘法（四捨五入）。 @param {number} a @param {number} b */
function mul(a, b) {
  const t = a * b + 0x80;
  return ((t >> 8) + t) >> 8;
}
/** @param {number} a @param {number} b */
function div(a, b) {
  return b === 0 ? 0 : Math.min(255, Math.trunc((a * 255 + b / 2) / b));
}

/** 分色混合（backdrop、source 都是 0–255）。 @type {Array<((b: number, s: number) => number) | null>} */
const BLENDS = [
  null, // Normal
  (b, s) => mul(b, s), // Multiply
  (b, s) => b + s - mul(b, s), // Screen
  (b, s) => hardLight(s, b), // Overlay
  (b, s) => Math.min(b, s), // Darken
  (b, s) => Math.max(b, s), // Lighten
  (b, s) => (b === 0 ? 0 : b >= 255 - s ? 255 : div(b, 255 - s)), // Color Dodge
  (b, s) => (b === 255 ? 255 : 255 - b >= s ? 0 : 255 - div(255 - b, s)), // Color Burn
  (b, s) => hardLight(b, s), // Hard Light
  softLight, // Soft Light
  (b, s) => Math.abs(b - s), // Difference
  (b, s) => b + s - 2 * mul(b, s), // Exclusion
  null, // Hue
  null, // Saturation
  null, // Color
  null, // Luminosity
  (b, s) => Math.min(255, b + s), // Addition
  (b, s) => Math.max(0, b - s), // Subtract
  (b, s) => (b === 0 ? 0 : b >= s ? 255 : div(b, s)), // Divide
];
/** @param {number} b @param {number} s */
function hardLight(b, s) {
  return s < 128 ? mul(b, s << 1) : (() => {
    const t = (s << 1) - 255;
    return b + t - mul(b, t);
  })();
}
/** @param {number} b @param {number} s */
function softLight(b, s) {
  const cb = b / 255;
  const cs = s / 255;
  const d = cb <= 0.25 ? ((16 * cb - 12) * cb + 4) * cb : Math.sqrt(cb);
  const r = cs <= 0.5 ? cb - (1 - 2 * cs) * cb * (1 - cb) : cb + (2 * cs - 1) * (d - cb);
  return Math.round(r * 255);
}
/** 有實作的混合模式；沒有的當 Normal。 @param {number} mode */
function blendFunction(mode) {
  return BLENDS[mode] ?? null;
}

/**
 * Aseprite 的 normal：把 s（不透明度已乘進 a）疊到 b 上。整數運算與截斷照它的原始碼，結果才會一模一樣。
 * @param {number[]} b @param {number[]} s @returns {number[]}
 */
function over(b, s) {
  if (b[3] === 0) return [s[0], s[1], s[2], s[3]];
  if (s[3] === 0) return b;
  const ra = s[3] + b[3] - mul(b[3], s[3]);
  return [
    b[0] + Math.trunc(((s[0] - b[0]) * s[3]) / ra),
    b[1] + Math.trunc(((s[1] - b[1]) * s[3]) / ra),
    b[2] + Math.trunc(((s[2] - b[2]) * s[3]) / ra),
    ra,
  ];
}

/** Aseprite 的 merge：從 b 往 s 走 amount／255 那麼多（含不透明度）。 @param {number[]} b @param {number[]} s @param {number} amount */
function merge(b, s, amount) {
  let r = b[0];
  let g = b[1];
  let bl = b[2];
  if (b[3] === 0) [r, g, bl] = s;
  else if (s[3] !== 0) {
    r = b[0] + mul(s[0] - b[0], amount);
    g = b[1] + mul(s[1] - b[1], amount);
    bl = b[2] + mul(s[2] - b[2], amount);
  }
  const a = b[3] + mul(s[3] - b[3], amount);
  return a === 0 ? [0, 0, 0, 0] : [r, g, bl, a];
}

/**
 * 一個像素畫上去。混合模式照 Aseprite 的「新式混合」：底是透明時就是 normal；否則分別算 normal 疊法與
 * 混合後的疊法，先依底的不透明度合併，再依兩者共同的不透明度往混合的結果合併。
 * @param {Uint8ClampedArray} dst @param {number} i @param {number} sr @param {number} sg @param {number} sb @param {number} sa
 * @param {((b: number, s: number) => number) | null} blend
 */
function composite(dst, i, sr, sg, sb, sa, blend) {
  if (sa === 0) return;
  const back = [dst[i], dst[i + 1], dst[i + 2], dst[i + 3]];
  let out;
  if (!blend || back[3] === 0) {
    out = over(back, [sr, sg, sb, sa]);
  } else {
    const normal = over(back, [sr, sg, sb, sa]);
    const mixed = over(back, [blend(back[0], sr), blend(back[1], sg), blend(back[2], sb), sa]);
    out = merge(merge(normal, mixed, back[3]), mixed, mul(back[3], sa));
  }
  dst[i] = out[0];
  dst[i + 1] = out[1];
  dst[i + 2] = out[2];
  dst[i + 3] = out[3];
}

/** 圖層連同上層群組都看得見，而且不是參考圖層。 @param {Sprite} s @param {number} index @param {Set<number>} hidden */
function layerShown(s, index, hidden) {
  for (let i = index; i >= 0; i = s.layers[i].parent) {
    const layer = s.layers[i];
    if (!layer || !layer.visible || layer.reference || hidden.has(i)) return false;
  }
  return true;
}

/** 圖層的不透明度，連同上層群組的（檔頭旗標說它們有效時）。 @param {Sprite} s @param {number} index */
function layerOpacity(s, index) {
  if (!(s.flags & 1)) return 255;
  let opacity = s.layers[index].opacity;
  if (s.flags & 2) {
    for (let p = s.layers[index].parent; p >= 0; p = s.layers[p].parent) opacity = mul(opacity, s.layers[p].opacity);
  }
  return opacity;
}

/**
 * 合成一格。`hidden` 是使用者在預覽裡關掉的圖層。
 * @param {Sprite} s @param {number} f @param {Set<number>} hidden @returns {ImageData}
 */
function renderFrame(s, f, hidden) {
  const image = new ImageData(s.width, s.height);
  const dst = image.data;
  const frame = s.frames[f];
  if (!frame) return image;
  const cels = frame.cels
    .map((cel) => (cel.link >= 0 ? (s.frames[cel.link]?.cels.find((c) => c.layer === cel.layer && c.link < 0) ?? null) : cel))
    .filter((cel) => cel !== null && cel.pixels !== null && s.layers[cel.layer]?.type !== 1);
  // 畫的順序：圖層順序加上 cel 的 z-index，一樣時 z-index 小的先。
  cels.sort((a, b) => a.layer + a.z - (b.layer + b.z) || a.z - b.z);
  for (const cel of /** @type {Cel[]} */ (cels)) {
    if (!layerShown(s, cel.layer, hidden)) continue;
    const layer = s.layers[cel.layer];
    const opacity = mul(cel.opacity, layerOpacity(s, cel.layer));
    if (opacity === 0) continue;
    const blend = blendFunction(layer.blend);
    const src = /** @type {Uint8ClampedArray} */ (cel.pixels);
    for (let y = 0; y < cel.h; y++) {
      const dy = cel.y + y;
      if (dy < 0 || dy >= s.height) continue;
      for (let x = 0; x < cel.w; x++) {
        const dx = cel.x + x;
        if (dx < 0 || dx >= s.width) continue;
        const from = (y * cel.w + x) * 4;
        const alpha = mul(src[from + 3], opacity);
        composite(dst, (dy * s.width + dx) * 4, src[from], src[from + 1], src[from + 2], alpha, blend);
      }
    }
  }
  return image;
}

/** 一個 tag 播一輪的畫格順序。 @param {Sprite} s @param {Tag | null} tag */
function sequence(s, tag) {
  const all = s.frames.map((_, i) => i);
  if (!tag) return all;
  const from = Math.max(0, Math.min(tag.from, s.frames.length - 1));
  const to = Math.max(from, Math.min(tag.to, s.frames.length - 1));
  const forward = all.slice(from, to + 1);
  const backward = [...forward].reverse();
  switch (tag.direction) {
    case 1:
      return backward;
    case 2:
      return forward.length > 2 ? [...forward, ...backward.slice(1, -1)] : forward;
    case 3:
      return backward.length > 2 ? [...backward, ...forward.slice(1, -1)] : backward;
    default:
      return forward;
  }
}

/** @param {Sprite} s */
const totalDuration = (s) => s.frames.reduce((n, f) => n + f.duration, 0);
const COLOR_MODES = { 32: "RGBA", 16: "灰階", 8: "索引色" };

// ---- 預覽 ----

/**
 * 預覽：畫格放大顯示（canvas 是原尺寸，用 CSS 整數倍放大、不模糊），照每格的時間播放。
 * @param {Sprite} s
 * @param {{ compact: boolean; autoplay: boolean; onFrame?: (frame: number) => void }} opts
 */
function createViewer(s, opts) {
  const canvas = /** @type {HTMLCanvasElement} */ (hoard.el("canvas", { class: "ap-canvas" }));
  canvas.width = s.width;
  canvas.height = s.height;
  const g = /** @type {CanvasRenderingContext2D} */ (canvas.getContext("2d"));
  const stage = hoard.el("div", { class: "ap-stage" }, [canvas]);
  /** 使用者關掉的圖層。 @type {Set<number>} */
  const hidden = new Set();
  /** @type {Map<number, ImageData>} */
  const cache = new Map();
  /** @type {Tag | null} */
  let tag = null;
  let order = sequence(s, null);
  let position = 0;
  let playing = false;
  let cycles = 0;
  /** @type {number | undefined} */
  let timer;
  /** 0 表示自動放大到放得下的最大整數倍。 */
  let zoom = 0;

  const frameLabel = hoard.el("span", { class: "ap-frame" });
  const playButton = hoard.el("button", { class: "ap-button ap-play", title: "播放／暫停（P）" });
  const prev = hoard.el("button", { class: "ap-button", title: "上一格（,）" }, [hoard.icon("step-back", { size: 14 })]);
  const next = hoard.el("button", { class: "ap-button", title: "下一格（.）" }, [hoard.icon("step-forward", { size: 14 })]);
  const tagSelect = /** @type {HTMLSelectElement} */ (hoard.el("select", { class: "ap-select", title: "要播的 tag" }));
  tagSelect.append(hoard.el("option", { value: "-1" }, ["全部畫格"]));
  s.tags.forEach((t, i) => tagSelect.append(hoard.el("option", { value: String(i) }, [`${t.name}（${t.from + 1}–${t.to + 1}）`])));
  const checker = hoard.el("button", { class: "ap-button", title: "棋盤格背景" }, [hoard.icon("grid-2x2", { size: 14 })]);
  const zoomOut = hoard.el("button", { class: "ap-button", title: "縮小" }, [hoard.icon("zoom-out", { size: 14 })]);
  const zoomIn = hoard.el("button", { class: "ap-button", title: "放大" }, [hoard.icon("zoom-in", { size: 14 })]);
  const zoomLabel = hoard.el("span", { class: "ap-zoom" });
  const copy = hoard.el("button", { class: "ap-button", title: "複製目前畫格為 PNG" }, [hoard.icon("copy", { size: 14 })]);

  const current = () => order[Math.min(position, order.length - 1)] ?? 0;
  const draw = () => {
    const f = current();
    let image = cache.get(f);
    if (!image) {
      image = renderFrame(s, f, hidden);
      cache.set(f, image);
    }
    g.putImageData(image, 0, 0);
    frameLabel.textContent = `${f + 1} / ${s.frames.length}`;
    opts.onFrame?.(f);
  };
  const fitScale = () => {
    const box = stage.getBoundingClientRect();
    if (box.width === 0 || box.height === 0) return 1;
    const fit = Math.min((box.width - 16) / s.width, (box.height - 16) / s.height);
    // 放得下時用整數倍；比畫面大的圖才縮小（縮小時就不是整數倍了）。
    return fit >= 1 ? Math.floor(fit) : fit;
  };
  const layout = () => {
    const scale = zoom || fitScale();
    canvas.style.width = `${Math.max(1, Math.round(s.width * scale))}px`;
    canvas.style.height = `${Math.max(1, Math.round(s.height * scale))}px`;
    zoomLabel.textContent = scale >= 1 ? `${Math.round(scale)}×` : `${Math.round(scale * 100)}%`;
  };
  const showState = () => {
    playButton.replaceChildren(hoard.icon(playing ? "pause" : "play", { size: 14 }));
    stage.classList.toggle("ap-checker", settings.checker);
    checker.classList.toggle("ap-on", settings.checker);
  };

  const schedule = () => {
    clearTimeout(timer);
    if (!playing || order.length < 2) return;
    timer = window.setTimeout(() => {
      position++;
      if (position >= order.length) {
        cycles++;
        // tag 的重複次數用完就停在最後一格；沒有 tag 或 0 次表示一直重複。
        if (tag && tag.repeat > 0 && cycles >= tag.repeat) {
          position = order.length - 1;
          playing = false;
          showState();
          return;
        }
        position = 0;
      }
      draw();
      schedule();
    }, s.frames[current()]?.duration ?? 100);
  };
  const play = () => {
    if (order.length < 2) return;
    if (!playing && tag && tag.repeat > 0 && cycles >= tag.repeat) {
      cycles = 0;
      position = 0;
    }
    playing = true;
    showState();
    schedule();
  };
  const pause = () => {
    playing = false;
    clearTimeout(timer);
    showState();
  };
  const toggle = () => (playing ? pause() : play());
  /** @param {number} delta */
  const step = (delta) => {
    pause();
    position = (position + delta + order.length) % order.length;
    draw();
  };
  /** @param {number} index -1：全部畫格 */
  const setTag = (index) => {
    tag = index >= 0 ? (s.tags[index] ?? null) : null;
    tagSelect.value = String(tag ? index : -1);
    order = sequence(s, tag);
    position = 0;
    cycles = 0;
    draw();
    play();
  };

  playButton.addEventListener("click", toggle);
  prev.addEventListener("click", () => step(-1));
  next.addEventListener("click", () => step(1));
  tagSelect.addEventListener("change", () => setTag(Number(tagSelect.value)));
  checker.addEventListener("click", () => {
    updateSettings({ checker: !settings.checker });
    showState();
  });
  zoomIn.addEventListener("click", () => {
    const scale = zoom || fitScale();
    zoom = scale >= 1 ? Math.min(64, Math.floor(scale) + 1) : Math.min(1, scale * 2);
    layout();
  });
  zoomOut.addEventListener("click", () => {
    const scale = zoom || fitScale();
    zoom = scale > 1 ? Math.floor(scale) - 1 : Math.max(1 / 16, scale / 2);
    layout();
  });
  copy.addEventListener("click", () => {
    canvas.toBlob((blob) => {
      if (!blob) return;
      navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]).then(
        () => hoard.toast("已複製目前畫格"),
        () => hoard.toast("複製失敗", { kind: "error" }),
      );
    }, "image/png");
  });
  const resize = new ResizeObserver(() => zoom || layout());
  resize.observe(stage);

  const multi = s.frames.length > 1;
  /** @type {Array<Node | null>} */
  const controls = multi ? [playButton, prev, frameLabel, next] : [frameLabel];
  if (multi && s.tags.length > 0) controls.push(tagSelect);
  controls.push(hoard.el("span", { class: "ap-spacer" }), checker, zoomOut, zoomLabel, zoomIn);
  if (!opts.compact) controls.push(copy);
  const el = hoard.el("div", { class: opts.compact ? "ap-viewer ap-compact" : "ap-viewer" }, [
    stage,
    hoard.el("div", { class: "ap-controls" }, controls),
  ]);

  showState();
  draw();
  requestAnimationFrame(layout);
  if (opts.autoplay) play();

  return {
    el,
    toggle,
    step,
    setTag,
    /** @param {number} index @param {boolean} shown */
    setLayerShown(index, shown) {
      if (shown) hidden.delete(index);
      else hidden.add(index);
      cache.clear();
      draw();
    },
    /** 現在畫的那一格的像素（測試與複製用）。 */
    canvas,
    destroy() {
      clearTimeout(timer);
      resize.disconnect();
    },
  };
}

/** @param {Sprite} s */
function summaryLine(s) {
  const parts = [`${s.width} × ${s.height}`, /** @type {Record<number, string>} */ (COLOR_MODES)[s.depth] ?? `${s.depth}-bit`];
  if (s.frames.length > 1) parts.push(`${s.frames.length} 格 · ${(totalDuration(s) / 1000).toFixed(2)} 秒`);
  if (s.tags.length > 0) parts.push(`${s.tags.length} 個 tag`);
  return parts.join(" · ");
}

// ---- 快速預覽 ----

/** @param {HTMLElement} root @param {HoardItemSummary} item @param {HoardQuickLookCtx} ctx */
function renderQuickLook(root, item, ctx) {
  let alive = true;
  /** @type {ReturnType<typeof createViewer> | null} */
  let viewer = null;
  const name = typeof item.metadata.original_name === "string" ? item.metadata.original_name : item.title;
  const line = hoard.el("p", { class: "ap-ql-line" }, ["讀取中…"]);
  const stage = hoard.el("div", { class: "ap-ql-stage" });
  const box = hoard.el(
    "div",
    {
      class: "ap-ql",
      onclick: (event) => {
        if (event.target === box) ctx.close();
      },
    },
    [stage, hoard.el("div", { class: "ap-ql-info" }, [hoard.el("p", { class: "ap-ql-name" }, [name]), line])],
  );
  root.append(box);
  ctx.onKey((event) => {
    if (event.ctrlKey || event.altKey || event.metaKey || !viewer) return false;
    const key = event.key.toLowerCase();
    if (key === "p") viewer.toggle();
    else if (key === ",") viewer.step(-1);
    else if (key === ".") viewer.step(1);
    else return false;
    return true;
  });

  void (async () => {
    await settingsLoaded;
    const detail = await detailOf(item.id);
    const file = spriteFileOf(detail);
    if (!alive || !file) return;
    const size = file.size ?? 0;
    try {
      const sprite = await spriteOf(file.path, size);
      if (!alive) return;
      viewer = createViewer(sprite, { compact: true, autoplay: settings.autoplay });
      stage.replaceChildren(viewer.el);
      line.textContent = `${summaryLine(sprite)} · P 播放／暫停 · , . 逐格`;
    } catch (err) {
      if (!alive) return;
      line.textContent = err instanceof NotSprite ? "不是 Aseprite 檔（.ase 也可能是 Adobe 色票）" : `無法顯示：${err instanceof Error ? err.message : err}`;
    }
  })();

  return () => {
    alive = false;
    viewer?.destroy();
  };
}


// ---- 詳情頁 ----

/** @param {number} bytes */
function formatSize(bytes) {
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit++;
  }
  return `${unit === 0 ? value : value.toFixed(1)} ${units[unit]}`;
}

/** @param {Array<[string, string | Node]>} rows */
function table(rows) {
  return hoard.el(
    "dl",
    { class: "ap-table" },
    rows.flatMap(([label, value]) => [hoard.el("dt", {}, [label]), hoard.el("dd", {}, [value])]),
  );
}

/** @param {string} title @param {Array<Node | null>} children */
function section(title, children) {
  return hoard.el("section", { class: "ap-section" }, [hoard.el("h3", { class: "ap-heading" }, [title]), ...children]);
}

const DIRECTIONS = ["正向", "反向", "來回", "反向來回"];

// 動畫（App 的 docs/conventions.md〈動畫〉：插件拿不到 App 的動畫程式，照同一組時長、曲線自己做）

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場、變大。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/**
 * 晚到的區塊換成內容：box 裡原本的骨架或「讀取中…」（CSS 讓它等 200ms 才淡入，很快就到的看不到它）淡出、內容淡入
 * （骨架出現過時 160ms 交叉，沒出現過時內容直接淡入 120ms），高度從骨架補間到內容的實際高度 200ms，下面的東西跟著滑，不是跳。
 * @param {HTMLElement} box @param {Node[]} content @param {number} since 開始等的時間（performance.now()）
 */
function settleLate(box, content, since) {
  if (!motionOn()) return void box.replaceChildren(...content);
  const seen = performance.now() - since >= 200;
  const skeleton = /** @type {HTMLElement[]} */ ([...box.children]);
  const from = box.getBoundingClientRect().height;
  for (const a of box.getAnimations()) a.cancel();
  // 骨架停在現在的樣子（搬進疊層時 CSS 動畫會重來），再疊到內容上面淡出。
  for (const el of skeleton) {
    el.style.opacity = getComputedStyle(el).opacity;
    el.style.animation = "none";
  }
  box.replaceChildren(...content);
  const to = box.getBoundingClientRect().height;
  if (Math.abs(to - from) > 0.5) {
    box.style.overflow = "clip";
    void box.animate([{ height: `${from}px` }, { height: `${to}px` }], { duration: 200, easing: EASE_OUT }).finished.then(
      () => (box.style.overflow = ""),
      () => {},
    );
  }
  for (const el of box.children) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: seen ? 160 : 120, easing: EASE_OUT, fill: "backwards" });
  if (!seen || skeleton.length === 0) return;
  const ghost = hoard.el("div", { class: "ap-late-ghost", "aria-hidden": "true" }, skeleton);
  box.prepend(ghost);
  void ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 160, easing: EASE_IN, fill: "forwards" }).finished.then(
    () => ghost.remove(),
    () => ghost.remove(),
  );
}

/** @param {HTMLElement} root @param {HoardItemDetail} item */
function renderDetail(root, item) {
  let alive = true;
  /** @type {ReturnType<typeof createViewer> | null} */
  let viewer = null;
  const file = spriteFileOf(item);
  if (!file) return;
  const meta = item.metadata;
  const size = file.size ?? 0;
  const since = performance.now();
  const stage = hoard.el("div", { class: "ap-detail-stage" }, [hoard.el("p", { class: "ap-note ap-wait" }, ["讀取中…"])]);
  // 右邊的資訊要解完檔案才知道：先放表格形狀的骨架佔位置。
  const side = hoard.el("div", { class: "ap-side" }, [
    hoard.el("div", { class: "ap-skeleton ap-info-bones", role: "status", "aria-label": "讀取中" }, [
      hoard.el("span", { class: "ap-info-bones-title" }),
      hoard.el("div", { class: "ap-info-bones-table" }, Array.from({ length: 6 }, () => hoard.el("span"))),
    ]),
  ]);
  /** @type {Array<[string, string]>} */
  const fileRows = [];
  if (typeof meta.original_name === "string") fileRows.push(["檔名", meta.original_name]);
  if (size) fileRows.push(["大小", formatSize(size)]);
  fileRows.push(["加入時間", hoard.formatDate(item.added_at)]);
  if (file.original_path) fileRows.push(["原始位置", file.original_path]);
  fileRows.push(["存放", file.in_place ? "原地引用（檔案留在連結的資料夾裡）" : "在 vault 裡"]);
  const fileSection = section("檔案", [table(fileRows), hoard.el("p", { class: "ap-note" }, ["右鍵選單可以用預設程式開啟，或在檔案總管顯示。"])]);
  root.append(hoard.el("div", { class: "ap-page" }, [stage, hoard.el("div", { class: "ap-side-column" }, [side, fileSection])]));

  void (async () => {
    await settingsLoaded;
    try {
      const sprite = await spriteOf(file.path, size);
      if (!alive) return;
      viewer = createViewer(sprite, { compact: false, autoplay: true });
      const v = viewer;
      settleLate(stage, [v.el], since);

      /** @type {Array<[string, string]>} */
      const rows = [
        ["尺寸", `${sprite.width} × ${sprite.height}`],
        ["色彩模式", /** @type {Record<number, string>} */ (COLOR_MODES)[sprite.depth] ?? `${sprite.depth}-bit`],
        ["格數", String(sprite.frames.length)],
      ];
      if (sprite.frames.length > 1) rows.push(["總長度", `${(totalDuration(sprite) / 1000).toFixed(2)} 秒`]);
      if (sprite.depth === 8) rows.push(["調色盤", `${sprite.paletteSize} 色`]);
      rows.push(["圖層", String(sprite.layers.filter((l) => l.type !== 1).length)]);
      if (sprite.tilesets.size > 0) rows.push(["Tileset", String(sprite.tilesets.size)]);

      // 圖層清單：由上到下（檔案裡是由下到上），群組縮排；勾掉就不畫。
      const layerList = hoard.el("ul", { class: "ap-layers" });
      for (let i = sprite.layers.length - 1; i >= 0; i--) {
        const layer = sprite.layers[i];
        const box = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox" }));
        box.checked = layer.visible && !layer.reference;
        box.disabled = layer.reference;
        box.addEventListener("change", () => v.setLayerShown(i, box.checked));
        const tags = [];
        if (layer.type === 1) tags.push("群組");
        if (layer.type === 2) tags.push("tilemap");
        if (layer.reference) tags.push("參考");
        if (layer.background) tags.push("背景");
        if (layer.blend > 0) tags.push(BLEND_NAMES[layer.blend] ?? `#${layer.blend}`);
        if (sprite.flags & 1 && layer.opacity < 255 && layer.type !== 1) tags.push(`${Math.round((layer.opacity / 255) * 100)}%`);
        layerList.append(
          hoard.el("li", { class: "ap-layer", style: `padding-left: ${layer.level * 0.875}rem` }, [
            hoard.el("label", { class: "ap-layer-label" }, [
              box,
              hoard.el("span", { class: "ap-layer-name" }, [layer.name || "（未命名）"]),
              tags.length > 0 ? hoard.el("span", { class: "ap-layer-tags" }, [tags.join(" · ")]) : null,
            ]),
          ]),
        );
      }

      /** @type {Array<Node | null>} */
      const body = [section("像素圖", [table(rows)])];
      if (sprite.tags.length > 0) {
        body.push(
          section(
            "Tag",
            [
              hoard.el(
                "ul",
                { class: "ap-tags" },
                sprite.tags.map((t, index) =>
                  hoard.el("li", {}, [
                    hoard.el(
                      "button",
                      { class: "ap-tag", title: "播這一段", onclick: () => v.setTag(index) },
                      [
                        hoard.el("span", { class: "ap-tag-name" }, [t.name]),
                        hoard.el("span", { class: "ap-tag-meta" }, [
                          `${t.from + 1}–${t.to + 1} 格 · ${DIRECTIONS[t.direction] ?? "正向"}${t.repeat > 0 ? ` · ${t.repeat} 次` : ""}`,
                        ]),
                      ],
                    ),
                  ]),
                ),
              ),
            ],
          ),
        );
      }
      body.push(section("圖層", [layerList]));
      if (sprite.unsupported.size > 0) {
        body.push(
          hoard.el("p", { class: "ap-note" }, [
            `${[...sprite.unsupported].join("、")} 混合模式還不支援，先當 Normal 畫，顏色會跟 Aseprite 裡不一樣。`,
          ]),
        );
      }
      settleLate(side, /** @type {Node[]} */ (body.filter((n) => n !== null)), since);
    } catch (err) {
      if (!alive) return;
      settleLate(
        stage,
        [
          hoard.el("p", { class: "ap-note" }, [
            err instanceof NotSprite
              ? "這不是 Aseprite 檔。.ase 也是 Adobe 色票（swatch）的副檔名，這種檔案 App 不顯示內容。"
              : `無法顯示：${err instanceof Error ? err.message : err}`,
          ]),
        ],
        since,
      );
      settleLate(side, [], since);
    }
  })();

  return () => {
    alive = false;
    viewer?.destroy();
  };
}

// 本機單一的 Aseprite 檔：快速預覽直接播動畫，詳情頁有完整的預覽與資訊。
hoard.registerPresenter({
  sources: ["local"],
  accepts: (item) => item.file_count === 1 && isSpriteItem(item),
  detail: renderDetail,
  quickLook: renderQuickLook,
});

// ---- 側欄的「像素圖」頁面 ----

/** 縮圖一次只解析一個，捲很快時不會卡住。 */
let thumbQueue = Promise.resolve();
const VIEW_PAGE = 200;
/** 畫到離最後一排這麼近時讀下一頁。 */
const VIEW_AHEAD = 4;
/** 格子至少多寬、格子之間的間距（rem，同 .ap-grid）。 */
const TILE_MIN_REM = 11.5;
const TILE_GAP_REM = 0.75;
/** 讀了才知道不是 Aseprite 檔的 .ase（Adobe 色票），這次載入裡不再列出。 @type {Set<number>} */
const notSprites = new Set();
/**
 * 換了清單（搜尋）時，舊的格子留著等新的；超過這麼久還沒讀好才換成佔位，上面打的和下面的格子才不會對不上太久
 * （docs/conventions.md〈回饋〉，跟 App 的收藏庫一樣）。
 */
const STALE_MS = 300;

/**
 * 讀好之前的佔位：格子的形狀，一排幾格照寬度自動排。
 * @param {boolean} now 已經等過了（換清單等超過 STALE_MS）就馬上淡入；否則自己等 200ms，很快讀完的什麼都不閃
 */
function spriteSkeleton(now) {
  return hoard.el(
    "div",
    {
      class: now ? "ap-skeleton ap-now" : "ap-skeleton",
      role: "status",
      "aria-label": "讀取中",
      style: `grid-template-columns: repeat(auto-fill, minmax(${TILE_MIN_REM}rem, 1fr)); gap: ${TILE_GAP_REM}rem`,
    },
    Array.from({ length: 10 }, () => hoard.el("div", { class: "ap-bone" }, [hoard.el("div", { class: "ap-bone-art" }), hoard.el("div", { class: "ap-bone-name" })])),
  );
}

/**
 * 像素圖頁的一份清單：照哪個搜尋讀、讀到哪。
 * @typedef {{ filter: HoardItemFilter; narrowed: boolean; items: HoardItemSummary[]; offset: number; done: boolean; loading: boolean; lastRow: number; error: string | null }} SpriteList
 */

/**
 * 一格縮圖：第一格放大到放得下的最大整數倍；滑鼠移上去時播動畫。不是 Aseprite 檔時呼叫 `onGone`。
 * 建好就排進縮圖佇列；輪到時已經捲走（不在頁面上）就略過。
 * @param {HoardItemSummary} item @param {(el: HTMLElement) => void} bind @param {() => void} onGone
 */
function createTile(item, bind, onGone) {
  const art = hoard.el("div", { class: "ap-tile-art" });
  const meta = hoard.el("span", { class: "ap-tile-meta" });
  const tile = hoard.el("div", { class: "ap-tile", role: "button", tabindex: "0" }, [
    art,
    hoard.el("div", { class: "ap-tile-text" }, [hoard.el("span", { class: "ap-tile-name" }, [item.title]), meta]),
  ]);
  bind(tile);
  /** @type {(() => void) | null} */
  let stop = null;
  thumbQueue = thumbQueue.then(async () => {
    if (!tile.isConnected) return;
    try {
      const detail = await detailOf(item.id);
      const file = spriteFileOf(detail);
      if (!file || !tile.isConnected) return;
      const size = file.size ?? 0;
      const sprite = await spriteOf(file.path, size);
      if (!tile.isConnected) return;
      const canvas = /** @type {HTMLCanvasElement} */ (hoard.el("canvas", { class: "ap-tile-canvas" }));
      canvas.width = sprite.width;
      canvas.height = sprite.height;
      const g = /** @type {CanvasRenderingContext2D} */ (canvas.getContext("2d"));
      /** @type {Map<number, ImageData>} */
      const frames = new Map();
      const none = new Set();
      /** @param {number} f */
      const show = (f) => {
        let image = frames.get(f);
        if (!image) {
          image = renderFrame(sprite, f, none);
          frames.set(f, image);
        }
        g.putImageData(image, 0, 0);
      };
      show(0);
      const box = 160;
      const fit = Math.min(box / sprite.width, box / sprite.height);
      const scale = fit >= 1 ? Math.floor(fit) : fit;
      canvas.style.width = `${Math.round(sprite.width * scale)}px`;
      canvas.style.height = `${Math.round(sprite.height * scale)}px`;
      art.replaceChildren(canvas);
      meta.textContent = sprite.frames.length > 1 ? `${sprite.width}×${sprite.height} · ${sprite.frames.length} 格` : `${sprite.width}×${sprite.height}`;
      if (sprite.frames.length < 2) return;
      tile.classList.add("ap-animated");
      /** @type {number | undefined} */
      let timer;
      tile.addEventListener("pointerenter", () => {
        let f = 0;
        const tick = () => {
          f = (f + 1) % sprite.frames.length;
          show(f);
          timer = window.setTimeout(tick, sprite.frames[f].duration);
        };
        timer = window.setTimeout(tick, sprite.frames[0].duration);
      });
      tile.addEventListener("pointerleave", () => {
        clearTimeout(timer);
        show(0);
      });
      stop = () => clearTimeout(timer);
    } catch (err) {
      // .ase 的 Adobe 色票：不是像素圖，從頁面上拿掉。
      if (err instanceof NotSprite) onGone();
      else art.replaceChildren(hoard.el("span", { class: "ap-note" }, ["無法顯示"]));
    }
  });
  return { tile, destroy: () => stop?.() };
}

hoard.registerView({
  id: "sprites",
  label: "像素圖",
  icon: "grid-3x3",
  render(el, ctx) {
    let search = "";
    let columns = 0;
    /** 照現在的搜尋，一份還沒讀的清單。 @returns {SpriteList} */
    const spriteList = () => ({
      filter: { source_type: "local", exts: [...EXTENSIONS], search: search || undefined },
      narrowed: Boolean(search),
      items: [],
      offset: 0,
      done: false,
      loading: false,
      /** 畫過最後面的那一排。 */
      lastRow: -1,
      error: null,
    });
    /** 畫面上的清單。 */
    let shown = spriteList();
    /** 換了搜尋：正在讀、讀好就換上的那份。 @type {SpriteList | null} */
    let next = null;
    /** 畫面上的格子；換成佔位時是 null。 @type {HoardVirtualList | null} */
    let list = null;
    /** @type {HTMLElement | null} */
    let skeleton = null;

    const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "search", placeholder: "搜尋標題、檔名…" }));
    const grid = hoard.el("div");
    const note = hoard.el("div", { class: "hoard-empty" });
    note.hidden = true;
    const body = hoard.el("div", { class: "ap-grid" }, [grid, note]);
    // 名稱與件數由 App 的頁首顯示；搜尋放在頁首右側。
    ctx.header.actions.append(hoard.el("label", { class: "hoard-search" }, [hoard.icon("search", { size: 13 }), input]));
    el.append(hoard.el("div", { class: "ap-view" }, [body]));

    const rem = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    const gap = TILE_GAP_REM * rem;
    // 還沒讀完時最後一排可能沒排滿，先不畫，讀完才補上。
    const rowCount = () => (shown.done ? Math.ceil(shown.items.length / columns) : Math.floor(shown.items.length / columns));
    /** 照寬度（扣掉左右留白）算一排幾格；變了回傳 true。 */
    const measure = () => {
      const style = getComputedStyle(body);
      const width = body.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
      const fits = Math.max(1, Math.floor((width + gap) / (TILE_MIN_REM * rem + gap)));
      if (fits === columns) return false;
      columns = fits;
      return true;
    };
    measure();

    /** 讀下一頁加進這份清單。 @param {SpriteList} wall */
    const readPage = async (wall) => {
      const page = await ctx.listItems(wall.filter, { offset: wall.offset, limit: VIEW_PAGE });
      wall.offset += page.items.length;
      wall.done = page.items.length === 0 || wall.offset >= page.total;
      wall.items.push(...page.items.filter((item) => isSpriteItem(item) && !notSprites.has(item.id)));
    };

    /** 件數，以及空的、讀取失敗時的說明。enter：同一份清單剛剛還有東西（最後一件被拿掉），空狀態慢一拍淡入。 @param {boolean} [enter] */
    const showStatus = (enter = false) => {
      const { items, done, error, narrowed } = shown;
      ctx.header.setCount(items.length, { more: !done });
      const text = error
        ? `讀取失敗：${error}`
        : done && items.length === 0
          ? narrowed
            ? "沒有符合條件的像素圖"
            : "還沒有 Aseprite 檔"
          : "";
      if (note.hidden && text) note.toggleAttribute("data-enter", enter);
      note.textContent = text;
      note.hidden = !text;
    };

    /** 讀到才知道不是像素圖：拿掉它，畫面上的格子重排。 @param {SpriteList} wall @param {HoardItemSummary} item */
    const gone = (wall, item) => {
      notSprites.add(item.id);
      wall.items = wall.items.filter((other) => other.id !== item.id);
      if (wall !== shown) return;
      list?.redraw(rowCount());
      showStatus(true);
    };

    /** 畫到快到底：再讀幾頁加在後面（setCount，畫好的格子不重畫）。 */
    const loadMore = async () => {
      const wall = shown;
      if (wall.loading || wall.done) return;
      wall.loading = true;
      try {
        while (wall === shown && !wall.done && wall.lastRow >= rowCount() - VIEW_AHEAD) {
          await readPage(wall);
          if (wall === shown) list?.setCount(rowCount());
        }
      } catch (err) {
        wall.error = String(err);
        wall.done = true;
      } finally {
        wall.loading = false;
        if (wall === shown) {
          list?.setCount(rowCount());
          showStatus();
        }
      }
    };

    /** 一排一列的格子，畫的是 shown。 */
    const startList = () =>
      ctx.virtualList(grid, {
        count: rowCount(),
        // .ap-tile-art 的高度加名稱與尺寸那兩行。
        estimateSize: () => Math.round(14.25 * rem),
        gap,
        renderRow(row, index) {
          const wall = shown;
          wall.lastRow = Math.max(wall.lastRow, index);
          if (index >= rowCount() - VIEW_AHEAD) void loadMore();
          const tiles = wall.items
            .slice(index * columns, (index + 1) * columns)
            .map((item) => createTile(item, (tileEl) => ctx.bindItem(tileEl, item), () => gone(wall, item)));
          row.append(
            hoard.el(
              "div",
              { class: "ap-grid-row", style: `grid-template-columns: repeat(${columns}, minmax(0, 1fr)); column-gap: ${gap}px` },
              tiles.map((t) => t.tile),
            ),
          );
          return () => tiles.forEach((t) => t.destroy());
        },
      });

    /** 格子拿掉，換成佔位。 @param {boolean} now */
    const showSkeleton = (now) => {
      list?.();
      list = null;
      note.hidden = true;
      skeleton?.remove();
      skeleton = spriteSkeleton(now);
      grid.before(skeleton);
    };

    /**
     * 從頭讀。換了搜尋：新的一份讀好第一頁之前，畫面上的格子留著，讀好才一次換上、從頂端開始；
     * 超過 STALE_MS 還沒好才換成佔位。第一次打開直接放佔位（它自己等 200ms 才淡入）。
     * keep：收藏在背景變了（匯入、移到垃圾桶），還是同一份清單：讀到跟現在一樣多件，原地重畫，捲動位置不變；讀不到就留著現在的。
     * @param {boolean} [keep]
     */
    const reload = async (keep = false) => {
      // 正在換清單（或還沒有格子）時，背景的變動也當成換清單：一樣照現在的搜尋讀。
      keep &&= list !== null && next === null;
      const wall = spriteList();
      next = wall;
      /** @type {ReturnType<typeof setTimeout> | undefined} */
      let slow;
      if (!keep) {
        if (list) slow = setTimeout(() => next === wall && showSkeleton(true), STALE_MS);
        else if (!skeleton) showSkeleton(false);
      }
      const want = keep ? shown.items.length : 0;
      try {
        do {
          await readPage(wall);
        } while (next === wall && !wall.done && wall.items.length < want);
      } catch (err) {
        if (keep) {
          if (next === wall) next = null;
          console.warn("[aseprite] 重讀失敗：", err);
          return;
        }
        wall.error = String(err);
        wall.done = true;
      } finally {
        clearTimeout(slow);
      }
      if (next !== wall) return;
      next = null;
      skeleton?.remove();
      skeleton = null;
      shown = wall;
      if (keep && list) {
        list.redraw(rowCount());
      } else {
        // 舊的格子拿掉後頁面只剩頁首，捲動位置跟著回到頂端，新的從那裡畫起。
        list?.();
        list = startList();
      }
      showStatus(keep && want > 0);
    };

    // 寬度改變到一排的格數不同時重排，捲動位置不變。等下一個畫格才排：在 ResizeObserver 裡改版面會再觸發它自己。
    let queued = 0;
    const resize = new ResizeObserver(() => {
      if (queued) return;
      queued = requestAnimationFrame(() => {
        queued = 0;
        if (measure()) list?.redraw(rowCount());
      });
    });
    resize.observe(body);

    /** @type {number | undefined} */
    let typing;
    input.addEventListener("input", () => {
      clearTimeout(typing);
      typing = window.setTimeout(() => {
        search = input.value.trim();
        void reload();
      }, 250);
    });
    // 加入、移到垃圾桶：稍等一下再重讀，一批匯入只讀一次。
    /** @type {number | undefined} */
    let settle;
    const later = () => {
      clearTimeout(settle);
      settle = window.setTimeout(() => void reload(true), 600);
    };
    const offs = [hoard.on("items-added", later), hoard.on("items-removed", later)];

    void reload();
    return () => {
      next = null;
      clearTimeout(typing);
      clearTimeout(settle);
      cancelAnimationFrame(queued);
      resize.disconnect();
      offs.forEach((off) => off());
      list?.();
    };
  },
});

// ---- 卡片的像素圖封面 ----

/** 封面的樣子（尺寸、畫法）或合成方式改了就加一，所有作品重做。 */
const COVER_VERSION = 1;
/** 放大到寬約這麼多（整數倍，所以不一定剛好）。 */
const COVER_WIDTH = 400;
/** 核心原樣保存的上限；超過時靜態圖會被轉成 JPEG、動畫會失敗。 */
const COVER_MAX_SIDE = 1600;
const COVER_MAX_BYTES = 2 * 1024 * 1024;

/** @param {HTMLCanvasElement} canvas @returns {Promise<Blob>} */
function pngOf(canvas) {
  return new Promise((resolve, reject) =>
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("無法輸出 PNG"))), "image/png"),
  );
}

/** 畫格用最近鄰放大 scale 倍。 @param {ImageData} image @param {number} scale */
function scaled(image, scale) {
  const source = document.createElement("canvas");
  source.width = image.width;
  source.height = image.height;
  /** @type {CanvasRenderingContext2D} */ (source.getContext("2d")).putImageData(image, 0, 0);
  if (scale === 1) return source;
  const canvas = document.createElement("canvas");
  canvas.width = image.width * scale;
  canvas.height = image.height * scale;
  const g = /** @type {CanvasRenderingContext2D} */ (canvas.getContext("2d"));
  g.imageSmoothingEnabled = false;
  g.drawImage(source, 0, 0, canvas.width, canvas.height);
  return canvas;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();
/** @param {Uint8Array} bytes */
function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** 一個 PNG chunk（長度、型別、資料、CRC）。 @param {string} type @param {Uint8Array} data */
function chunk(type, data) {
  const out = new Uint8Array(12 + data.length);
  const view = new DataView(out.buffer);
  view.setUint32(0, data.length);
  for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
  out.set(data, 8);
  view.setUint32(8 + data.length, crc32(out.subarray(4, 8 + data.length)));
  return out;
}

/** 拆開 canvas 輸出的 PNG：IHDR 的資料與所有 IDAT 接起來的資料。 @param {Blob} png */
async function pngParts(png) {
  const b = new Uint8Array(await png.arrayBuffer());
  const view = new DataView(b.buffer);
  /** @type {Uint8Array | null} */
  let header = null;
  /** @type {Uint8Array[]} */
  const data = [];
  for (let at = 8; at + 12 <= b.length; ) {
    const length = view.getUint32(at);
    const type = String.fromCharCode(...b.subarray(at + 4, at + 8));
    const body = b.subarray(at + 8, at + 8 + length);
    if (type === "IHDR") header = body;
    else if (type === "IDAT") data.push(body);
    at += 12 + length;
  }
  if (!header) throw new Error("PNG 沒有 IHDR");
  const joined = new Uint8Array(data.reduce((n, d) => n + d.length, 0));
  let offset = 0;
  for (const d of data) {
    joined.set(d, offset);
    offset += d.length;
  }
  return { header, data: joined };
}

/**
 * 多格的畫面組成 APNG：每格都是整張（dispose none、blend source），所以透明的地方也會蓋掉前一格。
 * 每格先讓瀏覽器編成 PNG，再把 IDAT 搬進 fdAT。
 * @param {HTMLCanvasElement[]} frames @param {number[]} durations 毫秒 @returns {Promise<Blob>}
 */
async function apngOf(frames, durations) {
  /** @type {Uint8Array<ArrayBuffer>[]} */
  const parts = [new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])];
  let sequence = 0;
  for (let i = 0; i < frames.length; i++) {
    const { header, data } = await pngParts(await pngOf(frames[i]));
    if (i === 0) {
      parts.push(chunk("IHDR", header));
      const control = new DataView(new ArrayBuffer(8));
      control.setUint32(0, frames.length);
      control.setUint32(4, 0); // 一直重複
      parts.push(chunk("acTL", new Uint8Array(control.buffer)));
    }
    // 延遲是分數：毫秒放不進 16 位元時改用百分之一秒。
    const ms = Math.max(1, Math.round(durations[i]));
    const [num, den] = ms <= 0xffff ? [ms, 1000] : [Math.min(0xffff, Math.round(ms / 10)), 100];
    const control = new DataView(new ArrayBuffer(26));
    control.setUint32(0, sequence++);
    control.setUint32(4, frames[i].width);
    control.setUint32(8, frames[i].height);
    control.setUint32(12, 0);
    control.setUint32(16, 0);
    control.setUint16(20, num);
    control.setUint16(22, den);
    control.setUint8(24, 0); // dispose: none
    control.setUint8(25, 0); // blend: source
    parts.push(chunk("fcTL", new Uint8Array(control.buffer)));
    if (i === 0) {
      parts.push(chunk("IDAT", data));
    } else {
      const body = new Uint8Array(4 + data.length);
      new DataView(body.buffer).setUint32(0, sequence++);
      body.set(data, 4);
      parts.push(chunk("fdAT", body));
    }
  }
  parts.push(chunk("IEND", new Uint8Array(0)));
  return new Blob(parts, { type: "image/png" });
}

/** @param {ImageData} a @param {ImageData} b */
function sameImage(a, b) {
  const x = new Uint32Array(a.data.buffer);
  const y = new Uint32Array(b.data.buffer);
  for (let i = 0; i < x.length; i++) if (x[i] !== y[i]) return false;
  return true;
}

/**
 * 封面：全部畫格照檔案的順序與時間播（不看 tag），一樣的連續畫格併成一格。
 * 動畫超過 2 MB 就降低倍數；1 倍還太大時只留第一格。
 * @param {Sprite} s @returns {Promise<Blob>}
 */
async function coverOf(s) {
  const none = new Set();
  /** @type {Array<{ image: ImageData; duration: number }>} */
  const frames = [];
  for (let f = 0; f < s.frames.length; f++) {
    const image = renderFrame(s, f, none);
    const last = frames[frames.length - 1];
    if (last && sameImage(last.image, image)) last.duration += s.frames[f].duration;
    else frames.push({ image, duration: s.frames[f].duration });
    if (f % 8 === 7) await idle();
  }
  const longest = Math.max(s.width, s.height);
  const best = Math.max(1, Math.min(Math.floor(COVER_WIDTH / s.width), Math.floor(COVER_MAX_SIDE / longest)));
  const still = () => pngOf(scaled(frames[0].image, best));
  // 比上限大的圖放不了大，核心會把它轉成 JPEG；動畫本來就保存不了。
  if (frames.length < 2 || longest > COVER_MAX_SIDE) return still();
  let scale = best;
  for (;;) {
    const blob = await apngOf(
      frames.map((frame) => scaled(frame.image, scale)),
      frames.map((frame) => frame.duration),
    );
    if (blob.size <= COVER_MAX_BYTES) return blob;
    if (scale === 1) return still();
    // 大小約和面積成正比；至少降一倍。
    scale = Math.max(1, Math.min(scale - 1, Math.floor(scale * Math.sqrt(COVER_MAX_BYTES / blob.size))));
    await idle();
  }
}

/**
 * 做過的作品：id → [封面版本, 檔案的 modified_at]。不是 Aseprite 檔（Adobe 色票）、太大或解析失敗的也記，
 * 檔案改過或版本提高時才再試。
 * @type {Record<string, [number, string | null]>}
 */
let covered = {};
const coveredLoaded = hoard.storage.get("covers").then((saved) => {
  if (saved && typeof saved === "object") covered = /** @type {typeof covered} */ (saved);
});
/** 一次補很多件時不要每件都寫一次 storage。 */
let saveTimer = 0;
function saveCovered() {
  if (saveTimer) return;
  saveTimer = window.setTimeout(() => {
    saveTimer = 0;
    void hoard.storage.set("covers", covered);
  }, 2000);
}

/** 等著做封面的作品，先進先做。 @type {Set<number>} */
const coverQueue = new Set();
/** 這次載入後排進來過的作品（清掉已經不在收藏庫的紀錄時用）。 @type {Set<string>} */
const queuedOnce = new Set();
let coverRunning = false;
let unloaded = false;
hoard.onUnload(() => {
  unloaded = true;
  if (saveTimer) {
    clearTimeout(saveTimer);
    void hoard.storage.set("covers", covered);
  }
});

/** 讓出主執行緒：等瀏覽器有空（最多等 1 秒）。 */
const idle = () => new Promise((resolve) => requestIdleCallback(() => resolve(undefined), { timeout: 1000 }));

/** @param {number[]} ids */
function queueCovers(ids) {
  for (const id of ids) {
    coverQueue.add(id);
    queuedOnce.add(String(id));
  }
  if (!coverRunning) void runCovers();
}

/** 一次只做一件，件與件之間讓出主執行緒。 */
async function runCovers() {
  coverRunning = true;
  try {
    await coveredLoaded;
    while (!unloaded && coverQueue.size > 0) {
      const id = /** @type {number} */ (coverQueue.values().next().value);
      coverQueue.delete(id);
      await idle();
      await makeCover(id).catch((err) => console.warn("[aseprite] 做不出封面：", id, err));
    }
  } finally {
    coverRunning = false;
  }
}

/** @param {number} id */
async function makeCover(id) {
  const item = await hoard.items.get(id);
  const file = item.source_type === "local" && item.files.length === 1 ? spriteFileOf(item) : null;
  // 找不到的檔案（外接硬碟沒接上）先跳過，下次載入再試。
  if (!file || file.missing) return;
  const key = String(id);
  const done = covered[key];
  if (done && done[0] === COVER_VERSION && done[1] === file.modified_at) return;
  /** @type {Sprite | null} */
  let sprite = null;
  try {
    // 不經過 spriteOf 的快取：背景補幾千件時不要把預覽用的擠掉。
    sprite = await loadSprite(file.path, file.size ?? 0);
  } catch (err) {
    if (!(err instanceof NotSprite) && !(err instanceof TooLarge)) throw err;
  }
  if (unloaded) return;
  if (sprite && sprite.width > 0 && sprite.height > 0 && sprite.frames.length > 0) {
    await hoard.items.setCover(id, { image: await coverOf(sprite), format: true });
  }
  covered[key] = [COVER_VERSION, file.modified_at];
  saveCovered();
}

/** Aseprite 副檔名的作品，一頁一頁讀。 @param {HoardItemFilter} filter @param {(ids: number[]) => void} onPage */
async function listSprites(filter, onPage) {
  for (let offset = 0; !unloaded; ) {
    const page = await hoard.items.list({ ...filter, source_type: "local", exts: [...EXTENSIONS] }, { offset, limit: 200 });
    offset += page.items.length;
    onPage(page.items.filter(isSpriteItem).map((item) => item.id));
    if (page.items.length === 0 || offset >= page.total) return true;
    await idle();
  }
  return false;
}

// 新作品進來就做。
hoard.on("items-added", ({ ids }) => {
  void (async () => {
    for (let at = 0; at < ids.length && !unloaded; at += 200) {
      await listSprites({ ids: ids.slice(at, at + 200) }, queueCovers);
    }
  })().catch((err) => console.warn("[aseprite] 讀不到新作品：", err));
});

// 載入時補舊作品；讀完整個收藏庫後，清掉已經不在收藏庫裡（垃圾桶、永久刪除）的紀錄。
void (async () => {
  await coveredLoaded;
  await idle();
  if (!(await listSprites({}, queueCovers))) return;
  const stale = Object.keys(covered).filter((key) => !queuedOnce.has(key));
  if (stale.length === 0) return;
  stale.forEach((key) => delete covered[key]);
  saveCovered();
})().catch((err) => console.warn("[aseprite] 補封面失敗：", err));

// ---- 設定 ----

hoard.registerSettingTab({
  label: "預覽",
  render(root) {
    /** @param {string} label @param {keyof Settings} key @param {string} hint */
    const field = (label, key, hint) => {
      const box = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox" }));
      void settingsLoaded.then(() => (box.checked = settings[key]));
      box.checked = settings[key];
      box.addEventListener("change", () => updateSettings({ [key]: box.checked }));
      return hoard.el("label", { class: "ap-field" }, [
        box,
        hoard.el("span", { class: "ap-field-text" }, [hoard.el("span", {}, [label]), hoard.el("span", { class: "ap-field-hint" }, [hint])]),
      ]);
    };
    root.append(
      hoard.el("div", { class: "ap-settings" }, [
        field("快速預覽打開時自動播放", "autoplay", "多格的像素圖按空白鍵就開始動"),
        field("棋盤格背景", "checker", "透明的地方畫成灰白格子；預覽上的按鈕也會改到這裡"),
      ]),
    );
  },
});
