// @ts-check
/// <reference path="../hoard-extractor.d.ts" />
/* Fanbox 貼文擷取器：走 api.fanbox.cc（頁面憑證），留言另走分頁端點。
   listCreatorPosts() 列出整位創作者的貼文，供彈出視窗的批次抓取使用。 */

/**
 * 貼文同時存在 `https://{creator}.fanbox.cc/posts/{id}` 與
 * `https://www.fanbox.cc/@{creator}/posts/{id}` 兩種網址；正規化成同一組。
 */
function parsePostUrl(url) {
  if (url.hostname === "www.fanbox.cc") {
    const match = url.pathname.match(/^\/@([\w.-]+)\/posts\/(\d+)/);
    return match ? { creator: match[1], postId: match[2] } : null;
  }
  const sub = url.hostname.match(/^([\w-]+)\.fanbox\.cc$/);
  if (sub && !["api", "downloads"].includes(sub[1])) {
    const match = url.pathname.match(/^\/posts\/(\d+)/);
    return match ? { creator: sub[1], postId: match[1] } : null;
  }
  return null;
}

/** 創作者頁與貼文頁都能取出創作者 ID：`{creator}.fanbox.cc/…` 或 `www.fanbox.cc/@{creator}/…`。 */
function parseCreatorId(url) {
  if (url.hostname === "www.fanbox.cc") {
    return url.pathname.match(/^\/@([\w.-]+)/)?.[1] ?? null;
  }
  const sub = url.hostname.match(/^([\w-]+)\.fanbox\.cc$/);
  return sub && !["api", "downloads", "www"].includes(sub[1]) ? sub[1] : null;
}

async function fanboxApi(url) {
  const res = await fetch(url, {
    credentials: "include",
    headers: { Accept: "application/json" },
  });
  if (!res.ok) throw new Error(`Fanbox API 回應 ${res.status}`);
  const json = await res.json();
  if (json.body === undefined) {
    throw new Error(`Fanbox API 錯誤：${json.error ?? "無回應內容"}`);
  }
  return json.body;
}

/** 把各貼文型別的 body 攤平成 文字 + 圖片網址 + 附件。 */
function collectContent(body) {
  if (body.blocks) {
    const lines = [];
    const imageUrls = [];
    const files = [];
    for (const block of body.blocks) {
      if (typeof block.text === "string") {
        lines.push(block.text);
      } else if (block.type === "image" && block.imageId) {
        const image = body.imageMap?.[block.imageId];
        if (image) imageUrls.push(image.originalUrl);
      } else if (block.type === "file" && block.fileId) {
        const file = body.fileMap?.[block.fileId];
        if (file) files.push(file);
      }
    }
    return { text: lines.join("\n").trim(), imageUrls, files };
  }
  return {
    text: body.text?.trim() ?? "",
    imageUrls: (body.images ?? []).map((image) => image.originalUrl),
    files: body.files ?? [],
  };
}

function toComment(comment) {
  return {
    author_name: comment.user?.name,
    author_handle: comment.user?.userId,
    content: comment.body,
    posted_at: comment.createdDatetime,
    like_count: comment.likeCount,
    replies: (comment.replies ?? []).map(toComment),
  };
}

/** 一頁貼文清單：目前是 { posts }，更早的版本是陣列或 { items }。 */
function postsOf(body) {
  return Array.isArray(body) ? body : body.posts ?? body.items ?? [];
}

/**
 * 列出創作者的所有貼文摘要。post.paginateCreator 先給出每一頁的網址
 * （目前是 { pageUrls }，2026-10 以前是陣列），再逐頁讀 post.listCreator；
 * 拿不到分頁時退回舊版 post.listCreator 的 nextUrl 分頁。
 */
async function listCreatorItems(creatorId, progress) {
  const items = [];
  const id = encodeURIComponent(creatorId);
  let pages = null;
  try {
    const body = await fanboxApi(`https://api.fanbox.cc/post.paginateCreator?creatorId=${id}`);
    pages = Array.isArray(body) ? body : body.pageUrls;
  } catch {
    // 退回舊版分頁。
  }
  if (Array.isArray(pages)) {
    for (let i = 0; i < pages.length; i++) {
      progress(`讀取作品清單 ${i + 1}/${pages.length} 頁…`);
      items.push(...postsOf(await fanboxApi(pages[i])));
      if (i < pages.length - 1) await hoard.sleep(300);
    }
    return items;
  }
  let url = `https://api.fanbox.cc/post.listCreator?creatorId=${id}&limit=100`;
  for (let page = 1; url; page++) {
    progress(`讀取作品清單第 ${page} 頁…`);
    const body = await fanboxApi(url);
    items.push(...postsOf(body));
    url = Array.isArray(body) ? null : body.nextUrl;
    if (url) await hoard.sleep(300);
  }
  return items;
}

/**
 * 留言：目前的端點是 post.getComments（limit/offset，回 { viewMode, commentList: { items, nextUrl } }），
 * 舊的 post.listComments 已經 404。兩個都試，結構防禦性解析。
 */
async function loadComments(postId, warnings) {
  const comments = [];
  const endpoints = [
    `https://api.fanbox.cc/post.getComments?postId=${postId}&limit=50&offset=0`,
    `https://api.fanbox.cc/post.listComments?postId=${postId}&limit=10`,
  ];
  for (const first of endpoints) {
    try {
      let url = first;
      const MAX_PAGES = 30;
      for (let page = 0; page < MAX_PAGES && url; page++) {
        const body = await fanboxApi(url);
        if (body.commentList === null) {
          // viewMode 說明為什麼看不到（例如 PLEDGE_INSUFFICIENT）。
          warnings.push("這篇的留言需要更高的贊助方案才能看，只會儲存貼文內容");
          return comments;
        }
        const list = body.commentList ?? body;
        for (const item of list.items ?? []) comments.push(toComment(item));
        url = list.nextUrl;
        if (url && page === MAX_PAGES - 1) warnings.push("留言太多，只儲存了部分留言");
      }
      return comments;
    } catch {
      if (comments.length > 0) return comments;
      // 換下一個端點。
    }
  }
  warnings.push("留言讀取失敗，只會儲存貼文內容");
  return comments;
}

hoard.registerExtractor({
  sourceType: "fanbox",

  sourceUrl(url) {
    const parsed = parsePostUrl(url);
    return parsed ? `https://www.fanbox.cc/@${parsed.creator}/posts/${parsed.postId}` : null;
  },

  async extract({ url }) {
    const parsed = parsePostUrl(url);
    if (!parsed) throw new Error("無法從網址取得貼文 ID");

    const info = await fanboxApi(`https://api.fanbox.cc/post.info?postId=${parsed.postId}`);
    // 2026-10 起貼文包在 { post } 裡；更早直接是貼文本身。
    const post = info.post ?? info;
    if (!post.body) {
      throw post.feeRequired > 0 || post.isRestricted
        ? new Error(`貼文未解鎖（需要 ¥${post.feeRequired} 以上的贊助方案）`)
        : new Error("讀不到貼文內容，Fanbox API 可能已改版");
    }

    const warnings = [];
    const { text, imageUrls, files } = collectContent(post.body);

    // 純文字/影片貼文沒有內嵌圖片，改用封面當縮圖。
    const urls = imageUrls.length > 0 ? imageUrls : post.coverImageUrl ? [post.coverImageUrl] : [];
    const media = await hoard.fetchAllMedia(urls, warnings);
    if (media.length === 0 && urls.length > 0) {
      warnings.push("所有圖片都下載失敗，只會儲存 metadata");
    }

    const saveComments = (await hoard.getSettings()).saveComments !== false;
    const comments = saveComments ? await loadComments(parsed.postId, warnings) : [];

    return {
      payload: {
        source_type: "fanbox",
        source_url: `https://www.fanbox.cc/@${parsed.creator}/posts/${parsed.postId}`,
        title: post.title,
        description: text || post.excerpt,
        author: {
          name: post.user?.name ?? post.creatorId,
          handle: post.creatorId,
          url: `https://www.fanbox.cc/@${post.creatorId}`,
        },
        published_at: post.publishedDatetime,
        metadata: {
          fee_required: post.feeRequired,
          // 創作者替貼文加的標籤；App 端的「自動匯入標籤」用它。
          tags: Array.isArray(post.tags) && post.tags.length > 0 ? post.tags : undefined,
          like_count: post.likeCount,
          comment_count: post.commentCount,
          post_type: post.type,
          attachments: files.map((file) => `${file.name}.${file.extension}`),
          video: post.body.video
            ? `${post.body.video.serviceProvider}:${post.body.video.videoId}`
            : undefined,
        },
        media,
        comments,
      },
      warnings,
    };
  },

  async listCreatorPosts({ url, progress }) {
    const creatorId = parseCreatorId(url);
    if (!creatorId) throw new Error("請先開啟創作者的頁面或其中一篇貼文");

    const items = await listCreatorItems(creatorId, progress);
    const name = items.find((item) => item.user?.name)?.user.name ?? creatorId;
    return {
      creator: name,
      posts: items.map((item) => ({
        url: `https://www.fanbox.cc/@${item.creatorId ?? creatorId}/posts/${item.id}`,
        title: item.title,
        // 清單上 isRestricted 代表目前帳號的方案看不到內文。
        locked: Boolean(item.isRestricted),
      })),
    };
  },
});
