// @ts-check
/// <reference path="../hoard-app.d.ts" />
/* FANBOX App 端：詳情頁仿 FANBOX 文章頁（淺灰底、白色文章卡、創作者列、
   付費方案、附件、留言），樣式見 styles.css。書架卡片沿用 App 主題。 */

/**
 * 頭像：插件存的頭像（`path`），沒有或讀不到時用名字第一個字。
 * @param {string | null | undefined} name @param {string} cls @param {string | null | undefined} [path]
 */
function avatar(name, cls, path) {
  const initial = () => hoard.el("div", { class: cls }, [(name || "?").trim().charAt(0).toUpperCase()]);
  if (!path) return initial();
  // 插件抓到的頭像；讀不到就退回首字。
  const img = hoard.el("img", { class: cls, src: hoard.fileSrc(path), alt: "", draggable: "false" });
  img.addEventListener("error", () => img.replaceWith(initial()), { once: true });
  return img;
}

function commentNode(node) {
  const c = node.comment;
  const row = hoard.el("div", { class: "hf-comment" }, [
    avatar(c.author_name, "hf-avatar hf-avatar-sm"),
    hoard.el("div", { class: "hf-comment-body" }, [
      hoard.el("p", { class: "hf-comment-head" }, [
        hoard.el("b", {}, [c.author_name || "匿名"]),
        c.posted_at ? hoard.el("span", { class: "hf-muted" }, [hoard.formatDate(c.posted_at)]) : null,
      ]),
      hoard.el("p", { class: "hf-comment-text" }, [c.content]),
    ]),
  ]);
  if (node.replies.length === 0) return row;
  return hoard.el("div", {}, [row, hoard.el("div", { class: "hf-replies" }, node.replies.map(commentNode))]);
}

/** 圖片的 width／height 屬性（原圖的像素尺寸；還沒量測時不給）。 @param {HoardItemFile} file */
const sizeAttrs = (file) => (file.width && file.height ? { width: String(file.width), height: String(file.height) } : {});

hoard.register({
  renderDetail(root, item, ctx) {
    const meta = item.metadata;
    const fee = typeof meta.fee_required === "number" ? meta.fee_required : 0;
    const attachments = Array.isArray(meta.attachments)
      ? meta.attachments.filter((entry) => typeof entry === "string")
      : [];
    const media = item.files.filter((f) => f.kind === "image" || f.kind === "video");

    // 創作者列（文章卡上方）。
    const author = item.author;
    const creator = [
      avatar(author && author.name, "hf-avatar", author && author.avatar_path),
      hoard.el("p", author ? { class: "hf-creator-name", style: "cursor:pointer", title: "查看這位創作者的所有收藏", onclick: () => ctx.openAuthor(author.id) } : { class: "hf-creator-name" }, [author ? author.name : "未知創作者"]),
    ];
    if (author && author.url) {
      const url = author.url;
      creator.push(hoard.el("button", { class: "hf-pill", onclick: () => hoard.openUrl(url) }, ["創作者頁面"]));
    }

    const article = [];
    if (fee > 0) article.push(hoard.el("p", { class: "hf-fee" }, [hoard.icon("lock", { size: 13 }), `¥${fee} 以上的方案`]));
    article.push(hoard.el("h1", { class: "hf-title" }, [item.title]));
    article.push(
      hoard.el("p", { class: "hf-meta" }, [
        hoard.formatDateTime(item.published_at) || "發布時間未知",
        hoard.el("span", { class: "hf-like" }, [hoard.icon("heart", { size: 14 }), hoard.formatCount(meta.like_count ?? 0)]),
      ]),
    );
    if (item.description) article.push(hoard.el("p", { class: "hf-body" }, [item.description]));
    for (const [i, file] of media.entries()) {
      if (file.kind === "video") {
        article.push(hoard.el("video", { class: "hf-media", src: hoard.fileSrc(file.path), controls: "", preload: "metadata" }));
      } else {
        // 原圖可能幾千萬像素：畫的時候才解碼會讓每一格都等它，交給背景解碼。
        // 先照原圖的尺寸佔好位置：還沒載入的圖高度不是 0，lazy 才只載入畫面附近的幾張，頁面也不會一張張被推開。
        const img = hoard.el("img", { class: "hf-media", src: hoard.fileSrc(file.path), alt: file.alt ?? "", ...(file.alt ? { title: file.alt } : {}), loading: "lazy", decoding: "async", ...sizeAttrs(file) });
        img.addEventListener("click", () => ctx.openViewer(media, i));
        article.push(img);
      }
    }
    if (attachments.length > 0) {
      article.push(
        hoard.el("div", { class: "hf-files" }, [
          hoard.el("p", { class: "hf-muted" }, ["附件（未下載，請至原始頁面取得）"]),
          ...attachments.map((name) =>
            hoard.el("p", { class: "hf-file" }, [hoard.icon("paperclip", { size: 16 }), hoard.el("span", {}, [name])]),
          ),
        ]),
      );
    }

    const page = [
      hoard.el("div", { class: "hf-creator" }, creator),
      hoard.el("article", { class: "hf-card" }, article),
    ];
    if (item.comments.length > 0) {
      page.push(
        hoard.el("section", { class: "hf-card hf-comments" }, [
          hoard.el("h3", { class: "hf-section-title" }, [`留言 ${item.comments.length}`]),
          ...hoard.buildCommentTree(item.comments).map(commentNode),
        ]),
      );
    }
    root.append(hoard.el("div", { class: "hf-page" }, page));
  },

  renderCardMeta(root, item) {
    const meta = item.metadata;
    const children = [];
    if (typeof meta.fee_required === "number" && meta.fee_required > 0) {
      children.push(
        hoard.el("span", { class: "hf-card-fee" }, [`¥${meta.fee_required}`]),
      );
    }
    children.push(hoard.el("span", {}, [hoard.formatDate(item.published_at)]));
    root.append(
      hoard.el("div", { class: "hf-card-meta" }, children),
    );
  },
});

// ---- 插件設定：在網頁上的行為（擴充端用 hoard.getSettings 讀，每個網站有的動作不同） ----

/** @type {Array<{ key: string; label: string; hint: string; fallback: boolean }>} */
const PAGE_OPTIONS = [
  { key: "saveComments", label: "收藏時一起抓留言", hint: "FANBOX 的留言與回覆。", fallback: true },
];

/**
 * 改擷取器設定（`hoard.storage` 的 `extractor`）的一項。用 `storage.update` 一次讀改寫：
 * 快速連切兩個開關時，後一個不會蓋掉前一個。
 * @param {string} key @param {unknown} value
 */
function saveExtractorSetting(key, value) {
  return hoard.storage.update("extractor", (/** @type {Record<string, unknown> | undefined} */ saved) => ({ ...saved, [key]: value }));
}

hoard.registerSettingTab({
  label: "在網頁上",
  render(el) {
    const inputs = PAGE_OPTIONS.map((option) => {
      const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hf-switch" }));
      el.append(
        hoard.el("label", { class: "hf-setting-row" }, [
          hoard.el("span", {}, [hoard.el("strong", {}, [option.label]), hoard.el("span", { class: "hf-setting-hint" }, [option.hint])]),
          input,
        ]),
      );
      return { option, input };
    });
    el.append(hoard.el("p", { class: "hf-setting-hint" }, ["改完後重新整理網頁就生效，不用同步插件。"]));
    void hoard.storage.get("extractor").then((saved) => {
      const settings = /** @type {Record<string, unknown>} */ (saved ?? {});
      for (const { option, input } of inputs) input.checked = typeof settings[option.key] === "boolean" ? Boolean(settings[option.key]) : option.fallback;
    });
    for (const { option, input } of inputs) {
      input.addEventListener("change", async () => {
        await saveExtractorSetting(option.key, input.checked);
      });
    }
  },
});

// ---- 作者頭像：插件找網址、下載，交給核心存（創作者清單、創作者頁顯示） ----

// api.fanbox.cc 只回應從 FANBOX 網頁來的請求。
const AVATAR_HEADERS = { Origin: "https://www.fanbox.cc", Referer: "https://www.fanbox.cc/" };

/**
 * 帳號的頭像網址：創作者資料（不用登入，handle 是 creatorId）。
 * @param {HoardAuthor} author
 */
async function avatarUrl(author) {
  if (!author.handle) return null;
  const res = await hoard.fetch(`https://api.fanbox.cc/creator.get?creatorId=${encodeURIComponent(author.handle)}`, {
    headers: AVATAR_HEADERS,
  });
  if (!res.ok) throw new Error(`創作者資料 HTTP ${res.status}`);
  const url = /** @type {any} */ (await res.json())?.body?.user?.iconUrl;
  return typeof url === "string" && url ? url : null;
}

/** 這次開 App 試過的帳號（抓到或失敗）不再試。 */
const avatarTried = new Set();
/** @type {Promise<void> | null} */
let avatarRun = null;
let avatarAgain = false;
let avatarStopped = false;
hoard.onUnload(() => {
  avatarStopped = true;
});

/** 替還沒有頭像的 FANBOX 帳號補上：一次一個、間隔一下；跑的時候又有新收藏就再跑一輪。 */
function fillAvatars() {
  if (avatarRun) {
    avatarAgain = true;
    return;
  }
  avatarRun = (async () => {
    do {
      avatarAgain = false;
      const authors = await hoard.authors.list({ source: "fanbox" });
      for (const author of authors) {
        if (avatarStopped) return;
        if (author.avatar_path || avatarTried.has(author.id)) continue;
        avatarTried.add(author.id);
        try {
          const url = await avatarUrl(author);
          if (!url) continue;
          const res = await hoard.fetch(url, { headers: AVATAR_HEADERS });
          if (!res.ok) throw new Error(`頭像 HTTP ${res.status}`);
          await hoard.authors.setAvatar(author.id, await res.arrayBuffer(), { source: url });
        } catch (err) {
          console.warn(`[fanbox] 抓不到 ${author.name} 的頭像：`, err);
        }
        await new Promise((resolve) => setTimeout(resolve, 1200));
      }
    } while (avatarAgain && !avatarStopped);
  })()
    .catch((err) => console.warn("[fanbox] 補頭像失敗：", err))
    .finally(() => {
      avatarRun = null;
    });
}

// 開 App 後先讓畫面載完再補；之後每有新收藏就補新的作者。
const avatarStart = setTimeout(fillAvatars, 8000);
hoard.onUnload(() => clearTimeout(avatarStart));
hoard.on("items-added", () => fillAvatars());

// ---- 標籤自動匯入（預設關閉）：把 FANBOX 作品的標籤加進標籤庫，並貼到作品上 ----

/** 創作者替貼文加的標籤（擷取器存在 metadata.tags；1.6.0 之前收的沒有）。 @param {HoardItemSummary} item @returns {string[]} */
function siteTagsOf(item) {
  const tags = Array.isArray(item.metadata.tags) ? item.metadata.tags : [];
  return tags.filter((tag) => typeof tag === "string" && tag.trim()).map((tag) => tag.trim());
}

/**
 * 替這些作品加上網站的標籤；同一個標籤的作品合成一次呼叫，標籤庫沒有的由核心建立。
 * @param {HoardItemSummary[]} items
 */
async function importSiteTags(items) {
  /** @type {Map<string, number[]>} */
  const byName = new Map();
  for (const item of items) {
    for (const name of new Set(siteTagsOf(item))) {
      const ids = byName.get(name);
      if (ids) ids.push(item.id);
      else byName.set(name, [item.id]);
    }
  }
  for (const [name, ids] of byName) await hoard.items.addTags(ids, [name]);
}

hoard.on("items-added", async ({ ids }) => {
  if ((await hoard.storage.get("autoTags")) !== true) return;
  const { items } = await hoard.items.list({ ids, source_type: "fanbox" }, { limit: ids.length });
  if (items.length > 0) await importSiteTags(items);
});

/** 替已經收藏的作品補上；使用者打開開關時問過才做。 */
async function importAllSiteTags() {
  hoard.toast("正在替已收藏的 FANBOX 作品加上標籤…", { kind: "busy" });
  try {
    let done = 0;
    for (let offset = 0; ; offset += 200) {
      const { items } = await hoard.items.list({ source_type: "fanbox" }, { offset, limit: 200 });
      await importSiteTags(items);
      done += items.length;
      if (items.length < 200) break;
    }
    hoard.toast(`已替 ${done} 件 FANBOX 作品加上標籤`);
  } catch (err) {
    hoard.toast(`加標籤失敗：${err instanceof Error ? err.message : err}`, { kind: "error" });
  }
}

hoard.registerSettingTab({
  label: "標籤",
  render(el) {
    const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hf-switch" }));
    el.append(
      hoard.el("label", { class: "hf-setting-row" }, [
        hoard.el("span", {}, [
          hoard.el("strong", {}, ["自動匯入標籤"]),
          hoard.el("span", { class: "hf-setting-hint" }, ["收藏的 FANBOX 作品自動加上網站上的標籤，標籤庫沒有的會建立。預設關閉：標籤一多，標籤庫會變得很雜。"]),
        ]),
        input,
      ]),
    );
    void hoard.storage.get("autoTags").then((value) => (input.checked = value === true));
    input.addEventListener("change", async () => {
      await hoard.storage.set("autoTags", input.checked);
      if (!input.checked) return;
      const { total } = await hoard.items.list({ source_type: "fanbox" }, { limit: 1 });
      if (total > 0 && (await hoard.confirm(`也替已經收藏的 ${total} 件 FANBOX 作品加上標籤？`, { confirmLabel: "加上標籤" }))) {
        await importAllSiteTags();
      }
    });
  },
});
