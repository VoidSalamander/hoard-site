// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：網頁。
 *
 *  - 存下來的網頁（.html、.htm、.xhtml，MHTML 的 .mhtml、.mht；SingleFile 存的是 .html）在快速預覽與詳情頁直接顯示，
 *    放在核心的沙盒框架裡（hoard.mountFrame）：和 App 不同源，碰不到 App 與 hoard 的指令，也連不了網。
 *    - 本機網頁：框架讀網頁檔所在的資料夾，相對路徑的圖片、樣式、程式（「另存網頁」旁邊的 _files）與資料夾裡的其他網頁都照常。
 *    - MHTML：在這裡拆開，主要的 HTML 與它用到的段落做成框架裡的檔案（r/1.png…），網址換成那些路徑；連結換成原網頁的網址。
 *    - 網頁的程式：設定「執行網頁裡的程式」（預設打開）。關掉時框架只跑 App 與 frame.js 的程式。
 *    - 連結：框架裡的照常換頁；往外的交給 App（剛點的直接用瀏覽器開，網頁的程式自己要開的先問）。
 *    - frame.js 在框架裡數被擋下的網路資源與沒有執行的程式（詳情頁註明）、照快速預覽的按鍵捲網頁、交出程式畫好的網頁給封面用。
 *  - 資訊：<title>、描述、原始網址（SingleFile 開頭註解的 url、「saved from url」、MHTML 的 Snapshot-Content-Location、og:url、canonical）、
 *    存檔時間。網域存成篩選值 site（「篩選」裡的「網站」），標題、描述、網址與內文前 2000 字存 _text 給搜尋框。
 *    詳情頁的「改用網頁標題」把作品標題改成 <title>（不自動改，toast 可以復原）。
 *  - 元件：沒有 doctype、<html>、<head>、<body> 的小片段（像 uiverse.io 上的按鈕、卡片；256 KB 以內、不是 MHTML）。
 *    分析時存成篩選值 kind（「篩選」裡的「網頁類型」：元件／網頁），頁面的規則也能用。判斷錯的在右鍵選單改，
 *    存在 kind_fixed，之後的分析照它。
 *    - 快速預覽、詳情頁、封面：包進一頁置中排的網頁（componentPage）再放進沙盒框架，相對路徑照常；封面照寬 480px 排版。
 *    - 側欄的「元件」頁面（registerView）：只列 HTML（全部／元件／網頁、搜尋），ctx.virtualList 一排一列、捲到快到底才讀下一頁。
 *      卡片裡直接畫出元件、可以互動（Shadow DOM，見 mountLive：不執行程式、連不了網）；
 *      點元件不會開啟作品，點下方的名稱才會。有程式的元件先顯示封面，滑鼠停一下才換成沙盒框架跑程式；網頁顯示封面。
 *  - 文字摘錄：核心把複製、拖進來的文字存成的 HTML 檔（開頭有 <meta name="generator" content="hoard clip">）。
 *    kind 是「摘錄」：不會是元件、不在「元件」頁面、右鍵選單沒有切換；site 是摘錄來的網頁（metadata.page_url）的網域。
 *    - 顯示：預設是閱讀排版（readingPage）：拿掉行內的字型、大小、顏色、底色、間距，只留粗體、斜體這類強調，
 *      字型、顏色照 App 的主題，置中一欄；也可以換成原版（檔案照原樣，底色是核心照複製內容推出來的）。
 *      詳情頁上方切換，記在設定，快速預覽也照它。不執行程式。
 *    - 封面：閱讀排版的開頭，透明底、中性灰的字（深色、淺色主題的卡片上都看得清楚）。
 *  - 封面：網頁第一屏（寬 1024px）用 SVG foreignObject 畫進 canvas，存成 600×800 的格式封面（網格卡片的 3:4）；
 *    畫不出來時退回標題＋網域的文字封面。SVG 圖片裡只讀得到 data:，所以這時資源全部換成 data: 網址，也清掉程式與內嵌框架。
 *    網頁用 og:image（或 twitter:image）指定了讀得到的圖片（data:、MHTML 的段落、連結資料夾裡同資料夾的檔案）時，封面就是那張圖（setDeclaredCover）。
 *    有程式的網頁（設定打開時）先在看不到的框架裡跑一次，拿程式畫好的網頁做封面與搜尋文字。
 *  - 背景分析：載入時與 items-added 時找還沒分析過的（篩選值 scanned 不是目前的 SCAN_VERSION），一件一件讀，件與件之間讓出主執行緒；
 *    讀不到的檔案這次載入跳過、下次再試（做法同 ai-metadata）。
 *  - 只讀檔案：不寫入原檔。
 */

const HTML_EXTENSIONS = new Set(["html", "htm", "xhtml", "mhtml", "mht"]);
const MHTML_EXTENSIONS = new Set(["mhtml", "mht"]);
/** 超過這個大小不在 App 裡顯示。 */
const MAX_SHOW = 128 * 1024 * 1024;
/** 背景分析不讀超過這個大小的檔案。 */
const MAX_SCAN = 64 * 1024 * 1024;
/** 分析的方式（資訊、封面）改了就加一，所有作品重做：舊的版本加進 OLD_SCANS，背景分析也找它們。 */
const SCAN_VERSION = "3";
/** 3：網頁指定的封面（og:image）。 */
const OLD_SCANS = ["2"];
const SCAN_BATCH = 20;
/** 給搜尋框的文字最多幾個字（篩選值 `_text` 的上限）。 */
const TEXT_LIMIT = 2000;
/** 封面：網頁照這個寬度排版，取第一屏（3:4），縮成 COVER_WIDTH × COVER_HEIGHT。 */
const COVER_PAGE_WIDTH = 1024;
const COVER_PAGE_HEIGHT = Math.round((COVER_PAGE_WIDTH * 4) / 3);
const COVER_WIDTH = 600;
const COVER_HEIGHT = 800;
/** 有程式的網頁做封面時：載入後等多久再取網頁、最多等多久。 */
const SNAPSHOT_SETTLE = 800;
const SNAPSHOT_TIMEOUT = 10_000;
/** 詳情頁的框至少這麼高。 */
const MIN_DETAIL_HEIGHT = 360;
/** 元件最大多大：再大就是網頁的片段，不是小元件。 */
const COMPONENT_MAX = 256 * 1024;
/** 篩選值 kind 的值；使用者指定的 kind_fixed 只有元件、網頁兩種（摘錄不能切換）。 */
const KIND_COMPONENT = "元件";
const KIND_PAGE = "網頁";
const KIND_CLIP = "摘錄";
/** 核心存的文字摘錄開頭的標記（src-tauri/src/clip.rs 的 clip_file）。 */
const CLIP_MARK = /<meta\s+name="generator"\s+content="hoard clip"/i;
/** 認摘錄只讀開頭這麼多位元組。 */
const CLIP_HEAD = 1024;
/** 網頁、元件、摘錄的封面照這個大小排版（取第一屏），畫成 COVER_WIDTH × COVER_HEIGHT。 */
const PAGE_SIZE = { width: COVER_PAGE_WIDTH, height: COVER_PAGE_HEIGHT };
const COMPONENT_SIZE = { width: 480, height: 640 };
const CLIP_SIZE = COMPONENT_SIZE;

// ---- 設定 ----

/** 文字摘錄怎麼顯示：閱讀排版或原版。 @typedef {"reading" | "original"} ClipView */
/** @typedef {{ scripts: boolean; clipView: ClipView }} Settings */
/** @type {Settings} */
const settings = { scripts: true, clipView: "reading" };
const settingsLoaded = hoard.storage.get("settings").then(
  (saved) => {
    if (saved && typeof saved === "object") Object.assign(settings, saved);
    if (settings.clipView !== "original") settings.clipView = "reading";
  },
  () => {},
);
/** @param {Partial<Settings>} changes */
function updateSettings(changes) {
  Object.assign(settings, changes);
  void hoard.storage.set("settings", settings);
}

// ---- 哪些作品是網頁 ----

/** 小寫副檔名，不含點。 @param {string} path */
function extOf(path) {
  const name = path.split(/[\\/]/).pop() ?? "";
  const dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : "";
}

/** 作品摘要看得出的網頁：本機的單一檔案，副檔名是網頁。 @param {HoardItemSummary} item */
function isHtmlItem(item) {
  return item.source_type === "local" && item.metadata.format == null && typeof item.ext === "string" && HTML_EXTENSIONS.has(item.ext.toLowerCase());
}

/** 作品的網頁檔；不是只有一個網頁檔的作品是 null。 @param {HoardItemDetail} item */
function htmlFileOf(item) {
  if (item.files.length !== 1) return null;
  const file = item.files[0];
  return file.kind === "file" && file.entry === null && HTML_EXTENSIONS.has(extOf(file.path)) ? file : null;
}

/** @param {number} bytes */
function formatSize(bytes) {
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit++;
  }
  return `${unit === 0 ? value : value.toFixed(1)} ${units[unit]}`;
}

/** @param {unknown} err */
const messageOf = (err) => (err instanceof Error ? err.message : String(err));

// ---- 位元組與文字 ----

/** 每個位元組對應一個字元（0–255），給 MIME 的解析用。 @param {Uint8Array} bytes */
function latin1(bytes) {
  let out = "";
  for (let at = 0; at < bytes.length; at += 0x8000) {
    out += String.fromCharCode.apply(null, /** @type {any} */ (bytes.subarray(at, at + 0x8000)));
  }
  return out;
}

/** latin1 的反向。 @param {string} text */
function binaryBytes(text) {
  const out = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) out[i] = text.charCodeAt(i);
  return out;
}

/** BOM，或開頭 8 KB 裡 <meta> 宣告的編碼；都沒有時是 UTF-8。 @param {Uint8Array} bytes */
function sniffCharset(bytes) {
  if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) return "utf-8";
  if (bytes[0] === 0xfe && bytes[1] === 0xff) return "utf-16be";
  if (bytes[0] === 0xff && bytes[1] === 0xfe) return "utf-16le";
  const head = latin1(bytes.subarray(0, 8192));
  const label = /<meta[^>]*?charset\s*=\s*["']?\s*([\w.:-]+)/i.exec(head)?.[1]?.toLowerCase() ?? "";
  // 照 HTML 規格：沒有 BOM、卻宣告 UTF-16 的檔其實是 UTF-8。
  return label && !label.startsWith("utf-16") ? label : "utf-8";
}

/** 認不得的編碼名稱退回 UTF-8。 @param {Uint8Array} bytes @param {string} charset */
function decodeText(bytes, charset) {
  try {
    return new TextDecoder(charset).decode(bytes);
  } catch {
    return new TextDecoder().decode(bytes);
  }
}

/** quoted-printable → 位元組。 @param {string} text */
function qpBytes(text) {
  const out = new Uint8Array(text.length);
  let n = 0;
  const hex = (/** @type {number} */ c) => (c >= 48 && c <= 57) || (c >= 65 && c <= 70) || (c >= 97 && c <= 102);
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    if (c === 61) {
      const a = text.charCodeAt(i + 1);
      // 軟換行
      if (a === 13 && text.charCodeAt(i + 2) === 10) {
        i += 2;
        continue;
      }
      if (a === 10) {
        i += 1;
        continue;
      }
      if (hex(a) && hex(text.charCodeAt(i + 2))) {
        out[n++] = parseInt(text.substr(i + 1, 2), 16);
        i += 2;
        continue;
      }
    }
    out[n++] = c & 0xff;
  }
  return out.subarray(0, n);
}

/** `data:` 網址裡的文字（樣式表）。 @param {string} url */
function dataUrlText(url) {
  const comma = url.indexOf(",");
  if (comma < 0) return "";
  const meta = url.slice(5, comma);
  const payload = url.slice(comma + 1);
  if (/;base64/i.test(meta)) {
    try {
      return decodeText(binaryBytes(atob(payload.replace(/\s/g, ""))), /charset=([^;]+)/i.exec(meta)?.[1] ?? "utf-8");
    } catch {
      return "";
    }
  }
  try {
    return decodeURIComponent(payload);
  } catch {
    return payload;
  }
}

/** `data:` 網址裡的檔案（網頁指定的封面）；解不開時是 null。 @param {string} url */
function dataUrlBlob(url) {
  const comma = url.indexOf(",");
  if (comma < 0) return null;
  const meta = url.slice(5, comma);
  const type = meta.split(";")[0].trim().toLowerCase();
  const payload = url.slice(comma + 1);
  try {
    const bytes = /;base64/i.test(meta) ? binaryBytes(atob(payload.replace(/\s/g, ""))) : new TextEncoder().encode(decodeURIComponent(payload));
    return new Blob([/** @type {BlobPart} */ (bytes)], { type });
  } catch {
    return null;
  }
}

/** @param {Blob} blob @returns {Promise<string>} */
function dataUrlOf(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

/** 本機檔案的類型（App 給的不一定對，字型、SVG 要對才用得了）。 @type {Record<string, string>} */
const MIME = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  avif: "image/avif",
  svg: "image/svg+xml",
  bmp: "image/bmp",
  ico: "image/x-icon",
  woff: "font/woff",
  woff2: "font/woff2",
  ttf: "font/ttf",
  otf: "font/otf",
  css: "text/css",
  mp4: "video/mp4",
  webm: "video/webm",
  mp3: "audio/mpeg",
  ogg: "audio/ogg",
  wav: "audio/wav",
};

// ---- 本機路徑與 file: 網址 ----

/** 本機路徑 → file: 網址，相對路徑才算得出來。 @param {string} path */
function fileUrl(path) {
  const unc = path.startsWith("\\\\");
  const segments = path.replace(/\\/g, "/").replace(/^\/+/, "").split("/");
  const encoded = segments.map((s, i) => (i === 0 && /^[A-Za-z]:$/.test(s) ? s : encodeURIComponent(s))).join("/");
  try {
    return new URL(unc ? `file://${encoded}` : `file:///${encoded}`).href;
  } catch {
    return "file:///";
  }
}

/** file: 網址 → 本機路徑。 @param {URL} url */
function pathOfFileUrl(url) {
  let pathname = url.pathname;
  try {
    pathname = decodeURIComponent(pathname);
  } catch {
    /* 照原樣 */
  }
  if (url.host) return `\\\\${url.host}${pathname.replace(/\//g, "\\")}`;
  return pathname.replace(/^\//, "").replace(/\//g, "\\");
}

/** 只收 http(s) 網址。 @param {string | null | undefined} value */
function httpUrl(value) {
  if (!value) return null;
  try {
    const url = new URL(value.trim());
    return url.protocol === "http:" || url.protocol === "https:" ? url.href : null;
  } catch {
    return null;
  }
}

// ---- MHTML ----

/** @typedef {{ type: string; charset: string | null; bytes: Uint8Array }} Part */

/** 標頭（續行接回去），名稱小寫。 @param {string} text */
function parseHeaders(text) {
  /** @type {Map<string, string>} */
  const map = new Map();
  for (const line of text.replace(/\r?\n[ \t]+/g, " ").split(/\r?\n/)) {
    const colon = line.indexOf(":");
    if (colon <= 0) continue;
    const name = line.slice(0, colon).trim().toLowerCase();
    if (!map.has(name)) map.set(name, line.slice(colon + 1).trim());
  }
  return map;
}

/** `Content-Type: a/b; name="value"` 的參數。 @param {string} value @param {string} name */
function headerParam(value, name) {
  const m = new RegExp(`;\\s*${name}\\s*=\\s*(?:"([^"]*)"|([^;\\s]*))`, "i").exec(value);
  return m ? (m[1] ?? m[2] ?? null) : null;
}

/** 標頭結束的空行：end 是標頭的結尾，body 是內容的開頭。 @param {string} text @param {number} from */
function blankLine(text, from) {
  const crlf = text.indexOf("\r\n\r\n", from);
  const lf = text.indexOf("\n\n", from);
  if (crlf !== -1 && (lf === -1 || crlf < lf)) return { end: crlf, body: crlf + 4 };
  if (lf !== -1) return { end: lf, body: lf + 2 };
  return { end: text.length, body: text.length };
}

/** 標頭裡 RFC 2047 編碼的文字（`=?utf-8?Q?...?=`）。 @param {string} text */
function decodeWords(text) {
  return text.replace(/=\?([^?]+)\?([QqBb])\?([^?]*)\?=/g, (_, charset, encoding, data) => {
    try {
      const bytes = encoding.toUpperCase() === "B" ? binaryBytes(atob(data)) : qpBytes(data.replace(/_/g, " "));
      return decodeText(bytes, charset);
    } catch {
      return data;
    }
  });
}

/**
 * 拆 MHTML（multipart/related）：主要的 HTML、它的網址，以及依網址（和 cid:）查得到的其他段落。
 * 不是 multipart 時回傳 null，當一般 HTML 讀。
 * @param {Uint8Array} bytes
 */
function parseMhtml(bytes) {
  const raw = latin1(bytes);
  const top = blankLine(raw, 0);
  const headers = parseHeaders(raw.slice(0, top.end));
  const type = headers.get("content-type") ?? "";
  const boundary = headerParam(type, "boundary");
  if (!/^multipart\//i.test(type) || !boundary) return null;
  const delimiter = `--${boundary}`;
  /** @type {Map<string, Part>} */
  const parts = new Map();
  /** @type {Array<Part & { id: string | null; location: string }>} */
  const list = [];
  let at = raw.indexOf(delimiter, top.body);
  while (at !== -1) {
    const after = at + delimiter.length;
    if (raw.startsWith("--", after)) break;
    const lineEnd = raw.indexOf("\n", after);
    if (lineEnd === -1) break;
    const next = raw.indexOf(`\n${delimiter}`, lineEnd);
    let end = next === -1 ? raw.length : next;
    if (raw[end - 1] === "\r") end--;
    const blank = blankLine(raw, lineEnd + 1);
    const partHeaders = parseHeaders(raw.slice(lineEnd + 1, Math.min(blank.end, end)));
    const body = raw.slice(Math.min(blank.body, end), end);
    const encoding = (partHeaders.get("content-transfer-encoding") ?? "").trim().toLowerCase();
    const partType = partHeaders.get("content-type") ?? "application/octet-stream";
    /** @type {Uint8Array} */
    let data;
    try {
      data =
        encoding === "base64"
          ? binaryBytes(atob(body.replace(/[^A-Za-z0-9+/=]/g, "")))
          : encoding === "quoted-printable"
            ? qpBytes(body)
            : binaryBytes(body);
    } catch {
      data = new Uint8Array(0);
    }
    const id = partHeaders.get("content-id")?.replace(/^<|>$/g, "") ?? null;
    const location = partHeaders.get("content-location") ?? "";
    const part = { type: partType.split(";")[0].trim().toLowerCase(), charset: headerParam(partType, "charset"), bytes: data };
    list.push({ ...part, id, location });
    if (location) {
      try {
        const url = new URL(location);
        url.hash = "";
        if (!parts.has(url.href)) parts.set(url.href, part);
      } catch {
        /* 不是網址 */
      }
    }
    if (id) parts.set(`cid:${id}`, part);
    at = next === -1 ? -1 : next + 1;
  }
  const start = headerParam(type, "start")?.replace(/^<|>$/g, "");
  const main = (start ? list.find((p) => p.id === start) : null) ?? list.find((p) => p.type === "text/html");
  if (!main) return null;
  const snapshotUrl = httpUrl(headers.get("snapshot-content-location"));
  return {
    html: decodeText(main.bytes, main.charset ?? sniffCharset(main.bytes)),
    base: main.location || snapshotUrl || "about:blank",
    parts,
    snapshotUrl: snapshotUrl ?? httpUrl(main.location),
    subject: decodeWords(headers.get("subject") ?? "").trim() || null,
    date: headers.get("date") ?? null,
  };
}

// ---- 讀檔 ----

/**
 * 解析好、還沒清理的網頁。base 是算相對網址用的（本機檔是 file: 網址，MHTML 是原網頁的網址）；
 * text 是原始碼（MHTML 是主要的 HTML）。
 * @typedef {{
 *   doc: Document;
 *   base: string;
 *   text: string;
 *   parts: Map<string, Part> | null;
 *   savedUrl: string | null;
 *   savedAt: string | null;
 *   subject: string | null;
 * }} Source
 */

/**
 * 解析 HTML；base 是它原本的網址，網頁裡的 <base> 照算。
 * @param {string} text @param {string} base @returns {{ doc: Document; base: string }}
 */
function parseHtml(text, base) {
  // <base> 解析前就拿掉：DOMParser 的文件沿用 App 的 CSP（base-uri 'none'），留著會一直回報違規。
  /** @type {string | null} */
  let baseHref = null;
  const html = text.replace(/<base\b[^>]*>/gi, (tag) => {
    baseHref ??= /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(tag)?.slice(1).find((v) => v !== undefined) ?? null;
    return "";
  });
  let at = base;
  if (baseHref) {
    try {
      at = new URL(baseHref, base).href;
    } catch {
      /* 照原本的 */
    }
  }
  return { doc: new DOMParser().parseFromString(html, "text/html"), base: at };
}

/** @param {HoardItemFile} file */
async function readBytes(file) {
  const res = await fetch(hoard.fileSrc(file.path));
  if (!res.ok) throw new Error(res.status === 404 ? "找不到檔案" : `讀不到檔案（${res.status}）`);
  return new Uint8Array(await res.arrayBuffer());
}

/** 不是 MHTML 的網頁檔的原始碼。 @param {HoardItemFile} file */
async function readText(file) {
  const bytes = await readBytes(file);
  return decodeText(bytes, sniffCharset(bytes));
}

/** @param {HoardItemFile} file @returns {Promise<Source>} */
async function loadSource(file) {
  const bytes = await readBytes(file);
  const mhtml = MHTML_EXTENSIONS.has(extOf(file.path)) ? parseMhtml(bytes) : null;
  const text = mhtml ? mhtml.html : decodeText(bytes, sniffCharset(bytes));
  const { doc, base } = parseHtml(text, mhtml ? mhtml.base : fileUrl(file.path));
  return {
    doc,
    base,
    text,
    parts: mhtml?.parts ?? null,
    savedUrl: mhtml?.snapshotUrl ?? null,
    savedAt: mhtml?.date ?? null,
    subject: mhtml?.subject ?? null,
  };
}

// ---- 網頁的資訊 ----

/**
 * @typedef {{
 *   title: string;
 *   description: string;
 *   url: string | null;
 *   site: string | null;
 *   savedAt: Date | null;
 *   iconHref: string | null;
 *   coverHref: string | null;
 * }} PageInfo
 */

/** 網址的網域（篩選值 site），不含 www.。 @param {string | null} url */
function siteOf(url) {
  if (!url) return null;
  try {
    return new URL(url).hostname.replace(/^www\./, "") || null;
  } catch {
    return null;
  }
}

/** 文件最外層的註解（SingleFile、「saved from url」寫在這裡）。 @param {Document} doc */
function topComments(doc) {
  /** @type {string[]} */
  const out = [];
  for (const parent of [doc, doc.documentElement, doc.head]) {
    if (!parent) continue;
    for (const node of Array.from(parent.childNodes)) if (node.nodeType === Node.COMMENT_NODE) out.push(node.nodeValue ?? "");
  }
  return out;
}

/** 要在清理之前讀：清理會拿掉 <meta>、<link>。 @param {Source} source @returns {PageInfo} */
function pageInfo(source) {
  const { doc } = source;
  const meta = (/** @type {string} */ selector) => doc.querySelector(selector)?.getAttribute("content")?.trim() ?? "";
  const title =
    (doc.querySelector("title")?.textContent ?? "").replace(/\s+/g, " ").trim() || meta('meta[property="og:title"]') || source.subject || "";
  const description = meta('meta[name="description" i]') || meta('meta[property="og:description"]');
  let url = source.savedUrl;
  let saved = source.savedAt;
  for (const text of topComments(doc)) {
    const singleFile = /Page saved with SingleFile/i.test(text);
    const found = singleFile ? /^\s*url:\s*(\S+)/m.exec(text)?.[1] : /saved from url=\(\d+\)(\S+)/i.exec(text)?.[1];
    url ??= httpUrl(found);
    if (singleFile) saved ??= /^\s*saved date:\s*(.+?)\s*$/m.exec(text)?.[1] ?? null;
  }
  url ??= httpUrl(meta('meta[property="og:url"]')) ?? httpUrl(doc.querySelector('link[rel="canonical" i]')?.getAttribute("href"));
  const savedAt = saved ? new Date(saved) : null;
  return {
    title,
    description,
    url,
    site: siteOf(url),
    savedAt: savedAt && !isNaN(savedAt.getTime()) ? savedAt : null,
    iconHref: doc.querySelector('link[rel~="icon" i][href]')?.getAttribute("href") ?? null,
    coverHref: meta('meta[property="og:image"]') || meta('meta[property="og:image:url"]') || meta('meta[name="twitter:image"]') || null,
  };
}

const TEXT_SKIP = new Set(["script", "style", "noscript", "template", "svg", "math", "head", "select"]);

/** 內文（給搜尋框），夠用就停。 @param {Document} doc */
function pageText(doc) {
  const body = doc.body;
  if (!body) return "";
  let text = "";
  const walker = doc.createTreeWalker(body, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
    acceptNode: (node) =>
      node.nodeType === Node.ELEMENT_NODE && TEXT_SKIP.has(/** @type {Element} */ (node).localName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT,
  });
  for (let node = walker.nextNode(); node && text.length < TEXT_LIMIT; node = walker.nextNode()) {
    if (node.nodeType !== Node.TEXT_NODE) continue;
    const part = (node.nodeValue ?? "").replace(/\s+/g, " ").trim();
    if (part) text += (text ? " " : "") + part;
  }
  return text;
}

/** @param {PageInfo} info @param {string} body */
function searchText(info, body) {
  return [info.title, info.description, info.url ?? "", body].filter(Boolean).join("\n").slice(0, TEXT_LIMIT).trim();
}

// ---- 元件 ----

/** 讀得出來、可能是元件的檔案。 @param {HoardItemFile} file */
function canBeComponent(file) {
  return !file.missing && !MHTML_EXTENSIONS.has(extOf(file.path)) && (file.size ?? 0) <= COMPONENT_MAX;
}

/** 原始碼看起來是元件：不是一整頁（沒有 doctype、<html>、<head>、<body>），除了樣式與程式還有別的元素。 @param {string} text */
function looksLikeComponent(text) {
  if (text.length > COMPONENT_MAX) return false;
  const code = text.replace(/<!--[\s\S]*?-->/g, "");
  if (/<(?:!doctype|html|head|body|frameset)\b/i.test(code)) return false;
  const rest = code.replace(/<(style|script)\b[\s\S]*?<\/\1\s*>/gi, "");
  return /<[a-z][\w-]*(?:\s|\/?>)/i.test(rest);
}

/** 元件有自己的程式（<script> 或 onclick 這類屬性）。 @param {string} text */
const hasScript = (text) => /<script\b|\son[a-z]+\s*=/i.test(text);

/** 元件放在這裡置中排（框架與卡片裡的 Shadow DOM 用同一組）；元件自己寫的 body 樣式排在後面，蓋得過去。 */
/**
 * 元件外層（body）的排法：置中；高度固定成整頁，`height: 100%` 的元件（背景圖樣）才撐得開。
 * 比頁面高的元件用 safe 置中，從上面開始往下長、捲得到，不會被推出上緣。
 */
const COMPONENT_BODY =
  "display:flex;flex-direction:column;align-items:safe center;justify-content:safe center;gap:12px;box-sizing:border-box;height:100%;padding:16px";
/** 上面的 padding（fitLive 量放不放得下時加上）。 */
const COMPONENT_PADDING = 16;

/** 把元件包成一頁：快速預覽、詳情頁、封面都用它。 @param {string} text */
function componentPage(text) {
  return `<!doctype html><html><head><meta charset="utf-8"><style>html{height:100%}body{margin:0;${COMPONENT_BODY}}</style></head><body>
${text}
</body></html>`;
}

/** 元件在框架裡：包好的那一頁頂替原檔，相對路徑照樣讀原檔所在的資料夾。 @param {string} path @param {string} text */
function componentSpec(path, text) {
  const spec = localSpec(path);
  return { ...spec, files: { [spec.entry]: componentPage(text) } };
}

/**
 * 作品怎麼顯示：文字摘錄、元件（都附上原始碼）或網頁。
 * @typedef {{ kind: "clip" | "component"; text: string } | { kind: "page" }} Display
 */
/** @type {Display} */
const AS_PAGE = { kind: "page" };

/** 核心存的文字摘錄（看開頭的標記）。 @param {string} text */
const isClipText = (text) => CLIP_MARK.test(text.slice(0, CLIP_HEAD));

/** 只讀檔案開頭，看是不是文字摘錄（摘錄裡的圖片寫在檔案裡，可能很大）。 @param {HoardItemFile} file */
async function isClipFile(file) {
  const size = file.size ?? 0;
  if (size === 0) return false;
  // Range 超出檔尾會丟出例外，小檔只讀到結尾。
  const res = await fetch(hoard.fileSrc(file.path), { headers: { Range: `bytes=0-${Math.min(CLIP_HEAD, size) - 1}` } });
  if (!res.ok) return false;
  return isClipText(new TextDecoder().decode(await res.arrayBuffer()));
}

/**
 * 作品怎麼顯示。分析過的照篩選值 kind（摘錄優先；元件、網頁由使用者指定的 kind_fixed 優先），
 * 還沒分析過的讀檔判斷。
 * @param {number} id @param {HoardItemFile} file @returns {Promise<Display>}
 */
async function displayOf(id, file) {
  if (file.missing || MHTML_EXTENSIONS.has(extOf(file.path))) return AS_PAGE;
  /** @type {Record<string, string[]>} */
  const fields = await hoard.items.getFields(id).catch(() => ({}));
  const analyzed = fields.kind?.[0];
  if (analyzed === KIND_CLIP || (analyzed === undefined && (await isClipFile(file)))) return { kind: "clip", text: await readText(file) };
  const kind = fields.kind_fixed?.[0] ?? analyzed;
  if (kind === KIND_PAGE || !canBeComponent(file)) return AS_PAGE;
  const text = await readText(file);
  return kind === KIND_COMPONENT || looksLikeComponent(text) ? { kind: "component", text } : AS_PAGE;
}

/** 作品是元件時回傳它的原始碼，不是元件是 null。 @param {number} id @param {HoardItemFile} file @returns {Promise<string | null>} */
async function componentText(id, file) {
  const display = await displayOf(id, file);
  return display.kind === "component" ? display.text : null;
}

/**
 * 使用者指定作品是元件還是網頁（fixed 是空的就回到自動判斷）：清掉 scanned，背景分析照它重做封面與 kind。
 * @param {Array<{ id: number; fixed: string[]; kind: string[] }>} changes
 */
async function writeKinds(changes) {
  await hoard.items.setFields(
    changes.flatMap(({ id, fixed, kind }) => [
      { id, key: "kind_fixed", values: fixed },
      { id, key: "kind", values: kind },
      { id, key: "scanned", values: [] },
    ]),
  );
  for (const { id, kind } of changes) {
    unreadable.delete(id);
    if (kind[0]) kindOfId.set(id, kind[0]);
  }
  // 這幾件可能排在讀不到的作品前面，從頭數。
  recount = true;
  void scan();
}

/** 右鍵選單的「當成元件顯示」「當成網頁顯示」：toast 可以復原。 @param {number[]} ids @param {string} kind */
async function setKind(ids, kind) {
  try {
    /** @type {Array<Record<string, string[]>>} */
    const before = await Promise.all(ids.map((id) => hoard.items.getFields(id).catch(() => ({}))));
    await writeKinds(ids.map((id) => ({ id, fixed: [kind], kind: [kind] })));
    const what = kind === KIND_COMPONENT ? "當成元件顯示" : "當成網頁顯示";
    hoard.toast(ids.length > 1 ? `${ids.length} 件改成${what}` : `改成${what}`, {
      action: {
        label: "復原",
        run: () =>
          void writeKinds(ids.map((id, i) => ({ id, fixed: before[i].kind_fixed ?? [], kind: before[i].kind ?? [] }))).catch((err) =>
            hoard.toast(messageOf(err), { kind: "error" }),
          ),
      },
    });
  } catch (err) {
    hoard.toast(messageOf(err), { kind: "error" });
  }
}

/**
 * 可以切換的作品（找得到檔案、不是 MHTML、256 KB 以內、分析過的網頁）現在是元件還是網頁。
 * 選單的 when 只拿得到 id 而且要馬上回答，所以先查好、隨作品變動更新（recheckKinds）；
 * 新加的作品分析完寫入 kind 時也是 items-changed。
 * @type {Map<number, string>}
 */
const kindOfId = new Map();
const COMPONENT_EXTS = [...HTML_EXTENSIONS].filter((ext) => !MHTML_EXTENSIONS.has(ext));
/** 一次查一輪，後查的結果不會被先查的蓋掉。 */
let kindsQueue = Promise.resolve();

/** 重查 ids（省略是全部）是元件還是網頁。 @param {number[]} [ids] */
function loadKinds(ids) {
  kindsQueue = kindsQueue
    .then(async () => {
      /** @type {Map<number, string>} */
      const found = new Map();
      for (const kind of [KIND_COMPONENT, KIND_PAGE]) {
        /** @type {HoardItemFilter} */
        const filter = {
          source_type: "local",
          ids,
          exts: COMPONENT_EXTS,
          max_size: COMPONENT_MAX,
          missing: false,
          fields: [{ owner: "html", key: "kind", any: [kind] }],
        };
        for (let offset = 0; ; offset += 500) {
          const page = await hoard.items.list(filter, { offset, limit: 500 });
          page.items.forEach((item) => found.set(item.id, kind));
          if (offset + 500 >= page.total) break;
        }
      }
      if (ids) ids.forEach((id) => kindOfId.delete(id));
      else kindOfId.clear();
      found.forEach((kind, id) => kindOfId.set(id, kind));
    })
    .catch((err) => console.warn("[html] 讀不到網頁類型：", err));
}
loadKinds();
/**
 * 等著重查的作品：背景分析每寫一件就是一次 items-changed（別的插件寫篩選值、封面也是），
 * 收集一下再一起查，一次最多 500 件（做法同 comic-reader 的 recheckReadable）。
 * @type {Set<number>}
 */
const recheckKindIds = new Set();
let recheckKindTimer = 0;
/** @param {{ ids: number[] }} payload */
function recheckKinds({ ids }) {
  if (ids.length === 0) return;
  for (const id of ids) recheckKindIds.add(id);
  if (recheckKindTimer) return;
  recheckKindTimer = window.setTimeout(() => {
    recheckKindTimer = 0;
    const all = [...recheckKindIds];
    recheckKindIds.clear();
    for (let i = 0; i < all.length; i += 500) loadKinds(all.slice(i, i + 500));
  }, 800);
}
hoard.onUnload(() => clearTimeout(recheckKindTimer));
hoard.on("items-changed", recheckKinds);
hoard.on("items-removed", ({ ids }) => {
  for (const id of ids) {
    kindOfId.delete(id);
    recheckKindIds.delete(id);
  }
});

/** 選取的作品裡現在是 kind 的那些。 @param {number[]} ids @param {string} kind */
const idsOfKind = (ids, kind) => ids.filter((id) => kindOfId.get(id) === kind);

hoard.registerMenuItem("item", {
  label: "當成元件顯示",
  icon: "component",
  when: (ids) => idsOfKind(ids, KIND_PAGE).length > 0,
  run: (ids) => setKind(idsOfKind(ids, KIND_PAGE), KIND_COMPONENT),
});
hoard.registerMenuItem("item", {
  label: "當成網頁顯示",
  icon: "app-window",
  when: (ids) => idsOfKind(ids, KIND_COMPONENT).length > 0,
  run: (ids) => setKind(idsOfKind(ids, KIND_COMPONENT), KIND_PAGE),
});

/** @param {string} text */
function copyCode(text) {
  navigator.clipboard.writeText(text).then(
    () => hoard.toast("已複製"),
    () => hoard.toast("複製失敗", { kind: "error" }),
  );
}

// ---- 資源 ----

/** 框架裡放 MHTML 段落的檔名用的副檔名。 @type {Record<string, string>} */
const PART_EXTENSIONS = Object.fromEntries(Object.entries(MIME).map(([ext, type]) => [type, ext]));

/**
 * 把網頁裡的網址換成用得了的：
 *  - "cover"：全部換成 data: 網址（SVG 圖片裡只讀得到 data:）：MHTML 的段落、本機檔案；網路上的用不了。
 *  - "frame"：MHTML 的段落做成框架裡的檔案（files），換成它們的路徑；其他的照原樣（框架裡被擋下，frame.js 數得到）。
 * @param {Source} source
 * @param {"cover" | "frame"} mode
 */
function createResolver(source, mode) {
  const inline = mode === "cover";
  /** @type {Map<string, Promise<string | null>>} */
  const cache = new Map();
  /** 框架裡的檔案：路徑 → 內容。 @type {Map<string, Blob>} */
  const files = new Map();

  /** @param {string} raw @param {string} base */
  function locate(raw, base) {
    let url;
    try {
      url = new URL(raw, base);
    } catch {
      return null;
    }
    url.hash = "";
    const href = url.href;
    const part = source.parts?.get(href);
    if (part) return { href, part, path: null };
    if (url.protocol === "file:" && inline) return { href, part: null, path: pathOfFileUrl(url) };
    return null;
  }

  /** @param {{ part: Part | null; path: string | null }} found @returns {Promise<Blob | null>} */
  async function blobOf(found) {
    if (found.part) return new Blob([/** @type {BlobPart} */ (found.part.bytes)], { type: found.part.type });
    if (!found.path) return null;
    try {
      const res = await fetch(hoard.fileSrc(found.path));
      if (!res.ok) return null;
      const blob = await res.blob();
      const type = MIME[extOf(found.path)];
      return type && blob.type !== type ? new Blob([blob], { type }) : blob;
    } catch {
      return null;
    }
  }

  return {
    inline,
    /** 用不了的網址照原樣留著（框架），不是拿掉（封面）。 */
    keep: !inline,
    files,
    /**
     * 圖片、影片、字型的網址；用不了時是 null。
     * @param {string} raw @param {string} base
     * @returns {Promise<string | null>}
     */
    url(raw, base) {
      const value = raw.trim();
      if (!value) return Promise.resolve(null);
      if (/^data:/i.test(value)) return Promise.resolve(value);
      // 存檔時的 blob: 網址早就失效了。
      if (/^blob:/i.test(value)) return Promise.resolve(null);
      const found = locate(value, base);
      if (!found) return Promise.resolve(null);
      let pending = cache.get(found.href);
      if (!pending) {
        pending = blobOf(found).then(async (blob) => {
          if (!blob) return null;
          if (inline) return dataUrlOf(blob);
          const path = `r/${files.size + 1}.${PART_EXTENSIONS[blob.type] ?? "bin"}`;
          files.set(path, blob);
          return path;
        });
        cache.set(found.href, pending);
      }
      return pending;
    },
    /** 一個網址的檔案本身（網頁指定的封面）；用不了時是 null。 @param {string} raw @param {string} base @returns {Promise<Blob | null>} */
    async blob(raw, base) {
      const value = raw.trim();
      if (!value) return null;
      if (/^data:/i.test(value)) return dataUrlBlob(value);
      const found = locate(value, base);
      return found ? await blobOf(found) : null;
    },
    /** 樣式表的文字與它自己的網址（裡面的相對路徑照它算）。 @param {string} raw @param {string} base */
    async css(raw, base) {
      const value = raw.trim();
      if (!value) return null;
      if (/^data:/i.test(value)) return { text: dataUrlText(value), base };
      const found = locate(value, base);
      if (!found) return null;
      const blob = await blobOf(found);
      if (!blob) return null;
      return { text: decodeText(new Uint8Array(await blob.arrayBuffer()), found.part?.charset ?? "utf-8"), base: found.href };
    },
  };
}

/** @typedef {ReturnType<typeof createResolver>} Resolver */

// ---- 樣式表 ----

const IMPORT_RE = /@import\s+(?:url\(\s*(?:"([^"]*)"|'([^']*)'|([^)\s]*))\s*\)|"([^"]*)"|'([^']*)')([^;]*);?/gi;
const URL_RE = /url\(\s*(?:"((?:[^"\\\n]|\\.)*)"|'((?:[^'\\\n]|\\.)*)'|([^)"'\s]*))\s*\)/gi;
/** 用不了的網址換成空的 data:，宣告照樣有效（@font-face 的 src 會試下一個）。 */
const EMPTY_URL = 'url("data:,")';

/**
 * 換掉樣式表裡的網址、展開 CSS 的 import 規則。top：封面裡網頁本身的樣式（不是網頁裡 shadow DOM 的）：
 * 網頁放在 SVG 的 foreignObject 裡，:root 是 <svg>，換成 html；:host 讓它對不到東西。
 * @param {string} text @param {string} base @param {Resolver} r @param {{ top: boolean; depth?: number }} opts
 * @returns {Promise<string>}
 */
async function processCss(text, base, r, opts) {
  const depth = opts.depth ?? 0;
  // @import 先換成記號，換網址那一輪才不會碰到它。
  /** @type {Promise<string>[]} */
  const imports = [];
  const css = text.replace(IMPORT_RE, (_, a, b, c, d, e, media) => {
    const raw = a ?? b ?? c ?? d ?? e ?? "";
    const list = String(media).trim();
    imports.push(
      depth >= 4
        ? Promise.resolve("")
        : r.css(raw, base).then(async (got) => {
            if (!got) return "";
            const inner = await processCss(got.text, got.base, r, { top: opts.top, depth: depth + 1 });
            return list && !/^(layer|supports)\b/i.test(list) ? `@media ${list}{${inner}}` : inner;
          }),
    );
    return `/*hv-import-${imports.length - 1}*/`;
  });

  /** @type {Array<{ start: number; end: number; raw: string }>} */
  const found = [];
  for (const m of css.matchAll(URL_RE)) {
    const start = m.index ?? 0;
    const raw = (m[1] ?? m[2] ?? m[3] ?? "").replace(/\\(.)/g, "$1");
    found.push({ start, end: start + m[0].length, raw });
  }
  // #片段（SVG 濾鏡、clip-path）照原樣。
  const urls = await Promise.all(found.map((f) => (f.raw.trim().startsWith("#") ? Promise.resolve(undefined) : r.url(f.raw, base))));
  let out = "";
  let at = 0;
  found.forEach((f, i) => {
    const url = urls[i];
    out += css.slice(at, f.start);
    const same = url === undefined || url === f.raw.trim() || (url === null && r.keep);
    out += same ? css.slice(f.start, f.end) : url ? `url("${url}")` : EMPTY_URL;
    at = f.end;
  });
  out += css.slice(at);
  const imported = await Promise.all(imports);
  out = out.replace(/\/\*hv-import-(\d+)\*\//g, (_, i) => imported[Number(i)] ?? "");
  if (opts.top) out = out.replace(/:root\b/g, "html").replace(/:host(-context)?(\([^)]*\))?/g, ":not(*)");
  return out;
}

// ---- 清理（封面） ----

const REMOVED_TAGS = new Set(["script", "noscript", "object", "embed", "applet", "param", "base", "meta", "portal", "fencedframe", "frameset"]);
const FRAME_TAGS = new Set(["iframe", "frame"]);
/**
 * 會執行、會跳走、會跑到最上層蓋住 App，或會搶焦點的屬性。popover 本身留著（沒打開時是隱藏的），
 * 拿掉的是打開它（和 <dialog>）的 popovertarget、command。
 */
const DROPPED_ATTRS = new Set([
  "autofocus",
  "popovertarget",
  "popovertargetaction",
  "command",
  "commandfor",
  "interestfor",
  "ping",
  "srcdoc",
  "action",
  "formaction",
  "http-equiv",
  "nonce",
  "integrity",
]);
const URL_ATTRS = new Set(["href", "xlink:href", "src", "srcset", "poster", "background", "data", "cite", "lowsrc", "dynsrc", "longdesc"]);
const UNSAFE_URL = /^(javascript|vbscript|data:text\/html)/i;

/** 內嵌框架的佔位：大小、id、class、style 照原本的，版面不會塌。 @param {Element} el */
function framePlaceholder(el) {
  const box = el.ownerDocument.createElement("div");
  for (const name of ["id", "class", "style"]) {
    const value = el.getAttribute(name);
    if (value) box.setAttribute(name, value);
  }
  box.setAttribute("data-hv-frame", "");
  const size = (/** @type {string | null} */ value, /** @type {string} */ fallback) => (value && /^\d+$/.test(value) ? `${value}px` : value || fallback);
  box.style.width ||= size(el.getAttribute("width"), "300px");
  box.style.height ||= size(el.getAttribute("height"), "150px");
  box.textContent = "內嵌的框架沒有顯示";
  return box;
}

/** 拿掉會執行或會跳走的東西（template 的內容一起）。 @param {Document | DocumentFragment} root */
function sanitize(root) {
  for (const el of Array.from(root.querySelectorAll("*"))) {
    const tag = el.localName;
    if (REMOVED_TAGS.has(tag)) {
      el.remove();
      continue;
    }
    if (FRAME_TAGS.has(tag)) {
      el.replaceWith(framePlaceholder(el));
      continue;
    }
    // SVG 動畫可以把 href 改成 javascript:。
    if ((tag === "set" || tag.startsWith("animate")) && /href/i.test(el.getAttribute("attributeName") ?? "")) {
      el.remove();
      continue;
    }
    for (const attr of Array.from(el.attributes)) {
      const name = attr.name.toLowerCase();
      if (name.startsWith("on")) {
        el.removeAttributeNode(attr);
      } else if (DROPPED_ATTRS.has(name)) {
        el.removeAttributeNode(attr);
      } else if (URL_ATTRS.has(name) && UNSAFE_URL.test(attr.value.replace(/[\s\u0000-\u001f]/g, ""))) {
        el.removeAttributeNode(attr);
      }
    }
    if (tag === "video" || tag === "audio") el.removeAttribute("autoplay");
    if (tag === "template") sanitize(/** @type {HTMLTemplateElement} */ (el).content);
  }
}

/** srcset 的每一項；data: 網址裡有逗號，不能直接用逗號切。 @param {string} text */
function parseSrcset(text) {
  /** @type {Array<{ url: string; descriptor: string }>} */
  const out = [];
  let i = 0;
  while (i < text.length) {
    while (i < text.length && /[\s,]/.test(text[i])) i++;
    if (i >= text.length) break;
    let j = i;
    while (j < text.length && !/\s/.test(text[j])) j++;
    let url = text.slice(i, j);
    i = j;
    let descriptor = "";
    if (url.endsWith(",")) {
      url = url.replace(/,+$/, "");
    } else {
      let k = text.indexOf(",", i);
      if (k === -1) k = text.length;
      descriptor = text.slice(i, k).trim();
      i = k + 1;
    }
    out.push({ url, descriptor });
  }
  return out;
}

/**
 * 換掉網頁裡所有的資源網址，<link rel=stylesheet> 換成 <style>。框架（r.keep）裡用不了的照原樣留著，
 * 連結換成原網頁的網址（網頁在框架裡的網址不是原本的）。
 * @param {Document | DocumentFragment} root @param {string} base @param {Resolver} r @param {boolean} top
 */
async function rewriteResources(root, base, r, top) {
  const { inline } = r;
  /** @type {Promise<unknown>[]} */
  const tasks = [];
  /** @param {Element} el @param {string} name */
  const setUrl = (el, name) => {
    const value = el.getAttribute(name);
    if (value === null) return;
    tasks.push(
      r.url(value, base).then((url) => {
        if (url) el.setAttribute(name, url);
        else if (!r.keep) el.removeAttribute(name);
      }),
    );
  };
  for (const el of Array.from(root.querySelectorAll("*"))) {
    const tag = el.localName;
    if (tag === "template") {
      tasks.push(rewriteResources(/** @type {HTMLTemplateElement} */ (el).content, base, r, false));
      continue;
    }
    if (r.keep && (tag === "a" || tag === "area")) {
      const href = el.getAttribute("href");
      if (href !== null && !href.trim().startsWith("#")) {
        try {
          el.setAttribute("href", new URL(href, base).href);
        } catch {
          /* 照原樣 */
        }
      }
    }
    if (tag === "link") {
      const rel = ` ${(el.getAttribute("rel") ?? "").toLowerCase()} `;
      if (!rel.includes(" stylesheet ") || rel.includes(" alternate ")) {
        if (!r.keep) el.remove();
        continue;
      }
      tasks.push(
        r.css(el.getAttribute("href") ?? "", base).then(async (got) => {
          if (!got) return r.keep ? undefined : el.remove();
          const style = el.ownerDocument.createElement("style");
          const media = el.getAttribute("media");
          if (media) style.setAttribute("media", media);
          style.textContent = await processCss(got.text, got.base, r, { top });
          el.replaceWith(style);
        }),
      );
      continue;
    }
    if (tag === "style") {
      tasks.push(processCss(el.textContent ?? "", base, r, { top }).then((css) => (el.textContent = css)));
    }
    const inlineStyle = el.getAttribute("style");
    if (inlineStyle && /url\(/i.test(inlineStyle)) {
      tasks.push(processCss(inlineStyle, base, r, { top: false }).then((css) => el.setAttribute("style", css)));
    }
    if (el.hasAttribute("background")) setUrl(el, "background");
    switch (tag) {
      case "img":
      case "source": {
        const srcset = el.getAttribute("srcset");
        if (srcset !== null) {
          if (inline) {
            // 封面只要一張：留 src，沒有 src 時用 srcset 的第一張。
            el.removeAttribute("srcset");
            const first = parseSrcset(srcset)[0];
            if (tag === "img" && !el.hasAttribute("src") && first) el.setAttribute("src", first.url);
          } else {
            tasks.push(
              Promise.all(parseSrcset(srcset).map(async (c) => ({ url: (await r.url(c.url, base)) ?? (r.keep ? c.url : null), descriptor: c.descriptor }))).then((list) => {
                const kept = list.filter((c) => c.url).map((c) => (c.descriptor ? `${c.url} ${c.descriptor}` : c.url));
                if (kept.length > 0) el.setAttribute("srcset", kept.join(", "));
                else el.removeAttribute("srcset");
              }),
            );
          }
        }
        setUrl(el, "src");
        if (inline) el.removeAttribute("loading");
        break;
      }
      case "video":
      case "audio":
      case "track":
        // 封面畫不出影片，不用把整個影片讀成 data:。
        if (inline) el.removeAttribute("src");
        else setUrl(el, "src");
        if (tag === "video") setUrl(el, "poster");
        break;
      case "input":
        setUrl(el, "src");
        break;
      case "image":
      case "feImage":
        setUrl(el, "href");
        setUrl(el, "xlink:href");
        break;
      case "use":
        // 同一頁的 #id 才用得了。
        if (inline) for (const name of ["href", "xlink:href"]) if (!(el.getAttribute(name) ?? "#").trim().startsWith("#")) el.removeAttribute(name);
        break;
    }
  }
  await Promise.all(tasks);
}

/** MHTML 在框架裡的檔案：主要的 HTML（index.html）與它用到的段落。會改到 source.doc。 @param {Source} source */
async function mhtmlFiles(source) {
  const r = createResolver(source, "frame");
  await rewriteResources(source.doc, source.base, r, false);
  const root = source.doc.documentElement;
  /** @type {Record<string, string | Blob>} */
  const files = Object.fromEntries(r.files);
  files["index.html"] = `<!doctype html>
${root.outerHTML}`;
  return files;
}

// ---- 文字摘錄：閱讀排版 ----

/** 摘錄來的網頁（核心記在 metadata.page_url）。 @param {HoardItemDetail} item */
const clipUrl = (item) => httpUrl(typeof item.metadata.page_url === "string" ? item.metadata.page_url : null);

/**
 * 閱讀排版的顏色與字型：畫面上照 App 的主題（appTheme），封面是透明底、中性灰（COVER_THEME）。
 * @typedef {{ bg: string; text: string; dim: string; link: string; line: string; code: string; font: string; mono: string; size: string; scheme: string }} ReadingTheme
 */

/** 現在的主題。框架裡讀不到 App 的 CSS 變數，照現在的值寫進去（換主題後重新打開才跟上）。 @returns {ReadingTheme} */
function appTheme() {
  const css = getComputedStyle(document.documentElement);
  // 值寫進 <style>，不讓它結束這段樣式。
  const value = (/** @type {string} */ name, /** @type {string} */ fallback) => css.getPropertyValue(name).replace(/[<>{};]/g, "").trim() || fallback;
  return {
    bg: value("--hoard-bg", "#111111"),
    text: value("--hoard-text", "#ededed"),
    dim: value("--hoard-text-dim", "#a8a8a8"),
    link: value("--hoard-accent", "#e5e5e5"),
    line: value("--hoard-border", "#2e2e2e"),
    code: value("--hoard-surface", "#1a1a1a"),
    font: value("--hoard-font", "system-ui, sans-serif"),
    mono: value("--hoard-font-mono", "ui-monospace, monospace"),
    size: value("--hoard-font-size", "16px"),
    scheme: value("color-scheme", "normal"),
  };
}

/** @type {ReadingTheme} */
const COVER_THEME = {
  bg: "transparent",
  text: "#8a8a8a",
  dim: "#8a8a8a",
  link: "#8a8a8a",
  line: "rgba(138, 138, 138, 0.4)",
  code: "rgba(138, 138, 138, 0.12)",
  font: '"Segoe UI", "Microsoft JhengHei", "Noto Sans TC", system-ui, sans-serif',
  mono: 'Consolas, "Cascadia Mono", ui-monospace, monospace',
  size: "16px",
  scheme: "normal",
};

/** @param {ReadingTheme} t */
function readingCss(t) {
  return `
:root { color-scheme: ${t.scheme}; }
html { background: ${t.bg}; }
body { margin: 0; padding: 2.5rem 1.5rem 4rem; color: ${t.text}; font-family: ${t.font}; font-size: calc(${t.size} * 1.0625); line-height: 1.8; overflow-wrap: anywhere; }
.hc-read { max-width: 42em; margin: 0 auto; }
.hc-read > :first-child { margin-top: 0; }
h1, h2, h3, h4, h5, h6 { margin: 1.6em 0 0.6em; font-weight: 600; line-height: 1.4; }
h1 { font-size: 1.6em; }
h2 { font-size: 1.35em; }
h3 { font-size: 1.15em; }
h4, h5, h6 { font-size: 1em; }
p, ul, ol, dl, blockquote, pre, table, figure { margin: 0 0 1em; }
ul, ol { padding-left: 1.5em; }
li + li { margin-top: 0.25em; }
a { color: ${t.link}; text-decoration: underline; text-decoration-color: ${t.line}; text-underline-offset: 0.2em; }
img, video { max-width: 100%; height: auto; border-radius: 4px; }
svg { max-width: 100%; fill: currentcolor; }
figure { margin-inline: 0; }
figcaption { margin-top: 0.5em; color: ${t.dim}; font-size: 0.875em; }
blockquote { margin-inline: 0; padding-left: 1em; border-left: 3px solid ${t.line}; color: ${t.dim}; }
code, kbd, samp, pre { font-family: ${t.mono}; font-size: 0.9em; }
code { padding: 0.1em 0.35em; border-radius: 4px; background: ${t.code}; }
pre { padding: 0.8em 1em; border-radius: 6px; background: ${t.code}; line-height: 1.6; white-space: pre-wrap; }
pre code { padding: 0; background: none; font-size: inherit; }
hr { margin: 2em 0; border: none; border-top: 1px solid ${t.line}; }
table { display: block; max-width: 100%; overflow-x: auto; border-collapse: collapse; }
th, td { padding: 0.4em 0.75em; border: 1px solid ${t.line}; text-align: start; vertical-align: top; }
th { font-weight: 600; }
.hc-missing { display: inline-block; padding: 0 0.5em; border: 1px dashed ${t.line}; border-radius: 4px; color: ${t.dim}; font-size: 0.875em; }
`;
}

/** 屬性裡排版用的（顏色、大小、對齊），閱讀排版不要；class 也拿掉（摘錄沒有樣式表，免得撞到閱讀排版的）。 */
const READING_DROPPED = ["class", "color", "bgcolor", "background", "face", "size", "align", "valign", "border", "cellpadding", "cellspacing", "nowrap"];
/** 網站的按鈕、輸入框：閱讀時是雜訊。勾選框留著（待辦清單），只是不能按。 */
const READING_CONTROLS = "button, select, textarea, input:not([type=checkbox])";

/** 樣式把它藏起來的元素（display: none、只給螢幕閱讀器的 1px 文字）：拿掉樣式就會露出來。 @param {CSSStyleDeclaration} style */
function hiddenByStyle(style) {
  if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return true;
  const tiny = (/** @type {string} */ value) => /^[01](px)?$/.test(value);
  return (tiny(style.width) && tiny(style.height)) || /^rect\(\s*0/.test(style.clip) || /^inset\(\s*50%/.test(style.clipPath);
}

/**
 * 閱讀排版留下的行內樣式：粗體、斜體、底線與刪除線、上下標、置中靠右、保留換行（純文字的摘錄靠它）；
 * SVG 留寬高（網站的小圖示靠樣式表定大小，拿掉會撐滿一欄）與填色、線條（顏色換成跟文字），圖片留寬度（高度照比例）。
 * @param {Element} el
 */
function readingStyle(el) {
  const style = /** @type {HTMLElement} */ (el).style;
  if (!style) return "";
  /** @type {string[]} */
  const kept = [];
  const weight = style.fontWeight;
  if (weight === "bold" || weight === "bolder" || Number(weight) >= 600) kept.push("font-weight: 600");
  if (/italic|oblique/.test(style.fontStyle)) kept.push("font-style: italic");
  const line = style.textDecorationLine || style.textDecoration;
  const marks = ["underline", "line-through"].filter((mark) => line.includes(mark));
  if (marks.length > 0) kept.push(`text-decoration-line: ${marks.join(" ")}`);
  if (style.verticalAlign === "super" || style.verticalAlign === "sub") kept.push(`vertical-align: ${style.verticalAlign}; font-size: 0.75em`);
  if (style.textAlign === "center" || style.textAlign === "right") kept.push(`text-align: ${style.textAlign}`);
  if (/^pre/.test(style.whiteSpace)) kept.push(`white-space: ${style.whiteSpace}`);
  else if (/^preserve/.test(style.getPropertyValue("white-space-collapse"))) kept.push(`white-space-collapse: ${style.getPropertyValue("white-space-collapse")}`);
  if (el.localName === "svg") {
    for (const name of ["width", "height"]) if (style.getPropertyValue(name)) kept.push(`${name}: ${style.getPropertyValue(name)}`);
  } else if (el.localName === "img" && style.width && style.width !== "auto") kept.push(`width: ${style.width}`);
  // SVG 圖示的填色、線條：有沒有要留著（線條圖示是 fill: none），顏色一律跟文字。
  if (el.closest("svg")) {
    for (const name of ["fill", "stroke"]) {
      const value = style.getPropertyValue(name);
      if (value) kept.push(`${name}: ${/^(none|currentcolor|url\()/i.test(value) ? value : "currentcolor"}`);
    }
    if (style.strokeWidth) kept.push(`stroke-width: ${style.strokeWidth}`);
  }
  return kept.join("; ");
}

/** 圖片沒有寫進摘錄（下載失敗）時的佔位：替代文字（表情符號圖片的就是那個字），沒有就說明。 @param {Element} el @param {string} what */
function missingNote(el, what) {
  const note = el.ownerDocument.createElement("span");
  note.className = "hc-missing";
  note.textContent = el.getAttribute("alt")?.trim() || what;
  return note;
}

/**
 * 文字摘錄的閱讀排版：只留內容與基本的強調（readingStyle），字型、大小、顏色照 theme，置中一欄。
 * 網路上的圖片與內嵌框架框架裡載入不了，換成佔位；程式、事件屬性照 sanitize 拿掉。
 * @param {string} text 摘錄檔的原始碼 @param {ReadingTheme} theme
 */
function readingPage(text, theme) {
  const doc = new DOMParser().parseFromString(text, "text/html");
  const body = doc.body;
  for (const el of Array.from(body.querySelectorAll("style, link, title"))) el.remove();
  for (const el of Array.from(body.querySelectorAll("*"))) {
    if (!el.isConnected) continue;
    const style = /** @type {HTMLElement} */ (el).style;
    if (style && hiddenByStyle(style)) {
      el.remove();
      continue;
    }
    if (el.matches(READING_CONTROLS)) {
      el.remove();
      continue;
    }
    if (el.localName === "iframe" || el.localName === "frame") {
      el.replaceWith(missingNote(el, "內嵌的框架沒有顯示"));
      continue;
    }
    if (el.localName === "img" && !(el.getAttribute("src") ?? "").trim().startsWith("data:")) {
      el.replaceWith(missingNote(el, "圖片沒有存下來"));
      continue;
    }
    const kept = readingStyle(el);
    for (const name of READING_DROPPED) el.removeAttribute(name);
    if (kept) el.setAttribute("style", kept);
    else el.removeAttribute("style");
    if (el.localName === "input") el.setAttribute("disabled", "");
  }
  sanitize(doc);
  return `<!doctype html><html><head><meta charset="utf-8"><style>${readingCss(theme)}</style></head><body><article class="hc-read">
${body.innerHTML}
</article></body></html>`;
}

/** 摘錄在框架裡：閱讀排版頂替原檔（同一個資料夾）；原版照原樣。 @param {string} path @param {string} text */
function clipSpec(path, text) {
  const spec = localSpec(path);
  return settings.clipView === "original" ? spec : { ...spec, files: { [spec.entry]: readingPage(text, appTheme()) } };
}

// ---- 掛到畫面上：沙盒框架 ----

/** 封面裡內嵌框架的佔位。 */
const FRAME_CSS = `
[data-hv-frame] { display: inline-flex; align-items: center; justify-content: center; box-sizing: border-box; max-width: 100%;
  border: 1px dashed #c4c4c4; background: #f5f5f5; color: #8a8a8a; font: 12px/1.4 system-ui, sans-serif; }
`;

/** 本機網頁在框架裡：讀它所在的資料夾。 @param {string} path */
function localSpec(path) {
  const at = Math.max(path.lastIndexOf("\\"), path.lastIndexOf("/"));
  // 磁碟根目錄（C:\a.html）留著斜線，"C:" 不是資料夾。
  return { dir: path.slice(0, at <= 2 ? at + 1 : at), entry: path.slice(at + 1) };
}

/** 框架回報的數字：網頁的程式也送得出這種訊息，只拿來顯示。 @param {unknown} value */
const countOf = (value) => (typeof value === "number" && Number.isFinite(value) ? Math.max(0, Math.min(Math.floor(value), 99_999)) : 0);

/** @typedef {{ network: number; scripts: number }} Blocked */

/**
 * 把網頁放進 box（沙盒框架）：本機網頁讀它所在的資料夾，MHTML 拆成框架裡的檔案，元件包成置中的一頁，
 * 文字摘錄照設定用閱讀排版或原版（不執行程式）。
 * 框架載入前顯示骨架，讀不到時 box 裡顯示原因。onBlocked：網頁換頁、或有東西被擋下時呼叫。離開時呼叫 cancel。
 * @param {HTMLElement} box @param {HoardItemFile} file
 * @param {{ title: string; display: Display; onBlocked?: (blocked: Blocked) => void }} opts
 */
function showPage(box, file, opts) {
  let cancelled = false;
  /** @type {HoardFrameHandle | null} */
  let frame = null;
  const { display } = opts;
  const done = (async () => {
    if (file.missing) throw new Error("找不到檔案");
    if ((file.size ?? 0) > MAX_SHOW) throw new Error(`網頁檔太大（${formatSize(file.size ?? 0)}），請用右鍵選單的「用預設程式開啟」`);
    await settingsLoaded;
    const spec = MHTML_EXTENSIONS.has(extOf(file.path))
      ? { entry: "index.html", files: await mhtmlFiles(await loadSource(file)) }
      : display.kind === "component"
        ? componentSpec(file.path, display.text)
        : display.kind === "clip"
          ? clipSpec(file.path, display.text)
          : localSpec(file.path);
    if (cancelled) return null;
    const scripts = display.kind !== "clip" && settings.scripts;
    const handle = hoard.mountFrame(box, { ...spec, scripts, script: "frame.js", title: opts.title });
    frame = handle;
    // 載入完才顯示：框架一開始是一張白色的空白頁。
    handle.element.style.visibility = "hidden";
    handle.on((message) => {
      if (message && message.kind === "blocked") opts.onBlocked?.({ network: countOf(message.network), scripts: countOf(message.scripts) });
    });
    await handle.loaded;
    if (cancelled) return null;
    handle.element.style.visibility = "";
    reveal(handle.element, /** @type {HTMLElement | null} */ (box.querySelector(".hv-skeleton")));
    return handle;
  })();
  done.catch((err) => {
    if (cancelled) return;
    frame?.close();
    box.replaceChildren(errorNote(err));
  });
  return {
    done,
    cancel() {
      cancelled = true;
      frame?.close();
    },
  };
}

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/**
 * 骨架換成載入好的框架（App 的 docs/conventions.md〈動畫〉）：骨架已經出現過（它等 200ms 才淡入）時框架淡入 180ms、
 * 骨架同時淡出；很快就載入、骨架還沒出現時框架直接淡入 120ms。沒有骨架（元件牆滑過時開的框架）也是淡入 120ms。
 * @param {HTMLElement} frame @param {HTMLElement | null} bones
 */
function reveal(frame, bones) {
  if (!motionOn()) return void bones?.remove();
  const seen = bones ? parseFloat(getComputedStyle(bones).opacity) > 0.05 : false;
  frame.animate([{ opacity: 0 }, { opacity: 1 }], { duration: seen ? 180 : 120, easing: EASE_OUT });
  if (!bones || !seen) return void bones?.remove();
  void bones.animate([{ opacity: getComputedStyle(bones).opacity }, { opacity: 0 }], { duration: 180, easing: EASE_IN, fill: "forwards" }).finished.then(
    () => bones.remove(),
    () => bones.remove(),
  );
}

/** @param {unknown} err */
function errorNote(err) {
  return hoard.el("div", { class: "hv-error" }, [hoard.icon("file-exclamation-point", { size: 20 }), hoard.el("p", {}, [messageOf(err)])]);
}

/** 讀檔時的佔位：一頁網頁的形狀。 */
function skeleton() {
  return hoard.el(
    "div",
    { class: "hv-skeleton" },
    ["w-40", "w-90", "w-75", "w-85", "w-60"].map((width) => hoard.el("div", { class: `hv-skeleton-line hv-${width}` })),
  );
}

// ---- 快速預覽 ----

/** 焦點在 App 時，這些鍵交給框架捲網頁（焦點在框架裡時網頁自己處理）。 */
const SCROLL_KEYS = new Set(["ArrowDown", "ArrowUp", "PageDown", "PageUp", "Home", "End"]);

/** @param {HTMLElement} root @param {HoardItemSummary} item @param {HoardQuickLookCtx} ctx */
function renderQuickLook(root, item, ctx) {
  let alive = true;
  /** @type {ReturnType<typeof showPage> | null} */
  let view = null;
  /** @type {HoardFrameHandle | null} */
  let frame = null;
  const box = hoard.el("div", { class: "hv-frame hv-ql-frame" }, [skeleton()]);
  const shell = hoard.el(
    "div",
    {
      class: "hv-ql",
      onclick: (event) => {
        if (event.target === shell) ctx.close();
      },
    },
    [box],
  );
  root.append(shell);
  // ↑ ↓、PageUp／PageDown、Home／End 捲網頁（這件只有一個檔案，不用換張）。
  ctx.onKey((event) => {
    if (!frame || event.ctrlKey || event.altKey || event.metaKey || !SCROLL_KEYS.has(event.key)) return false;
    frame.send({ kind: "scroll", key: event.key });
    return true;
  });
  hoard.items.get(item.id).then(
    async (detail) => {
      if (!alive) return;
      const file = htmlFileOf(detail);
      if (!file) return box.replaceChildren(errorNote("這件作品不是網頁檔"));
      // 讀不到原始碼時當成網頁，讀不到的原因由框架那邊顯示。
      const display = await displayOf(item.id, file).catch(() => AS_PAGE);
      if (!alive) return;
      view = showPage(box, file, { title: item.title, display });
      view.done.then(
        (shown) => {
          if (alive) frame = shown;
        },
        () => {
          /* 原因已經顯示在框裡 */
        },
      );
    },
    (err) => alive && box.replaceChildren(errorNote(err)),
  );
  return () => {
    alive = false;
    view?.cancel();
  };
}


// ---- 詳情頁 ----

/**
 * 詳情頁只畫網頁本身。頁首是 App 的（conventions〈頁首〉）：摘錄的閱讀排版／原版、「改用網頁標題」、
 * 元件的「複製程式碼」與沒有載入、沒有執行的提示放進 `ctx.header.actions`，存下來的網頁記的網址交給
 * `ctx.header.setSourceUrl`，由頁首的「開啟原始頁面」開。
 * @param {HTMLElement} root @param {HoardItemDetail} item @param {HoardDetailCtx} ctx
 */
function renderDetail(root, item, ctx) {
  const file = htmlFileOf(item);
  if (!file) return;
  let alive = true;
  /** 網頁裡的資訊；還沒讀到、讀不了、摘錄是 null。 @type {PageInfo | null} */
  let page = null;
  /** @type {Blocked} */
  let blocked = { network: 0, scripts: 0 };
  /** 怎麼顯示；還沒讀到是 null。 @type {Display | null} */
  let display = null;
  const box = hoard.el("div", { class: "hv-frame hv-detail-frame" }, [skeleton()]);
  root.append(hoard.el("div", { class: "hv-detail" }, [box]));
  /** 文字摘錄換成閱讀排版或原版：記在設定（快速預覽也照它），框架重開。 @param {ClipView} mode */
  const switchClipView = (mode) => {
    if (!display || mode === settings.clipView) return;
    updateSettings({ clipView: mode });
    redraw();
    show(display);
  };
  const redraw = () => {
    if (alive) ctx.header.actions.replaceChildren(...headerActions(item, page, blocked, display, switchClipView));
  };
  /** @type {ReturnType<typeof showPage> | null} */
  let view = null;
  /** @param {Display} shown */
  const show = (shown) => {
    view?.cancel();
    blocked = { network: 0, scripts: 0 };
    box.replaceChildren(skeleton());
    view = showPage(box, file, {
      title: item.title,
      display: shown,
      onBlocked: (counts) => {
        blocked = counts;
        redraw();
      },
    });
  };
  void displayOf(item.id, file)
    .catch(() => AS_PAGE)
    .then((got) => {
      if (!alive) return;
      display = got;
      redraw();
      show(got);
      // 網頁的資訊在這裡另外讀：框架裡的網頁碰不到 App。摘錄的來源記在作品上（page_url），App 自己會開，不用讀。
      if (got.kind === "clip") return;
      pageInfoOf(file).then(
        (info) => {
          if (!alive) return;
          page = info;
          if (info?.url) ctx.header.setSourceUrl(info.url);
          redraw();
        },
        (err) => console.warn("[html] 讀不到網頁資訊：", item.id, err),
      );
    });
  // 框撐到詳情頁底部，網頁在框裡捲，像一個瀏覽器分頁；詳情頁的大小改變時重算。
  const scroller = scrollParent(box);
  const fit = () => {
    if (!scroller) return;
    const top = box.getBoundingClientRect().top - scroller.getBoundingClientRect().top + scroller.scrollTop;
    box.style.height = `${Math.max(MIN_DETAIL_HEIGHT, Math.floor(scroller.clientHeight - top))}px`;
  };
  const resize = new ResizeObserver(fit);
  if (scroller) resize.observe(scroller);
  fit();
  return () => {
    alive = false;
    resize.disconnect();
    view?.cancel();
  };
}

/** 最近的會捲動的上層。 @param {HTMLElement} el */
function scrollParent(el) {
  for (let node = el.parentElement; node; node = node.parentElement) {
    if (/(auto|scroll)/.test(getComputedStyle(node).overflowY)) return node;
  }
  return null;
}

/** 詳情頁要的網頁資訊（網址、網頁標題）；讀不了的檔案是 null。 @param {HoardItemFile} file @returns {Promise<PageInfo | null>} */
async function pageInfoOf(file) {
  if (file.missing || (file.size ?? 0) > MAX_SHOW) return null;
  return pageInfo(await loadSource(file));
}

/** 文字摘錄的「閱讀排版／原版」切換。 @param {(mode: ClipView) => void} onSwitch */
function clipViewSwitch(onSwitch) {
  /** @type {Array<[ClipView, string, string]>} */
  const modes = [
    ["reading", "閱讀排版", "字型、顏色跟 App 一樣，置中一欄"],
    ["original", "原版", "照複製時的樣子"],
  ];
  return hoard.el(
    "div",
    { class: "hv-view-kinds", role: "group", "aria-label": "摘錄的顯示方式" },
    modes.map(([mode, label, hint]) =>
      hoard.el(
        "button",
        { class: "hv-view-kind", type: "button", title: hint, "aria-pressed": String(settings.clipView === mode), onclick: () => onSwitch(mode) },
        [label],
      ),
    ),
  );
}

/**
 * 詳情頁頁首右側（`ctx.header.actions`）：摘錄的閱讀排版／原版切換、網頁標題和作品標題不同時的「改用網頁標題」、
 * 元件的「複製程式碼」，以及沒有載入、沒有執行的東西（圖示，說明在 tooltip）。作品標題與「開啟原始頁面」是 App 的。
 * @param {HoardItemDetail} item @param {PageInfo | null} page @param {Blocked} blocked
 * @param {Display | null} display 還不知道是 null
 * @param {(mode: ClipView) => void} onClipView
 */
function headerActions(item, page, blocked, display, onClipView) {
  const clip = display?.kind === "clip";
  const component = display?.kind === "component" ? display.text : null;
  /** @type {Node[]} */
  const actions = [];
  if (clip) actions.push(clipViewSwitch(onClipView));
  // 摘錄的 <title> 就是作品標題，不比。
  const pageTitle = !clip && page?.title && page.title !== item.title ? page.title : "";
  if (pageTitle) {
    actions.push(
      hoard.el("button", { class: "hoard-button", type: "button", title: `作品標題改成「${pageTitle}」`, onclick: () => void useTitle(item, pageTitle) }, [
        hoard.icon("text-cursor-input", { size: 13 }),
        "改用網頁標題",
      ]),
    );
  }
  // 元件與網頁的切換在作品的右鍵選單（不常用，不佔頁首）。
  if (component !== null) {
    actions.push(
      hoard.el("button", { class: "hoard-button", type: "button", title: "複製元件的原始碼", onclick: () => copyCode(component) }, [
        hoard.icon("copy", { size: 13 }),
        "複製程式碼",
      ]),
    );
  }
  /** @type {string[]} */
  const notes = [];
  if (blocked.scripts > 0) notes.push("網頁的程式沒有執行");
  if (blocked.network > 0) notes.push(`${blocked.network} 個網路上的資源沒有載入`);
  if (notes.length > 0) {
    const why = clip
      ? "摘錄在隔離的框架裡顯示：連不了網，也碰不到 hoard"
      : settings.scripts
        ? "網頁在隔離的框架裡執行：連不了網，也碰不到 hoard"
        : "網頁在隔離的框架裡顯示：不執行網頁的程式（插件設定裡可以打開），也連不了網";
    actions.push(
      hoard.el("span", { class: "hv-blocked", role: "img", "aria-label": notes.join("、"), title: `${notes.join("、")}
${why}` }, [
        hoard.icon("shield-off", { size: 15 }),
      ]),
    );
  }
  return actions;
}

/** @param {HoardItemDetail} item @param {string} title */
async function useTitle(item, title) {
  const previous = item.title;
  try {
    await hoard.items.update([item.id], { title });
    hoard.toast("已改用網頁標題", {
      action: {
        label: "復原",
        run: () => void hoard.items.update([item.id], { title: previous }).catch((err) => hoard.toast(messageOf(err), { kind: "error" })),
      },
    });
  } catch (err) {
    hoard.toast(messageOf(err), { kind: "error" });
  }
}

hoard.registerPresenter({
  sources: ["local"],
  accepts: (item) => item.file_count === 1 && isHtmlItem(item),
  detail: renderDetail,
  quickLook: renderQuickLook,
});

// ---- 篩選 ----

hoard.registerFilter({ id: "site", label: "網站", icon: "globe", key: "site" });
hoard.registerFilter({ id: "kind", label: "網頁類型", icon: "component", key: "kind" });

// ---- 封面 ----

/** @param {HTMLCanvasElement} canvas @param {string} type @param {number} [quality] @returns {Promise<Blob>} */
function canvasBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => {
    try {
      canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("無法輸出圖片"))), type, quality);
    } catch (err) {
      reject(err); // canvas 被鎖住（SecurityError）
    }
  });
}

/** XML 的屬性名稱（Vue 的 @click、:class 不是，留著整張 SVG 會解析失敗）。 */
const XML_NAME = /^[A-Za-z_][\w.-]*(:[A-Za-z_][\w.-]*)?$/;

/**
 * 網頁第一屏：照 size 排版（網頁寬 1024px，元件、摘錄 480px），用 SVG foreignObject 畫進 canvas。SVG 圖片裡不執行程式、
 * 只讀得到 data:，所以先清掉程式與內嵌框架、資源全部換成 data:。會改到 source.doc。
 * 底色：網頁、元件沒寫底色時跟瀏覽器一樣是白的；摘錄的閱讀排版是 null（透明）。
 * @param {Source} source @param {{ width: number; height: number }} size @param {string | null} [background]
 */
async function pageCover(source, size, background = "#fff") {
  sanitize(source.doc);
  await rewriteResources(source.doc, source.base, createResolver(source, "cover"), true);
  const root = source.doc.documentElement;
  for (const el of Array.from(root.querySelectorAll("*"))) {
    // shadow DOM 畫不進 SVG 圖片。
    if (el.localName === "template") {
      el.remove();
      continue;
    }
    for (const attr of Array.from(el.attributes)) if (!XML_NAME.test(attr.name)) el.removeAttributeNode(attr);
  }
  const markup = new XMLSerializer().serializeToString(root).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
  // 直接照封面的大小點陣化（viewBox 縮放），小的元件放大了也不糊。
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="${COVER_WIDTH}" height="${COVER_HEIGHT}" viewBox="0 0 ${size.width} ${size.height}">` +
    `<foreignObject x="0" y="0" width="${size.width}" height="${size.height}">` +
    `<div xmlns="http://www.w3.org/1999/xhtml" style="width:${size.width}px;height:${size.height}px;overflow:hidden;background:${background ?? "transparent"};color-scheme:${background ? "light" : "normal"}">` +
    `<style>${FRAME_CSS}</style>${markup}</div></foreignObject></svg>`;
  // 要用 data: 網址：blob: 網址的 SVG 裡有 foreignObject 時，WebView2 會鎖住 canvas。
  const img = new Image();
  img.src = await dataUrlOf(new Blob([svg], { type: "image/svg+xml" }));
  await img.decode();
  const canvas = document.createElement("canvas");
  canvas.width = COVER_WIDTH;
  canvas.height = COVER_HEIGHT;
  const g = canvas.getContext("2d");
  if (!g) throw new Error("無法建立 canvas");
  if (background) {
    g.fillStyle = background;
    g.fillRect(0, 0, COVER_WIDTH, COVER_HEIGHT);
  }
  g.drawImage(img, 0, 0, COVER_WIDTH, COVER_HEIGHT);
  return await canvasBlob(canvas, "image/webp", 0.85);
}

/** 一行放得下多少：英數連在一起算一個字，其他（中文）一個字一個字斷。 @param {CanvasRenderingContext2D} g @param {string} text @param {number} width @param {number} maxLines */
function wrapLines(g, text, width, maxLines) {
  const tokens = text.match(/[\x21-\x7e]+|\s+|./gu) ?? [];
  /** @type {string[]} */
  const lines = [];
  let line = "";
  for (const token of tokens) {
    const next = line + token;
    if (g.measureText(next).width <= width || !line.trim()) {
      line = next;
      continue;
    }
    lines.push(line.trim());
    line = token.trim() ? token : "";
    if (lines.length === maxLines) break;
  }
  if (lines.length < maxLines && line.trim()) lines.push(line.trim());
  const used = lines.join("").length;
  if (used < text.replace(/\s+/g, "").length && lines.length > 0) {
    let last = lines[lines.length - 1];
    while (last && g.measureText(`${last}…`).width > width) last = last.slice(0, -1);
    lines[lines.length - 1] = `${last}…`;
  }
  return lines;
}

/** 畫不出網頁時的封面：標題與網域，透明底、中性灰（深色、淺色主題的卡片上都看得清楚）。 @param {string} title @param {string | null} site */
function textCover(title, site) {
  const canvas = document.createElement("canvas");
  canvas.width = COVER_WIDTH;
  canvas.height = COVER_HEIGHT;
  const g = canvas.getContext("2d");
  if (!g) return Promise.reject(new Error("無法建立 canvas"));
  const font = '"Segoe UI", "Microsoft JhengHei", "Noto Sans TC", system-ui, sans-serif';
  g.fillStyle = "#8a8a8a";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.font = `600 44px ${font}`;
  const lines = wrapLines(g, title || "網頁", 480, 6);
  const lineHeight = 60;
  const blockHeight = lines.length * lineHeight + (site ? 60 : 0);
  const top = (COVER_HEIGHT - blockHeight) / 2;
  lines.forEach((line, i) => g.fillText(line, COVER_WIDTH / 2, top + lineHeight * (i + 0.5)));
  if (site) {
    g.font = `28px ${font}`;
    g.fillText(site, COVER_WIDTH / 2, top + lines.length * lineHeight + 40, 480);
  }
  return canvasBlob(canvas, "image/png");
}

// ---- 背景分析：篩選值與封面 ----

let unloaded = false;
let scanning = false;
let scanAgain = false;
/** 這次載入讀不到的作品：補算時跳過，免得每一批都撈到它們；下次載入再試。 @type {Set<number>} */
const unreadable = new Set();
/**
 * 移到垃圾桶的作品從查詢結果消失；還原時又回來，可能排在讀不到的那幾件中間，
 * 這時下一輪從頭數，不能直接跳過 unreadable.size 件。
 */
const removedIds = new Set();
let recount = false;
hoard.onUnload(() => {
  unloaded = true;
});
hoard.on("items-removed", ({ ids }) => {
  for (const id of ids) {
    unreadable.delete(id);
    removedIds.add(id);
  }
});
hoard.on("items-changed", ({ ids }) => {
  if (!ids.some((id) => removedIds.delete(id))) return;
  recount = true;
  void scan();
});

/** 背景分析寫好一批篩選值（kind）之後呼叫：「元件」頁面照類型列，要重讀。 @type {Set<() => void>} */
const kindsWritten = new Set();

/** 讓出主執行緒：等瀏覽器有空（最多等 1 秒）。 */
const idle = () => new Promise((resolve) => requestIdleCallback(() => resolve(undefined), { timeout: 1000 }));

/** @param {number} ms */
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * 程式畫好之後的網頁（HTML）：在看不到的框架裡照 size 打開、等一下再要；SNAPSHOT_TIMEOUT 內拿不到就放棄。
 * @param {{ dir: string; entry: string; files?: Record<string, string> }} spec @param {{ width: number; height: number }} size
 * @returns {Promise<string>}
 */
async function snapshot(spec, size) {
  const box = hoard.el("div", { class: "hv-offscreen", style: `width: ${size.width}px; height: ${size.height}px` });
  box.inert = true;
  document.body.append(box);
  const frame = hoard.mountFrame(box, { ...spec, scripts: true, script: "frame.js" });
  /** @type {ReturnType<typeof setTimeout> | undefined} */
  let timer;
  try {
    return await Promise.race([
      (async () => {
        /** @type {Promise<string>} */
        const got = new Promise((resolve) => {
          frame.on((message) => {
            if (message && message.kind === "snapshot" && typeof message.html === "string") resolve(message.html);
          });
        });
        await frame.loaded;
        await delay(SNAPSHOT_SETTLE);
        frame.send({ kind: "snapshot" });
        return got;
      })(),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error("網頁太久沒有回應")), SNAPSHOT_TIMEOUT);
      }),
    ]);
  } finally {
    clearTimeout(timer);
    frame.close();
    box.remove();
  }
}

/**
 * 讀一件網頁：存封面，回傳要寫的篩選值；讀不到時是 undefined（這次載入跳過）。
 * @param {number} id
 * @returns {Promise<Array<{ id: number; key: string; values: string[] }> | undefined>}
 */
async function analyze(id) {
  const item = await hoard.items.get(id);
  const file = htmlFileOf(item);
  const done = { id, key: "scanned", values: [SCAN_VERSION] };
  if (!file) return [done];
  if (file.missing) return undefined;
  if ((file.size ?? 0) > MAX_SCAN) return [done];
  /** @type {Source} */
  let source;
  try {
    source = await loadSource(file);
  } catch (err) {
    console.warn("[html] 讀不到網頁：", id, err);
    return undefined;
  }
  if (isClipText(source.text)) return await analyzeClip(item, source);
  /** @type {Record<string, string[]>} */
  const fields = await hoard.items.getFields(id).catch(() => ({}));
  const fixed = fields.kind_fixed?.[0];
  const component = canBeComponent(file) && (fixed ? fixed === KIND_COMPONENT : looksLikeComponent(source.text));
  // 內文要在清理（畫封面）之前讀。
  const info = pageInfo(source);
  let text = searchText(info, pageText(source.doc));
  const size = component ? COMPONENT_SIZE : PAGE_SIZE;
  /** @type {Source} */
  let coverSource = component ? { ...source, ...parseHtml(componentPage(source.text), source.base) } : source;
  // 有程式的網頁：封面與搜尋文字用程式畫好之後的樣子（程式寫的標題也算）。
  const scripted = component ? hasScript(source.text) : source.doc.querySelector("script") !== null;
  if (settings.scripts && source.parts === null && scripted) {
    const spec = component ? componentSpec(file.path, source.text) : localSpec(file.path);
    const html = await snapshot(spec, size).catch((err) => {
      console.warn("[html] 跑不出網頁的程式，照存下來的內容做封面：", id, err);
      return null;
    });
    if (unloaded) return undefined;
    if (html) {
      const shot = parseHtml(html, source.base);
      coverSource = { ...source, doc: shot.doc, base: shot.base };
      info.title ||= pageInfo(coverSource).title;
      text = searchText(info, pageText(shot.doc));
    }
  }
  if (!(await setDeclaredCover(id, source, info))) {
    /** @type {Blob | null} */
    let cover = null;
    try {
      cover = await pageCover(coverSource, size);
    } catch (err) {
      console.warn("[html] 畫不出網頁封面，改用文字封面：", id, err);
    }
    if (unloaded) return undefined;
    try {
      await hoard.items.setCover(id, { image: cover ?? (await textCover(info.title || item.title, info.site)), format: true });
    } catch (err) {
      console.warn("[html] 存不了封面：", id, err);
    }
  }
  if (unloaded) return undefined;
  const entries = [done, { id, key: "kind", values: [component ? KIND_COMPONENT : KIND_PAGE] }];
  if (info.site) entries.push({ id, key: "site", values: [info.site] });
  if (text) entries.push({ id, key: "_text", values: [text] });
  return entries;
}

/**
 * 網頁自己指定的封面（og:image，AI 寫的網頁常附上）：data: 圖片、MHTML 的段落，或 App 讀得到的本機圖片（連結資料夾裡同資料夾的檔案）；
 * 網路上的圖片讀不到，照舊畫第一屏。存成格式封面，有存到才是 true。要在清理（畫封面）之前讀。
 * @param {number} id @param {Source} source @param {PageInfo} info
 */
async function setDeclaredCover(id, source, info) {
  if (!info.coverHref) return false;
  const image = await createResolver(source, "cover").blob(info.coverHref, source.base);
  if (!image?.type.startsWith("image/") || unloaded) return false;
  try {
    await hoard.items.setCover(id, { image, format: true });
    return true;
  } catch (err) {
    console.warn("[html] 用不了網頁指定的封面，改畫第一屏：", id, err);
    return false;
  }
}

/**
 * 讀一件文字摘錄：封面是閱讀排版的開頭（透明底），kind 是摘錄，site 是摘錄來的網頁的網域；讀不到時是 undefined。
 * @param {HoardItemDetail} item @param {Source} source
 * @returns {Promise<Array<{ id: number; key: string; values: string[] }> | undefined>}
 */
async function analyzeClip(item, source) {
  const { id } = item;
  const url = clipUrl(item);
  const site = siteOf(url);
  const text = [pageText(source.doc), url ?? ""].filter(Boolean).join("\n").slice(0, TEXT_LIMIT).trim();
  /** @type {Blob | null} */
  let cover = null;
  try {
    cover = await pageCover({ ...source, ...parseHtml(readingPage(source.text, COVER_THEME), source.base) }, CLIP_SIZE, null);
  } catch (err) {
    console.warn("[html] 畫不出摘錄的封面，改用文字封面：", id, err);
  }
  if (unloaded) return undefined;
  try {
    await hoard.items.setCover(id, { image: cover ?? (await textCover(item.title, site)), format: true });
  } catch (err) {
    console.warn("[html] 存不了封面：", id, err);
  }
  const entries = [
    { id, key: "scanned", values: [SCAN_VERSION] },
    { id, key: "kind", values: [KIND_CLIP] },
  ];
  if (site) entries.push({ id, key: "site", values: [site] });
  if (text) entries.push({ id, key: "_text", values: [text] });
  return entries;
}

/**
 * 替還沒分析過的網頁做封面與篩選值：插件載入時補舊的，之後新收進來的也走這裡。
 * 一件一件讀、一批寫一次，件與件之間讓出主執行緒；同時只跑一輪，跑的時候又有新作品就再跑一輪。
 */
async function scan() {
  if (scanning) {
    scanAgain = true;
    return;
  }
  scanning = true;
  try {
    await settingsLoaded;
    do {
      scanAgain = false;
      // 先找還沒分析過的，再找舊版本分析的。
      // 由舊到新：讀不到的作品留在最前面，通常直接從第 unreadable.size 件開始；新收進來的接在最後。
      // 有作品從垃圾桶還原時從頭數。寫過的作品離開結果，留下來的（讀不到的）往後跳過。
      const conditions = [
        { owner: "html", key: "scanned", none: true },
        { owner: "html", key: "scanned", any: OLD_SCANS },
      ];
      const fromStart = recount;
      recount = false;
      for (const [i, condition] of conditions.entries()) {
        let offset = fromStart || i > 0 ? 0 : unreadable.size;
        for (;;) {
          if (unloaded) return;
          const page = await hoard.items.list(
            { source_type: "local", exts: [...HTML_EXTENSIONS], fields: [condition] },
            { limit: SCAN_BATCH, offset, sort: "added", ascending: true },
          );
          if (page.items.length === 0 || unloaded) break;
          /** @type {Array<{ id: number; key: string; values: string[] }>} */
          const entries = [];
          let written = 0;
          for (const item of page.items) {
            if (unreadable.has(item.id)) continue;
            await idle();
            if (unloaded) return;
            const result = await analyze(item.id).catch((err) => {
              console.warn("[html] 分析失敗：", item.id, err);
              return undefined;
            });
            if (result === undefined) unreadable.add(item.id);
            else {
              entries.push(...result);
              written++;
            }
          }
          if (unloaded) return;
          if (entries.length > 0) {
            await hoard.items.setFields(entries);
            kindsWritten.forEach((listener) => listener());
          }
          offset += page.items.length - written;
        }
      }
    } while (scanAgain || recount);
  } catch (err) {
    console.error("[html] 背景分析中斷：", err);
  } finally {
    scanning = false;
  }
}

hoard.on("items-added", () => void scan());
void scan();

// ---- 元件直接畫在卡片裡（Shadow DOM） ----

/**
 * 拿掉的：不屬於片段的標籤（樣式另外收進 adoptedStyleSheets）、會搶焦點或跳出卡片的屬性、原生的滑鼠提示。
 * 程式、事件屬性、javascript: 網址、內嵌框架由 setHTML 預設的安全清單拿掉。
 */
const LIVE_SANITIZER = {
  removeElements: ["meta", "link", "base", "title", "style", "noscript"],
  removeAttributes: ["autofocus", "popover", "popovertarget", "popovertargetaction", "command", "commandfor", "interestfor", "title"],
};

/**
 * 元件的 html、body 是這兩個 div：hc-html 擋住 App 繼承進來的樣式（字型、顏色），白底、淺色的表單元件，跟框架裡一樣；
 * hc-body 照 componentPage 置中排，另外：
 *  - isolation：真的網頁裡 body 的底色畫在整頁最底層，z-index 是負的元素還看得到；div 的底色會蓋住它們，
 *    自成一層之後底色才回到最底下。
 *  - hc-html 是元件的視窗：vh、vw 換成的 cqh、cqw 照它算（fitLive 會把它放大再縮回卡片大小）。
 */
const LIVE_BASE = new CSSStyleSheet();
LIVE_BASE.replaceSync(`
.hc-html { all: initial; display: block; box-sizing: border-box; width: 100%; height: 100%; overflow: clip; container-type: size; color-scheme: light; background: #fff; color: #000; }
.hc-body { ${COMPONENT_BODY}; isolation: isolate; }
`);

/** 選擇器裡的 html、:root、body（前面是開頭、空白、組合子、逗號或括號，後面不接名稱）。 */
const ROOT_SELECTOR = /(^|[\s>+~,(])(?:html|:root)(?![\w-])/gi;
const BODY_SELECTOR = /(^|[\s>+~,(])body(?![\w-])/gi;
/** 視窗單位（含 d／s／l 開頭的）；前面接著名稱的（.mt-10vh 這種 class）不算。 */
const VIEWPORT_UNIT = /(?<![\w.-])(-?(?:\d+\.?\d*|\.\d+))[dsl]?v(h|w|i|b|min|max)(?![\w-])/gi;

/** 視窗單位換成卡片的（容器查詢單位）：100vh 的元件撐滿卡片，不是撐滿 App 的視窗。 @param {string} css */
const toCardUnits = (css) => css.replace(VIEWPORT_UNIT, "$1cq$2");

/** 規則裡的 html、:root、body 換成 hc-html、hc-body，巢狀的規則與 @media 裡的也換。 @param {CSSRuleList} rules */
function rewriteRules(rules) {
  for (const rule of Array.from(rules)) {
    if (rule instanceof CSSStyleRule) {
      const selector = rule.selectorText.replace(ROOT_SELECTOR, "$1.hc-html").replace(BODY_SELECTOR, "$1.hc-body");
      if (selector !== rule.selectorText) rule.selectorText = selector;
    }
    const nested = /** @type {{ cssRules?: CSSRuleList }} */ (rule).cssRules;
    if (nested) rewriteRules(nested);
  }
}

/** 點到元件裡的連結不換頁（App 的視窗會整個換掉）。 @param {Event} event */
function stopNavigation(event) {
  for (const node of event.composedPath()) {
    if (node instanceof Element && node.matches("a[href], area[href]")) {
      event.preventDefault();
      return;
    }
  }
}

/**
 * 把元件畫進 host 的 shadow root：樣式只作用在裡面，App 的樣式也進不來。用 open 模式，App 才看得出點到的是元件裡的
 * 按鈕還是卡片（src/lib/eventTarget.ts）。不執行程式；連不了網（App 的 CSP），表單送不出去、連結不換頁。
 * 元件的 html、body 選擇器與視窗單位（vh、vw）換成卡片的；@media 仍然照 App 的視窗。
 * 用不了（WebView 沒有 setHTML）時丟出錯誤，由呼叫的地方顯示封面。
 * @param {HTMLElement} host @param {string} text
 */
function mountLive(host, text) {
  const body = hoard.el("div", { class: "hc-body" });
  const setHTML = /** @type {any} */ (body).setHTML;
  if (typeof setHTML !== "function") throw new Error("這個 WebView 沒有 setHTML");
  const css = Array.from(parseHtml(text, "about:blank").doc.querySelectorAll("style"))
    .filter((el) => el.namespaceURI === "http://www.w3.org/1999/xhtml")
    .map((el) => el.textContent ?? "")
    .join("\n");
  const sheet = new CSSStyleSheet();
  sheet.replaceSync(toCardUnits(css.replace(IMPORT_RE, "")));
  rewriteRules(sheet.cssRules);
  const root = host.attachShadow({ mode: "open" });
  root.adoptedStyleSheets = [LIVE_BASE, sheet];
  root.append(hoard.el("div", { class: "hc-html" }, [body]));
  setHTML.call(body, text, { sanitizer: LIVE_SANITIZER });
  for (const el of Array.from(body.querySelectorAll("[style]"))) el.setAttribute("style", toCardUnits(el.getAttribute("style") ?? ""));
  root.addEventListener("click", stopNavigation, true);
  root.addEventListener("auxclick", stopNavigation, true);
  root.addEventListener("submit", (event) => event.preventDefault(), true);
}

/**
 * 比卡片大的元件縮小到放得下（只縮不放大，小元件維持原本的大小）。像是把瀏覽器視窗開大、再整個縮小來看：
 * 先照卡片大小排一次，量 hc-body 裡最外層元素佔的範圍；放不下就把 hc-html（元件的整頁）放大到放得下，
 * 再整頁縮回卡片大小。縮的是整頁，body 的底色一樣鋪滿卡片。卡片大小變了再量一次。回傳停止的函式。
 * @param {HTMLElement} host mountLive 畫過的
 */
function fitLive(host) {
  const page = /** @type {HTMLElement | null} */ (host.shadowRoot?.querySelector(".hc-html") ?? null);
  const body = page?.querySelector(".hc-body");
  if (!page || !body) return () => {};
  const fit = () => {
    const width = host.clientWidth;
    const height = host.clientHeight;
    if (width <= 0 || height <= 0) return;
    page.style.cssText = "";
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    for (const child of Array.from(body.children)) {
      const box = child.getBoundingClientRect();
      if (box.width === 0 && box.height === 0) continue;
      left = Math.min(left, box.left);
      top = Math.min(top, box.top);
      right = Math.max(right, box.right);
      bottom = Math.max(bottom, box.bottom);
    }
    if (left === Infinity) return;
    const scale = Math.min(
      1,
      width / (right - left + COMPONENT_PADDING * 2),
      height / (bottom - top + COMPONENT_PADDING * 2),
    );
    if (scale > 0.99) return;
    page.style.cssText = `width:${100 / scale}%;height:${100 / scale}%;transform:scale(${scale});transform-origin:0 0`;
  };
  const resize = new ResizeObserver(fit);
  resize.observe(host);
  return () => resize.disconnect();
}

// ---- 側欄的「元件」頁面 ----

/** 卡片至少多寬、卡片之間的間距。 */
const WALL_CARD_MIN = 240;
const WALL_GAP = 16;
/** 卡片下方名稱那一列的高度（估計列高用）。 */
const WALL_NAME_HEIGHT = 34;
/** 有程式的元件：滑鼠停多久才換成框架。 */
const HOVER_DELAY = 400;
/** 記住幾件元件的原始碼。 */
const LIVE_CACHE_LIMIT = 300;
/** 一次向 App 要幾件。 */
const VIEW_PAGE = 120;
/** 畫到離最後一排這麼近時讀下一頁。 */
const VIEW_AHEAD = 3;
/**
 * 換了清單（類型、搜尋）時，舊的卡片留著等新的；超過這麼久還沒讀好才換成佔位，上面選的和下面的卡片才不會對不上太久
 * （docs/conventions.md〈回饋〉，跟 App 的收藏庫一樣）。
 */
const STALE_MS = 300;
/** 頁面上選的類型（"" 是全部）；離開再回來時照上次的。 */
let viewKind = "";

/** @typedef {{ file: HoardItemFile; text: string; scripted: boolean }} LiveComponent */

/** 作品是元件時的檔案與原始碼；不是元件是 null。捲回來、頁面重讀時不用再讀。 @type {Map<number, Promise<LiveComponent | null>>} */
const liveCache = new Map();
/** @param {{ ids: number[] }} event */
const forgetLive = ({ ids }) => ids.forEach((id) => liveCache.delete(id));
hoard.on("items-changed", forgetLive);
hoard.on("items-removed", forgetLive);

/** @param {HoardItemSummary} item @returns {Promise<LiveComponent | null>} */
function liveComponent(item) {
  const cached = liveCache.get(item.id);
  if (cached) return cached;
  const got = (async () => {
    const file = htmlFileOf(await hoard.items.get(item.id));
    if (!file) return null;
    const text = await componentText(item.id, file);
    return text === null ? null : { file, text, scripted: hasScript(text) };
  })().catch((err) => {
    console.warn("[html] 讀不到元件：", item.id, err);
    liveCache.delete(item.id);
    return null;
  });
  liveCache.set(item.id, got);
  // 最早記下的先忘。
  if (liveCache.size > LIVE_CACHE_LIMIT) liveCache.delete(/** @type {number} */ (liveCache.keys().next().value));
  return got;
}

/** 正在顯示的那個框架（一次只開一個：iframe 不輕）。 @type {(() => void) | null} */
let closeHover = null;

/**
 * 有程式的元件：滑鼠在預覽上停 HOVER_DELAY 就在封面上開沙盒框架跑程式，離開就關。回傳拆掉的函式。
 * @param {HTMLElement} preview @param {LiveComponent} live @param {string} title
 */
function hoverFrame(preview, live, title) {
  /** @type {ReturnType<typeof setTimeout> | undefined} */
  let timer;
  /** @type {HoardFrameHandle | null} */
  let frame = null;
  const close = () => {
    clearTimeout(timer);
    frame?.close();
    frame = null;
    if (closeHover === close) closeHover = null;
  };
  const open = () => {
    closeHover?.();
    closeHover = close;
    const handle = hoard.mountFrame(preview, { ...componentSpec(live.file.path, live.text), scripts: true, title });
    frame = handle;
    // 載入完才蓋上去：框架一開始是一張白色的空白頁。
    handle.element.style.visibility = "hidden";
    handle.loaded.then(
      () => {
        if (frame !== handle) return;
        handle.element.style.visibility = "";
        reveal(handle.element, null);
      },
      () => {
        /* 開不了就留著封面 */
      },
    );
  };
  const enter = () => {
    if (frame) return;
    clearTimeout(timer);
    timer = setTimeout(open, HOVER_DELAY);
  };
  preview.addEventListener("pointerenter", enter);
  preview.addEventListener("pointerleave", close);
  return () => {
    preview.removeEventListener("pointerenter", enter);
    preview.removeEventListener("pointerleave", close);
    close();
  };
}

/** 封面（還沒有時是圖示）。 @param {HoardItemSummary} item */
function wallCover(item) {
  const path = item.cover_path ?? item.thumbnail_path;
  return path
    ? hoard.el("img", { class: "hv-card-cover", src: hoard.fileSrc(path), alt: "", loading: "lazy", draggable: "false" })
    : hoard.el("span", { class: "hv-card-empty" }, [hoard.icon("globe", { size: 24 })]);
}

/**
 * 一張卡片：元件畫在上面（可以互動，點了不開啟作品），下面是名稱（點了開啟）；整張卡片右鍵、拖曳照常。
 * 不是元件的網頁顯示封面，點哪裡都開啟。
 * @param {HoardItemSummary} item @param {(card: HTMLElement) => void} bind
 */
function wallCard(item, bind) {
  let alive = true;
  /** @type {(() => void) | null} */
  let stopHover = null;
  /** @type {(() => void) | null} */
  let stopFit = null;
  const preview = hoard.el("div", { class: "hv-card-preview" });
  const card = hoard.el("div", { class: "hv-card" }, [preview, hoard.el("div", { class: "hv-card-name", title: item.title }, [item.title])]);
  bind(card);
  void liveComponent(item).then((live) => {
    if (!alive) return;
    if (!live) return preview.append(wallCover(item));
    // 有程式的元件（設定打開時）：封面，停一下換成框架。還沒有封面時照沒有程式的畫。
    if (live.scripted && settings.scripts && (item.cover_path ?? item.thumbnail_path)) {
      preview.append(wallCover(item));
      stopHover = hoverFrame(preview, live, item.title);
      return;
    }
    const host = hoard.el("div", { class: "hv-live" });
    try {
      mountLive(host, live.text);
    } catch (err) {
      console.warn("[html] 畫不出元件，改用封面：", item.id, err);
      return preview.append(wallCover(item));
    }
    preview.append(host);
    stopFit = fitLive(host);
    preview.classList.add("hv-card-live");
    // 點元件是在操作它：不開啟作品。
    preview.addEventListener("click", (event) => event.stopPropagation());
  });
  return {
    el: card,
    cleanup() {
      alive = false;
      stopHover?.();
      stopFit?.();
    },
  };
}

/**
 * 讀好之前的佔位：卡片的形狀，一排幾張照寬度自動排。
 * @param {number} count 幾張 @param {boolean} now 已經等過了（換清單等超過 STALE_MS）就馬上淡入；否則自己等 200ms，很快讀完的什麼都不閃
 */
function wallSkeleton(count, now) {
  return hoard.el(
    "div",
    {
      class: now ? "hv-wall-skeleton hv-now" : "hv-wall-skeleton",
      role: "status",
      "aria-label": "讀取中",
      style: `grid-template-columns: repeat(auto-fill, minmax(${WALL_CARD_MIN}px, 1fr)); gap: ${WALL_GAP}px`,
    },
    Array.from({ length: count }, () =>
      hoard.el("div", { class: "hv-wall-bone" }, [hoard.el("div", { class: "hv-wall-bone-preview" }), hoard.el("div", { class: "hv-wall-bone-name" })]),
    ),
  );
}

/**
 * 元件頁的一份清單：照哪個類型與搜尋讀、讀到哪。
 * @typedef {{ filter: HoardItemFilter; narrowed: boolean; items: HoardItemSummary[]; offset: number; done: boolean; loading: boolean; lastRow: number; error: string | null }} WallList
 */

hoard.registerView({
  id: "components",
  label: "元件",
  icon: "component",
  render(el, ctx) {
    let search = "";
    let columns = 0;
    let cardWidth = WALL_CARD_MIN;
    /**
     * 照現在選的類型與搜尋，一份還沒讀的清單。「全部」是元件與網頁：文字摘錄是讀的，不列在這裡；
     * 所以還沒分析過的也不在，分析完（items-changed）才補上（refresh）。
     * @returns {WallList}
     */
    const wallList = () => ({
      filter: {
        source_type: "local",
        exts: [...HTML_EXTENSIONS],
        search: search || undefined,
        fields: [{ owner: "html", key: "kind", any: viewKind ? [viewKind] : [KIND_COMPONENT, KIND_PAGE] }],
      },
      narrowed: Boolean(search || viewKind),
      items: [],
      offset: 0,
      done: false,
      loading: false,
      /** 畫過最後面的那一排。 */
      lastRow: -1,
      error: null,
    });
    /** 畫面上的清單。 */
    let shown = wallList();
    /** 換了類型、搜尋：正在讀、讀好就換上的那份。 @type {WallList | null} */
    let next = null;
    /** 畫面上的卡片；換成佔位時是 null。 @type {HoardVirtualList | null} */
    let list = null;
    /** @type {HTMLElement | null} */
    let skeleton = null;

    /** @type {Array<[string, string]>} */
    const kindLabels = [
      ["", "全部"],
      [KIND_COMPONENT, "元件"],
      [KIND_PAGE, "網頁"],
    ];
    const kinds = kindLabels.map(([kind, label]) => ({
      kind,
      button: hoard.el(
        "button",
        {
          class: "hv-view-kind",
          type: "button",
          onclick: () => {
            if (viewKind === kind) return;
            viewKind = kind;
            showKind();
            void reload();
          },
        },
        [label],
      ),
    }));
    const showKind = () => kinds.forEach(({ kind, button }) => button.setAttribute("aria-pressed", String(kind === viewKind)));
    showKind();
    const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "search", placeholder: "搜尋標題、內文…" }));
    const grid = hoard.el("div");
    const note = hoard.el("div", { class: "hoard-empty" });
    note.hidden = true;
    const body = hoard.el("div", { class: "hv-wall" }, [grid, note]);
    // 名稱與件數由 App 的頁首顯示；類型與搜尋放在頁首右側。
    ctx.header.actions.append(
      hoard.el("div", { class: "hv-view-kinds" }, kinds.map(({ button }) => button)),
      hoard.el("label", { class: "hoard-search" }, [hoard.icon("search", { size: 13 }), input]),
    );
    el.append(hoard.el("div", { class: "hv-view" }, [body]));

    // 還沒讀完時最後一排可能沒排滿，先不畫，讀完才補上。
    const rowCount = () => (shown.done ? Math.ceil(shown.items.length / columns) : Math.floor(shown.items.length / columns));
    /** 照寬度（扣掉左右留白）算欄數；欄數變了回傳 true。 */
    const measure = () => {
      const style = getComputedStyle(body);
      const width = Math.max(WALL_CARD_MIN, body.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight));
      const fits = Math.max(1, Math.floor((width + WALL_GAP) / (WALL_CARD_MIN + WALL_GAP)));
      cardWidth = (width - WALL_GAP * (fits - 1)) / fits;
      if (fits === columns) return false;
      columns = fits;
      return true;
    };
    measure();

    /** 讀下一頁加進這份清單。 @param {WallList} wall */
    const readPage = async (wall) => {
      const page = await ctx.listItems(wall.filter, { offset: wall.offset, limit: VIEW_PAGE });
      wall.offset += page.items.length;
      wall.done = page.items.length === 0 || wall.offset >= page.total;
      wall.items.push(...page.items.filter(isHtmlItem));
    };

    /** 件數，以及空的、讀取失敗時的說明。enter：同一份清單剛剛還有東西（最後一件被拿掉），空狀態慢一拍淡入。 @param {boolean} [enter] */
    const showStatus = (enter = false) => {
      const { items, done, error, narrowed } = shown;
      ctx.header.setCount(items.length, { more: !done });
      const text = error
        ? `讀取失敗：${error}`
        : done && items.length === 0
          ? narrowed
            ? "沒有符合條件的網頁"
            : "還沒有網頁"
          : "";
      if (note.hidden && text) note.toggleAttribute("data-enter", enter);
      note.textContent = text;
      note.hidden = !text;
    };

    /** 畫到快到底：再讀幾頁加在後面（setCount，畫好的卡片不重畫）。 */
    const loadMore = async () => {
      const wall = shown;
      if (wall.loading || wall.done) return;
      wall.loading = true;
      try {
        while (wall === shown && !wall.done && wall.lastRow >= rowCount() - VIEW_AHEAD) {
          await readPage(wall);
          if (wall === shown) list?.setCount(rowCount());
        }
      } catch (err) {
        wall.error = String(err);
        wall.done = true;
      } finally {
        wall.loading = false;
        if (wall === shown) {
          list?.setCount(rowCount());
          showStatus();
        }
      }
    };

    /** 一排一列的卡片，畫的是 shown。 */
    const startList = () =>
      ctx.virtualList(grid, {
        count: rowCount(),
        estimateSize: () => cardWidth + WALL_NAME_HEIGHT,
        gap: WALL_GAP,
        renderRow(row, index) {
          shown.lastRow = Math.max(shown.lastRow, index);
          if (index >= rowCount() - VIEW_AHEAD) void loadMore();
          const cards = shown.items
            .slice(index * columns, (index + 1) * columns)
            .map((item) => wallCard(item, (card) => ctx.bindItem(card, item)));
          row.append(
            hoard.el(
              "div",
              { class: "hv-wall-row", style: `grid-template-columns: repeat(${columns}, minmax(0, 1fr)); column-gap: ${WALL_GAP}px` },
              cards.map((card) => card.el),
            ),
          );
          return () => cards.forEach((card) => card.cleanup());
        },
      });

    /** 卡片拿掉，換成佔位。 @param {boolean} now */
    const showSkeleton = (now) => {
      list?.();
      list = null;
      note.hidden = true;
      skeleton?.remove();
      skeleton = wallSkeleton(columns * 2, now);
      grid.before(skeleton);
    };

    /**
     * 從頭讀。換了類型或搜尋：新的一份讀好第一頁之前，畫面上的卡片留著，讀好才一次換上、從頂端開始；
     * 超過 STALE_MS 還沒好才換成佔位。第一次打開直接放佔位（它自己等 200ms 才淡入）。
     * keep：收藏在背景變了（匯入、移到垃圾桶），還是同一份清單：讀到跟現在一樣多件，原地重畫，捲動位置不變；讀不到就留著現在的。
     * @param {boolean} [keep]
     */
    const reload = async (keep = false) => {
      // 正在換清單（或還沒有卡片）時，背景的變動也當成換清單：一樣照現在選的讀。
      keep &&= list !== null && next === null;
      const wall = wallList();
      next = wall;
      /** @type {ReturnType<typeof setTimeout> | undefined} */
      let slow;
      if (!keep) {
        if (list) slow = setTimeout(() => next === wall && showSkeleton(true), STALE_MS);
        else if (!skeleton) showSkeleton(false);
      }
      const want = keep ? shown.items.length : 0;
      try {
        do {
          await readPage(wall);
        } while (next === wall && !wall.done && wall.items.length < want);
      } catch (err) {
        if (keep) {
          if (next === wall) next = null;
          console.warn("[html] 重讀失敗：", err);
          return;
        }
        wall.error = String(err);
        wall.done = true;
      } finally {
        clearTimeout(slow);
      }
      if (next !== wall) return;
      next = null;
      skeleton?.remove();
      skeleton = null;
      shown = wall;
      if (keep && list) {
        list.redraw(rowCount());
      } else {
        // 舊的卡片拿掉後頁面只剩頁首，捲動位置跟著回到頂端，新的從那裡畫起。
        list?.();
        list = startList();
      }
      showStatus(keep && want > 0);
    };

    // 寬度改變到欄數不同時重排，捲動位置不變。等下一個畫格才排：在 ResizeObserver 裡改版面會再觸發它自己。
    let queued = 0;
    const resize = new ResizeObserver(() => {
      if (queued) return;
      queued = requestAnimationFrame(() => {
        queued = 0;
        if (measure()) list?.redraw(rowCount());
      });
    });
    resize.observe(body);

    /** @type {number | undefined} */
    let typing;
    input.addEventListener("input", () => {
      clearTimeout(typing);
      typing = window.setTimeout(() => {
        search = input.value.trim();
        void reload();
      }, 250);
    });

    // 加入、移到垃圾桶：稍等一下再重讀，一批匯入只讀一次。
    /** @type {number | undefined} */
    let settle;
    const later = () => {
      clearTimeout(settle);
      settle = window.setTimeout(() => void reload(true), 600);
    };
    // 清單裡的作品變了（背景分析做好封面、改了類型）：重讀那幾件，畫面上的卡片重畫，捲動位置不變。
    /** @param {{ ids: number[] }} event */
    const refresh = async ({ ids }) => {
      const wall = shown;
      const changed = ids.filter((id) => wall.items.some((item) => item.id === id));
      if (changed.length === 0) return;
      try {
        const { items: fresh } = await ctx.listItems({ ids: changed }, { limit: changed.length });
        if (wall !== shown) return;
        const byId = new Map(fresh.map((item) => [item.id, item]));
        wall.items = wall.items.map((item) => byId.get(item.id) ?? item);
        list?.redraw();
      } catch (err) {
        console.warn("[html] 重讀作品失敗：", err);
      }
    };
    // 背景分析寫好類型（剛收進來的、改了類型的）：可能多出或少了符合的作品，跟加入一樣重讀。
    kindsWritten.add(later);
    const offs = [
      hoard.on("items-added", later),
      hoard.on("items-removed", later),
      hoard.on("items-changed", (event) => void refresh(event)),
      () => kindsWritten.delete(later),
    ];

    void reload();
    return () => {
      next = null;
      clearTimeout(typing);
      clearTimeout(settle);
      cancelAnimationFrame(queued);
      resize.disconnect();
      offs.forEach((off) => off());
      list?.();
    };
  },
});

// ---- 設定 ----

hoard.registerSettingTab({
  label: "顯示",
  render(root) {
    const box = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox" }));
    box.checked = settings.scripts;
    void settingsLoaded.then(() => (box.checked = settings.scripts));
    box.addEventListener("change", () => updateSettings({ scripts: box.checked }));
    root.append(
      hoard.el("div", { class: "hv-settings" }, [
        hoard.el("label", { class: "hv-field" }, [
          box,
          hoard.el("span", { class: "hv-field-text" }, [
            hoard.el("span", {}, ["執行網頁裡的程式"]),
            hoard.el("span", { class: "hv-field-hint" }, [
              "程式在隔離的框架裡執行，連不了網，也碰不到 hoard；關掉時只顯示存下來的內容。之後打開的網頁才套用",
            ]),
          ]),
        ]),
      ]),
    );
  },
});
