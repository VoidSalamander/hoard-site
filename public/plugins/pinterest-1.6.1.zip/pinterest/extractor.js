// @ts-check
/// <reference path="../hoard-extractor.d.ts" />
/* Pinterest Pin 擷取器：走站方的資源介面（網頁自己也用它），在 Pin 所在的網域呼叫才帶得到 cookie。
   一個 Pin 的內容有三種：單張圖（images.orig）、多圖（carousel_data 的每一格）、
   Idea Pin（story_pin_data 每一頁的圖片或影片區塊）；影片優先拿 mp4，只有 HLS 時交給 App 的 yt-dlp。
   另外有：看板／分區整批收藏（listCreatorPosts）、已收藏的 Pin 上的 hoard 標記、按「儲存」時自動收藏、拖 Pin 到擴充的投放區（dragCapture）。 */

/** /pin/123/ 或 /pin/標題--123/ */
const PIN_PATH = /\/pin\/(?:[^/]*--)?(\d+)/;

const canonicalUrl = (id) => `https://www.pinterest.com/pin/${id}/`;

/** @param {URL} url */
function pinId(url) {
  const match = url.pathname.match(PIN_PATH);
  return match ? match[1] : null;
}

/**
 * 站方的資源介面（網頁自己也用它）。handler 是網頁對應的路由；沒有 X-Pinterest-PWS-Handler 會回 403。
 * 回傳 data 與下一頁的 bookmark（沒有下一頁時是 null）；找不到（404）時 data 是 null。
 * @param {string} name @param {Record<string, unknown>} options @param {string} sourceUrl @param {string} handler
 * @returns {Promise<{ data: any; bookmark: string | null }>}
 */
async function pinterestResource(name, options, sourceUrl, handler) {
  const url =
    `${location.origin}/resource/${name}/get/?source_url=${encodeURIComponent(sourceUrl)}` +
    `&data=${encodeURIComponent(JSON.stringify({ options, context: {} }))}`;
  const res = await fetch(url, {
    credentials: "include",
    headers: { Accept: "application/json", "X-Requested-With": "XMLHttpRequest", "X-Pinterest-PWS-Handler": handler },
  });
  if (res.status === 404) return { data: null, bookmark: null };
  if (!res.ok) throw new Error(`Pinterest 回應 ${res.status}`);
  const json = await res.json();
  const bookmark = json?.resource_response?.bookmark;
  return { data: json?.resource_response?.data ?? null, bookmark: bookmark && bookmark !== "-end-" ? bookmark : null };
}

/**
 * 一路翻頁讀完清單型的資源，只留真的 Pin（數字 id，不含推廣與其他卡片）。
 * pageSize 超過資源允許的上限會回 400（看板 250、分區 50）。
 * @param {string} name @param {Record<string, unknown>} options @param {number} pageSize
 * @param {string} sourceUrl @param {string} handler @param {(count: number) => void} progress
 */
async function allPins(name, options, pageSize, sourceUrl, handler, progress) {
  /** @type {any[]} */
  const pins = [];
  /** @type {string | null} */
  let bookmark = null;
  for (let page = 0; page < 200; page++) {
    const { data, bookmark: next } = await pinterestResource(
      name,
      { ...options, page_size: pageSize, ...(bookmark ? { bookmarks: [bookmark] } : {}) },
      sourceUrl,
      handler,
    );
    const items = Array.isArray(data) ? data : [];
    pins.push(...items.filter((item) => item?.type === "pin" && /^\d+$/.test(String(item.id)) && !item.is_promoted));
    progress(pins.length);
    if (!next || items.length === 0) break;
    bookmark = next;
  }
  return pins;
}

/** @param {string} id */
async function fetchPin(id) {
  const { data: pin } = await pinterestResource("PinResource", { id, field_set_key: "detailed" }, `/pin/${id}/`, "www/pin/[id].js");
  if (!pin) {
    /** @type {Error & { skipped?: boolean }} */
    const err = new Error("找不到這個 Pin（可能已刪除或不公開）");
    err.skipped = true;
    throw err;
  }
  return pin;
}

/**
 * 一組尺寸裡原圖的候選網址，依序試。縮圖（236x、736x…）的網址把尺寸那段換成 originals 就是原圖，
 * 多圖 Pin 的格子只給縮圖時靠這個拿原圖。副檔名不可靠：縮圖一律是 .jpg，Idea Pin 區塊給的 originals
 * 網址也可能寫 .jpg 但檔案是 .png，所以每種副檔名都列，最後才退回最大的縮圖本身。
 * @returns {string[]}
 */
function imageCandidates(images) {
  if (!images) return [];
  const sized = Object.values(images)
    .filter((img) => img && typeof img.url === "string" && !/\/originals\//.test(img.url))
    .sort((a, b) => (b.width ?? 0) - (a.width ?? 0))[0];
  const original = images.orig?.url || images.originals?.url || sized?.url.replace(/^(https:\/\/i\.pinimg\.com\/)[^/]+\//, "$1originals/");
  if (!original) return [];
  const stem = original.replace(/\.\w+$/, "");
  const exts = [...new Set([original.slice(stem.length), ".png", ".jpg", ".gif", ".webp"])];
  const candidates = [...new Set(exts.map((ext) => stem + ext))];
  return sized && !candidates.includes(sized.url) ? [...candidates, sized.url] : candidates;
}

/** 第一個存在的候選網址（不存在的原圖回 403）。 @param {string[]} candidates */
async function firstExisting(candidates) {
  for (const url of candidates) {
    try {
      const res = await fetch(url, { method: "HEAD" });
      if (res.ok) return url;
    } catch {
      // 被擋下來就判斷不了，直接用它（擴充背景下載時不受頁面的 CORS 限制）。
      return url;
    }
  }
  // 都不存在（或 HEAD 被擋）時用最後一個，通常是縮圖。
  return candidates[candidates.length - 1] ?? null;
}

/** 實際存在的原圖網址；沒有任何候選時是 null。 */
const bestImage = (images) => firstExisting(imageCandidates(images));

/** 影片清單裡最大的 mp4；只有 HLS 串流時是 null。 */
function bestMp4(videoList) {
  if (!videoList) return null;
  const mp4 = Object.values(videoList)
    .filter((v) => v && typeof v.url === "string" && /\.mp4(?:\?|$)/.test(v.url))
    .sort((a, b) => (b.width ?? 0) - (a.width ?? 0))[0];
  return mp4?.url ?? null;
}

/**
 * 依顯示順序列出要下載的檔案。
 * @returns {Promise<{ sources: Array<{ url: string; alt?: string | null }>; streamOnly: boolean; poster: string | null }>}
 */
async function collectMedia(pin) {
  const alt = pin.auto_alt_text || pin.alt_text || pin.seo_alt_text || null;
  /** @type {Array<{ url: string; alt?: string | null }>} */
  const sources = [];
  let streamOnly = false;

  const pages = pin.story_pin_data?.pages ?? [];
  const slots = pin.carousel_data?.carousel_slots ?? [];
  if (pages.length > 0) {
    for (const page of pages) {
      for (const block of page.blocks ?? []) {
        const video = block.video?.video_list;
        if (video) {
          const url = bestMp4(video);
          if (url) sources.push({ url });
          else streamOnly = true;
          continue;
        }
        const url = await bestImage(block.image?.images);
        if (url) sources.push({ url, alt: block.image?.alt_text ?? alt });
      }
    }
  } else if (slots.length > 0) {
    for (const slot of slots) {
      const url = await bestImage(slot.images);
      if (url) sources.push({ url, alt: slot.title || alt });
    }
  }

  if (sources.length === 0 && pin.videos?.video_list) {
    const url = bestMp4(pin.videos.video_list);
    if (url) sources.push({ url });
    else streamOnly = true;
  }
  const cover = await bestImage(pin.images);
  // 沒有其他圖時，封面圖就是 Pin 本身。
  if (sources.length === 0 && cover && !streamOnly) sources.push({ url: cover, alt });
  // 只有影片時，封面圖當卡片圖。
  const onlyVideo = sources.every((source) => /\.mp4(?:\?|$)/.test(source.url));
  return { sources, streamOnly, poster: onlyVideo ? cover : null };
}

/** 標題常是空的：依序退回卡片標題、描述的第一行、SEO 標題（「 | 」之後是站方加的關鍵字）。 */
function titleOf(pin) {
  const firstLine = (text) => (typeof text === "string" ? text.trim().split("\n")[0].slice(0, 100) : "");
  const own = firstLine(pin.title) || firstLine(pin.grid_title);
  if (own) return { title: own, auto: false };
  const title =
    firstLine(pin.closeup_unified_description || pin.description) ||
    firstLine(pin.seo_title).split(" | ")[0] ||
    `Pin ${pin.id}`;
  // 不是 Pin 自己的標題：Pinterest 的卡片不會顯示，App 的卡片也照做（見 app.js 的 cardTitle）。
  return { title, auto: true };
}

/** Pinterest 的日期（"Sun, 22 May 2022 11:52:09 +0000"）轉成 ISO；讀不懂時是 undefined。 @param {unknown} value */
function isoDate(value) {
  if (typeof value !== "string" || !value) return undefined;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? undefined : date.toISOString();
}

/** 一則留言（一般留言或「試做」心得）轉成 hoard 的格式；沒有文字的略過。 @returns {HoardCommentPayload | null} */
function toComment(item) {
  const content = (item.type === "userdiditdata" ? item.details : item.text)?.trim();
  if (!content) return null;
  const reactions = Object.values(item.reaction_counts ?? {}).reduce((sum, n) => sum + (Number(n) || 0), 0);
  return {
    author_name: item.user?.full_name || item.user?.username || undefined,
    author_handle: item.user?.username || undefined,
    content,
    posted_at: isoDate(item.created_at || item.done_at),
    like_count: reactions || item.like_count || undefined,
  };
}

/**
 * 留言（只有第一層，站方沒有公開回覆的介面），最多 500 則。讀不到時記一個警告，收藏照常。
 * @param {any} pin @param {string[]} warnings @returns {Promise<HoardCommentPayload[]>}
 */
async function fetchComments(pin, warnings) {
  const aggregatedId = pin.aggregated_pin_data?.id;
  if (!aggregatedId || !(pin.aggregated_pin_data?.comment_count > 0)) return [];
  /** @type {HoardCommentPayload[]} */
  const comments = [];
  /** @type {string | null} */
  let bookmark = null;
  try {
    for (let page = 0; page < 10 && comments.length < 500; page++) {
      const { data, bookmark: next } = await pinterestResource(
        "UnifiedCommentsResource",
        {
          aggregated_pin_id: aggregatedId,
          comment_featured_ids: [],
          page_size: 50,
          is_reversed: false,
          ...(bookmark ? { bookmarks: [bookmark] } : {}),
        },
        `/pin/${pin.id}/`,
        "www/pin/[id].js",
      );
      const items = Array.isArray(data) ? data : [];
      for (const item of items) {
        const comment = toComment(item);
        if (comment) comments.push(comment);
      }
      if (!next || items.length === 0) break;
      bookmark = next;
    }
  } catch (err) {
    warnings.push(`留言讀取失敗：${err instanceof Error ? err.message : String(err)}`);
  }
  return comments;
}

// ---- 看板與分區：在這些頁面按彈出視窗的「抓取此頁」就整批收藏 ----

/** 網址第一段是這些的不是看板（看板是 /帳號/看板/ 或 /帳號/看板/分區/）。 */
const NOT_BOARD = new Set(["pin", "search", "ideas", "today", "settings", "business", "about", "explore", "notifications", "messages", "videos", "shopping"]);

/** @param {URL} url @returns {{ username: string; slug: string; section: string | null } | null} */
function boardPath(url) {
  const parts = url.pathname.split("/").filter(Boolean).map(decodeURIComponent);
  if (parts.length < 2 || parts.length > 3 || NOT_BOARD.has(parts[0]) || parts.some((part) => part.startsWith("_"))) {
    return null;
  }
  return { username: parts[0], slug: parts[1], section: parts[2] ?? null };
}

/** @param {HoardListContext} ctx @returns {Promise<HoardCreatorListing>} */
async function listBoard(ctx) {
  const path = boardPath(ctx.url);
  if (!path) throw new Error("請在 Pinterest 的看板或分區頁面使用（網址像 pinterest.com/帳號/看板/）");
  const boardUrl = `/${path.username}/${path.slug}/`;
  const handler = "www/[username]/[slug].js";
  ctx.progress("讀取看板…");
  const { data: board } = await pinterestResource(
    "BoardResource",
    { username: path.username, slug: path.slug, field_set_key: "detailed" },
    boardUrl,
    handler,
  );
  if (!board?.id) throw new Error("找不到這個看板（可能已刪除或不公開）");

  const { data: sectionData } = await pinterestResource("BoardSectionsResource", { board_id: board.id, page_size: 250 }, boardUrl, handler);
  /** @type {Array<{ id: string; title: string; slug: string }>} */
  let sections = Array.isArray(sectionData) ? sectionData : [];
  if (path.section) {
    sections = sections.filter((section) => section.slug === path.section);
    if (sections.length === 0) throw new Error("找不到這個分區");
  }

  /** @type {Map<string, HoardListedPost>} */
  const posts = new Map();
  /** @param {any[]} pins @param {string | null} section */
  const add = (pins, section) => {
    for (const pin of pins) {
      const id = String(pin.id);
      if (posts.has(id)) continue;
      posts.set(id, {
        url: canonicalUrl(id),
        title: pin.title || pin.grid_title || undefined,
        data: { board: board.name, section },
      });
    }
  };
  // 看板本身的清單不含分區裡的 Pin，分區要一個一個讀。
  if (!path.section) {
    const pins = await allPins(
      "BoardFeedResource",
      { board_id: board.id, board_url: boardUrl, field_set_key: "react_grid_pin" },
      250,
      boardUrl,
      handler,
      (n) => ctx.progress(`讀取看板的 Pin：${n} 篇`),
    );
    add(pins, null);
  }
  for (const section of sections) {
    const pins = await allPins(
      "BoardSectionPinsResource",
      { section_id: section.id },
      50,
      `${boardUrl}${section.slug}/`,
      "www/[username]/[slug]/[section_slug].js",
      (n) => ctx.progress(`讀取分區「${section.title}」：${n} 篇`),
    );
    add(pins, section.title);
  }
  const subject = path.section ? `${board.name} / ${sections[0].title}` : board.name;
  return { creator: subject, posts: [...posts.values()] };
}

/** 上傳者優先，沒有時是存下這個 Pin 的人。 */
function authorOf(pin) {
  const user = pin.native_creator || pin.origin_pinner || pin.pinner;
  if (!user?.username) return undefined;
  return {
    name: user.full_name || user.username,
    handle: user.username,
    url: `https://www.pinterest.com/${user.username}/`,
  };
}

// ---- 拖曳收藏：投放區由擴充提供，這裡只說拖的是哪個 Pin ----

/** 拖曳中的 Pin 網址：Pinterest 自己放的 pinrep 資料，或拖曳帶的連結。 @param {DataTransfer} dt */
function draggedPinUrl(dt) {
  try {
    const rep = JSON.parse(dt.getData("application/x-pinterest-pinrep") || "null");
    if (rep?.pinId && /^\d+$/.test(String(rep.pinId))) return canonicalUrl(rep.pinId);
  } catch {
    // 不是 JSON 就看連結
  }
  for (const line of (dt.getData("text/uri-list") || dt.getData("text/plain") || "").split(/\r?\n/)) {
    try {
      const id = pinId(new URL(line.trim(), location.href));
      if (id) return canonicalUrl(id);
    } catch {
      // 不是網址
    }
  }
  return null;
}

/** Pinterest 拖曳時自己打開的「以圖搜尋」框（放大鏡彈出視窗）。 */
const lensDialog = () => document.querySelector('[data-test-id="lens-file-upload"]')?.closest('[role="dialog"]') ?? null;

/**
 * 拖 Pin（卡片或連到 Pin 頁的連結）或 Pin 頁的大圖時收整個 Pin；其他圖片交給擴充只存那一張。
 * @param {DragEvent} event
 * @returns {HoardDragCapture | null}
 */
function dragCapture(event) {
  if (!(event.target instanceof Element)) return null;
  const pin = event.target.closest('[data-test-id="pin"], a[href*="/pin/"]');
  // Pin 頁的大圖沒有連到自己的連結，用目前網址判斷。
  const onPinPage = pinId(new URL(location.href)) !== null && event.target.closest("img, video");
  if (!pin && !onPinPage) return null;
  // 拖曳前「以圖搜尋」框就開著的話，放進 hoard 後不要關它。
  const lensWasOpen = lensDialog() !== null;
  return {
    element: event.target.closest('[data-test-id="pin"]') ?? null,
    resolve(dt) {
      // 拖動時 Pinterest 會打開「以圖搜尋」框，放進 hoard 後它不會自己關；第一個按鈕是關閉鍵。
      if (!lensWasOpen) setTimeout(() => lensDialog()?.querySelector("button")?.click(), 50);
      const url = dt ? draggedPinUrl(dt) : null;
      // 沒拿到拖曳資料時，在 Pin 頁就是目前這個 Pin。
      const current = pinId(new URL(location.href));
      return url ?? (current ? canonicalUrl(current) : null);
    },
  };
}

// ---- 已收藏的標記與「儲存」時自動收藏 ----

/**
 * 已經收進 hoard 的 Pin 常駐顯示 hoard 的 logo（卡片左上角、Pin 頁的「儲存」左邊）。
 * 還沒收的不顯示：滑過時不多一個按鈕，收藏用拖曳或「儲存」。
 */
const MARK_STYLE = `
  [data-hoard-pin] {
    position: absolute; top: 12px; left: 12px; z-index: 5;
    border-radius: 999px; background: rgb(255 255 255 / 0.92);
  }
  [data-hoard-closeup] { align-items: center; margin-right: 4px; }
  [data-hoard-pin]:not([data-saved]), [data-hoard-closeup]:not([data-saved]) { display: none; }
  [data-hoard-pin][data-saved], [data-hoard-closeup][data-saved] { display: flex; }
`;

/** 某個元素所屬的 Pin（卡片用它的連結）；不在卡片裡是 null。 @param {Element} el */
function pinTargetOf(el) {
  const card = el.closest('[data-test-id="pin"]');
  if (card) {
    const href = card.querySelector('a[href*="/pin/"]')?.getAttribute("href");
    const id = href ? pinId(new URL(href, location.href)) : null;
    return id ? { url: canonicalUrl(id), element: card } : null;
  }
  return null;
}

/** 目前在 Pin 頁時是這個 Pin。 */
function pagePin() {
  const id = pinId(new URL(location.href));
  return id ? { url: canonicalUrl(id), element: null } : null;
}

/** 標記的 holder → 它的 Pin 網址，用來重查收藏狀態。 @type {WeakMap<Element, string>} */
const markUrls = new WeakMap();

/** @param {HoardPage} page @param {Element} holder */
function refreshMark(page, holder) {
  const url = markUrls.get(holder);
  if (!url) return;
  void page.isSaved(url).then((saved) => {
    if (saved) holder.setAttribute("data-saved", "");
    else holder.removeAttribute("data-saved");
  });
}

/**
 * @param {HoardPage} page @param {string} url @param {Element | null} element
 * @param {string} attribute @param {number} size
 */
function createMark(page, url, element, attribute, size) {
  const holder = document.createElement("div");
  holder.setAttribute(attribute, "");
  // 用擴充的收藏按鈕：已收藏時是 logo 加綠色勾勾，按了會重新檢查。
  holder.append(page.createButton(url, element, { size, color: "#111" }));
  markUrls.set(holder, url);
  refreshMark(page, holder);
  return holder;
}

/** @param {HoardPage} page @param {Element} card */
function mountCardMark(page, card) {
  if (card.querySelector("[data-hoard-pin]")) return;
  const wrapper = card.querySelector('[data-test-id="pinWrapper"]');
  const target = pinTargetOf(card);
  if (!wrapper || !target) return;
  wrapper.append(createMark(page, target.url, card, "data-hoard-pin", 32));
}

/** @param {HoardPage} page */
function mountCloseupMark(page) {
  const save = document.querySelector('[data-test-id="pin-better-save-button"]');
  const target = pagePin();
  if (!save || !target || save.parentElement?.querySelector("[data-hoard-closeup]")) return;
  save.before(createMark(page, target.url, null, "data-hoard-closeup", 40));
}

/** @param {HoardPage} page */
function installSavedMarks(page) {
  const style = document.createElement("style");
  style.textContent = MARK_STYLE;
  document.head.append(style);
  const marks = () => document.querySelectorAll("[data-hoard-pin], [data-hoard-closeup]");
  // 卡片是虛擬捲動、隨時重繪的，用 MutationObserver 補標記（每幀最多掃一次）。
  let scheduled = false;
  const scan = () => {
    scheduled = false;
    if (page.settings.savedMarks === false) {
      for (const el of marks()) el.remove();
      return;
    }
    for (const card of document.querySelectorAll('[data-test-id="pin"]')) mountCardMark(page, card);
    mountCloseupMark(page);
  };
  new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(scan);
  }).observe(document.body, { childList: true, subtree: true });
  scan();
  // 剛收進來的（拖曳、儲存、彈出視窗）過一下就出現標記；查詢有快取，很便宜。
  setInterval(() => {
    for (const holder of marks()) refreshMark(page, holder);
  }, 2000);
}

/**
 * 按 Pinterest 的「儲存」時一起收進 hoard（插件設定「在網頁上」的 saveOnSave）：卡片上的快速儲存、
 * Pin 頁的儲存，以及「選擇圖版」選單裡的看板（選單是另外掛在頁面上的，用打開選單前按的那個 Pin）。
 * 按鈕已經是「已儲存」時是取消儲存，不動 hoard。
 * @param {HoardPage} page
 */
function installAutoSave(page) {
  /** @type {{ url: string; element: Element | null } | null} */
  let lastPin = null;
  document.addEventListener(
    "pointerdown",
    (event) => {
      if (event.target instanceof Element) lastPin = pinTargetOf(event.target) ?? lastPin;
    },
    true,
  );
  document.addEventListener(
    "click",
    (event) => {
      if (page.settings.saveOnSave !== true || !(event.target instanceof Element)) return;
      const quick = event.target.closest('[data-test-id="quick-save-button"]');
      const closeup = event.target.closest('[data-test-id="PinBetterSaveButton"]');
      const row = event.target.closest('[data-test-id="board-picker-flyout"] [data-test-id^="board-row"]');
      const trigger = quick ?? closeup ?? row;
      if (!trigger || /已儲存|已保存|Saved|保存済み/.test(trigger.textContent ?? "")) return;
      const target = quick ? pinTargetOf(quick) : (closeup ? pinTargetOf(closeup) : lastPin) ?? pagePin();
      if (target) void page.capture(target.url, target.element);
    },
    true,
  );
}

hoard.registerExtractor({
  sourceType: "pinterest",

  dragCapture,

  integrate(page) {
    installSavedMarks(page);
    installAutoSave(page);
  },

  sourceUrl(url) {
    const id = pinId(url);
    return id ? canonicalUrl(id) : null;
  },

  listCreatorPosts: listBoard,

  async extract(ctx) {
    const id = pinId(ctx.url);
    if (!id) throw new Error("這不是 Pin 的頁面（網址裡要有 /pin/ 與 Pin 的編號）");
    ctx.progress("讀取 Pin 資料");
    const pin = await fetchPin(id);
    /** @type {string[]} */
    const warnings = [];

    const { sources, streamOnly, poster } = await collectMedia(pin);
    // 圖片只給網址，由擴充背景下載：交出去之後重新整理或關掉分頁，收藏也會完成。
    const media = sources.map((source) => (source.alt ? { url: source.url, alt: source.alt } : { url: source.url }));

    const { title, auto: titleAuto } = titleOf(pin);
    const description = (pin.closeup_unified_description || pin.description || "").trim();
    const board = pin.board;
    const saveComments = (await hoard.getSettings()).saveComments !== false;
    if (saveComments) ctx.progress("讀取留言");
    const comments = saveComments ? await fetchComments(pin, warnings) : [];
    /** 從看板批次收藏時，清單上記著是哪個看板、哪個分區（App 端依它放進資料夾）。 */
    const from = /** @type {{ board?: string; section?: string | null } | undefined} */ (ctx.listing?.data);

    return {
      payload: {
        source_type: "pinterest",
        source_url: canonicalUrl(id),
        title,
        description: description || undefined,
        author: authorOf(pin),
        published_at: isoDate(pin.created_at),
        metadata: {
          pin_id: id,
          // 原圖檔名裡的雜湊：同一張圖被轉存成不同的 Pin 時相同，App 端用它找重複。
          image_signature: pin.image_signature || undefined,
          auto_title: titleAuto ? title : undefined,
          collected_board: from?.board || undefined,
          collected_section: from?.section || undefined,
          board_name: board?.name || undefined,
          board_url: board?.url ? `https://www.pinterest.com${board.url}` : undefined,
          saved_by: pin.pinner?.username || undefined,
          link: pin.link || undefined,
          // 自己上傳的 Pin 是「Uploaded by user」這種字，不是網域。
          domain: /^[\w-]+(?:\.[\w-]+)+$/.test(pin.domain ?? "") ? pin.domain : undefined,
          save_count: pin.aggregated_pin_data?.aggregated_stats?.saves ?? undefined,
          dominant_color: pin.dominant_color || undefined,
          // 只有 HLS 串流：App 用 yt-dlp 下載 source_url 的影片。
          has_video: streamOnly || Boolean(pin.videos) || undefined,
        },
        media,
        poster: poster ? { url: poster } : undefined,
        comments: comments.length > 0 ? comments : undefined,
      },
      warnings,
    };
  },
});
