// @ts-check
/// <reference path="../hoard-app.d.ts" />
/* Pinterest App 端：
   - 卡片（renderCard）：照 Pinterest 的 Pin，不要 App 的外框，只有 16px 圓角的圖與下方的標題（沒有作者）；
     滑過時上方加深，多張圖的 Pin 出現左右箭頭與圓點，GIF 與影片會播放。前 4 張用 item.previews，更多張時第一次換圖才讀完整的 files。
   - 詳情頁：仿 Pinterest 的 Pin 頁，左邊是圖（多張時可以左右切換），右邊是標題、說明、原始連結、上傳者、看板與留言。
   - 收進來之後：從看板整批收藏的放進「Pinterest / 看板 / 分區」資料夾；轉存的同一張圖提示可以移到垃圾桶。
   樣式見 styles.css：卡片用 pn- 前綴的全域 class，詳情頁限定在 [data-hoard-skin="pinterest"] 之下。 */

/** @param {unknown} value */
const text = (value) => (typeof value === "string" ? value : "");

/** @param {HoardItemFile} file */
const isImage = (file) => file.kind === "image";

/** @param {HoardItemFile} file */
const slideSrc = (file) => hoard.fileSrc(file.preview_path || file.path);

/** 作品 id → 全部圖片的網址（超過 previews 的 4 張時才讀）。作品變動時丟掉。 */
const fullSlides = new Map();
hoard.on("items-changed", ({ ids }) => {
  for (const id of ids) fullSlides.delete(id);
});

/** @param {HoardItemSummary} item @returns {Promise<string[]>} */
async function loadAllSlides(item) {
  const cached = fullSlides.get(item.id);
  if (cached) return cached;
  const detail = await hoard.items.get(item.id);
  const slides = detail.files.filter(isImage).map(slideSrc);
  fullSlides.set(item.id, slides);
  return slides;
}

/** 原始連結的網域，例如 "dreamstime.com"。 */
function linkLabel(item) {
  const link = text(item.metadata.link);
  if (!link) return "";
  const domain = text(item.metadata.domain);
  if (/^[\w-]+(?:\.[\w-]+)+$/.test(domain)) return domain;
  try {
    return new URL(link).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

/**
 * 沒有標題的 Pin，擷取器用「看板 上的 Pin」這類 Pinterest 自動產生的字當標題；卡片照原站不顯示它。
 * 使用者自己改過標題就照常顯示。舊的作品沒有 auto_title，用常見的格式判斷。
 * @param {HoardItemSummary} item
 */
function cardTitle(item) {
  const auto = item.metadata.auto_title;
  if (typeof auto === "string") return item.title === auto ? "" : item.title;
  return /(?: 上的 Pin|のピン)$|^Pin on |^Pin \d+$/.test(item.title) ? "" : item.title;
}

// ---- 動畫（App 的 docs/conventions.md〈動畫〉：插件拿不到 App 的動畫程式，照同一組時長、曲線自己做） ----

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場、移動、變大。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/** 元素現在（滑到一半也算）的水平位移，px。 @param {Element} el */
function shiftOf(el) {
  const value = parseFloat(getComputedStyle(el).translate);
  return Number.isFinite(value) ? value : 0;
}

/** 每個框裡還在滑走的圖，與最近一次換圖的記號。 @type {WeakMap<HTMLElement, { gone: HTMLElement[]; token: object }>} */
const tracks = new WeakMap();

/**
 * 換一張：舊的整張往反方向滑出框、新的從另一邊整張滑進來，兩張同時走、不淡出（跟 App 換作品的 slideWorks 同一套）。
 * 像一條每格一個框寬的軌道：連按時從目前的位置接著走，還在滑走的跟著一起走；按反方向時，剛滑走的那張由新的一張接回它的位置。
 * fresh 要先放進框裡；它也可以是還在滑走的那一張（拉回來）。滑動期間才裁掉框外。
 * @param {HTMLElement} clip @param {HTMLElement} shown @param {HTMLElement} fresh
 * @param {1 | -1} d 1：往後一張（整條往左走）
 * @param {{ ms?: number; gone?: (el: HTMLElement) => void; pin?: boolean }} [opts]
 *   gone：滑出去的那張怎麼收（預設拿掉）；pin：舊的排在版面裡時，先釘在原位（新的才能接著排進來）
 */
function slideTo(clip, shown, fresh, d, opts = {}) {
  const { ms = 220, gone = (/** @type {HTMLElement} */ el) => el.remove(), pin = false } = opts;
  const live = (tracks.get(clip)?.gone ?? []).filter((el) => el.isConnected && el !== shown && el !== fresh);
  if (!motionOn()) {
    tracks.delete(clip);
    for (const el of [shown, ...live]) gone(el);
    return;
  }
  const D = clip.clientWidth;
  const cur = shiftOf(shown);
  const rest = live.map((el) => /** @type {const} */ ([el, shiftOf(el)]));
  for (const el of [shown, fresh, ...live]) for (const a of el.getAnimations()) a.cancel();
  if (pin && getComputedStyle(shown).position !== "absolute") {
    Object.assign(shown.style, {
      position: "absolute",
      left: `${shown.offsetLeft}px`,
      top: `${shown.offsetTop}px`,
      width: `${shown.offsetWidth}px`,
      height: `${shown.offsetHeight}px`,
      margin: "0",
    });
  }
  clip.style.overflowX = "clip";
  const delta = -d * D - cur; // 整條這次走多遠
  const start = cur + d * D; // 新的一張緊接在舊的後面
  /** @param {HTMLElement} el @param {number} from */
  const out = (el, from) => {
    const a = el.animate([{ translate: `${from}px 0` }, { translate: `${from + delta}px 0` }], { duration: ms, easing: EASE_OUT, fill: "forwards" });
    return a.finished.then(
      () => {
        gone(el);
        a.cancel();
      },
      () => {},
    );
  };
  const leaving = [shown];
  /** @type {Promise<unknown>[]} */
  const runs = [out(shown, cur)];
  for (const [el, at] of rest) {
    if (Math.abs(at - start) < 1) {
      gone(el); // 按反方向：新的一張接回它的位置
      continue;
    }
    leaving.push(el);
    runs.push(out(el, at));
  }
  runs.push(fresh.animate([{ translate: `${start}px 0` }, { translate: "0 0" }], { duration: ms, easing: EASE_OUT }).finished.catch(() => {}));
  const token = {};
  tracks.set(clip, { gone: leaving, token });
  void Promise.all(runs).then(() => {
    if (tracks.get(clip)?.token !== token) return;
    tracks.delete(clip);
    clip.style.overflowX = "";
  });
}

/**
 * 卡片上的換圖：第 0 張是封面本身（App 縮小過的），其他張是疊在上面的 <img>；按箭頭往那個方向整張滑過去。
 * 底部的圓點是第幾張。
 * @param {HTMLElement} cover
 * @param {HoardItemSummary} item
 * @param {HTMLElement | null} base 封面的 <img>；封面是 App 畫的（mountCover）時是 null
 */
function attachSlider(cover, item, base) {
  let slides = item.previews.filter(isImage).map(slideSrc);
  let loaded = item.file_count <= item.previews.length;
  let index = 0;
  // 第 0 張：封面的 <img>；App 畫的封面不能移動，就用一層透明的代替（滑走時露出底下的封面）。
  const zero = base ?? hoard.el("span", { class: "pn-slide" });
  /** 現在這張。 */
  let current = zero;
  /** 滑出去的：第 0 張藏起來（下次還要用），其他張拿掉。 @param {HTMLElement} el */
  const gone = (el) => {
    if (el === zero) el.style.visibility = "hidden";
    else el.remove();
  };

  const dots = hoard.el("div", { class: "pn-dots" });
  const show = () => {
    // 最多 10 個圓點；張數更多時每個圓點代表一段（30 張時第 1–3 張亮第一個，第 4–6 張亮第二個…）。
    const pages = loaded ? slides.length : item.file_count;
    const count = Math.min(pages, 10);
    const on = Math.floor((index * count) / pages);
    dots.replaceChildren(
      ...Array.from({ length: count }, (_, i) => hoard.el("span", { class: i === on ? "pn-dot pn-dot-on" : "pn-dot" })),
    );
  };

  /** @param {number} step */
  const go = async (step) => {
    if (!loaded) {
      try {
        slides = await loadAllSlides(item);
      } catch {
        // 讀不到就只在前幾張之間換。
      }
      loaded = true;
    }
    if (slides.length < 2) return;
    index = (index + step + slides.length) % slides.length;
    const shown = current;
    const fresh = index === 0 ? zero : hoard.el("img", { class: "pn-slide", src: slides[index], alt: "", draggable: "false" });
    current = fresh;
    fresh.style.visibility = "";
    // 疊在封面與滑過的暗角上、箭頭下（跟以前那層 <img> 同一個位置）。
    if (fresh !== zero || !base) prev.before(fresh);
    show();
    slideTo(cover, shown, fresh, step > 0 ? 1 : -1, { gone });
    // 先載入下一張，按下去時不會閃。
    const next = slides[(index + 1) % slides.length];
    if (next) new Image().src = next;
  };

  const arrow = (cls, icon, label, step) =>
    hoard.el("button", { class: `pn-btn pn-nav ${cls}`, title: label, "aria-label": label, onclick: () => void go(step) }, [
      hoard.icon(icon, { size: 16 }),
    ]);

  const prev = arrow("pn-prev", "chevron-left", "上一張", -1);
  show();
  cover.append(prev, arrow("pn-next", "chevron-right", "下一張", 1), dots);
  if (!base) prev.before(zero);
}

/**
 * 左下角的「造訪網站」：放得下就寫網址，網址太長寫「造訪網站」，再放不下只留圖示，連圖示都放不下就不顯示。
 * 卡片大小會變（視窗、卡片大小滑桿），用 ResizeObserver 重算；回傳停止的函式。
 * @param {HTMLElement} cover
 * @param {HoardItemSummary} item
 * @param {string} link
 */
function attachVisit(cover, item, link) {
  const label = hoard.el("span", { class: "pn-visit-label" });
  const button = hoard.el(
    "button",
    { class: "pn-btn pn-visit", title: link, "aria-label": "造訪網站", onclick: () => hoard.openUrl(link) },
    [hoard.icon("arrow-up-right", { size: 14 }), label],
  );
  cover.append(button);
  const texts = [linkLabel(item), "造訪網站"].filter(Boolean);
  const fit = () => {
    // 左右各留 12px；有換圖圓點時只用到圓點左邊。
    const dots = cover.querySelector(".pn-dots");
    const room = dots
      ? (cover.clientWidth - dots.getBoundingClientRect().width) / 2 - 12 - 8
      : cover.clientWidth - 24;
    button.hidden = false;
    button.classList.remove("pn-visit-icon");
    for (const value of texts) {
      label.textContent = value;
      if (button.offsetWidth <= room) return;
    }
    label.textContent = "";
    button.classList.add("pn-visit-icon");
    if (button.offsetWidth > room) button.hidden = true;
  };
  const observer = new ResizeObserver(fit);
  observer.observe(cover);
  return () => observer.disconnect();
}

// ---- 詳情頁 ----

/** 圖片或影片有尺寸了（載入完、讀到影片資訊，或讀不到）。 @param {HTMLElement} el @returns {Promise<void>} */
function whenSized(el) {
  return new Promise((resolve) => {
    if (el instanceof HTMLImageElement ? el.complete : el instanceof HTMLVideoElement ? el.readyState >= 1 : true) return resolve();
    el.addEventListener(el instanceof HTMLImageElement ? "load" : "loadedmetadata", () => resolve(), { once: true });
    el.addEventListener("error", () => resolve(), { once: true });
  });
}

/**
 * 左邊的圖：多張時左右切換（往按的方向整張滑過去，比例不同時框的高度跟著補間），點圖開全螢幕檢視器。
 * @param {HoardItemDetail} item
 * @param {HoardRenderCtx} ctx
 */
function mediaStage(item, ctx) {
  const media = item.files.filter((file) => file.kind === "image" || file.kind === "video");
  const stage = hoard.el("div", { class: "pnd-media" });
  if (media.length === 0) return stage;
  let index = 0;
  const frame = hoard.el("div", { class: "pnd-frame" });
  const dots = hoard.el("div", { class: "pnd-dots" });
  /** 現在這張。 @type {HTMLElement | null} */
  let current = null;
  /** 最近一次換圖的編號：晚到的「有尺寸了」不動到之後那一張的高度。 */
  let sizing = 0;

  /** @param {HoardItemFile} file */
  const mediaEl = (file) =>
    file.kind === "video"
      ? hoard.el("video", { src: hoard.fileSrc(file.path), controls: "", loop: "", preload: "metadata" })
      : // 原圖不設 decoding: "async"：每換一張都是新的 <img>，已經載入過的圖同步解碼，下一格就畫出來，
        // 非同步會先空一下。Pinterest 的圖最大約 830 萬像素，同步解碼的停頓不明顯（docs/conventions.md〈例外〉）。
        hoard.el("img", {
          src: hoard.fileSrc(file.path),
          alt: file.alt ?? item.title,
          ...(file.alt ? { title: file.alt } : {}),
          onclick: () => ctx.openViewer(media, index),
        });

  /** @param {number} next @param {1 | -1 | 0} d 往哪邊換；0 是第一次畫 */
  const show = (next, d) => {
    index = next;
    const fresh = mediaEl(media[index]);
    const old = current;
    current = fresh;
    dots.replaceChildren(
      ...media.map((_, i) =>
        hoard.el("button", {
          class: i === index ? "pnd-dot pnd-dot-on" : "pnd-dot",
          "aria-label": `第 ${i + 1} 張`,
          onclick: () => {
            if (i !== index) show(i, i > index ? 1 : -1);
          },
        }),
      ),
    );
    if (!old || d === 0) {
      frame.replaceChildren(fresh);
      return;
    }
    // 框的高度：從它現在顯示的（補間到一半也算）開始，等新的一張有尺寸再補間過去。
    const from = frame.getBoundingClientRect().height;
    for (const a of frame.getAnimations()) a.cancel();
    frame.append(fresh);
    slideTo(frame, old, fresh, d, { pin: true });
    if (!motionOn()) return;
    frame.style.height = `${from}px`;
    const mine = ++sizing;
    void whenSized(fresh).then(() => {
      if (mine !== sizing || !frame.isConnected) return;
      frame.style.height = "";
      const to = frame.offsetHeight;
      if (Math.abs(to - from) > 0.5) frame.animate([{ height: `${from}px` }, { height: `${to}px` }], { duration: 200, easing: EASE_OUT });
    });
  };
  show(0, 0);
  stage.append(frame);
  if (media.length > 1) {
    /** @param {1 | -1} step */
    const go = (step) => show((index + step + media.length) % media.length, step);
    stage.append(
      hoard.el("button", { class: "pnd-nav pnd-prev", "aria-label": "上一張", onclick: () => go(-1) }, [
        hoard.icon("chevron-left", { size: 20 }),
      ]),
      hoard.el("button", { class: "pnd-nav pnd-next", "aria-label": "下一張", onclick: () => go(1) }, [
        hoard.icon("chevron-right", { size: 20 }),
      ]),
      dots,
    );
  }
  return stage;
}

/** @param {HoardItemDetail} item @param {HoardRenderCtx} ctx */
function infoPanel(item, ctx) {
  const meta = item.metadata;
  const link = text(meta.link);
  const boardName = text(meta.board_name);
  const boardUrl = text(meta.board_url);
  const actions = [];
  if (link) {
    actions.push(
      hoard.el("button", { class: "pnd-pill", title: link, onclick: () => hoard.openUrl(link) }, [
        hoard.icon("external-link", { size: 14 }),
        linkLabel(item) || "原始連結",
      ]),
    );
  }
  if (item.source_url) {
    const url = item.source_url;
    actions.push(hoard.el("button", { class: "pnd-pill pnd-pill-red", onclick: () => hoard.openUrl(url) }, ["在 Pinterest 開啟"]));
  }

  const parts = [hoard.el("div", { class: "pnd-actions" }, actions), hoard.el("h1", { class: "pnd-title" }, [item.title])];
  if (item.description && item.description !== item.title) {
    parts.push(hoard.el("p", { class: "pnd-desc" }, [item.description]));
  }

  const author = item.author;
  if (author) {
    parts.push(
      hoard.el("div", { class: "pnd-author" }, [
        author.avatar_path
          ? hoard.el("img", { class: "pnd-avatar", src: hoard.fileSrc(author.avatar_path), alt: "", draggable: "false" })
          : hoard.el("span", { class: "pnd-avatar" }, [author.name.trim().charAt(0).toUpperCase() || "?"]),
        hoard.el("div", {}, [
          hoard.el(
            "p",
            { class: "pnd-author-name", title: "查看這位創作者的所有收藏", onclick: () => ctx.openAuthor(author.id) },
            [author.name],
          ),
          author.handle ? hoard.el("p", { class: "pnd-muted" }, [`@${author.handle}`]) : null,
        ]),
      ]),
    );
  }

  const facts = [];
  if (boardName) {
    facts.push(
      hoard.el("p", { class: "pnd-fact" }, [
        hoard.icon("layout-grid", { size: 14 }),
        "看板 ",
        boardUrl
          ? hoard.el("button", { class: "pnd-link", onclick: () => hoard.openUrl(boardUrl) }, [boardName])
          : hoard.el("strong", {}, [boardName]),
      ]),
    );
  }
  if (typeof meta.save_count === "number" && meta.save_count > 0) {
    facts.push(hoard.el("p", { class: "pnd-fact" }, [hoard.icon("pin", { size: 14 }), `${hoard.formatCount(meta.save_count)} 次儲存`]));
  }
  if (item.published_at) {
    facts.push(hoard.el("p", { class: "pnd-fact pnd-muted" }, [hoard.formatDateTime(item.published_at)]));
  }
  if (facts.length > 0) parts.push(hoard.el("div", { class: "pnd-facts" }, facts));
  if (item.comments.length > 0) {
    const list = hoard.el("div", { class: "pnd-comment-list" });
    ctx.mountComments(list, item.comments);
    // App 的留言串自己有「留言 · N」標題。
    parts.push(hoard.el("section", { class: "pnd-comments" }, [list]));
  }
  return hoard.el("div", { class: "pnd-info" }, parts);
}

// ---- 收進來之後：看板放進資料夾、找出轉存的同一張圖 ----

/** 依序執行，避免同時建立兩個同名資料夾。 */
/** @type {Promise<unknown>} */
let queue = Promise.resolve();
/** @param {() => Promise<unknown>} task */
const enqueue = (task) => {
  queue = queue.then(task).catch((err) => console.error("[pinterest]", err));
  return queue;
};

/**
 * 從看板整批收藏的作品放進「Pinterest / 看板 / 分區」資料夾（沒有就建立）。
 * 已經收藏過、這次被跳過的 Pin 不會經過這裡，要的話自己拖進資料夾。
 * @param {HoardItemSummary[]} items
 */
async function fileByBoard(items) {
  const collected = items.filter((item) => text(item.metadata.collected_board));
  if (collected.length === 0) return;
  const folders = await hoard.folders.list();
  /** @param {string} name @param {number | null} parentId */
  const folder = async (name, parentId) => {
    // The overview's folders: one made inside a page belongs to that page only.
    const found = folders.find(
      (f) => f.page_id === null && f.parent_id === parentId && f.name.toLowerCase() === name.toLowerCase(),
    );
    if (found) return found;
    const created = await hoard.folders.create(name, parentId ?? undefined);
    folders.push(created);
    return created;
  };
  const root = await folder("Pinterest", null);
  /** @type {Map<number, number[]>} */
  const byFolder = new Map();
  for (const item of collected) {
    const board = await folder(text(item.metadata.collected_board), root.id);
    const section = text(item.metadata.collected_section);
    const target = section ? await folder(section, board.id) : board;
    byFolder.set(target.id, [...(byFolder.get(target.id) ?? []), item.id]);
  }
  for (const [id, ids] of byFolder) await hoard.folders.add(id, ids);
}

/**
 * 原圖的雜湊 → 有這張圖的作品。同一張圖被別人轉存成不同的 Pin 時雜湊相同，Pin 編號不同，
 * 所以收藏時不會被當成同一篇；收進來之後在這裡比對。第一次用到時讀一次全部的 Pinterest 作品，之後隨事件更新。
 * @type {Map<string, Set<number>> | null}
 */
let bySignature = null;

async function signatureIndex() {
  if (bySignature) return bySignature;
  /** @type {Map<string, Set<number>>} */
  const index = new Map();
  for (let offset = 0; ; offset += 500) {
    const page = await hoard.items.list({ source_type: "pinterest" }, { offset, limit: 500 });
    for (const item of page.items) indexItem(index, item);
    if (page.items.length < 500) break;
  }
  bySignature = index;
  return index;
}

/** @param {Map<string, Set<number>>} index @param {HoardItemSummary} item */
function indexItem(index, item) {
  const signature = text(item.metadata.image_signature);
  if (!signature) return;
  index.set(signature, (index.get(signature) ?? new Set()).add(item.id));
}

/** 這次發現的重複（新收進來的那一件），提示合併成一則，按鈕一次移到垃圾桶。 */
const duplicates = new Set();
let duplicateTimer = 0;

function announceDuplicates() {
  // Said once: ignoring the notice keeps them, and later batches don't bring them up again.
  const ids = [...duplicates];
  duplicates.clear();
  if (ids.length === 0) return;
  hoard.toast(ids.length === 1 ? "這張圖已經收藏過（另一個 Pin）" : `${ids.length} 張圖已經收藏過（另一個 Pin）`, {
    kind: "info",
    action: {
      label: "移到垃圾桶",
      run: () => {
        void hoard.items.trash(ids).then((n) => hoard.toast(`已把 ${n} 件重複的作品移到垃圾桶`));
      },
    },
  });
}

/** @param {HoardItemSummary[]} items */
async function findDuplicates(items) {
  const index = await signatureIndex();
  for (const item of items) {
    const signature = text(item.metadata.image_signature);
    const others = signature ? [...(index.get(signature) ?? [])].filter((id) => id !== item.id) : [];
    indexItem(index, item);
    if (others.length > 0) duplicates.add(item.id);
  }
  if (duplicates.size === 0) return;
  // 整批收藏時每篇都會來一次，等一下再一起提示（只提示這段時間新發現的）。
  clearTimeout(duplicateTimer);
  duplicateTimer = window.setTimeout(announceDuplicates, 1500);
}

hoard.on("items-added", ({ ids }) => {
  void enqueue(async () => {
    const { items } = await hoard.items.list({ ids, source_type: "pinterest" }, { limit: ids.length });
    if (items.length === 0) return;
    await fileByBoard(items);
    await findDuplicates(items);
  });
});
/** 移出收藏庫（例如進了垃圾桶）的作品；只有它們可能被還原回來。 @type {Set<number>} */
const removedIds = new Set();
hoard.on("items-removed", ({ ids }) => {
  for (const id of ids) {
    duplicates.delete(id);
    removedIds.add(id);
  }
  if (!bySignature) return;
  for (const set of bySignature.values()) for (const id of ids) set.delete(id);
});
// 從垃圾桶還原也算回來；其他欄位的改變不影響雜湊。別的插件在背景寫篩選值、封面時這個事件很頻繁，
// 所以只看移走過的作品，其他的不查。
hoard.on("items-changed", ({ ids }) => {
  const restored = ids.filter((id) => removedIds.delete(id));
  if (!bySignature || restored.length === 0) return;
  void enqueue(async () => {
    const { items } = await hoard.items.list({ ids: restored, source_type: "pinterest" }, { limit: restored.length });
    if (bySignature) for (const item of items) indexItem(bySignature, item);
  });
});

hoard.register({
  // 仿 Pinterest 的 Pin：只有圓角的圖與下方的標題，不顯示作者，也不要 App 的卡片外框。
  cardFrame: false,

  renderCard(root, item, ctx) {
    const card = hoard.el("div", { class: `pn-card pn-d-${ctx.density}` });
    const cover = hoard.el("div", { class: "pn-cover", style: `aspect-ratio: ${ctx.coverAspect}` });
    const src = item.cover_path || item.thumbnail_path;
    if (src) {
      const still = hoard.fileSrc(src);
      const img = hoard.el("img", { class: "pn-img", src: still, alt: item.title, loading: "lazy", draggable: "false" });
      cover.append(img);
      // 封面是靜態的縮圖；GIF 的 Pin 滑過時換成原檔，就會動。
      const gif = item.previews.find((file) => isImage(file) && file.ext === "gif");
      if (gif) {
        const moving = hoard.fileSrc(gif.path);
        card.addEventListener("mouseenter", () => img.setAttribute("src", moving));
        card.addEventListener("mouseleave", () => img.setAttribute("src", still));
        cover.append(hoard.el("span", { class: "pn-gif" }, ["GIF"]));
      }
      // 影片也一樣：滑過時靜音循環播放，有畫面了才淡入、▶ 同時淡出（跟 App 的卡片一樣）；
      // 滑開時影片停在那一格淡出、▶ 淡回來，淡完才移除（不在背景繼續下載）。
      const video = item.previews.find((file) => file.kind === "video");
      if (video) {
        /** @type {HTMLVideoElement | null} */
        let player = null;
        card.addEventListener("mouseenter", () => {
          if (player) return;
          const p = /** @type {HTMLVideoElement} */ (
            hoard.el("video", { class: "pn-hover-video", src: hoard.fileSrc(video.path), muted: "", loop: "", playsinline: "", autoplay: "" })
          );
          p.muted = true;
          p.addEventListener("playing", () => {
            if (player !== p) return;
            p.classList.add("pn-on");
            cover.classList.add("pn-playing");
          });
          player = p;
          img.after(p);
        });
        card.addEventListener("mouseleave", () => {
          const p = player;
          player = null;
          cover.classList.remove("pn-playing");
          if (!p) return;
          const drop = () => {
            p.removeAttribute("src");
            p.load();
            p.remove();
          };
          if (!motionOn() || !p.classList.contains("pn-on")) return drop();
          p.animate([{ opacity: getComputedStyle(p).opacity }, { opacity: 0 }], { duration: 160, easing: EASE_IN, fill: "forwards" }).finished.then(drop, drop);
        });
      }
    } else {
      ctx.mountCover(cover);
    }
    // 滑過時上方加深，跟原站一樣。
    cover.append(hoard.el("div", { class: "pn-wash" }));
    if (item.metadata.has_video) cover.append(hoard.el("span", { class: "pn-video" }, [hoard.icon("play", { size: 12 })]));
    // 太小的卡片放不下箭頭。
    if (item.file_count > 1 && ctx.density !== "cover") attachSlider(cover, item, /** @type {HTMLElement | null} */ (cover.querySelector(".pn-img")));
    const link = text(item.metadata.link);
    const stopFitting = link ? attachVisit(cover, item, link) : undefined;
    card.append(cover);
    const title = ctx.density === "full" ? cardTitle(item) : "";
    if (title) card.append(hoard.el("p", { class: "pn-title" }, [title]));
    root.append(card);
    return stopFitting;
  },

  renderDetail(root, item, ctx) {
    root.append(
      hoard.el("div", { class: "pnd-page" }, [
        hoard.el("article", { class: "pnd-closeup" }, [mediaStage(item, ctx), infoPanel(item, ctx)]),
      ]),
    );
  },
});

// ---- 插件設定：在網頁上的行為（擴充端用 page.settings 讀，每個網站有的動作不同） ----

/** @type {Array<{ key: string; label: string; hint: string; fallback: boolean }>} */
const PAGE_OPTIONS = [
  { key: "savedMarks", label: "已收藏的 Pin 顯示 hoard 標記", hint: "卡片左上角與 Pin 頁的「儲存」左邊。", fallback: true },
  { key: "saveOnSave", label: "按「儲存」時一起收藏", hint: "卡片上的快速儲存、Pin 頁的儲存、「選擇圖版」選單裡的看板。", fallback: false },
  { key: "saveComments", label: "收藏時一起抓留言", hint: "最多 500 則；關掉後收藏比較快。", fallback: true },
];

/**
 * 改擷取器設定（`hoard.storage` 的 `extractor`）的一項。用 `storage.update` 一次讀改寫：
 * 快速連切兩個開關時，後一個不會蓋掉前一個。
 * @param {string} key @param {unknown} value
 */
function saveExtractorSetting(key, value) {
  return hoard.storage.update("extractor", (/** @type {Record<string, unknown> | undefined} */ saved) => ({ ...saved, [key]: value }));
}

hoard.registerSettingTab({
  label: "在網頁上",
  render(el) {
    const inputs = PAGE_OPTIONS.map((option) => {
      const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "pn-switch" }));
      el.append(
        hoard.el("label", { class: "pn-setting-row" }, [
          hoard.el("span", {}, [hoard.el("strong", {}, [option.label]), hoard.el("span", { class: "pn-setting-hint" }, [option.hint])]),
          input,
        ]),
      );
      return { option, input };
    });
    el.append(hoard.el("p", { class: "pn-setting-hint" }, ["改完後重新整理網頁就生效，不用同步插件。"]));
    void hoard.storage.get("extractor").then((saved) => {
      const settings = /** @type {Record<string, unknown>} */ (saved ?? {});
      for (const { option, input } of inputs) input.checked = typeof settings[option.key] === "boolean" ? Boolean(settings[option.key]) : option.fallback;
    });
    for (const { option, input } of inputs) {
      input.addEventListener("change", async () => {
        await saveExtractorSetting(option.key, input.checked);
      });
    }
  },
});

// ---- 作者頭像：插件找網址、下載，交給核心存（創作者清單、創作者頁顯示） ----

/** @type {Record<string, string>} */
const AVATAR_HEADERS = {};

/**
 * 帳號的頭像網址：用個人頁網址的使用者名稱查站方的 UserResource（不用登入，要帶 PWS 標頭）；
 * 沒設頭像的預設圖不算。
 * @param {HoardAuthor} author
 */
async function avatarUrl(author) {
  if (!author.url) return null;
  const username = new URL(author.url).pathname.split("/").filter(Boolean)[0];
  if (!username) return null;
  const data = JSON.stringify({ options: { username, field_set_key: "profile" }, context: {} });
  const res = await hoard.fetch(
    `https://www.pinterest.com/resource/UserResource/get/?source_url=${encodeURIComponent(`/${username}/`)}&data=${encodeURIComponent(data)}`,
    { headers: { "X-Pinterest-PWS-Handler": "www/[username].js" } },
  );
  if (!res.ok) throw new Error(`使用者資料 HTTP ${res.status}`);
  const user = /** @type {any} */ (await res.json())?.resource_response?.data;
  const url = user?.image_xlarge_url || user?.image_large_url;
  return typeof url === "string" && url && !url.includes("/default_") ? url : null;
}

/** 這次開 App 試過的帳號（抓到或失敗）不再試。 */
const avatarTried = new Set();
/** @type {Promise<void> | null} */
let avatarRun = null;
let avatarAgain = false;
let avatarStopped = false;
hoard.onUnload(() => {
  avatarStopped = true;
});

/** 替還沒有頭像的 Pinterest 帳號補上：一次一個、間隔一下；跑的時候又有新收藏就再跑一輪。 */
function fillAvatars() {
  if (avatarRun) {
    avatarAgain = true;
    return;
  }
  avatarRun = (async () => {
    do {
      avatarAgain = false;
      const authors = await hoard.authors.list({ source: "pinterest" });
      for (const author of authors) {
        if (avatarStopped) return;
        if (author.avatar_path || avatarTried.has(author.id)) continue;
        avatarTried.add(author.id);
        try {
          const url = await avatarUrl(author);
          if (!url) continue;
          const res = await hoard.fetch(url, { headers: AVATAR_HEADERS });
          if (!res.ok) throw new Error(`頭像 HTTP ${res.status}`);
          await hoard.authors.setAvatar(author.id, await res.arrayBuffer(), { source: url });
        } catch (err) {
          console.warn(`[pinterest] 抓不到 ${author.name} 的頭像：`, err);
        }
        await new Promise((resolve) => setTimeout(resolve, 1200));
      }
    } while (avatarAgain && !avatarStopped);
  })()
    .catch((err) => console.warn("[pinterest] 補頭像失敗：", err))
    .finally(() => {
      avatarRun = null;
    });
}

// 開 App 後先讓畫面載完再補；之後每有新收藏就補新的作者。
const avatarStart = setTimeout(fillAvatars, 8000);
hoard.onUnload(() => clearTimeout(avatarStart));
hoard.on("items-added", () => fillAvatars());
