// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：PDF。收進來的 PDF 就是一份 PDF（本機的單一檔案），這裡用 Mozilla 的 pdf.js 顯示；
 * 要當漫畫讀是使用者自己的決定（右鍵「展開成頁」再「開啟方式」選漫畫閱讀器），這裡不替使用者決定。
 *
 *  - 檢視器放在核心的沙盒框架裡（hoard.mountFrame）：和 App 不同源、碰不到 App 與 hoard 的指令，也連不了網。
 *    框架讀得到 PDF 所在的資料夾（dir），插件資料夾在框架的 .hoard/plugin/（viewer/ 與 pdf.js）。
 *    入口頁是這裡做的（files），設定（模式、檔名、頁碼、縮放、圖示）寫在頁裡。PDF 的程式不執行。
 *  - 詳情頁（registerDetail）：工具列（目錄、頁碼、縮放、搜尋）與連續捲動的頁面，文字可以選取、複製；
 *    文件裡的連結：文件內的直接跳，外面的網址交給 App（問過才開）。
 *  - 快速預覽（registerQuickLook）：只有頁面，↑ ↓ PageUp PageDown Home End 捲動。
 *  - 記住的：每份 PDF 讀到第幾頁（storage 的 positions，最近的 POSITION_LIMIT 份）、上次的縮放（settings.zoom）。
 *  - 背景分析：載入時與 items-added 時找還沒分析過的（篩選值 scanned 不是目前的 SCAN_VERSION），一件一件在看不到的框架裡
 *    畫第一頁當封面（hoard.items.setCover）、讀前幾頁的文字與文件標題、作者給搜尋框（_text）。有密碼、畫不出來的用文字封面。
 *  - 只讀檔案，不改原檔：表單照外觀畫，不能填。
 */

const SCAN_VERSION = "1";
const SCAN_BATCH = 20;
/** 背景分析一件最多等多久。 */
const SCAN_TIMEOUT = 30_000;
/** 記住讀到第幾頁的 PDF 最多幾份（最近看的留著）。 */
const POSITION_LIMIT = 1000;
/** 頁碼、縮放多久沒變才寫進 storage。 */
const SAVE_DELAY = 800;
/** 框架多久沒說打開了就先露出來（讓它自己顯示狀況）。 */
const REVEAL_TIMEOUT = 8000;
const MIN_DETAIL_HEIGHT = 360;
const COVER_WIDTH = 600;
const COVER_HEIGHT = 800;
const ENTRY = "hoard-pdf.html";

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";
/** 框架裡用到的 App 圖示（lucide 名稱）。 */
const ICONS = [
  "table-of-contents",
  "chevron-up",
  "chevron-down",
  "chevron-right",
  "minus",
  "plus",
  "move-horizontal",
  "rectangle-vertical",
  "search",
  "lock",
  "file-exclamation-point",
];
/** 焦點在 App 時，這些鍵交給框架捲頁面。 */
const SCROLL_KEYS = new Set(["ArrowDown", "ArrowUp", "PageDown", "PageUp", "Home", "End"]);

/** @param {unknown} err */
const messageOf = (err) => (err instanceof Error ? err.message : String(err));

// ---- 設定與記住的位置 ----

/** @type {{ zoom: string }} */
const settings = { zoom: "auto" };
/** 作品 id → 讀到第幾頁。物件的順序就是最近看的順序（最後的最新）。 @type {Record<string, number>} */
let positions = {};
const loaded = Promise.all([
  hoard.storage.get("settings").then((saved) => {
    if (saved && typeof saved === "object" && typeof (/** @type {any} */ (saved).zoom) === "string") settings.zoom = /** @type {any} */ (saved).zoom;
  }),
  hoard.storage.get("positions").then((saved) => {
    if (saved && typeof saved === "object") positions = /** @type {Record<string, number>} */ (saved);
  }),
]).catch((err) => console.warn("[pdf] 讀不到插件資料：", err));

/** @type {ReturnType<typeof setTimeout> | undefined} */
let saveTimer;
/** @type {Set<"settings" | "positions">} */
const dirty = new Set();
/** @param {"settings" | "positions"} key */
function save(key) {
  dirty.add(key);
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flush, SAVE_DELAY);
}
function flush() {
  clearTimeout(saveTimer);
  for (const key of dirty) void hoard.storage.set(key, key === "settings" ? settings : positions).catch((err) => console.warn("[pdf] 存不了：", key, err));
  dirty.clear();
}
hoard.onUnload(flush);

/** @param {number} id @param {number} page */
function rememberPage(id, page) {
  const key = String(id);
  delete positions[key];
  if (page > 1) positions[key] = page;
  const keys = Object.keys(positions);
  for (const old of keys.slice(0, Math.max(0, keys.length - POSITION_LIMIT))) delete positions[old];
  save("positions");
}

// ---- 哪些是 PDF ----

/** @param {string} path */
function extOf(path) {
  const name = path.split(/[\\/]/).pop() ?? "";
  const dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : "";
}

/** 作品摘要看得出的 PDF：本機的單一檔案，副檔名是 pdf。 @param {HoardItemSummary} item */
function isPdfItem(item) {
  return item.source_type === "local" && item.metadata.format == null && typeof item.ext === "string" && item.ext.toLowerCase() === "pdf";
}

/** 作品的 PDF 檔；不是只有一個 PDF 檔的作品是 null。 @param {HoardItemDetail} item */
function pdfFileOf(item) {
  if (item.files.length !== 1) return null;
  const file = item.files[0];
  return file.kind === "file" && file.entry === null && extOf(file.path) === "pdf" ? file : null;
}

/** PDF 在框架裡：讀它所在的資料夾。 @param {string} path */
function placeOf(path) {
  const at = Math.max(path.lastIndexOf("\\"), path.lastIndexOf("/"));
  // 磁碟根目錄（C:\a.pdf）留著斜線，"C:" 不是資料夾。
  return { dir: path.slice(0, at <= 2 ? at + 1 : at), name: path.slice(at + 1) };
}

// ---- 框架 ----

/** 現在 App 的主題，寫成框架裡的 CSS 變數（框架讀不到 App 的變數；換主題後重新打開才跟上）。 */
function themeCss() {
  const css = getComputedStyle(document.documentElement);
  // 值寫進 <style>，不讓它結束這段樣式。
  const value = (/** @type {string} */ name, /** @type {string} */ fallback) => css.getPropertyValue(name).replace(/[<>{};]/g, "").trim() || fallback;
  /** @type {Array<[string, string]>} */
  const vars = [
    ["bg", value("--hoard-bg", "#111111")],
    ["surface", value("--hoard-surface", "#1a1a1a")],
    ["surface-2", value("--hoard-surface-2", "#242424")],
    ["line", value("--hoard-border", "#2e2e2e")],
    ["line-strong", value("--hoard-border-strong", "#404040")],
    ["text", value("--hoard-text", "#ededed")],
    ["dim", value("--hoard-text-dim", "#a8a8a8")],
    ["muted", value("--hoard-muted", "#8a8a8a")],
    ["accent", value("--hoard-accent", "#e5e5e5")],
    ["shadow", value("--hoard-shadow-low", "none")],
    ["font", value("--hoard-font", "system-ui, sans-serif")],
    ["rem", value("--hoard-font-size", "16px")],
  ];
  return `:root { color-scheme: ${value("color-scheme", "normal")}; ${vars.map(([name, v]) => `--hp-${name}: ${v};`).join(" ")} }`;
}

/** 框架裡的圖示：App 的 lucide 圖示做成 SVG 原始碼。 */
function iconMarkup() {
  /** @type {Record<string, string>} */
  const icons = {};
  for (const name of ICONS) {
    const node = hoard.icon(name, { size: 16 });
    if (node instanceof Element) icons[name] = node.outerHTML;
  }
  return icons;
}

/** @param {string} text */
const escapeHtml = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/**
 * 框架的入口頁。
 * @param {{ mode: "view" | "preview" | "scan"; file: string; title: string; page?: number; zoom?: string }} opts
 */
function entryPage(opts) {
  const config = { mode: opts.mode, file: opts.file, page: opts.page, zoom: opts.zoom, icons: iconMarkup() };
  // 寫在 <script> 裡的 JSON 不能出現 </script>。
  const json = JSON.stringify(config).replace(/</g, "\\u003c");
  return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>${escapeHtml(opts.title)}</title>
<link rel="stylesheet" href=".hoard/plugin/pdfjs/web/pdf_viewer.css">
<link rel="stylesheet" href=".hoard/plugin/viewer/viewer.css">
<style>${themeCss()}</style>
<script type="application/json" id="hoard-pdf">${json}</script>
<script type="module" src=".hoard/plugin/viewer/viewer.mjs"></script>
</head><body></body></html>`;
}

/**
 * 把 PDF 放進 box。框架載入前 box 裡是 App 的骨架，框架說打開了（或打不開、要密碼）才露出來。
 * 離開時呼叫 cancel。
 * @param {HTMLElement} box @param {HoardItemFile} file
 * @param {{ mode: "view" | "preview"; title: string; page?: number; zoom?: string; onMessage?: (message: any) => void }} opts
 */
function showPdf(box, file, opts) {
  if (file.missing) {
    box.replaceChildren(errorNote("找不到檔案"));
    return { frame: null, cancel() {} };
  }
  const { dir, name } = placeOf(file.path);
  const frame = hoard.mountFrame(box, {
    entry: ENTRY,
    files: { [ENTRY]: entryPage({ mode: opts.mode, file: name, title: opts.title, page: opts.page, zoom: opts.zoom }) },
    dir,
    scripts: true,
    title: opts.title,
  });
  frame.element.style.visibility = "hidden";
  let shown = false;
  // 骨架換成文件（App 的 docs/conventions.md〈動畫〉）：骨架已經出現過（它等 200ms 才淡入）時文件淡入 180ms、
  // 骨架同時淡出；很快就打開、骨架還沒出現時文件直接淡入 120ms。系統要求減少動態時直接換。
  const reveal = () => {
    if (shown) return;
    shown = true;
    clearTimeout(timer);
    frame.element.style.visibility = "";
    const bones = /** @type {HTMLElement | null} */ (box.querySelector(".hp-skeleton"));
    if (!motionOn()) return void bones?.remove();
    const seen = bones ? parseFloat(getComputedStyle(bones).opacity) > 0.05 : false;
    frame.element.animate([{ opacity: 0 }, { opacity: 1 }], { duration: seen ? 180 : 120, easing: EASE_OUT });
    if (!bones || !seen) return void bones?.remove();
    void bones.animate([{ opacity: getComputedStyle(bones).opacity }, { opacity: 0 }], { duration: 180, easing: EASE_IN, fill: "forwards" }).finished.then(
      () => bones.remove(),
      () => bones.remove(),
    );
  };
  const timer = setTimeout(reveal, REVEAL_TIMEOUT);
  frame.on((message) => {
    if (!message || typeof message !== "object") return;
    if (message.kind === "opened" || message.kind === "failed" || message.kind === "password") reveal();
    opts.onMessage?.(message);
  });
  frame.loaded.catch((err) => {
    clearTimeout(timer);
    frame.close();
    box.replaceChildren(errorNote(err));
  });
  return {
    frame,
    cancel() {
      clearTimeout(timer);
      frame.close();
    },
  };
}

/** @param {unknown} err */
function errorNote(err) {
  return hoard.el("div", { class: "hp-error" }, [hoard.icon("file-exclamation-point", { size: 20 }), hoard.el("p", {}, [messageOf(err)])]);
}

/** 讀檔時的佔位：一頁文件的形狀。 */
function skeleton() {
  return hoard.el("div", { class: "hp-skeleton" }, [hoard.el("div", { class: "hp-skeleton-page" })]);
}

// ---- 快速預覽 ----

/** @param {HTMLElement} root @param {HoardItemSummary} item @param {HoardQuickLookCtx} ctx */
function renderQuickLook(root, item, ctx) {
  let alive = true;
  /** @type {ReturnType<typeof showPdf> | null} */
  let view = null;
  const box = hoard.el("div", { class: "hp-frame hp-ql-frame" }, [skeleton()]);
  const shell = hoard.el(
    "div",
    {
      class: "hp-ql",
      onclick: (event) => {
        if (event.target === shell) ctx.close();
      },
    },
    [box],
  );
  root.append(shell);
  // ↑ ↓、PageUp／PageDown、Home／End 捲頁面（這件只有一個檔案，不用換張）。
  ctx.onKey((event) => {
    if (!view?.frame || event.ctrlKey || event.altKey || event.metaKey || !SCROLL_KEYS.has(event.key)) return false;
    view.frame.send({ kind: "scroll", key: event.key });
    return true;
  });
  Promise.all([hoard.items.get(item.id), loaded]).then(
    ([detail]) => {
      if (!alive) return;
      const file = pdfFileOf(detail);
      if (!file) return box.replaceChildren(errorNote("這件作品不是 PDF"));
      view = showPdf(box, file, { mode: "preview", title: item.title, page: positions[String(item.id)] });
    },
    (err) => alive && box.replaceChildren(errorNote(err)),
  );
  return () => {
    alive = false;
    view?.cancel();
  };
}


// ---- 詳情頁 ----

/** @param {HTMLElement} root @param {HoardItemDetail} item */
function renderDetail(root, item) {
  const file = pdfFileOf(item);
  if (!file) return;
  let alive = true;
  /** @type {ReturnType<typeof showPdf> | null} */
  let view = null;
  const box = hoard.el("div", { class: "hp-frame hp-detail-frame" }, [skeleton()]);
  root.append(box);
  void loaded.then(() => {
    if (!alive) return;
    view = showPdf(box, file, {
      mode: "view",
      title: item.title,
      page: positions[String(item.id)],
      zoom: settings.zoom,
      onMessage: (message) => {
        // 框架裡的程式也送得出這些，只收看得懂的值。
        if (message.kind === "page" && Number.isInteger(message.page) && message.page > 0) rememberPage(item.id, message.page);
        else if (message.kind === "zoom" && typeof message.value === "string" && /^(auto|page-width|page-fit|page-actual|\d+(\.\d+)?)$/.test(message.value)) {
          settings.zoom = message.value;
          save("settings");
        }
      },
    });
  });
  // 框撐到詳情頁底部，頁面在框裡捲；詳情頁的大小改變時重算。
  const scroller = scrollParent(box);
  const fit = () => {
    if (!scroller) return;
    const rect = scroller.getBoundingClientRect();
    const style = getComputedStyle(scroller);
    // 用實際的小數高度量：clientHeight 是四捨五入的整數，縮放不是整數倍時比實際多零點幾 px，框就把詳情頁撐出第二條捲軸。
    const inner = rect.height - parseFloat(style.borderTopWidth) - parseFloat(style.borderBottomWidth);
    const top = box.getBoundingClientRect().top - rect.top - parseFloat(style.borderTopWidth) + scroller.scrollTop;
    box.style.height = `${Math.max(MIN_DETAIL_HEIGHT, Math.floor(inner - top))}px`;
  };
  const resize = new ResizeObserver(fit);
  if (scroller) resize.observe(scroller);
  fit();
  return () => {
    alive = false;
    resize.disconnect();
    view?.cancel();
    flush();
  };
}

/** 最近的會捲動的上層。 @param {HTMLElement} el */
function scrollParent(el) {
  for (let node = el.parentElement; node; node = node.parentElement) {
    if (/(auto|scroll)/.test(getComputedStyle(node).overflowY)) return node;
  }
  return null;
}

hoard.registerPresenter({
  sources: ["local"],
  accepts: (item) => item.file_count === 1 && isPdfItem(item),
  detail: renderDetail,
  quickLook: renderQuickLook,
});

// ---- 封面 ----

/** @param {HTMLCanvasElement} canvas @param {string} type @returns {Promise<Blob>} */
function canvasBlob(canvas, type) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("無法輸出圖片"))), type);
  });
}

/** 一行放得下多少：英數連在一起算一個字，其他（中文）一個字一個字斷。 @param {CanvasRenderingContext2D} g @param {string} text @param {number} width @param {number} maxLines */
function wrapLines(g, text, width, maxLines) {
  const tokens = text.match(/[\x21-\x7e]+|\s+|./gu) ?? [];
  /** @type {string[]} */
  const lines = [];
  let line = "";
  for (const token of tokens) {
    const next = line + token;
    if (g.measureText(next).width <= width || !line.trim()) {
      line = next;
      continue;
    }
    lines.push(line.trim());
    line = token.trim() ? token : "";
    if (lines.length === maxLines) break;
  }
  if (lines.length < maxLines && line.trim()) lines.push(line.trim());
  const used = lines.join("").length;
  if (used < text.replace(/\s+/g, "").length && lines.length > 0) {
    let last = lines[lines.length - 1];
    while (last && g.measureText(`${last}…`).width > width) last = last.slice(0, -1);
    lines[lines.length - 1] = `${last}…`;
  }
  return lines;
}

/**
 * 畫不出第一頁時的封面（有密碼、損壞）：標題與一行說明，透明底、中性灰（深色、淺色主題的卡片上都看得清楚）。
 * @param {string} title @param {string} note
 */
function textCover(title, note) {
  const canvas = document.createElement("canvas");
  canvas.width = COVER_WIDTH;
  canvas.height = COVER_HEIGHT;
  const g = canvas.getContext("2d");
  if (!g) return Promise.reject(new Error("無法建立 canvas"));
  const font = '"Segoe UI", "Microsoft JhengHei", "Noto Sans TC", system-ui, sans-serif';
  g.fillStyle = "#8a8a8a";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.font = `600 44px ${font}`;
  const lines = wrapLines(g, title || "PDF", 480, 6);
  const lineHeight = 60;
  const blockHeight = lines.length * lineHeight + 60;
  const top = (COVER_HEIGHT - blockHeight) / 2;
  lines.forEach((line, i) => g.fillText(line, COVER_WIDTH / 2, top + lineHeight * (i + 0.5)));
  g.font = `28px ${font}`;
  g.fillText(note, COVER_WIDTH / 2, top + lines.length * lineHeight + 40, 480);
  return canvasBlob(canvas, "image/png");
}

// ---- 背景分析：封面與搜尋文字 ----

let unloaded = false;
let scanning = false;
let scanAgain = false;
/** 這次載入讀不到的作品：補算時跳過，免得每一批都撈到它們；下次載入再試。 @type {Set<number>} */
const unreadable = new Set();
/** 移到垃圾桶的作品從查詢結果消失；還原時又回來，可能排在讀不到的那幾件中間，這時下一輪從頭數。 */
const removedIds = new Set();
let recount = false;
hoard.onUnload(() => {
  unloaded = true;
});
hoard.on("items-removed", ({ ids }) => {
  for (const id of ids) {
    unreadable.delete(id);
    removedIds.add(id);
  }
});
hoard.on("items-changed", ({ ids }) => {
  if (!ids.some((id) => removedIds.delete(id))) return;
  recount = true;
  void scan();
});

/** 讓出主執行緒：等瀏覽器有空（最多等 1 秒）。 */
const idle = () => new Promise((resolve) => requestIdleCallback(() => resolve(undefined), { timeout: 1000 }));

/**
 * 打不開時 pages 是 0：locked 是有密碼，broken 是檔案損壞（兩者都不是：這次讀不了，下次載入再試）。
 * @typedef {{ cover: Blob | null; text: string; title: string; author: string; pages: number; locked: boolean; broken: boolean }} Scanned
 */

/** 在看不到的框架裡讀一份 PDF；SCAN_TIMEOUT 內沒有結果就放棄。 @param {string} path @returns {Promise<Scanned>} */
async function scanFile(path) {
  const box = hoard.el("div", { class: "hp-offscreen" });
  box.inert = true;
  document.body.append(box);
  const { dir, name } = placeOf(path);
  const frame = hoard.mountFrame(box, { entry: ENTRY, files: { [ENTRY]: entryPage({ mode: "scan", file: name, title: name }) }, dir, scripts: true });
  /** @type {ReturnType<typeof setTimeout> | undefined} */
  let timer;
  try {
    return await Promise.race([
      new Promise((resolve) => {
        frame.on((message) => {
          if (!message || message.kind !== "scanned") return;
          const str = (/** @type {unknown} */ value, /** @type {number} */ max) => (typeof value === "string" ? value.slice(0, max) : "");
          resolve({
            cover: message.cover instanceof Blob && message.cover.size > 0 ? message.cover : null,
            text: str(message.text, 2000),
            title: str(message.title, 300),
            author: str(message.author, 300),
            pages: Number.isInteger(message.pages) ? message.pages : 0,
            locked: message.locked === true,
            broken: message.broken === true,
          });
        });
      }),
      frame.loaded.then(() => new Promise(() => {})),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error("PDF 太久沒有讀完")), SCAN_TIMEOUT);
      }),
    ]);
  } finally {
    clearTimeout(timer);
    frame.close();
    box.remove();
  }
}

/**
 * 讀一件 PDF：存封面，回傳要寫的篩選值；讀不到時是 undefined（這次載入跳過）。
 * @param {number} id
 * @returns {Promise<Array<{ id: number; key: string; values: string[] }> | undefined>}
 */
async function analyze(id) {
  const item = await hoard.items.get(id);
  const file = pdfFileOf(item);
  const done = { id, key: "scanned", values: [SCAN_VERSION] };
  if (!file) return [done];
  if (file.missing) return undefined;
  const result = await scanFile(file.path);
  if (unloaded) return undefined;
  if (result.pages === 0 && !result.locked && !result.broken) {
    console.warn("[pdf] 打不開，下次再試：", id);
    return undefined;
  }
  try {
    const cover = result.cover ?? (await textCover(item.title, result.locked ? "有密碼的 PDF" : result.broken ? "無法讀取的 PDF" : "PDF"));
    await hoard.items.setCover(id, { image: cover, format: true });
  } catch (err) {
    console.warn("[pdf] 存不了封面：", id, err);
  }
  const text = [result.title, result.author, result.text].filter(Boolean).join("\n").slice(0, 2000).trim();
  const entries = [done];
  if (text) entries.push({ id, key: "_text", values: [text] });
  return entries;
}

/**
 * 替還沒分析過的 PDF 做封面與搜尋文字：插件載入時補舊的，之後新收進來的也走這裡。
 * 一件一件讀、一批寫一次，件與件之間讓出主執行緒；同時只跑一輪，跑的時候又有新作品就再跑一輪。
 */
async function scan() {
  if (scanning) {
    scanAgain = true;
    return;
  }
  scanning = true;
  try {
    do {
      scanAgain = false;
      // 由舊到新：讀不到的作品留在最前面，通常直接從第 unreadable.size 件開始；新收進來的接在最後。
      let offset = recount ? 0 : unreadable.size;
      recount = false;
      for (;;) {
        if (unloaded) return;
        const page = await hoard.items.list(
          { source_type: "local", exts: ["pdf"], fields: [{ owner: "pdf", key: "scanned", none: true }] },
          { limit: SCAN_BATCH, offset, sort: "added", ascending: true },
        );
        if (page.items.length === 0 || unloaded) break;
        /** @type {Array<{ id: number; key: string; values: string[] }>} */
        const entries = [];
        let written = 0;
        for (const item of page.items) {
          if (unreadable.has(item.id)) continue;
          await idle();
          if (unloaded) return;
          const result = await analyze(item.id).catch((err) => {
            console.warn("[pdf] 分析失敗：", item.id, err);
            return undefined;
          });
          if (result === undefined) unreadable.add(item.id);
          else {
            entries.push(...result);
            written++;
          }
        }
        if (unloaded) return;
        if (entries.length > 0) await hoard.items.setFields(entries);
        offset += page.items.length - written;
      }
    } while (scanAgain || recount);
  } catch (err) {
    console.error("[pdf] 背景分析中斷：", err);
  } finally {
    scanning = false;
  }
}

hoard.on("items-added", () => void scan());
void scan();
