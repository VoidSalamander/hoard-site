// @ts-check
/*
 * PDF 檢視器在沙盒框架裡的那一半。app.js 用 hoard.mountFrame 打開：entry 是 app.js 做的一頁
 * （設定寫在 <script type="application/json" id="hoard-pdf">），dir 是 PDF 所在的資料夾，
 * 插件自己的檔案（這支程式、pdf.js）在 .hoard/plugin/。
 *
 * 框架和 App 不同源（不透明的 origin），所以：
 *  - pdf.js 的 worker 不能直接用網址開（Worker 只收同源的腳本），module worker 在不透明的 origin 也開不起來（WebView2），
 *    改用框架自己做的 blob: classic worker，在裡面動態 import pdf.js 的 worker；import 完成之前送來的訊息先排隊，
 *    載完再照順序交給它。
 *  - 讀 PDF、cmap、字型、wasm 都是跨來源的 fetch：核心回 Access-Control-Allow-Origin: *，
 *    帶 Range 的請求先預檢。PDF 自己用 Range 一段一段讀（PDFDataRangeTransport），只讀用得到的部分，
 *    也不受核心整檔讀取的大小上限影響。
 *
 * 三種模式（config.mode）：
 *  - view：詳情頁。上方工具列（目錄、頁碼、縮放、搜尋），目錄在左邊展開。
 *  - preview：快速預覽。只有頁面與右下角的頁碼；App 把 ↑ ↓ PageUp PageDown Home End 傳進來捲動。
 *  - scan：背景分析。畫第一頁當封面、讀前幾頁的文字與文件資訊，送回 app.js 就結束。
 *
 * 送回 app.js 的訊息（hoardFrame.send）：
 *   { kind: "opened", pages }                     文件打開了
 *   { kind: "page", page }                        看到第幾頁（從 1 起算）
 *   { kind: "zoom", value }                       使用者改了縮放（"auto"、"page-width"、"page-fit" 或倍率的字串）
 *   { kind: "password" }                          在問密碼（框架裡的輸入框）
 *   { kind: "failed", message, locked }           打不開；locked 是有密碼
 *   { kind: "scanned", cover, text, title, author, pages, locked, broken }   scan 模式的結果（cover 是 Blob 或 null；
 *                                                 打不開時 pages 是 0，locked 是有密碼、broken 是檔案損壞）
 * 收 app.js 的：{ kind: "scroll", key }。
 * PDF 的程式（JavaScript）不執行；表單照外觀畫出來、不能填（hoard 不改原檔，填了也存不回去）。
 */

/**
 * @typedef {{
 *   mode: "view" | "preview" | "scan";
 *   file: string;
 *   page?: number;
 *   zoom?: string;
 *   icons?: Record<string, string>;
 * }} Config
 */

/** @type {Config} */
const config = JSON.parse(document.getElementById("hoard-pdf")?.textContent || "{}");
const PDFJS = new URL("../pdfjs/", import.meta.url).href;
/** 封面的長邊（像素）。 */
const COVER_LONG_SIDE = 1200;
/** 搜尋框比對的文字最多幾個字（核心的 _text 上限）。 */
const TEXT_LIMIT = 2000;
/** 分析時最多讀幾頁的文字。 */
const TEXT_PAGES = 20;
const ZOOM_PRESETS = new Set(["auto", "page-width", "page-fit", "page-actual"]);
/** 先讀的開頭（小檔一次讀完）；pdf.js 的分段是 64 KB，這兩個都要是它的倍數。 */
const FIRST_PIECE = 1024 * 1024;
/** 一次 Range 請求最多讀多少（核心一次最多給 8 MB）。 */
const RANGE_PIECE = 4 * 1024 * 1024;

/** @param {unknown} message */
const send = (message) => /** @type {any} */ (window).hoardFrame?.send(message);
/** @param {unknown} err */
const messageOf = (err) => (err instanceof Error ? err.message : String(err));

/** 系統要求減少動態時不做動畫（框架裡吃不到 App 的減少動態規則，自己判斷）。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場、變大。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場、縮小。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/**
 * @param {string} tag
 * @param {Record<string, string | ((event: any) => void)>} [attrs]
 * @param {Array<Node | string | null | undefined | false>} [children]
 */
function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [name, value] of Object.entries(attrs)) {
    if (typeof value === "function") node.addEventListener(name.replace(/^on/, ""), value);
    else node.setAttribute(name, value);
  }
  for (const child of children) if (child) node.append(child);
  return node;
}

/** App 的圖示（app.js 用 hoard.icon 做好傳進來的 SVG）。 @param {string} name */
function icon(name) {
  const span = el("span", { class: "hp-icon", "aria-hidden": "true" });
  span.innerHTML = config.icons?.[name] ?? "";
  return span;
}

/** 整個框架換成一段說明（打不開、有密碼）。 @param {string} iconName @param {string} text @param {Node[]} [extra] */
function notice(iconName, text, extra = []) {
  document.body.replaceChildren(el("div", { class: "hp-notice" }, [icon(iconName), el("p", {}, [text]), ...extra]));
}

// ---- 載入 pdf.js ----

/** @returns {Promise<{ lib: any; ui: any }>} */
async function loadPdfjs() {
  try {
    await import(`${PDFJS}build/pdf.min.mjs`);
    const ui = await import(`${PDFJS}web/pdf_viewer.mjs`);
    return { lib: /** @type {any} */ (globalThis).pdfjsLib, ui };
  } catch (err) {
    console.error("[pdf] 讀不到 pdf.js（開發時先執行 bun run fetch:pdfjs）：", err);
    throw new Error("PDF 插件少了 pdf.js 的檔案，請重新安裝這個插件");
  }
}

/** classic worker 的開頭：排隊收訊息，動態 import pdf.js 的 worker，載完把排隊的交給它；載不到時丟出錯誤（Worker 的 error）。 */
const WORKER_BOOT = (/** @type {string} */ src) => `
const held = [];
const hold = (event) => held.push(event.data);
self.addEventListener("message", hold);
import(${JSON.stringify(src)}).then(
  () => {
    self.removeEventListener("message", hold);
    for (const data of held) self.dispatchEvent(new MessageEvent("message", { data }));
  },
  (err) => setTimeout(() => { throw err; }),
);`;

/** @param {any} lib @param {(err: Error) => void} onError */
function startWorker(lib, onError) {
  const url = URL.createObjectURL(new Blob([WORKER_BOOT(`${PDFJS}build/pdf.worker.min.mjs`)], { type: "text/javascript" }));
  const worker = new Worker(url);
  worker.addEventListener("error", (event) => {
    event.preventDefault();
    console.error("[pdf] pdf.js 的背景程式：", event.message);
    onError(new Error("pdf.js 的背景程式開不起來"));
  });
  lib.GlobalWorkerOptions.workerPort = worker;
}

/** @param {string} url @param {number} start @param {number} end 不含 */
async function readRange(url, start, end) {
  const response = await fetch(url, { headers: { Range: `bytes=${start}-${end - 1}` } });
  if (response.status !== 206 && response.status !== 200) throw Object.assign(new Error(`讀檔失敗（${response.status}）`), { name: "ResponseException" });
  return response;
}

/**
 * PDF 給 pdf.js 的樣子：小檔是整個檔（data），大檔是 Range 一段一段讀（range）。
 * @param {any} lib @param {string} url
 */
async function pdfSource(lib, url) {
  const head = await readRange(url, 0, FIRST_PIECE);
  const first = new Uint8Array(await head.arrayBuffer());
  const total = head.status === 206 ? Number(/\/(\d+)\s*$/.exec(head.headers.get("Content-Range") ?? "")?.[1]) : first.length;
  if (!(total > 0) || first.length >= total) return { data: first };
  const transport = new lib.PDFDataRangeTransport(total, first);
  // pdf.js 要一次拿到它要的那一段（begin 對得上）：分幾次讀，接起來再給。
  transport.requestDataRange = (/** @type {number} */ begin, /** @type {number} */ end) => {
    void (async () => {
      const chunk = new Uint8Array(end - begin);
      for (let at = begin; at < end; at += RANGE_PIECE) {
        const to = Math.min(end, at + RANGE_PIECE);
        const piece = new Uint8Array(await (await readRange(url, at, to)).arrayBuffer());
        chunk.set(piece.subarray(0, to - at), at - begin);
      }
      transport.onDataRange(begin, chunk);
    })().catch((err) => console.warn("[pdf] 讀不到一段：", begin, end, err));
  };
  return { range: transport };
}

/**
 * 打開 PDF。有密碼時呼叫 askPassword（沒給就當成打不開）：回傳使用者輸入的密碼，或 null 放棄。
 * @param {any} lib
 * @param {{ askPassword?: (wrong: boolean) => Promise<string | null> }} opts
 */
async function openDocument(lib, opts) {
  const url = new URL(config.file.split("/").map(encodeURIComponent).join("/"), document.baseURI).href;
  const task = lib.getDocument({
    ...(await pdfSource(lib, url)),
    cMapUrl: `${PDFJS}cmaps/`,
    cMapPacked: true,
    standardFontDataUrl: `${PDFJS}standard_fonts/`,
    wasmUrl: `${PDFJS}wasm/`,
    iccUrl: `${PDFJS}iccs/`,
    isEvalSupported: false,
    // 只讀用得到的段落（看到的頁、搜尋讀到的頁），不在背景把整個檔讀進記憶體。
    disableAutoFetch: true,
  });
  /** @type {(err: Error) => void} */
  let fail = () => {};
  const locked = new Promise((_, reject) => {
    fail = reject;
  });
  task.onPassword = (/** @type {(password: string) => void} */ update, /** @type {number} */ reason) => {
    if (!opts.askPassword) {
      fail(Object.assign(new Error("這份 PDF 有密碼"), { locked: true }));
      void task.destroy();
      return;
    }
    opts.askPassword(reason === lib.PasswordResponses.INCORRECT_PASSWORD).then((password) => {
      if (password === null) {
        fail(Object.assign(new Error("這份 PDF 有密碼"), { locked: true }));
        void task.destroy();
      } else update(password);
    });
  };
  return await Promise.race([task.promise, locked]);
}

/** 讀不出來的原因，給使用者看的。 @param {unknown} err */
function reasonOf(err) {
  const name = err && typeof err === "object" && "name" in err ? String(err.name) : "";
  if (name === "InvalidPDFException") return "這不是 PDF，或檔案已經損壞";
  if (name === "ResponseException" || name === "MissingPDFException") return "讀不到檔案";
  return messageOf(err);
}

// ---- 背景分析 ----

/** @param {any} lib @param {any} doc */
async function scan(lib, doc) {
  /** @type {Blob | null} */
  let cover = null;
  try {
    const page = await doc.getPage(1);
    const base = page.getViewport({ scale: 1 });
    const scale = Math.min(COVER_LONG_SIDE / Math.max(base.width, base.height), 8);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(viewport.width));
    canvas.height = Math.max(1, Math.round(viewport.height));
    const g = canvas.getContext("2d");
    if (!g) throw new Error("無法建立 canvas");
    // 分析的框架放在畫面外：Chromium 不替畫面外的跨來源框架跑 requestAnimationFrame，一般的渲染會一直等下去。
    // 列印的渲染不經過它（差別只在註解照列印的樣子畫，當封面一樣）。
    await page.render({ canvasContext: g, viewport, intent: "print", annotationMode: lib.AnnotationMode.ENABLE }).promise;
    cover = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", 0.85));
  } catch (err) {
    console.warn("[pdf] 畫不出第一頁：", err);
  }
  let text = "";
  for (let n = 1; n <= Math.min(doc.numPages, TEXT_PAGES) && text.length < TEXT_LIMIT; n++) {
    try {
      const page = await doc.getPage(n);
      const content = await page.getTextContent();
      const lines = content.items.map((/** @type {any} */ item) => (typeof item.str === "string" ? item.str + (item.hasEOL ? "\n" : "") : "")).join("");
      text += `${lines.replace(/[ \t ]+/g, " ").replace(/\s*\n\s*/g, "\n").trim()}\n`;
    } catch (err) {
      console.warn("[pdf] 讀不到第", n, "頁的文字：", err);
    }
  }
  /** @type {{ Title?: unknown; Author?: unknown }} */
  let info = {};
  try {
    info = (await doc.getMetadata()).info ?? {};
  } catch {
    /* 沒有文件資訊 */
  }
  const str = (/** @type {unknown} */ value) => (typeof value === "string" ? value.trim().slice(0, 300) : "");
  send({ kind: "scanned", cover, text: text.trim().slice(0, TEXT_LIMIT), title: str(info.Title), author: str(info.Author), pages: doc.numPages, locked: false, broken: false });
}

// ---- 檢視 ----

/**
 * 輸入密碼：換掉整個框架，回傳輸入的密碼。快速預覽不問（空白鍵、Enter 是 App 的），只說有密碼。
 * @param {boolean} wrong
 * @returns {Promise<string | null>}
 */
function askPassword(wrong) {
  if (config.mode !== "view") {
    notice("lock", "這份 PDF 有密碼，請在詳情頁輸入");
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    const input = /** @type {HTMLInputElement} */ (el("input", { type: "password", class: "hp-field", "aria-label": "密碼", autocomplete: "off" }));
    const form = el(
      "form",
      {
        class: "hp-password",
        onsubmit: (/** @type {SubmitEvent} */ event) => {
          event.preventDefault();
          if (input.value) resolve(input.value);
        },
      },
      [input, el("button", { type: "submit", class: "hp-button hp-primary" }, ["打開"])],
    );
    notice("lock", wrong ? "密碼不對，請再試一次" : "這份 PDF 有密碼", [form, el("p", { class: "hp-hint" }, ["密碼只用來打開這一次，hoard 不會記住"])]);
    send({ kind: "password" });
    input.focus();
  });
}

/**
 * pdf.js 的 PDFLinkService，跳到目錄、文件內連結的目的地時：
 *  - 不讓焦點把畫面捲走。原本的 goToDestination 等目的地那頁的文字層畫好，就呼叫 textLayer.div.focus()（給螢幕閱讀器、鍵盤從那裡接著捲），
 *    沒有 preventScroll：文字層和整頁一樣高、比畫面高，Chromium 會把它捲進畫面（頁的底邊對齊畫面底邊），
 *    剛跳到的標題在畫好的那一刻被捲走幾百 px，看起來就是閃一下（Firefox 的 focus 不捲，所以 pdf.js 那邊沒事）。
 *    這裡一樣把焦點移過去，但不捲動。
 *  - 不照目的地改縮放（建構時 ignoreDestinationZoom）：縮放是使用者選的、會記住，跳過去只是捲動；
 *    /Fit 這類目的地照樣改縮放的話，每一頁都要重畫，也會蓋掉使用者的設定。
 * 只用 pdf.js 公開的 API（getDestination、cachedPageNumber、getPageIndex、scrollPageIntoView、getPageView）。
 * @param {any} ui
 * @returns {new (options: { eventBus: any; ignoreDestinationZoom?: boolean }) => any}
 */
function linkServiceClass(ui) {
  return class extends ui.PDFLinkService {
    /** @type {AbortController | null} */
    #pendingFocus = null;

    /** @param {string | any[] | Promise<any[]>} dest */
    async goToDestination(dest) {
      const doc = this.pdfDocument;
      if (!doc) return;
      const explicit = typeof dest === "string" ? await doc.getDestination(dest) : await dest;
      if (!Array.isArray(explicit)) return;
      const [ref] = explicit;
      let pageNumber = 0;
      if (ref && typeof ref === "object") {
        pageNumber = doc.cachedPageNumber(ref) || (await doc.getPageIndex(ref).then((/** @type {number} */ i) => i + 1, () => 0));
      } else if (Number.isInteger(ref)) pageNumber = ref + 1;
      if (!(pageNumber >= 1 && pageNumber <= this.pagesCount)) return;
      this.pdfViewer.scrollPageIntoView({ pageNumber, destArray: explicit, ignoreDestinationZoom: true });

      this.#pendingFocus?.abort();
      const focus = () => this.pdfViewer.getPageView(pageNumber - 1)?.textLayer?.div?.focus({ preventScroll: true });
      if (this.pdfViewer.getPageView(pageNumber - 1)?.textLayer?.div?.isConnected) {
        focus();
        return;
      }
      const pending = (this.#pendingFocus = new AbortController());
      this.eventBus.on(
        "textlayerrendered",
        (/** @type {{ pageNumber: number }} */ event) => {
          if (event.pageNumber !== pageNumber) return;
          pending.abort();
          focus();
        },
        { signal: pending.signal },
      );
    }
  };
}

/** @param {any} lib @param {any} ui @param {any} doc */
function showDocument(lib, ui, doc) {
  const view = config.mode === "view";
  const eventBus = new ui.EventBus();
  const linkService = new (linkServiceClass(ui))({ eventBus, ignoreDestinationZoom: true });
  const findController = view ? new ui.PDFFindController({ eventBus, linkService, updateMatchesCountOnProgress: true }) : null;
  const pagesHost = el("div", { class: "pdfViewer" });
  const scroller = el("div", { class: "hp-scroll", tabindex: "-1" }, [pagesHost]);
  const body = el("div", { class: "hp-body" }, [scroller]);
  document.body.replaceChildren(body);
  const viewer = new ui.PDFViewer({
    container: scroller,
    viewer: pagesHost,
    eventBus,
    linkService,
    findController,
    textLayerMode: 1,
    annotationMode: lib.AnnotationMode.ENABLE,
    supportsPinchToZoom: true,
  });
  linkService.setViewer(viewer);
  viewer.setDocument(doc);
  linkService.setDocument(doc, null);
  const total = doc.numPages;

  /** 使用者改了縮放：記下來（app.js 存成下次的預設）。 */
  const zoomed = () => {
    if (view) send({ kind: "zoom", value: String(viewer.currentScaleValue) });
  };
  /** @param {string | number} value */
  const setZoom = (value) => {
    viewer.currentScaleValue = String(value);
    zoomed();
  };

  eventBus.on("pagesinit", () => {
    const zoom = config.zoom && (ZOOM_PRESETS.has(config.zoom) || Number(config.zoom) > 0) ? config.zoom : "auto";
    viewer.currentScaleValue = view ? zoom : "auto";
    const page = Math.floor(Number(config.page));
    if (page > 1 && page <= total) viewer.currentPageNumber = page;
    send({ kind: "opened", pages: total });
  });
  eventBus.on("pagechanging", (/** @type {{ pageNumber: number }} */ { pageNumber }) => send({ kind: "page", page: pageNumber }));

  // Ctrl＋滾輪、觸控板捏合：在游標處縮放（不讓 webview 縮放整個畫面）。pdf.js 把倍率四捨五入到 1%，
  // 捏合一次只動一點點，先累積到看得出差別才套用。
  let wheelFactor = 1;
  scroller.addEventListener(
    "wheel",
    (event) => {
      if (!event.ctrlKey && !event.metaKey) return;
      event.preventDefault();
      const delta = event.deltaMode === 1 ? event.deltaY * 33 : event.deltaY;
      wheelFactor *= Math.exp(-delta * 0.0025);
      const scale = viewer.currentScale;
      if (Math.round(scale * wheelFactor * 100) === Math.round(scale * 100)) return;
      viewer.updateScale({ scaleFactor: wheelFactor, origin: [event.clientX, event.clientY], drawingDelay: 300 });
      wheelFactor = 1;
      zoomed();
    },
    { passive: false },
  );

  // 快速預覽：App 收到的捲動鍵傳進來（焦點在 App，不在框架）。
  /** @type {Record<string, () => void>} */
  const keys = {
    ArrowDown: () => scroller.scrollBy({ top: 60 }),
    ArrowUp: () => scroller.scrollBy({ top: -60 }),
    PageDown: () => scroller.scrollBy({ top: scroller.clientHeight * 0.9 }),
    PageUp: () => scroller.scrollBy({ top: -scroller.clientHeight * 0.9 }),
    Home: () => (viewer.currentPageNumber = 1),
    End: () => (viewer.currentPageNumber = total),
  };
  /** @type {any} */ (window).hoardFrame?.on((/** @type {any} */ message) => {
    if (message && message.kind === "scroll" && typeof message.key === "string" && Object.hasOwn(keys, message.key)) keys[message.key]();
  });

  if (!view) {
    const badge = el("div", { class: "hp-badge", "aria-hidden": "true" }, [`1 / ${total}`]);
    body.append(badge);
    eventBus.on("pagechanging", (/** @type {{ pageNumber: number }} */ { pageNumber }) => {
      badge.textContent = `${pageNumber} / ${total}`;
    });
    return;
  }

  // ---- 工具列 ----

  /** @param {string} iconName @param {string} label @param {() => void} onClick @param {string} [cls] */
  const button = (iconName, label, onClick, cls = "") =>
    el("button", { type: "button", class: `hp-button hp-icon-button ${cls}`.trim(), title: label, "aria-label": label, onclick: onClick }, [icon(iconName)]);

  // 目錄
  const outlineButton = button("table-of-contents", "目錄", () => toggleOutline());
  outlineButton.hidden = true;
  const sidebar = el("nav", { class: "hp-sidebar", "aria-label": "目錄" });
  body.prepend(sidebar);
  let outlineOpen = false;
  // 開目錄：欄寬從 0 長到原本的寬度 220ms ease-out（頁面跟著往右讓），裡面的目錄從左邊 24px 滑進來淡入；
  // 關上 180ms ease-in 反過來，關完才藏起來（App 的 docs/conventions.md〈動畫〉的側欄）。系統要求減少動態時直接開關。
  const toggleOutline = (/** @type {boolean} */ open = !outlineOpen) => {
    outlineButton.setAttribute("aria-pressed", String(open));
    if (open === outlineOpen) return;
    outlineOpen = open;
    const list = /** @type {HTMLElement | null} */ (sidebar.firstElementChild);
    const moving = [scroller, sidebar, ...(list ? [list] : [])];
    if (!motionOn()) {
      for (const node of moving) for (const a of node.getAnimations()) a.cancel();
      document.body.classList.toggle("hp-outline-open", open);
      return;
    }
    // 從現在的樣子（開、關到一半也算）接著走。
    const visible = document.body.classList.contains("hp-outline-open");
    const shown = visible ? parseFloat(getComputedStyle(scroller).left) || 0 : 0;
    const style = list && visible ? getComputedStyle(list) : null;
    const hidden = { opacity: "0", translate: "-24px 0" };
    const from = style ? { opacity: style.opacity, translate: style.translate === "none" ? "0px 0" : style.translate } : hidden;
    for (const node of moving) for (const a of node.getAnimations()) a.cancel();
    document.body.classList.add("hp-outline-open");
    const width = sidebar.offsetWidth;
    const to = open ? width : 0;
    const timing = { duration: open ? 220 : 180, easing: open ? EASE_OUT : EASE_IN, fill: /** @type {const} */ ("forwards") };
    const run = scroller.animate([{ left: `${shown}px` }, { left: `${to}px` }], timing);
    sidebar.animate([{ clipPath: `inset(0 ${width - shown}px 0 0)` }, { clipPath: `inset(0 ${width - to}px 0 0)` }], timing);
    list?.animate([from, open ? { opacity: "1", translate: "0px 0" } : hidden], timing);
    void run.finished.then(
      () => {
        if (!outlineOpen) document.body.classList.remove("hp-outline-open");
        for (const node of moving) for (const a of node.getAnimations()) a.cancel();
      },
      () => {},
    );
  };
  void doc.getOutline().then(
    (/** @type {any[] | null} */ outline) => {
      if (!outline || outline.length === 0) return;
      sidebar.append(outlineList(outline, linkService));
      outlineButton.hidden = false;
      outlineButton.setAttribute("aria-pressed", "false");
    },
    (/** @type {unknown} */ err) => console.warn("[pdf] 讀不到目錄：", err),
  );

  // 頁碼
  const pageInput = /** @type {HTMLInputElement} */ (
    el("input", { class: "hp-field hp-page-input", inputmode: "numeric", "aria-label": "頁碼", value: "1", autocomplete: "off" })
  );
  const goTo = () => {
    const page = Math.floor(Number(pageInput.value));
    if (page >= 1 && page <= total) viewer.currentPageNumber = page;
    pageInput.value = String(viewer.currentPageNumber);
  };
  pageInput.addEventListener("change", goTo);
  pageInput.addEventListener("focus", () => pageInput.select());
  pageInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      goTo();
      pageInput.select();
    } else if (event.key === "Escape") {
      // 欄位自己的 Esc：還原頁碼、離開欄位（App 聽不到）。
      event.preventDefault();
      pageInput.value = String(viewer.currentPageNumber);
      pageInput.blur();
    }
  });
  const prev = button("chevron-up", "上一頁", () => viewer.previousPage());
  const next = button("chevron-down", "下一頁", () => viewer.nextPage());
  const syncPage = (/** @type {number} */ page) => {
    if (document.activeElement !== pageInput) pageInput.value = String(page);
    prev.toggleAttribute("disabled", page <= 1);
    next.toggleAttribute("disabled", page >= total);
  };
  eventBus.on("pagechanging", (/** @type {{ pageNumber: number }} */ { pageNumber }) => syncPage(pageNumber));
  syncPage(1);

  // 縮放
  const zoomLabel = el("button", { type: "button", class: "hp-button hp-zoom-label", title: "實際大小", "aria-label": "實際大小", onclick: () => setZoom("page-actual") }, [
    "100%",
  ]);
  const fitWidth = button("move-horizontal", "符合寬度", () => setZoom("page-width"));
  const fitPage = button("rectangle-vertical", "整頁", () => setZoom("page-fit"));
  eventBus.on("scalechanging", (/** @type {{ scale: number; presetValue?: string }} */ { scale, presetValue }) => {
    zoomLabel.textContent = `${Math.round(scale * 100)}%`;
    fitWidth.setAttribute("aria-pressed", String(presetValue === "page-width"));
    fitPage.setAttribute("aria-pressed", String(presetValue === "page-fit"));
  });
  const zoomOut = button("minus", "縮小（Ctrl＋−）", () => {
    viewer.decreaseScale();
    zoomed();
  });
  const zoomIn = button("plus", "放大（Ctrl＋＋）", () => {
    viewer.increaseScale();
    zoomed();
  });

  // 搜尋
  const searchInput = /** @type {HTMLInputElement} */ (
    el("input", { type: "search", class: "hp-field hp-search-input", placeholder: "搜尋文件", "aria-label": "搜尋文件（Ctrl＋F）", autocomplete: "off", spellcheck: "false" })
  );
  const count = el("span", { class: "hp-count", "aria-live": "polite" });
  /** @param {string} type @param {boolean} [previous] */
  const find = (type, previous = false) => {
    const query = searchInput.value.trim();
    if (!query) {
      eventBus.dispatch("findbarclose", { source: null });
      count.textContent = "";
      return;
    }
    eventBus.dispatch("find", { source: null, type, query, caseSensitive: false, entireWord: false, highlightAll: true, findPrevious: previous, matchDiacritics: false });
  };
  searchInput.addEventListener("input", () => find(""));
  searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      find("again", event.shiftKey);
    } else if (event.key === "Escape" && searchInput.value) {
      // 欄位自己的 Esc：先清掉搜尋；空的時候 Esc 交給 App（回到列表）。
      event.preventDefault();
      searchInput.value = "";
      find("");
    }
  });
  const findPrev = button("chevron-up", "上一個（Shift＋Enter）", () => find("again", true));
  const findNext = button("chevron-down", "下一個（Enter）", () => find("again"));
  /** @param {{ current: number; total: number }} matches */
  const showCount = (matches) => {
    count.textContent = !searchInput.value.trim() ? "" : matches.total > 0 ? `${matches.current} / ${matches.total}` : "找不到";
  };
  eventBus.on("updatefindmatchescount", (/** @type {any} */ { matchesCount }) => showCount(matchesCount));
  eventBus.on("updatefindcontrolstate", (/** @type {any} */ { state, matchesCount }) => {
    if (state === ui.FindState.NOT_FOUND) count.textContent = searchInput.value.trim() ? "找不到" : "";
    else if (matchesCount) showCount(matchesCount);
  });

  const toolbar = el("div", { class: "hp-toolbar", role: "toolbar", "aria-label": "PDF" }, [
    outlineButton,
    el("div", { class: "hp-group" }, [prev, next, pageInput, el("span", { class: "hp-total" }, [`/ ${total}`])]),
    el("div", { class: "hp-spacer" }),
    el("div", { class: "hp-group" }, [zoomOut, zoomLabel, zoomIn, fitWidth, fitPage]),
    el("div", { class: "hp-search" }, [icon("search"), searchInput, count, findPrev, findNext]),
  ]);
  document.body.prepend(toolbar);

  // 焦點在框架裡時的快捷鍵（焦點在 App 時是 App 的）。
  window.addEventListener("keydown", (event) => {
    const mod = event.ctrlKey || event.metaKey;
    if (!mod || event.altKey) return;
    const key = event.key.toLowerCase();
    if (key === "f") {
      searchInput.focus();
      searchInput.select();
    } else if (key === "=" || key === "+") {
      viewer.increaseScale();
      zoomed();
    } else if (key === "-") {
      viewer.decreaseScale();
      zoomed();
    } else if (key === "0") setZoom("auto");
    else return;
    event.preventDefault();
  });
}

/** 目錄：可以展開的清單；點了跳到那裡，外部網址交給 App（frames.js 接連結）。 @param {any[]} items @param {any} linkService */
function outlineList(items, linkService) {
  const list = el("ul", { class: "hp-outline", role: "list" });
  for (const item of items) {
    const title = String(item.title ?? "").trim() || "（沒有標題）";
    const children = Array.isArray(item.items) && item.items.length > 0 ? item.items : null;
    const link = item.url
      ? el("a", { class: "hp-outline-link", href: String(item.url), title: String(item.url) }, [title])
      : el(
          "a",
          {
            class: "hp-outline-link",
            href: "#",
            onclick: (/** @type {MouseEvent} */ event) => {
              event.preventDefault();
              if (item.dest) void linkService.goToDestination(item.dest);
            },
          },
          [title],
        );
    if (item.bold) link.classList.add("hp-bold");
    if (item.italic) link.classList.add("hp-italic");
    // 一開始展開與否照 PDF 的標記：Count 是正的就是展開（PDF 規格），負的或沒寫是收合。
    const open = typeof item.count === "number" && item.count > 0;
    const row = el("div", { class: "hp-outline-row" }, [
      children
        ? el(
            "button",
            {
              type: "button",
              class: "hp-outline-toggle",
              "aria-label": open ? "收合" : "展開",
              "aria-expanded": String(open),
              onclick: (/** @type {MouseEvent} */ event) => {
                const toggle = /** @type {HTMLElement} */ (event.currentTarget);
                const open = toggle.getAttribute("aria-expanded") !== "true";
                toggle.setAttribute("aria-expanded", String(open));
                toggle.setAttribute("aria-label", open ? "收合" : "展開");
              },
            },
            [icon("chevron-right")],
          )
        : el("span", { class: "hp-outline-toggle" }),
      link,
    ]);
    const entry = el("li", {}, [row]);
    if (children) entry.append(outlineList(children, linkService));
    list.append(entry);
  }
  return list;
}

// ---- 開始 ----

(async () => {
  document.body.classList.add(`hp-mode-${config.mode}`);
  try {
    const { lib, ui } = await loadPdfjs();
    /** @type {Promise<never>} */
    const failed = new Promise((_, reject) => startWorker(lib, reject));
    failed.catch(() => {});
    if (config.mode === "scan") {
      const doc = await Promise.race([openDocument(lib, {}), failed]);
      await scan(lib, doc);
      return;
    }
    const doc = await Promise.race([openDocument(lib, { askPassword }), failed]);
    showDocument(lib, ui, doc);
  } catch (err) {
    const locked = !!(err && typeof err === "object" && "locked" in err);
    if (!locked) console.warn("[pdf] 打不開：", err);
    if (config.mode === "scan") {
      const broken = !!(err && typeof err === "object" && "name" in err && err.name === "InvalidPDFException");
      send({ kind: "scanned", cover: null, text: "", title: "", author: "", pages: 0, locked, broken });
      return;
    }
    send({ kind: "failed", message: reasonOf(err), locked });
    if (locked) notice("lock", config.mode === "view" ? "這份 PDF 有密碼" : "這份 PDF 有密碼，請在詳情頁輸入");
    else notice("file-exclamation-point", reasonOf(err));
  }
})();
