// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：漫畫閱讀器。是一個呈現者（registerPresenter，auto: false）：任何有圖的作品（多頁作品、
 * Pixiv 的多圖貼文⋯）右鍵「開啟方式」都列出它，但哪些是漫畫由使用者選，選了的作品（`presenter`
 * 是這個插件）才由這裡呈現。讀檔、列頁、封面都是核心的通用功能；作品的來源不因此改變。
 *
 *  - 詳情頁（呈現者的 detail）：封面與檔案資訊、閱讀入口、書籤、下一卷、全部頁面縮圖
 *    （可以設為封面，hoard.items.setCover）。
 *  - 卡片（呈現者的 card，cardFrame: false）：一本沒有文字的漫畫書，滑鼠停上去封面微微翻開、露出封面後面那一頁。
 *  - 系列與卷號由這裡判斷：系列是所在的資料夾名稱，沒有資料夾的（例如貼文）放在「未分組」；卷號從標題讀
 *    （來源寫了 metadata.series／volume 的優先，例如 Pixiv 的系列）。
 *  - 一件作品只用它的「開啟方式」打開：沒交給這裡的作品沒有閱讀的入口（2026-11-21 拿掉右鍵「閱讀」）。
 *  - 資料夾不能當成一本讀（2026-11-22 拿掉「設為漫畫」）：連載就把新的一話收進同一個資料夾，書架照資料夾分系列。
 *  - 書架（registerLayout，呈現者的專屬版型：側欄的「漫畫」頁放交給這裡的作品並用它畫，其他頁面只有規則
 *    只留下交給這裡的作品時才能選）：依系列分組、卷號排序，封面下顯示閱讀進度，
 *    最上面一排是「繼續閱讀」。點書開它的詳情頁（封面、資訊、全部頁面），「繼續閱讀」那一排點了直接接著讀；
 *    Ctrl／Shift 點選取、右鍵選單、拖進資料夾都由 ctx.bindItem 交給 App。
 *  - 閱讀器（registerView，hidden）：只從書架、詳情頁或指令面板用 hoard.openView 打開，
 *    關掉時 ctx.back() 回到原本的畫面。版面照 OpenComic：翻頁或連續捲動；一般、漫畫（右到左）
 *    或條漫；單頁／雙頁／自動，封面單獨、橫向頁單獨；符合高度／寬度／原始大小。
 *  - 閱讀進度、書籤、每本的設定與預設設定都存在 hoard.storage（這個插件自己的資料）：
 *      progress   { [作品 id]: { position, total, finished, updated } }，position 從 0 起算
 *      bookmarks  { [作品 id]: 頁碼陣列 }
 *      pageOrder  { [作品 id]: file_index 陣列 }，編輯過頁面的作品上次看到的頁序；順序變了（復原也算）就把進度、書籤換算過去
 *      overrides  { [作品 id]: { scope: "item", settings } 或 { scope: "global" } }
 *      defaults   預設的閱讀設定
 *  - 頁面圖片用 hoard.pageSrc（圖片資料夾、壓縮檔、PDF 都一樣）。
 */

// ---- 閱讀設定 ----

/**
 * @typedef {{
 *   view: "slide" | "scroll";
 *   mode: "normal" | "manga" | "webtoon";
 *   spread: "single" | "double" | "auto";
 *   coverAlone: boolean;
 *   landscapeAlone: boolean;
 *   fit: "height" | "width" | "original";
 *   marginX: number; marginY: number;
 *   cropTop: number; cropBottom: number; cropLeft: number; cropRight: number;
 *   brightness: number; contrast: number; saturate: number; sepia: number;
 *   invert: boolean;
 * }} Settings
 */

/** @type {Settings} */
const DEFAULT_SETTINGS = {
  view: "slide",
  mode: "normal",
  spread: "single",
  coverAlone: true,
  landscapeAlone: true,
  fit: "height",
  marginX: 0,
  marginY: 0,
  cropTop: 0,
  cropBottom: 0,
  cropLeft: 0,
  cropRight: 0,
  brightness: 100,
  contrast: 100,
  saturate: 100,
  sepia: 0,
  invert: false,
};

/** 內容模式說了算的部分：條漫一律連續捲動、單頁、符合寬度。 @param {Settings} s */
function applied(s) {
  if (s.mode !== "webtoon") return s;
  return { ...s, view: /** @type {const} */ ("scroll"), spread: /** @type {const} */ ("single"), fit: /** @type {const} */ ("width") };
}

/** @param {Settings} s */
function filterCss(s) {
  const parts = [];
  if (s.brightness !== 100) parts.push(`brightness(${s.brightness}%)`);
  if (s.contrast !== 100) parts.push(`contrast(${s.contrast}%)`);
  if (s.saturate !== 100) parts.push(`saturate(${s.saturate}%)`);
  if (s.sepia > 0) parts.push(`sepia(${s.sepia}%)`);
  if (s.invert) parts.push("invert(100%)");
  return parts.join(" ");
}

/** 只留認得、型別對的欄位。 @param {unknown} value @returns {Partial<Settings>} */
function sanitize(value) {
  if (!value || typeof value !== "object") return {};
  /** @type {Record<string, unknown>} */
  const out = {};
  for (const [key, fallback] of Object.entries(DEFAULT_SETTINGS)) {
    const v = /** @type {Record<string, unknown>} */ (value)[key];
    if (typeof v === typeof fallback) out[key] = v;
  }
  return /** @type {Partial<Settings>} */ (out);
}

/** 從作品本身推得的設定：Pixiv 標成漫畫的作品右到左雙頁，插畫一次一張。 @param {HoardItemDetail} item */
function inferredSettings(item) {
  const type = item.metadata.work_type;
  if (type === "manga") return { mode: /** @type {const} */ ("manga"), spread: /** @type {const} */ ("double") };
  if (type === "illust") return { mode: /** @type {const} */ ("normal"), spread: /** @type {const} */ ("single") };
  return null;
}

// ---- 插件資料 ----

const store = {
  /** @type {Record<string, { position: number; total: number; finished: boolean; updated: number }>} */
  progress: {},
  /** @type {Record<string, number[]>} */
  bookmarks: {},
  /** @type {Record<string, { scope: "item" | "global"; settings?: Partial<Settings> }>} */
  overrides: {},
  /** @type {Partial<Settings>} */
  defaults: {},
  /** 編輯過頁面的作品上次看到的頁序（file_index），見 syncPageOrder。 @type {Record<string, number[]>} */
  pageOrder: {},
};
/** @typedef {"progress" | "bookmarks" | "overrides" | "defaults" | "pageOrder"} StoreKey */
/** @type {StoreKey[]} */
const STORE_KEYS = ["progress", "bookmarks", "overrides", "defaults", "pageOrder"];

/** 一本書的 id，就是作品 id。進度、書籤、設定都用它當鍵。 @typedef {number} BookId */

/** @type {Promise<void> | null} */
let loading = null;
let loaded = false;
function loadStore() {
  loading ??= Promise.all(STORE_KEYS.map((key) => hoard.storage.get(key))).then((values) => {
    STORE_KEYS.forEach((key, i) => {
      const value = values[i];
      if (value && typeof value === "object" && !Array.isArray(value)) /** @type {any} */ (store)[key] = value;
    });
    loaded = true;
  });
  return loading;
}

/** @type {Map<StoreKey, number>} */
const saveTimers = new Map();
/** 寫回 storage（短時間內的多次修改併成一次）。 @param {StoreKey} key */
function save(key) {
  clearTimeout(saveTimers.get(key));
  saveTimers.set(
    key,
    window.setTimeout(() => flush(key), 300),
  );
}
/** @param {StoreKey} key */
function flush(key) {
  if (!saveTimers.has(key)) return;
  clearTimeout(saveTimers.get(key));
  saveTimers.delete(key);
  hoard.storage.set(key, store[key]).catch((err) => console.error("[comic-reader] 儲存失敗：", err));
}
hoard.onUnload(() => STORE_KEYS.forEach(flush));

/**
 * 記下讀到哪裡。finished 一旦成立就不會被之後的進度清掉（翻回前面看，這本仍算讀完）；
 * 雙頁時最後一頁可能在 position 之前就已經在畫面上，所以由呼叫端另外告知。
 * @param {BookId} id @param {number} position @param {number} total @param {boolean} finished
 */
function setProgress(id, position, total, finished) {
  const prev = store.progress[id];
  store.progress[id] = {
    position,
    total,
    finished: Boolean(prev?.finished || finished || (total > 0 && position + 1 >= total)),
    updated: Date.now(),
  };
  save("progress");
  redrawShelves();
}

/**
 * 頁的順序變了（在詳情頁編輯、Ctrl+Z 復原）：閱讀進度與書籤跟著頁走，不是停在同一個頁碼。
 * 只追蹤編輯過頁面的作品（store.pageOrder 是上次看到的頁序）；移出的頁，進度換到它後面第一個還在的頁，書籤拿掉。
 * @param {number} id @param {number[]} now 作品現在的頁（圖片的 file_index，照順序）
 */
function syncPageOrder(id, now) {
  const before = store.pageOrder[id];
  if (!before || (before.length === now.length && before.every((page, i) => page === now[i]))) return;
  const at = new Map(now.map((page, i) => [page, i]));
  /** 舊的第幾頁 → 新的第幾頁。 @param {number} page */
  const moved = (page) => {
    for (let i = page; i < before.length; i++) {
      const to = at.get(before[i]);
      if (to !== undefined) return to;
    }
    return Math.max(0, now.length - 1);
  };
  const progress = store.progress[id];
  if (progress) {
    store.progress[id] = { ...progress, position: moved(progress.position), total: now.length };
    save("progress");
    redrawShelves();
  }
  const marks = store.bookmarks[id];
  if (marks) {
    const kept = marks.flatMap((page) => {
      const to = at.get(before[page]);
      return to === undefined ? [] : [to];
    });
    if (kept.length > 0) store.bookmarks[id] = [...new Set(kept)].sort((a, b) => a - b);
    else delete store.bookmarks[id];
    save("bookmarks");
  }
  store.pageOrder[id] = now;
  save("pageOrder");
}

/** 手動標成已讀／未讀。 @param {BookId} id @param {boolean} finished @param {number} total */
function setFinished(id, finished, total) {
  const prev = store.progress[id];
  store.progress[id] = { position: prev?.position ?? 0, total: prev?.total ?? total, finished, updated: Date.now() };
  save("progress");
  redrawShelves();
}

/** 這本的設定與套用範圍：自己的、跟隨預設，或沒設過時從作品推得。 @param {HoardItemDetail} item */
function settingsFor(item) {
  const defaults = { ...DEFAULT_SETTINGS, ...sanitize(store.defaults) };
  const stored = store.overrides[/** @type {BookId} */ (item.id)];
  if (stored?.scope === "global") return { settings: defaults, scope: /** @type {Scope} */ ("global") };
  if (stored?.scope === "item") return { settings: { ...defaults, ...sanitize(stored.settings) }, scope: /** @type {Scope} */ ("item") };
  const inferred = inferredSettings(item);
  if (inferred) return { settings: { ...defaults, ...inferred }, scope: /** @type {Scope} */ ("item") };
  return { settings: defaults, scope: /** @type {Scope} */ ("global") };
}
/** @typedef {"item" | "global"} Scope */

/** 依範圍存：只記在這本，或成為預設（這本改成跟隨預設）。 @param {BookId} id @param {Scope} scope @param {Settings} settings */
function saveSettings(id, scope, settings) {
  if (scope === "item") {
    store.overrides[id] = { scope: "item", settings };
  } else {
    store.defaults = settings;
    store.overrides[id] = { scope: "global" };
    save("defaults");
  }
  save("overrides");
}

// ---- 系列 ----

const UNGROUPED = "\0ungrouped";
const titleOrder = new Intl.Collator("zh-Hant", { numeric: true, sensitivity: "base" });

/**
 * 系列：來源寫的 metadata.series（例如 Pixiv 的系列）優先，否則是漫畫所在的資料夾名稱；複製進 vault 的看匯入時的位置。
 * 都沒有的（例如貼文）沒有系列，書架上放在「未分組」；不拿創作者當系列，否則設成漫畫的每一篇都自成一區。
 * @param {HoardItemSummary} item
 */
function seriesOf(item) {
  const series = item.metadata.series;
  if (typeof series === "string" && series.trim()) return series.trim();
  const path = item.metadata.original_path ?? item.metadata.folder_path ?? item.metadata.file_path;
  if (typeof path === "string") {
    const parts = path.split(/[\\/]/).filter(Boolean);
    if (parts.length >= 2) return parts[parts.length - 2];
  }
  return null;
}

// ---- 交給這裡的作品 ----

/** 這個插件的 id：作品的 `presenter` 是它，就是交給漫畫閱讀器的。 */
const PLUGIN_ID = "comic-reader";

/** 有圖可以讀的作品才能當漫畫。 @param {HoardItemSummary} item */
function readable(item) {
  return item.metadata.format != null || item.previews.some((f) => f.kind === "image");
}

/** 中文數字（到百位）：三、十二、一百零五。 @param {string} raw */
function chineseNumber(raw) {
  /** @type {Record<string, number>} */
  const digits = { 零: 0, 〇: 0, 一: 1, 二: 2, 兩: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
  let total = 0;
  let current = 0;
  for (const c of raw) {
    if (c === "百") {
      total += Math.max(current, 1) * 100;
      current = 0;
    } else if (c === "十") {
      total += Math.max(current, 1) * 10;
      current = 0;
    } else if (c in digits) {
      current = digits[c];
    } else {
      return null;
    }
  }
  const n = total + current;
  return n > 0 ? n : null;
}

/** @param {string} raw */
function parseNumber(raw) {
  const ascii = raw.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
  const n = Number(ascii);
  return ascii !== "" && isFinite(n) ? n : chineseNumber(ascii);
}

/**
 * 從名稱讀卷號：「第3卷」「第三集」「vol.03」「v3」「#3」，都沒有的話是括號外的最後一個數字（「標題 03」）。
 * @param {string} name
 */
function parseVolume(name) {
  const explicit = [
    /第\s*([0-9０-９零〇一二兩两三四五六七八九十百.]+)\s*[卷巻冊册集話话回部]/,
    /\bvol(?:ume)?\.?\s*([0-9]+(?:\.[0-9]+)?)/i,
    /(?:^|[\s_\-[(])v([0-9]+(?:\.[0-9]+)?)\b/i,
    /#\s*([0-9]+(?:\.[0-9]+)?)/,
  ];
  for (const re of explicit) {
    const match = re.exec(name);
    const n = match ? parseNumber(match[1]) : null;
    if (n !== null) return n;
  }
  // 先拿掉 [作者] (2003) 【完】 這類括號。
  const stripped = name.replace(/\[[^\]]*\]|\([^)]*\)|（[^）]*）|【[^】]*】/g, " ");
  const numbers = stripped.match(/[0-9]+(?:\.[0-9]+)?/g);
  return numbers ? Number(numbers[numbers.length - 1]) : null;
}

/** 卷號：來源寫的 metadata.volume（例如 Pixiv 系列裡的第幾話），否則從標題讀。 @param {HoardItemSummary} item */
function volumeOf(item) {
  const v = item.metadata.volume;
  if (typeof v === "number" && isFinite(v)) return v;
  return parseVolume(item.title);
}

/** 有卷號的照卷號，其他照標題自然排序（「第2卷」在「第10卷」前面）。 @param {HoardItemSummary} a @param {HoardItemSummary} b */
function volumeOrder(a, b) {
  const va = volumeOf(a);
  const vb = volumeOf(b);
  if (va !== null && vb !== null && va !== vb) return va - vb;
  if (va !== null && vb === null) return -1;
  if (va === null && vb !== null) return 1;
  return titleOrder.compare(a.title, b.title);
}

/** @type {Map<number, Promise<HoardItemSummary | null>>} */
const nextCache = new Map();
hoard.on("items-added", () => nextCache.clear());
hoard.on("items-removed", () => nextCache.clear());
hoard.on("items-changed", () => nextCache.clear());

/**
 * 同一系列的下一卷：同來源、同作者（兩位作者都可能有叫「短編」的系列），依卷號排序。
 * @param {HoardItemDetail} item
 */
function nextVolume(item) {
  let pending = nextCache.get(item.id);
  if (!pending) {
    pending = findNextVolume(item).catch(() => null);
    nextCache.set(item.id, pending);
  }
  return pending;
}

/** @param {HoardItemDetail} item */
async function findNextVolume(item) {
  const series = seriesOf(item);
  if (!series) return null;
  /** @type {HoardItemSummary[]} */
  const volumes = [];
  // 下一卷只從交給這裡的作品裡找。
  /** @type {HoardItemFilter} */
  const filter = { presenter: PLUGIN_ID };
  if (item.author) filter.author_id = item.author.id;
  for (let offset = 0; offset < 10000; offset += 500) {
    const page = await hoard.items.list(filter, { offset, limit: 500 });
    for (const other of page.items) {
      // 沒有作者的作品只跟同樣沒有作者的排在一起。
      if (!item.author && other.author_name !== null) continue;
      if (seriesOf(other) === series) volumes.push(other);
    }
    if (offset + 500 >= page.total) break;
  }
  if (!volumes.some((v) => v.id === item.id)) volumes.push(item);
  volumes.sort(volumeOrder);
  const index = volumes.findIndex((v) => v.id === item.id);
  return volumes[index + 1] ?? null;
}

/**
 * 「繼續閱讀」：最近讀過但沒讀完的，加上最近讀完那本的下一卷（還沒打開過的話），
 * 限在目前這個收藏庫畫面的篩選裡。
 * @param {HoardItemFilter} filter @param {number} limit
 * @returns {Promise<HoardItemSummary[]>}
 */
async function continueReading(filter, limit) {
  await loadStore();
  const recent = Object.entries(store.progress)
    .map(([id, p]) => /** @type {const} */ ([Number(id), p]))
    .sort((a, b) => (b[1].updated ?? 0) - (a[1].updated ?? 0))
    .slice(0, 200);
  const opened = new Set(recent.map(([id]) => id));
  /** @type {number[]} */
  const order = [];
  let lookups = 0;
  for (const [id, p] of recent) {
    let candidate = id;
    if (p.finished) {
      // 找下一卷要列出整個系列，只查最近幾本。
      if (++lookups > limit * 2) continue;
      const item = await hoard.items.get(id).catch(() => null);
      const next = item ? await nextVolume(item) : null;
      if (!next || opened.has(next.id)) continue;
      candidate = next.id;
    }
    if (!order.includes(candidate)) order.push(candidate);
    // 多留一些，篩選可能會再拿掉幾本。
    if (order.length >= limit * 2) break;
  }
  if (order.length === 0) return [];
  const { items } = await hoard.items.list({ ...filter, ids: order }, { limit: order.length });
  items.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
  return items.slice(0, limit);
}

// ---- 打開閱讀器 ----

/** 要打開的作品；閱讀器畫面重畫時（例如重新載入插件）沿用最後一次的。 */
/** @type {{ id: BookId; page?: number } | null} */
let opening = null;

/** @param {BookId} id @param {number} [page] 從這頁開始（0 起算）；省略時接續上次的位置 */
function openReader(id, page) {
  opening = { id, page };
  hoard.openView("reader");
}

// ---- 書架 ----

const BOOK_MIN_WIDTH = 132;
const BOOK_GAP = 20;

/** 進度條與文字。 @param {BookId} id */
function progressLabel(id) {
  const p = store.progress[id];
  if (!p || p.total <= 0) return null;
  const done = p.finished || p.position + 1 >= p.total;
  return {
    ratio: done ? 1 : Math.min(1, (p.position + 1) / p.total),
    text: done ? "已讀完" : `${p.position + 1} / ${p.total} 頁`,
  };
}

/**
 * 書架上的一本作品：點了開詳情頁（App 的開啟，卡片放大過去）；`read` 時直接開閱讀器。
 * @param {HoardItemSummary} item @param {HoardLayoutCtx} ctx @param {boolean} [read]
 */
function bookEl(item, ctx, read = false) {
  const book = bookFace(item.title, item.cover_path ?? item.thumbnail_path, progressLabel(item.id));
  ctx.bindItem(book, item, read ? { open: (id) => openReader(id) } : undefined);
  return book;
}

/**
 * 書的樣子：封面、進度條、標題、進度文字。
 * @param {string} title @param {string | null} cover @param {{ ratio: number; text: string } | null} progress
 */
function bookFace(title, cover, progress) {
  const face = cover
    ? hoard.el("img", {
        src: hoard.fileSrc(cover),
        alt: title,
        loading: "lazy",
        draggable: "false",
        class: "cr-book-img",
      })
    : hoard.el("span", { class: "cr-book-placeholder" }, [
        hoard.icon("image", { size: 16, class: "cr-book-placeholder-icon" }),
        hoard.el("span", { class: "cr-book-placeholder-title" }, [title]),
      ]);
  return hoard.el("button", { class: "cr-book", title }, [
    hoard.el(
      "span",
      {
        class: "cr-book-cover",
      },
      [
        face,
        progress &&
          hoard.el("span", { class: "cr-book-progress" }, [
            hoard.el("span", { class: "cr-book-progress-bar", style: `width: ${progress.ratio * 100}%` }),
          ]),
      ],
    ),
    hoard.el("span", { class: "cr-book-title" }, [title]),
    hoard.el("span", { class: "cr-book-status" }, [progress ? progress.text : "未讀"]),
  ]);
}

/** @param {string} name @param {string} [count] */
function shelfHeader(name, count) {
  return hoard.el("div", { class: "cr-shelf-header" }, [
    hoard.el("h3", { class: "cr-shelf-name" }, [name]),
    count ? hoard.el("span", { class: "cr-shelf-count" }, [count]) : null,
  ]);
}

/**
 * 一排書。書架是虛擬捲動的（ctx.virtualList），一排一列，欄數由版型依寬度算好；每一區的第一排上面多留一點。
 * @param {HTMLElement[]} books @param {number} columns @param {boolean} first
 */
function shelfGrid(books, columns, first) {
  return hoard.el(
    "div",
    {
      class: "cr-shelf-grid",
      style: `grid-template-columns: repeat(${columns}, minmax(0, 1fr)); column-gap: ${BOOK_GAP}px; padding-top: ${first ? 16 : BOOK_GAP}px`,
    },
    books,
  );
}

/** 依系列分組（照目前排序第一次出現的順序），系列內依卷號。 @param {HoardItemSummary[]} items */
function seriesGroups(items) {
  /** @type {Map<string, HoardItemSummary[]>} */
  const groups = new Map();
  for (const item of items) {
    const key = seriesOf(item) ?? UNGROUPED;
    const list = groups.get(key);
    if (list) list.push(item);
    else groups.set(key, [item]);
  }
  for (const [key, list] of groups) if (key !== UNGROUPED) list.sort(volumeOrder);
  return groups;
}

/** 開著的書架（進度改變時重畫）。 @type {Set<() => void>} */
const shelves = new Set();
function redrawShelves() {
  shelves.forEach((draw) => draw());
}

/** 書架上這一頁的作品以外、要另外查的：繼續閱讀。 @typedef {{ continuing: HoardItemSummary[] }} ShelfExtras */
/** @type {ShelfExtras} */
const NO_EXTRAS = { continuing: [] };
/**
 * 每種篩選最近一次查到的 ShelfExtras：再畫同一個書架時直接用它，畫面跟離開時一樣；背後查完有變才重畫
 * （docs/conventions.md〈清單〉）。 @type {Map<string, ShelfExtras>}
 */
const shelfCache = new Map();
/**
 * 第一次畫某個書架（還沒查過）時，等另外查的東西最多這麼久才先畫出作品：整個書架一起出現，
 * 不會先畫出下面幾排、「繼續閱讀」才擠進上面。
 */
const EXTRAS_WAIT_MS = 300;

/**
 * 一起查書架另外要的東西（也等閱讀進度讀進來）。
 * @param {HoardItemFilter} filter @param {number} columns @param {boolean} wantsContinue @returns {Promise<ShelfExtras>}
 */
async function shelfExtras(filter, columns, wantsContinue) {
  await loadStore();
  return { continuing: wantsContinue ? await continueReading(filter, columns) : [] };
}

/**
 * 不用查就知道的 ShelfExtras，不知道就是 null：閱讀進度讀進來了、不列「繼續閱讀」（搜尋中）。
 * 打字搜尋時每次都是還沒查過的篩選，靠它直接畫，不必等查詢而讓書架空一下（App 換結果時會先清掉版型）。
 * @param {boolean} wantsContinue @returns {ShelfExtras | null}
 */
function knownExtras(wantsContinue) {
  return !loaded || wantsContinue ? null : NO_EXTRAS;
}

/** 書架上看得出來的部分（哪幾本）：兩次查到的一樣就不必重畫。 @param {ShelfExtras} extras */
function extrasKey({ continuing }) {
  return continuing.map((item) => item.id).join();
}

hoard.registerLayout({
  id: "shelf",
  label: "書架",
  icon: "library",

  render(root, items, ctx) {
    let alive = true;
    const content = hoard.el("div", { class: "cr-shelf" });
    root.append(content);
    // 欄數照書架的寬度（扣掉左右留白）算，每一排都一樣寬。
    const width = Math.max(BOOK_MIN_WIDTH, content.clientWidth - 48);
    const columns = Math.max(1, Math.floor((width + BOOK_GAP) / (BOOK_MIN_WIDTH + BOOK_GAP)));
    const bookWidth = (width - BOOK_GAP * (columns - 1)) / columns;
    const filterKey = JSON.stringify(ctx.filter);
    // 搜尋是在找特定的東西，這一排只會礙事。
    const wantsContinue = !ctx.filter.search;
    /** 畫面上用的另外查的東西；這個書架還沒查過、也不用查就知道時是 null。 */
    let extras = shelfCache.get(filterKey) ?? knownExtras(wantsContinue);
    /**
     * 每一列是一個標題或一排書；書在捲進畫面時才建出來。
     * @type {Array<{ header: [string, string | undefined] } | { books: Array<() => HTMLElement>; first: boolean }>}
     */
    let rows = [];
    /** 畫好的書架；第一次畫之前是 null。 @type {HoardVirtualList | null} */
    let shelf = null;

    const draw = () => {
      if (!alive) return;
      const { continuing } = extras ?? NO_EXTRAS;
      /** @type {typeof rows} */
      const next = [];
      /** @param {Array<() => HTMLElement>} books */
      const addBooks = (books) => {
        for (let i = 0; i < books.length; i += columns) next.push({ books: books.slice(i, i + columns), first: i === 0 });
      };
      if (continuing.length > 0) {
        next.push({ header: ["繼續閱讀", undefined] });
        addBooks(continuing.map((item) => () => bookEl(item, ctx, true)));
      }
      const groups = seriesGroups(items);
      // 全部都沒有系列時不必有標題。
      const headers = !(groups.size === 1 && groups.has(UNGROUPED));
      for (const [name, list] of groups) {
        if (headers) next.push({ header: [name === UNGROUPED ? "未分組" : name, `${list.length} 冊`] });
        addBooks(list.map((item) => () => bookEl(item, ctx)));
      }
      rows = next;
      // 重畫用同一份清單：畫面上的列換掉，捲動位置不變。
      if (shelf) {
        shelf.redraw(rows.length);
        return;
      }
      shelf = ctx.virtualList(content, {
        count: rows.length,
        // 封面 2:3，加上進度條與兩行文字。
        estimateSize: (i) => ("header" in rows[i] ? 48 : bookWidth * 1.5 + 64 + BOOK_GAP),
        renderRow(row, i) {
          const entry = rows[i];
          if ("header" in entry) row.append(shelfHeader(...entry.header));
          else row.append(shelfGrid(entry.books.map((make) => make()), columns, entry.first));
        },
      });
    };
    // 進度改了（讀了、標為已讀）：畫好的書架重畫。還沒畫的等第一次畫。
    const redraw = () => {
      if (shelf) draw();
    };
    shelves.add(redraw);

    /** 另外查一次；有變（或是第一次查到）就換上，畫好的書架重畫。 */
    const refresh = () => {
      const asked = shelfExtras(ctx.filter, columns, wantsContinue);
      asked.then(
        (found) => {
          shelfCache.set(filterKey, found);
          if (!alive) return;
          const changed = extras === null || extrasKey(found) !== extrasKey(extras);
          extras = found;
          if (changed) redraw();
        },
        (err) => console.error("[comic-reader] 書架另外查的作品：", err),
      );
      return asked;
    };
    const first = refresh();
    if (extras !== null && loaded) {
      // 查過這個書架，或不用查就知道：直接畫（背後查完有變才重畫）。
      draw();
    } else {
      // 要查才知道：等另外查的與閱讀進度一起出現；太久就先畫作品，查到再補上。
      const late = setTimeout(() => !shelf && draw(), EXTRAS_WAIT_MS);
      const settle = () => {
        clearTimeout(late);
        if (!shelf) draw();
      };
      first.then(settle, settle);
    }

    /** @type {IntersectionObserver | null} */
    let observer = null;
    if (ctx.hasMore) {
      // 捲到底載入下一頁；App 重畫時會保留捲動位置。
      const sentinel = hoard.el("div", { class: "cr-shelf-sentinel" });
      root.append(sentinel);
      observer = new IntersectionObserver((entries) => entries.some((e) => e.isIntersecting) && ctx.loadMore(), {
        root,
        rootMargin: "800px",
      });
      observer.observe(sentinel);
    }
    return () => {
      alive = false;
      shelves.delete(redraw);
      observer?.disconnect();
    };
  },
});

// ---- 閱讀器 ----

/** 目前跨頁前後各幾個跨頁要真的載入圖片（也會預先載入）。 */
const WINDOW = 3;
const ZOOM_MIN = 0.25;
const ZOOM_MAX = 6;
/** 跨頁裡的頁碼（閱讀順序）；-1 是補的空白頁。 */
const BLANK = -1;

/** @typedef {{ width: number; height: number }} PageSize */

/**
 * 照 OpenComic 的方式排成跨頁：可選擇開頭補一張空白讓封面單獨，橫向頁單獨一個跨頁
 * （它前一頁也就單獨，不跨過它配對），其他兩兩一組。
 * @param {PageSize[]} pages @param {boolean} double @param {boolean} coverAlone @param {boolean} landscapeAlone
 */
function buildSpreads(pages, double, coverAlone, landscapeAlone) {
  if (!double) return pages.map((_, i) => [i]);
  const landscape = (/** @type {number} */ i) => pages[i].width > 0 && pages[i].height > 0 && pages[i].width > pages[i].height;
  const sequence = coverAlone ? [BLANK, ...pages.map((_, i) => i)] : pages.map((_, i) => i);
  /** @type {number[][]} */
  const spreads = [];
  /** @type {number[]} */
  let pending = [];
  const flush = () => {
    // 只有空白頁的跨頁（封面是橫的）就不要了。
    if (pending.some((i) => i !== BLANK)) spreads.push(pending);
    pending = [];
  };
  for (const index of sequence) {
    if (index !== BLANK && landscapeAlone && landscape(index)) {
      flush();
      spreads.push([index]);
      continue;
    }
    pending.push(index);
    if (pending.length === 2) flush();
  }
  flush();
  return spreads;
}

/** 裁切後留下的比例。 @param {Settings} s */
function cropFactors(s) {
  return {
    w: Math.max(0.05, 1 - (s.cropLeft + s.cropRight) / 100),
    h: Math.max(0.05, 1 - (s.cropTop + s.cropBottom) / 100),
  };
}

/** 顯示出來（裁切後）的寬高比；尺寸還不知道時當直式。 @param {PageSize | undefined} page @param {Settings} s */
function shownAspect(page, s) {
  const crop = cropFactors(s);
  if (!page || page.width <= 0 || page.height <= 0) return (0.7 * crop.w) / crop.h;
  return (page.width * crop.w) / (page.height * crop.h);
}

/**
 * 一個跨頁裡每頁的大小。同一跨頁的頁一樣高，空白頁借旁邊那頁的比例。
 *  - height：跟可視區一樣高，但不超出寬度
 *  - width：整個跨頁填滿寬度
 *  - original：頁面本身的像素高度（裁切後）
 * 再乘上 zoom（Ctrl＋滾輪）。
 * @param {number[]} spread @param {PageSize[]} pages @param {Settings} s
 * @param {{ width: number; height: number }} viewport @param {number} zoom
 */
function layoutSpread(spread, pages, s, viewport, zoom) {
  const real = spread.filter((i) => i !== BLANK);
  const aspects = spread.map((i) => shownAspect(pages[i === BLANK ? real[0] : i], s));
  const sum = aspects.reduce((a, b) => a + b, 0) || 1;
  const W = Math.max(50, viewport.width - 2 * s.marginX);
  const H = Math.max(50, viewport.height - 2 * s.marginY);
  let height;
  if (s.fit === "width") {
    height = W / sum;
  } else if (s.fit === "original") {
    const natural = Math.max(...real.map((i) => pages[i]?.height || 0)) * cropFactors(s).h;
    height = natural > 0 ? natural : H;
  } else {
    height = Math.min(H, W / sum);
  }
  height *= zoom;
  return spread.map((index, k) => ({ index, width: height * aspects[k], height }));
}

/** 頁框（overflow: hidden）裡那張圖的大小與位移，做出裁切。 @param {Settings} s @param {{ width: number; height: number }} box */
function cropStyle(s, box) {
  const crop = cropFactors(s);
  const width = box.width / crop.w;
  const height = box.height / crop.h;
  return {
    width: `${width}px`,
    height: `${height}px`,
    maxWidth: "none",
    marginLeft: `${-(s.cropLeft / 100) * width}px`,
    marginTop: `${-(s.cropTop / 100) * height}px`,
  };
}

/** @param {number} value @param {number} min @param {number} max */
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

/** @param {EventTarget | null} target */
const isTyping = (target) =>
  target instanceof Element && Boolean(target.closest("input, textarea, select, [contenteditable='true']"));

/**
 * 頁首右側的工具按鈕（App 的 hoard-icon-button，開著的用 aria-pressed 亮起）。
 * @param {string} title @param {Node | string} content @param {() => void} onclick
 * @param {{ active?: boolean; disabled?: boolean; extra?: string }} [opts]
 */
function toolButton(title, content, onclick, opts = {}) {
  /** @type {Record<string, string | ((event: Event) => void)>} */
  const attrs = {
    type: "button",
    title,
    "aria-label": title,
    "aria-pressed": String(Boolean(opts.active)),
    class: ["hoard-icon-button", opts.extra ?? ""].filter(Boolean).join(" "),
    onclick,
  };
  if (opts.disabled) attrs.disabled = "";
  return hoard.el("button", attrs, [content]);
}

// ---- 動畫（App 的 docs/conventions.md〈動畫〉：插件拿不到 App 的動畫程式，照同一組時長、曲線自己做） ----

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場、移動、變大。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/** EASE_OUT 的 JS 版（頁碼滑桿的值不能用 CSS 動畫，只能每一格自己算）：時間 0–1 → 進度 0–1。 @param {number} x */
function easeOut(x) {
  /** @param {number} a @param {number} b @param {number} t */
  const at = (a, b, t) => 3 * a * t * (1 - t) ** 2 + 3 * b * t * t * (1 - t) + t ** 3;
  let lo = 0;
  let hi = 1;
  let t = x;
  for (let i = 0; i < 24; i++) {
    t = (lo + hi) / 2;
    if (at(0.2, 0, t) < x) lo = t;
    else hi = t;
  }
  return at(0, 1, t);
}

/** 元素現在（滑到一半也算）的水平位移，px。 @param {Element} el */
function shiftOf(el) {
  const value = parseFloat(getComputedStyle(el).translate);
  return Number.isFinite(value) ? value : 0;
}

/**
 * 退場：從現在的樣子（進場到一半也算）走到 to，走完才拿掉；退場中的不能點。
 * @param {HTMLElement} el @param {Record<string, string>} to @param {number} ms
 */
function leave(el, to, ms) {
  el.classList.add("cr-leaving");
  el.style.pointerEvents = "none";
  if (!motionOn()) return void el.remove();
  const style = getComputedStyle(el);
  /** @type {Record<string, string>} */
  const from = {};
  for (const key of Object.keys(to)) from[key] = style.getPropertyValue(key);
  for (const a of el.getAnimations()) a.cancel();
  void el.animate([from, to], { duration: ms, easing: EASE_IN, fill: "forwards" }).finished.then(
    () => el.remove(),
    () => {},
  );
}

/** 每個翻頁框裡還在滑走的跨頁，與最近一次翻頁的記號。 @type {WeakMap<HTMLElement, { gone: HTMLElement[]; token: object }>} */
const tracks = new WeakMap();

/**
 * 翻頁：舊的跨頁整個往反方向滑出去、新的從另一邊整個滑進來，兩個同時走、不淡出（跟 App 換作品的 slideWorks 同一套）。
 * 像一條每格 D 寬的軌道：連翻時從目前的位置接著走，還在滑走的跟著一起走；往回翻時，剛滑走的那個由新的接回它的位置。
 * shown 要已經釘在原位（position: absolute）、fresh 已經排進版面；滑動期間裁掉 clip 外面。
 * @param {HTMLElement} clip @param {HTMLElement} shown @param {HTMLElement} fresh
 * @param {1 | -1} d 1：整條往左走 @param {number} D 一格多寬
 */
function slideRows(clip, shown, fresh, d, D) {
  const ms = 220;
  const live = (tracks.get(clip)?.gone ?? []).filter((el) => el.isConnected && el !== shown && el !== fresh);
  const cur = shiftOf(shown);
  const rest = live.map((el) => /** @type {const} */ ([el, shiftOf(el)]));
  for (const el of [shown, fresh, ...live]) for (const a of el.getAnimations()) a.cancel();
  clip.style.overflow = "clip";
  const delta = -d * D - cur; // 整條這次走多遠
  const start = cur + d * D; // 新的緊接在舊的後面
  /** @param {HTMLElement} el @param {number} from */
  const out = (el, from) => {
    const a = el.animate([{ translate: `${from}px 0` }, { translate: `${from + delta}px 0` }], { duration: ms, easing: EASE_OUT, fill: "forwards" });
    return a.finished.then(
      () => el.remove(),
      () => {},
    );
  };
  const leaving = [shown];
  /** @type {Promise<unknown>[]} */
  const runs = [out(shown, cur)];
  for (const [el, at] of rest) {
    if (Math.abs(at - start) < 1) {
      el.remove(); // 往回翻：新的接回它的位置
      continue;
    }
    leaving.push(el);
    runs.push(out(el, at));
  }
  runs.push(fresh.animate([{ translate: `${start}px 0` }, { translate: "0 0" }], { duration: ms, easing: EASE_OUT }).finished.catch(() => {}));
  const token = {};
  tracks.set(clip, { gone: leaving, token });
  void Promise.all(runs).then(() => {
    if (tracks.get(clip)?.token !== token) return;
    tracks.delete(clip);
    clip.style.overflow = "";
  });
}

/**
 * 分段鈕目前選項的底色是一塊跟著選項走的底：放到選中的那一格；before 是重建前每一組的位置，有就從那裡滑過去（200ms，寬度也補間）。
 * @param {HTMLElement} root @param {Array<{ left: string; width: string }>} [before]
 */
function placeMarks(root, before = []) {
  root.querySelectorAll(".cr-segmented").forEach((group, i) => {
    const mark = group.querySelector(".cr-segment-mark");
    const active = group.querySelector(".cr-active");
    if (!(mark instanceof HTMLElement)) return;
    mark.hidden = !(active instanceof HTMLElement);
    if (!(active instanceof HTMLElement)) return;
    const to = { left: `${active.offsetLeft}px`, width: `${active.offsetWidth}px` };
    Object.assign(mark.style, to);
    const from = before[i];
    if (from && motionOn() && (from.left !== to.left || from.width !== to.width)) {
      mark.animate([from, to], { duration: 200, easing: EASE_OUT });
    }
  });
}

/** 每一組分段鈕的底現在（滑到一半也算）在哪裡。 @param {HTMLElement} root */
const marksOf = (root) =>
  [...root.querySelectorAll(".cr-segmented")].map((group) => {
    const mark = group.querySelector(".cr-segment-mark");
    const style = mark ? getComputedStyle(mark) : null;
    return { left: style?.left ?? "0px", width: style?.width ?? "0px" };
  });

/**
 * 晚到的區塊（box 裡先放好骨架佔位置；CSS 讓骨架等 200ms 才淡入，很快就到的看不到它）換成內容：
 * 骨架淡出、內容淡入（骨架出現過時 160ms 交叉，沒出現過時內容直接淡入 120ms），
 * 高度從骨架補間到內容的實際高度 200ms，下面的東西跟著滑，不是跳。沒有內容就整塊收起來（連同它在父層 gap 裡佔的空隙）。
 * @param {HTMLElement} box @param {HTMLElement[]} content @param {number} since 骨架放上去的時間（performance.now()）
 */
function settle(box, content, since) {
  if (!motionOn()) return void box.replaceChildren(...content);
  const seen = performance.now() - since >= 200;
  const skeleton = /** @type {HTMLElement[]} */ ([...box.children]);
  const from = box.getBoundingClientRect().height;
  for (const a of box.getAnimations()) a.cancel();
  box.style.overflow = "clip";
  if (content.length === 0) {
    const gap = box.parentElement ? parseFloat(getComputedStyle(box.parentElement).rowGap) || 0 : 0;
    for (const el of skeleton) el.animate([{ opacity: getComputedStyle(el).opacity }, { opacity: 0 }], { duration: 160, easing: EASE_IN, fill: "forwards" });
    const fold = box.animate([{ height: `${from}px`, marginBottom: "0px" }, { height: "0px", marginBottom: `${-gap}px` }], { duration: 200, easing: EASE_OUT, fill: "forwards" });
    void fold.finished.then(
      () => {
        box.replaceChildren();
        box.style.overflow = "";
        fold.cancel();
      },
      () => {},
    );
    return;
  }
  // 骨架停在現在的樣子（搬進疊層時 CSS 動畫會重來），再疊到內容上面淡出。
  for (const el of skeleton) {
    el.style.opacity = getComputedStyle(el).opacity;
    el.style.animation = "none";
  }
  box.replaceChildren(...content);
  const to = box.getBoundingClientRect().height;
  const grow = box.animate([{ height: `${from}px` }, { height: `${to}px` }], { duration: 200, easing: EASE_OUT });
  void grow.finished.then(
    () => (box.style.overflow = ""),
    () => {},
  );
  for (const el of content) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: seen ? 160 : 120, easing: EASE_OUT, fill: "backwards" });
  if (!seen) return;
  const ghost = hoard.el("div", { class: "cr-late-ghost", "aria-hidden": "true" }, skeleton);
  box.prepend(ghost);
  void ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 160, easing: EASE_IN, fill: "forwards" }).finished.then(
    () => ghost.remove(),
    () => ghost.remove(),
  );
}

/**
 * 一個閱讀器畫面。版面（跨頁、頁框）只在設定或頁面尺寸改變時重排；翻頁只換目前的跨頁
 * （翻頁檢視）或捲過去（連續捲動），圖片只放在目前跨頁附近。
 */
class Reader {
  /** @param {HTMLElement} host @param {HoardViewCtx} ctx */
  constructor(host, ctx) {
    this.host = host;
    this.ctx = ctx;
    host.className = "cr-reader";
    host.style.height = "100%";
    this.alive = true;
    /** @type {Array<() => void>} */
    this.cleanups = [];
    /** @type {BookId | null} */
    this.id = null;
    /** @type {HoardItemDetail | null} */
    this.item = null;
    /** @type {HoardItemFile[]} */
    this.files = [];
    /** @type {PageSize[]} */
    this.pages = [];
    /** @type {Settings} */
    this.settings = DEFAULT_SETTINGS;
    /** @type {Settings | null} 套用內容模式後的設定；null 表示還在讀取 */
    this.s = null;
    /** @type {Scope} */
    this.scope = "global";
    this.page = 0;
    this.current = 0;
    /** @type {number[][]} */
    this.spreads = [];
    /** @type {number[]} */
    this.spreadOf = [];
    this.double = false;
    this.rtl = false;
    this.zoom = 1;
    /** @type {"settings" | "bookmarks" | null} */
    this.panel = null;
    /** @type {number[]} */
    this.bookmarks = [];
    this.magnifier = false;
    this.magnifierRatio = 2.5;
    this.atEnd = false;
    /** @type {HoardItemSummary | null | undefined} 下一卷；undefined：還在找 */
    this.nextItem = undefined;
    this.layoutKey = "";
    this.scopeHintShown = false;
    /** @type {Array<{ row: HTMLElement; boxes: Array<{ index: number; el: HTMLElement; img: HTMLImageElement | null }> }>} */
    this.rows = [];
    /** @type {HTMLImageElement[]} */
    this.preloads = [];
    this.wheelLock = 0;
    /** @type {{ x: number; y: number } | null} */
    this.swipe = null;
    this.swallowClick = false;
    /** @type {number | undefined} */ this.saveTimer = undefined;
    /** @type {number | undefined} */ this.persistTimer = undefined;
    /** @type {number | undefined} */ this.hintTimer = undefined;
    /** @type {number} */ this.relayoutFrame = 0;
    /** @type {IntersectionObserver | null} */
    this.observer = null;
    /** @type {ResizeObserver | null} */
    this.resizeObserver = null;
    /** @type {(() => void) | null} 還沒寫出的設定 */
    this.persistPending = null;
    /** @type {HTMLElement | null} */ this.stage = null;
    /** 頁首右側的工具（App 的頁首，見 ctx.header）。不做蓋在畫面上、會自動隱藏的工具列（docs/conventions.md〈頁首〉）。 */
    this.tools = hoard.el("div", { class: "cr-tools" });
    ctx.header.actions.append(this.tools);
    /** @type {HTMLElement | null} */ this.footer = null;
    /** @type {HTMLInputElement | null} */ this.slider = null;
    /** @type {HTMLElement | null} */ this.panelHost = null;
    /** @type {HTMLElement | null} */ this.endOverlay = null;
    /** @type {HTMLElement | null} */ this.endHost = null;
    /** @type {HTMLElement | null} */ this.hint = null;
    /** @type {HTMLElement | null} */ this.lens = null;
    /** @type {HTMLElement | null} */ this.scroller = null;
    /** @type {HTMLElement | null} */ this.inner = null;
    /** @type {HTMLElement | null} 翻頁檢視裡目前的跨頁（翻頁時整個滑出去的就是它） */ this.slideRow = null;
    /** 正在拖頁碼滑桿：直接跳，不翻頁、滑桿也不補間。 */
    this.scrubbing = false;
    /** @type {number} 頁碼滑桿補間的下一格 */ this.sliderFrame = 0;

    this.listen(window, "keydown", (e) => this.onKey(/** @type {KeyboardEvent} */ (e)), true);
    this.listen(document, "fullscreenchange", () => this.renderHeader());
    this.listen(window, "mousemove", (e) => this.moveLens(/** @type {MouseEvent} */ (e)));
    // Once for the whole session: build() runs again for every volume.
    this.listen(this.host, "wheel", (e) => this.onWheel(/** @type {WheelEvent} */ (e)), { passive: false });
  }

  /** @param {EventTarget} target @param {string} type @param {(e: Event) => void} fn @param {AddEventListenerOptions | boolean} [opts] */
  listen(target, type, fn, opts) {
    target.addEventListener(type, fn, opts);
    this.cleanups.push(() => target.removeEventListener(type, fn, opts));
  }

  destroy() {
    if (this.saveTimer !== undefined) this.saveProgress();
    this.alive = false;
    this.cleanups.forEach((fn) => fn());
    this.observer?.disconnect();
    this.resizeObserver?.disconnect();
    clearTimeout(this.hintTimer);
    clearTimeout(this.persistTimer);
    if (this.persistPending) this.persistPending();
    cancelAnimationFrame(this.relayoutFrame);
    cancelAnimationFrame(this.sliderFrame);
    this.preloads.forEach((img) => (img.src = ""));
    if (document.fullscreenElement === this.host) void document.exitFullscreen().catch(() => {});
  }

  close() {
    this.ctx.back();
  }

  /** @param {string} text @param {boolean} [error] */
  message(text, error = false) {
    this.s = null;
    // 還沒有一卷可讀：頁首回到「閱讀器」，沒有頁碼與工具。
    this.ctx.header.setTitle(null);
    this.ctx.header.setCount(null);
    this.tools.replaceChildren();
    this.host.replaceChildren(
      hoard.el("div", { class: "cr-message" }, [
        hoard.el("p", { class: error ? "cr-message-text cr-error" : "cr-message-text" }, [text]),
        error ? hoard.el("button", { class: "cr-quiet-btn", onclick: () => this.close() }, ["關閉"]) : null,
      ]),
    );
  }

  /** @param {BookId} id @param {number} [startPage] */
  async open(id, startPage) {
    if (this.saveTimer !== undefined) this.saveProgress();
    this.id = id;
    this.item = null;
    this.nextItem = undefined;
    this.atEnd = false;
    this.zoom = 1;
    this.panel = null;
    this.layoutKey = "";
    this.message("讀取中…");
    try {
      const [item] = await Promise.all([hoard.items.get(id), loadStore()]);
      if (!this.alive || this.id !== id) return;
      const files = item.files.filter((f) => f.kind === "image");
      if (files.length === 0) return this.message("這件作品沒有可以閱讀的圖片。", true);
      syncPageOrder(id, files.map((f) => f.file_index));
      this.item = item;
      this.files = files;
      this.pages = files.map((f) => ({ width: f.width ?? 0, height: f.height ?? 0 }));
      const config = settingsFor(item);
      this.settings = config.settings;
      this.scope = config.scope;
      this.bookmarks = [...(store.bookmarks[id] ?? [])];
      this.page = clamp(startPage ?? store.progress[id]?.position ?? 0, 0, files.length - 1);
      this.build();
      // 打開就算讀過（會出現在「繼續閱讀」）。
      this.saveTimer = window.setTimeout(() => this.saveProgress(), 500);
      void nextVolume(item).then((next) => {
        if (!this.alive || this.id !== id) return;
        this.nextItem = next;
        this.renderEnd();
      });
    } catch (err) {
      if (this.alive && this.id === id) this.message(String(err), true);
    }
  }

  // ---- 骨架 ----

  build() {
    this.stage = hoard.el("div", { class: "cr-stage" });
    this.slider = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "range", min: "0", class: "cr-page-slider" }));
    const slider = this.slider;
    slider.addEventListener("pointerdown", () => {
      // 抓住滑桿時停下補間。
      cancelAnimationFrame(this.sliderFrame);
      slider.step = "1";
    });
    slider.addEventListener("input", () => {
      this.scrubbing = true;
      this.goToPage(Math.round(Number(slider.value)), false);
      this.scrubbing = false;
    });
    this.footer = hoard.el("footer", { class: "cr-footer" }, [this.slider]);
    this.panelHost = hoard.el("div");
    this.endOverlay = hoard.el("div");
    this.hint = hoard.el("div");
    this.lens = hoard.el("div", {
      class: "cr-lens cr-lens-hidden",
      style: "width: 260px; height: 260px; background-color: #000",
    });
    this.host.replaceChildren(this.stage, this.endOverlay, this.footer, this.panelHost, this.hint, this.lens);

    // The stage is new for every volume; its listeners go with it.
    const stage = this.stage;
    stage.addEventListener("click", (e) => this.onStageClick(/** @type {MouseEvent} */ (e)));
    stage.addEventListener("pointerdown", (e) => {
      const p = /** @type {PointerEvent} */ (e);
      if (p.pointerType === "touch") this.swipe = { x: p.clientX, y: p.clientY };
    });
    stage.addEventListener("pointerup", (e) => this.onSwipeEnd(/** @type {PointerEvent} */ (e)));
    this.resizeObserver ??= new ResizeObserver(() => this.relayout());
    this.resizeObserver.disconnect();
    this.resizeObserver.observe(stage);
    this.relayout(true);
  }

  get viewport() {
    return { width: this.stage?.clientWidth ?? 0, height: this.stage?.clientHeight ?? 0 };
  }

  /** 設定、可視區或頁面尺寸變了：跨頁結構不同就整個重建，否則只調大小。 @param {boolean} [force] */
  relayout(force = false) {
    if (!this.item || !this.stage) return;
    const s = applied(this.settings);
    this.s = s;
    this.rtl = s.mode === "manga";
    const { width, height } = this.viewport;
    this.double = s.spread === "double" || (s.spread === "auto" && width > height);
    this.spreads = buildSpreads(this.pages, this.double, s.coverAlone, s.landscapeAlone);
    /** @type {number[]} */
    const spreadOf = [];
    this.spreads.forEach((spread, k) => spread.forEach((i) => i !== BLANK && (spreadOf[i] = k)));
    this.spreadOf = spreadOf;
    this.current = spreadOf[this.page] ?? 0;
    const key = `${s.view}|${s.mode}|${JSON.stringify(this.spreads)}`;
    if (force || key !== this.layoutKey) {
      this.layoutKey = key;
      this.buildScroller();
    } else {
      this.sizeRows();
    }
    this.renderHeader();
    this.renderFooter();
    this.renderEnd();
  }

  buildScroller() {
    const s = /** @type {Settings} */ (this.s);
    this.observer?.disconnect();
    this.observer = null;
    this.rows = [];
    this.slideRow = null;
    // 同一卷換版面（雙頁、RTL、檢視方式）：舊的版面淡出、新的淡入；剛開的一卷直接放。
    const old = this.scroller && this.stage && this.scroller.parentElement === this.stage ? this.scroller : null;
    this.scroller = hoard.el("div", { class: "cr-scroller" });
    if (s.view === "slide") {
      this.inner = hoard.el("div", { class: "cr-slide" });
      this.scroller.append(this.inner);
      this.swapScroller(old);
      this.renderSlide();
    } else {
      this.inner = hoard.el("div", { class: "cr-strip" });
      this.spreads.forEach((spread, k) => {
        const row = this.makeRow(spread, k);
        row.dataset.spread = String(k);
        /** @type {HTMLElement} */ (this.inner).append(row);
      });
      this.endHost = hoard.el("div", { class: "cr-strip-end", onclick: (e) => e.stopPropagation() });
      this.inner.append(this.endHost);
      this.scroller.append(this.inner);
      this.swapScroller(old);
      this.sizeRows();
      this.updateWindow();
      // 最上面那個跨頁就是目前的。
      /** @type {Set<number>} */
      const visible = new Set();
      this.observer = new IntersectionObserver(
        (entries) => {
          for (const e of entries) {
            const k = Number(/** @type {HTMLElement} */ (e.target).dataset.spread);
            if (e.isIntersecting) visible.add(k);
            else visible.delete(k);
          }
          if (visible.size === 0) return;
          const k = Math.min(...visible);
          const target = this.spreads[k]?.find((i) => i !== BLANK);
          if (target !== undefined && k !== this.current) this.setPage(target);
        },
        { root: this.scroller, rootMargin: "0px 0px -60% 0px" },
      );
      this.rows.forEach(({ row }) => /** @type {IntersectionObserver} */ (this.observer).observe(row));
      const jump = this.current;
      requestAnimationFrame(() => this.rows[jump]?.row.scrollIntoView({ block: "start" }));
    }
  }

  /**
   * 放上新的版面：old 是同一卷上一個版面，淡出 160ms（新的同時淡入）後拿掉。
   * @param {HTMLElement | null} old
   */
  swapScroller(old) {
    const stage = this.stage;
    const scroller = this.scroller;
    if (!stage || !scroller) return;
    if (!old || !motionOn()) return void stage.replaceChildren(scroller);
    for (const el of stage.querySelectorAll(":scope > .cr-leaving")) el.remove();
    // 疊在新版面上原地淡出（捲動位置不變）。
    Object.assign(old.style, { position: "absolute", inset: "0" });
    leave(old, { opacity: "0" }, 160);
    stage.append(scroller);
    scroller.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 160, easing: EASE_OUT });
  }

  /**
   * 翻頁檢視：只放目前的跨頁。d 是往哪邊翻（1：整條往左走，-1：往右），0 直接換。
   * @param {0 | 1 | -1} [d]
   */
  renderSlide(d = 0) {
    const inner = this.inner;
    if (!inner) return;
    const old = this.slideRow;
    this.rows = [];
    const spread = this.spreads[this.current];
    const row = spread ? this.makeRow(spread, this.current) : hoard.el("div");
    this.slideRow = row;
    if (d === 0 || !old || old.parentElement !== inner || !motionOn()) {
      inner.replaceChildren(row);
      this.sizeRows();
      this.updateWindow();
      return;
    }
    // 舊的跨頁釘在畫面上原來的位置（新的才排得進版面、捲動才能歸零），再一起往那邊滑。
    const was = old.getBoundingClientRect();
    const shift = shiftOf(old);
    old.classList.add("cr-leaving");
    Object.assign(old.style, { position: "absolute", margin: "0" });
    inner.style.overflow = "clip"; // 滑出去的不撐出捲軸
    inner.append(row);
    this.sizeRows();
    this.updateWindow();
    const scroller = this.scroller;
    scroller?.scrollTo({ top: 0, left: this.rtl ? scroller.scrollWidth : 0 });
    const box = inner.getBoundingClientRect();
    Object.assign(old.style, { left: `${was.left - box.left - shift}px`, top: `${was.top - box.top}px` });
    // 一格要比畫面與兩個跨頁都寬：比畫面寬的跨頁也整個離開、整個從外面進來。
    const D = Math.max(scroller?.clientWidth ?? 0, was.width, row.getBoundingClientRect().width);
    slideRows(inner, old, row, d, D);
  }

  /** @param {number[]} spread @param {number} k */
  makeRow(spread, k) {
    const row = hoard.el("div", { class: "cr-row" });
    const boxes = spread.map((index) => {
      const el = hoard.el("div", { class: "cr-page" });
      return { index, el, img: /** @type {HTMLImageElement | null} */ (null) };
    });
    row.append(...boxes.map((b) => b.el));
    this.rows[k] = { row, boxes };
    return row;
  }

  /** 依設定與可視區調整每個頁框、邊距與圖片的裁切、濾鏡。 */
  sizeRows() {
    const s = /** @type {Settings} */ (this.s);
    if (!this.inner) return;
    this.inner.style.padding = `${s.marginY}px ${s.marginX}px`;
    this.inner.style.gap = s.view === "scroll" && s.mode !== "webtoon" ? "8px" : "0";
    const filter = filterCss(s);
    const viewport = this.viewport;
    this.rows.forEach((entry, k) => {
      if (!entry) return;
      entry.row.style.flexDirection = this.rtl ? "row-reverse" : "row";
      const sizes = layoutSpread(this.spreads[k], this.pages, s, viewport, this.zoom);
      entry.boxes.forEach((box, n) => {
        box.el.style.width = `${sizes[n].width}px`;
        box.el.style.height = `${sizes[n].height}px`;
        if (box.img) {
          Object.assign(box.img.style, cropStyle(s, sizes[n]));
          box.img.style.filter = filter;
        }
      });
    });
  }

  /** 目前跨頁附近才放圖片，其他放頁碼；也預先載入前後的頁。 */
  updateWindow() {
    const s = /** @type {Settings} */ (this.s);
    const near = s.view === "scroll" ? WINDOW + 1 : 0;
    this.rows.forEach((entry, k) => {
      if (!entry) return;
      const active = Math.abs(k - this.current) <= near;
      for (const box of entry.boxes) {
        if (box.index === BLANK) continue;
        if (active && !box.img) {
          box.img = this.makeImg(box.index);
          box.el.replaceChildren(box.img);
        } else if (!active && (box.img || box.el.childElementCount === 0)) {
          box.img = null;
          box.el.replaceChildren(
            hoard.el("div", { class: "cr-page-placeholder" }, [
              String(box.index + 1),
            ]),
          );
        }
      }
    });
    this.sizeRows();
    // 預先載入：目前跨頁前後各 WINDOW 個。
    const keep = this.preloads;
    this.preloads = [];
    for (let k = Math.max(0, this.current - WINDOW); k <= Math.min(this.spreads.length - 1, this.current + WINDOW); k++) {
      for (const i of this.spreads[k]) {
        if (i === BLANK) continue;
        const img = new Image();
        img.src = this.srcOf(i);
        this.preloads.push(img);
      }
    }
    keep.forEach((img) => (img.src = ""));
  }

  /** @param {number} index */
  srcOf(index) {
    const file = this.files[index];
    return hoard.pageSrc(/** @type {HoardItemDetail} */ (this.item).id, file.file_index);
  }

  /** @param {number} index */
  makeImg(index) {
    const img = /** @type {HTMLImageElement} */ (
      hoard.el("img", { src: this.srcOf(index), alt: `第 ${index + 1} 頁`, draggable: "false", class: "cr-page-img" })
    );
    img.dataset.pageImg = "";
    img.addEventListener("load", () => this.learnSize(index, img.naturalWidth, img.naturalHeight));
    return img;
  }

  /** 圖片載入後才知道尺寸的頁：補上，再重排（資料庫量好的尺寸優先）。 @param {number} index @param {number} width @param {number} height */
  learnSize(index, width, height) {
    const p = this.pages[index];
    if (!p || width <= 0 || (p.width === width && p.height === height)) return;
    if (p.width > 0 && p.height > 0 && Math.abs(p.width / p.height - width / height) < 0.01) return;
    this.pages[index] = { width, height };
    cancelAnimationFrame(this.relayoutFrame);
    this.relayoutFrame = requestAnimationFrame(() => this.relayout());
  }

  // ---- 翻頁 ----

  /** @param {number} page */
  setPage(page) {
    this.page = page;
    const previous = this.current;
    this.current = this.spreadOf[page] ?? 0;
    if (this.current !== previous) this.updateWindow();
    this.renderHeader();
    this.renderFooter();
    clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => this.saveProgress(), 500);
  }

  saveProgress() {
    clearTimeout(this.saveTimer);
    this.saveTimer = undefined;
    if (this.id === null || this.pages.length === 0) return;
    // 已經開始讀了：之後重畫（例如重新載入插件）從讀到的地方接著開，不再跳回指定的頁。
    if (opening?.id === this.id) opening = { id: this.id };
    const total = this.pages.length;
    const finished = (this.spreads[this.current] ?? []).includes(total - 1);
    setProgress(this.id, Math.min(this.page, total - 1), total, finished);
  }

  /**
   * @param {number} k
   * @param {boolean} [animate] 翻頁檢視裡往那個方向整頁滑過去（照閱讀方向：漫畫模式的下一頁從左邊進來）；拖滑桿時直接跳
   */
  goToSpread(k, animate = true) {
    if (this.spreads.length === 0 || !this.s) return;
    const last = this.spreads.length - 1;
    if (k > last) {
      this.atEnd = true;
      this.renderEnd();
      return;
    }
    this.atEnd = false;
    k = Math.max(0, k);
    const from = this.current;
    const target = this.spreads[k].find((i) => i !== BLANK) ?? 0;
    // 翻頁檢視：舊的跨頁要帶著圖整個滑出去，別讓 setPage 裡的 updateWindow 把它的圖換回頁碼。
    if (this.s.view === "slide") this.rows = [];
    this.setPage(target);
    if (this.s.view === "scroll") {
      this.rows[k]?.row.scrollIntoView({ block: "start" });
    } else {
      const step = !animate || k === from ? 0 : k > from ? 1 : -1;
      this.renderSlide(/** @type {0 | 1 | -1} */ (this.rtl ? -step : step));
      this.scroller?.scrollTo({ top: 0, left: this.rtl ? this.scroller.scrollWidth : 0 });
    }
    this.renderEnd();
  }

  /** @param {number} page @param {boolean} [animate] */
  goToPage(page, animate = true) {
    this.goToSpread(this.spreadOf[page] ?? 0, animate);
  }
  next() {
    this.goToSpread(this.current + 1);
  }
  prev() {
    this.goToSpread(this.current - 1);
  }

  /** 翻頁檢視裡比畫面高（或寬）的跨頁，先捲完再翻頁。 @param {1 | -1} dir */
  slideStep(dir) {
    const el = this.scroller;
    if (!el) return false;
    const room = dir > 0 ? el.scrollHeight - el.clientHeight - el.scrollTop : el.scrollTop;
    if (room <= 2) return false;
    el.scrollBy({ top: dir * el.clientHeight * 0.8, behavior: "smooth" });
    return true;
  }

  toggleFullscreen() {
    if (document.fullscreenElement) void document.exitFullscreen().catch(() => {});
    else void this.host.requestFullscreen().catch(() => {});
  }

  toggleBookmark() {
    if (this.id === null) return;
    const target = (this.spreads[this.current] ?? []).find((i) => i !== BLANK);
    if (target === undefined) return;
    this.bookmarks = this.bookmarks.includes(target)
      ? this.bookmarks.filter((p) => p !== target)
      : [...this.bookmarks, target].sort((a, b) => a - b);
    if (this.bookmarks.length > 0) store.bookmarks[this.id] = this.bookmarks;
    else delete store.bookmarks[this.id];
    save("bookmarks");
    this.renderHeader();
    if (this.panel === "bookmarks") this.renderPanel();
  }

  // ---- 設定 ----

  /** @param {Partial<Settings>} patch @param {boolean} [redrawPanel] 拖曳滑桿時不重建面板 */
  update(patch, redrawPanel = true) {
    const previous = this.settings;
    this.settings = { ...previous, ...patch };
    this.persist();
    // 在漫畫裡改到所有漫畫的預設很容易是無心的：每次開啟提醒一次，並提供「只套用這本」。
    if (this.scope === "global" && !this.scopeHintShown && this.panel !== "settings") {
      this.scopeHintShown = true;
      this.showScopeHint(previous);
    }
    this.relayout();
    if (this.panel === "settings" && redrawPanel) this.renderPanel();
  }

  persist() {
    clearTimeout(this.persistTimer);
    const id = /** @type {BookId} */ (this.id);
    const scope = this.scope;
    const settings = this.settings;
    this.persistPending = () => {
      this.persistPending = null;
      saveSettings(id, scope, settings);
    };
    this.persistTimer = window.setTimeout(() => this.persistPending?.(), 400);
  }

  /** @param {Scope} next */
  changeScope(next) {
    this.scope = next;
    // 改成跟隨預設：從現在起用預設值。
    if (next === "global") this.settings = { ...DEFAULT_SETTINGS, ...sanitize(store.defaults) };
    this.persist();
    this.relayout();
    this.renderPanel();
  }

  makeDefault() {
    store.defaults = { ...this.settings };
    save("defaults");
  }

  /** @param {Settings} previous */
  showScopeHint(previous) {
    const close = () => {
      clearTimeout(this.hintTimer);
      /** @type {HTMLElement} */ (this.hint).replaceChildren();
    };
    const keep = () => {
      this.scope = "item";
      this.persist();
      store.defaults = previous;
      save("defaults");
      close();
    };
    /** @type {HTMLElement} */ (this.hint).replaceChildren(
      hoard.el(
        "div",
        {
          class: "cr-hint",
          onclick: (e) => e.stopPropagation(),
        },
        [
          "已設為所有漫畫的預設",
          hoard.el("button", { class: "cr-hint-keep", onclick: keep }, ["只套用這本"]),
          hoard.el("button", { class: "cr-close-btn", onclick: close }, [hoard.icon("x", { size: 13 })]),
        ],
      ),
    );
    clearTimeout(this.hintTimer);
    this.hintTimer = window.setTimeout(close, 7000);
  }

  // ---- 畫面上的其他部分 ----

  /** 頁首：左邊是卷名與頁碼，右邊是工具。 */
  renderHeader() {
    const s = this.s;
    const item = this.item;
    if (!s || !item) return;
    const webtoon = s.mode === "webtoon";
    const shown = (this.spreads[this.current] ?? []).filter((i) => i !== BLANK);
    const label = shown.length > 1 ? `${shown[0] + 1}-${shown[shown.length - 1] + 1}` : `${this.page + 1}`;
    const bookmarked = shown.some((p) => this.bookmarks.includes(p));
    const fullscreen = document.fullscreenElement === this.host;
    this.ctx.header.setTitle(item.title);
    this.ctx.header.setCount(`${label} / ${this.pages.length}`);
    this.tools.replaceChildren(
      toolButton(
        s.view === "slide" ? "翻頁（切換為連續捲動）" : "連續捲動（切換為翻頁）",
        hoard.icon(s.view === "slide" ? "gallery-horizontal" : "gallery-vertical", { size: 15 }),
        () => this.update({ view: this.settings.view === "slide" ? "scroll" : "slide" }),
        { disabled: webtoon },
      ),
      toolButton("雙頁 (Ctrl+D)", hoard.icon("columns-2", { size: 15 }), () => this.update({ spread: this.double ? "single" : "double" }), {
        active: this.double,
        disabled: webtoon,
      }),
      toolButton("漫畫模式：右到左 (Ctrl+M)", "RTL", () => this.update({ mode: this.settings.mode === "manga" ? "normal" : "manga" }), {
        active: this.rtl,
        extra: "cr-tool-btn-mono",
      }),
      toolButton("條漫模式 (Ctrl+W)", "條漫", () => this.update({ mode: this.settings.mode === "webtoon" ? "normal" : "webtoon" }), {
        active: webtoon,
        extra: "cr-tool-btn-small",
      }),
      hoard.el("span", { class: "cr-tool-sep" }),
      toolButton("書籤 (B)", hoard.icon(bookmarked ? "bookmark-check" : "bookmark", { size: 15 }), () => this.toggleBookmark(), {
        active: bookmarked,
      }),
      toolButton("書籤列表", hoard.icon("list", { size: 15 }), () => this.togglePanel("bookmarks"), {
        active: this.panel === "bookmarks",
      }),
      toolButton("放大鏡 (G)", hoard.icon("search", { size: 15 }), () => this.toggleMagnifier(), { active: this.magnifier }),
      toolButton("全螢幕 (F11)", hoard.icon(fullscreen ? "minimize" : "maximize", { size: 15 }), () => this.toggleFullscreen(), {
        active: fullscreen,
      }),
      toolButton("閱讀設定", hoard.icon("settings-2", { size: 15 }), () => this.togglePanel("settings"), {
        active: this.panel === "settings",
      }),
    );
  }

  renderFooter() {
    const slider = this.slider;
    if (!slider) return;
    slider.max = String(Math.max(0, this.pages.length - 1));
    slider.style.direction = this.rtl ? "rtl" : "ltr";
    // 進度從原本的位置補間到新的一頁（200ms）；剛建好的滑桿、正在拖的直接放。
    cancelAnimationFrame(this.sliderFrame);
    const to = this.page;
    const from = Number(slider.value);
    const first = slider.dataset.shown === undefined;
    slider.dataset.shown = "";
    if (first || this.scrubbing || from === to || !motionOn()) {
      slider.step = "1";
      slider.value = String(to);
      return;
    }
    slider.step = "any"; // 補間中的值不是整數
    const start = performance.now();
    /** @param {number} now */
    const tick = (now) => {
      const t = Math.min(1, (now - start) / 200);
      if (t < 1) {
        slider.value = String(from + (to - from) * easeOut(t));
        this.sliderFrame = requestAnimationFrame(tick);
      } else {
        slider.step = "1";
        slider.value = String(to);
      }
    };
    this.sliderFrame = requestAnimationFrame(tick);
  }

  /** 讀到最後：翻頁檢視蓋一層，連續捲動放在最下面。 */
  renderEnd() {
    if (!this.s || !this.endOverlay) return;
    const slideEnd = this.atEnd && this.s.view === "slide";
    const host = this.endOverlay;
    const shown = host.querySelector(":scope > .cr-end-overlay:not(.cr-leaving)");
    if (slideEnd && shown?.firstElementChild) {
      // 已經蓋著：只換卡片內容（例如找到下一卷），不重播進場。
      shown.firstElementChild.replaceChildren(this.endCard());
    } else if (slideEnd) {
      const card = hoard.el("div", { onclick: (/** @type {Event} */ e) => e.stopPropagation() }, [this.endCard()]);
      const shade = hoard.el(
        "div",
        {
          class: "cr-end-overlay",
          onclick: () => {
            this.atEnd = false;
            this.renderEnd();
          },
        },
        [card],
      );
      host.replaceChildren(shade);
      // 暗幕淡入 200ms；卡片晚 40ms 從下方 12px 浮上來、淡入 220ms。
      if (motionOn()) {
        shade.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 200, easing: EASE_OUT });
        card.animate([{ opacity: 0, translate: "0 12px" }, { opacity: 1, translate: "0 0" }], { duration: 220, delay: 40, easing: EASE_OUT, fill: "backwards" });
      }
    } else if (shown instanceof HTMLElement) {
      leave(shown, { opacity: "0" }, 150);
    }
    if (this.s.view === "scroll") this.endHost?.replaceChildren(this.endCard());
  }

  endCard() {
    const next = this.nextItem;
    const cover = next ? (next.cover_path ?? next.thumbnail_path) : null;
    /** @type {Array<Node | null>} */
    const body = [hoard.el("p", { class: "cr-end-heading" }, ["已讀完"])];
    if (next) {
      if (cover) body.push(hoard.el("img", { src: hoard.fileSrc(cover), alt: "", class: "cr-end-cover" }));
      body.push(
        hoard.el("p", { class: "cr-end-next" }, [`下一卷：${next.title}`]),
        hoard.el(
          "button",
          {
            class: "cr-end-next-btn",
            onclick: () => {
              opening = { id: next.id };
              void this.open(next.id);
            },
          },
          [hoard.icon("book-open", { size: 15 }), "閱讀下一卷"],
        ),
      );
    } else if (next === null && this.item && seriesOf(this.item)) {
      body.push(hoard.el("p", { class: "cr-end-note" }, ["這是系列的最後一卷。"]));
    }
    body.push(hoard.el("button", { class: "cr-quiet-btn", onclick: () => this.close() }, ["關閉閱讀器"]));
    return hoard.el(
      "div",
      { class: "cr-end-card" },
      body,
    );
  }

  /** @param {"settings" | "bookmarks"} panel */
  togglePanel(panel) {
    this.panel = this.panel === panel ? null : panel;
    this.renderPanel();
    this.renderHeader();
  }

  /**
   * 開、關、更新側邊的面板。打開時從右邊 16px 滑進來並淡入 200ms，關上時滑回去淡出 150ms；
   * 開著時更新內容不重播進場、捲動位置不變，分段鈕的底滑到新的選項。
   */
  renderPanel() {
    const host = this.panelHost;
    if (!host) return;
    const kind = this.panel;
    const open = /** @type {HTMLElement | null} */ (host.querySelector(":scope > aside:not(.cr-leaving)"));
    if (kind && open?.dataset.panel === kind) {
      const fresh = this.buildPanel(kind);
      const marks = marksOf(open);
      const top = open.scrollTop;
      // 還在進場就接著進場。
      for (const a of open.getAnimations()) {
        const effect = /** @type {KeyframeEffect} */ (a.effect);
        const b = fresh.animate(effect.getKeyframes(), effect.getTiming());
        b.currentTime = a.currentTime;
      }
      open.replaceWith(fresh);
      fresh.scrollTop = top;
      placeMarks(fresh, marks);
      return;
    }
    if (open) leave(open, { opacity: "0", translate: "16px 0" }, 150);
    if (!kind) return;
    const fresh = this.buildPanel(kind);
    host.append(fresh);
    placeMarks(fresh);
    if (motionOn()) fresh.animate([{ opacity: 0, translate: "16px 0" }, { opacity: 1, translate: "0 0" }], { duration: 200, easing: EASE_OUT });
  }

  /** @param {"settings" | "bookmarks"} kind */
  buildPanel(kind) {
    const panel = kind === "settings" ? this.settingsPanel() : this.bookmarkPanel();
    panel.dataset.panel = kind;
    return panel;
  }

  bookmarkPanel() {
    return hoard.el(
      "aside",
      {
        class: "cr-bookmarks",
        onclick: (e) => e.stopPropagation(),
      },
      this.bookmarks.length === 0
        ? [hoard.el("div", { class: "hoard-empty cr-bookmarks-empty" }, ["還沒有書籤"])]
        : this.bookmarks.map((p) =>
            hoard.el(
              "button",
              {
                class: "cr-bookmark-item",
                onclick: () => {
                  this.goToPage(p);
                  this.togglePanel("bookmarks");
                },
              },
              [hoard.icon("bookmark", { size: 12, class: "cr-bookmark-icon" }), `第 ${p + 1} 頁`],
            ),
          ),
    );
  }

  /** OpenComic 風格的閱讀設定。 */
  settingsPanel() {
    const s = this.settings;
    const webtoon = s.mode === "webtoon";
    /** @param {string} title @param {Array<Node | null>} children */
    const section = (title, children) =>
      hoard.el("section", { class: "cr-settings-section" }, [
        hoard.el("h4", { class: "cr-settings-label" }, [title]),
        ...children,
      ]);
    /**
     * @template {string} T
     * @param {T} value @param {Array<[T, string]>} options @param {(value: T) => void} onChange @param {boolean} [disabled]
     */
    const segmented = (value, options, onChange, disabled = false) =>
      hoard.el("div", { class: disabled ? "cr-segmented cr-disabled" : "cr-segmented" }, [
        // 選中那格的底：放好之後由 placeMarks 移到選中的那格，換選項時滑過去。
        hoard.el("span", { class: "cr-segment-mark", "aria-hidden": "true" }),
        ...options.map(([key, label]) => {
          /** @type {Record<string, string | ((event: Event) => void)>} */
          const attrs = {
            class: value === key ? "cr-segment cr-active" : "cr-segment",
            onclick: () => onChange(key),
          };
          if (disabled) attrs.disabled = "";
          return hoard.el("button", attrs, [label]);
        }),
      ]);
    /** @param {string} label @param {boolean} checked @param {(value: boolean) => void} onChange @param {boolean} [disabled] */
    const check = (label, checked, onChange, disabled = false) => {
      /** @type {Record<string, string | ((event: Event) => void)>} */
      const attrs = { type: "checkbox", onchange: (e) => onChange(/** @type {HTMLInputElement} */ (e.target).checked) };
      if (checked) attrs.checked = "";
      if (disabled) attrs.disabled = "";
      return hoard.el("label", { class: disabled ? "cr-check cr-disabled" : "cr-check" }, [
        hoard.el("input", attrs),
        label,
      ]);
    };
    /**
     * @param {string} label @param {keyof Settings} key @param {number} min @param {number} max
     * @param {number} [step] @param {string} [unit]
     */
    const slider = (label, key, min, max, step = 1, unit = "") => {
      const value = /** @type {number} */ (s[key]);
      const shown = hoard.el("span", { class: "cr-slider-value" }, [`${value}${unit}`]);
      const input = /** @type {HTMLInputElement} */ (
        hoard.el("input", { type: "range", min: String(min), max: String(max), step: String(step), value: String(value), class: "cr-slider-input" })
      );
      input.addEventListener("input", () => {
        shown.textContent = `${input.value}${unit}`;
        this.update({ [key]: Number(input.value) }, false);
      });
      return hoard.el("label", { class: "cr-slider" }, [
        hoard.el("span", { class: "cr-slider-label" }, [label]),
        input,
        shown,
      ]);
    };
    const link = (/** @type {string} */ label, /** @type {() => void} */ onclick) =>
      hoard.el("button", { class: "cr-link", onclick }, [label]);

    const shortcuts = [
      ["← →", "翻頁（漫畫模式對調）"],
      ["空白鍵", "下一頁／條漫捲 70%"],
      ["Ctrl+M", "漫畫模式"],
      ["Ctrl+W", "條漫模式"],
      ["Ctrl+D", "雙頁"],
      ["G", "放大鏡（滾輪調倍率）"],
      ["B", "書籤"],
      ["F11", "全螢幕"],
      ["Ctrl+滾輪", "縮放；Ctrl+0 還原"],
    ];

    return hoard.el(
      "aside",
      {
        class: "cr-settings",
        onclick: (e) => e.stopPropagation(),
      },
      [
        hoard.el("header", { class: "cr-settings-header" }, [
          hoard.el("h3", { class: "cr-settings-title" }, ["閱讀設定"]),
          hoard.el("button", { class: "cr-close-btn", title: "關閉", onclick: () => this.togglePanel("settings") }, [
            hoard.icon("x", { size: 16 }),
          ]),
        ]),
        section("套用範圍", [
          segmented(
            this.scope,
            [
              ["item", "只套用這本"],
              ["global", "跟隨預設"],
            ],
            (scope) => this.changeScope(scope),
          ),
          hoard.el("p", { class: "cr-settings-note" }, [
            this.scope === "item" ? "變更只記在這本漫畫。" : "變更會成為所有漫畫的預設值（已個別設定的不受影響）。",
          ]),
          this.scope === "item" ? link("把目前設定設為預設", () => this.makeDefault()) : null,
        ]),
        section("內容模式", [
          segmented(
            s.mode,
            [
              ["normal", "一般"],
              ["manga", "漫畫（右到左）"],
              ["webtoon", "條漫"],
            ],
            (mode) => this.update({ mode }),
          ),
        ]),
        section("檢視", [
          segmented(
            webtoon ? "scroll" : s.view,
            [
              ["slide", "翻頁"],
              ["scroll", "連續捲動"],
            ],
            (view) => this.update({ view }),
            webtoon,
          ),
        ]),
        section("雙頁", [
          segmented(
            webtoon ? "single" : s.spread,
            [
              ["single", "單頁"],
              ["double", "雙頁"],
              ["auto", "自動"],
            ],
            (spread) => this.update({ spread }),
            webtoon,
          ),
          check("封面單獨（開頭補空白頁）", s.coverAlone, (coverAlone) => this.update({ coverAlone }), webtoon || s.spread === "single"),
          check(
            "橫向頁自己佔一個跨頁",
            s.landscapeAlone,
            (landscapeAlone) => this.update({ landscapeAlone }),
            webtoon || s.spread === "single",
          ),
        ]),
        section("縮放", [
          segmented(
            webtoon ? "width" : s.fit,
            [
              ["height", "符合高度"],
              ["width", "符合寬度"],
              ["original", "原始大小"],
            ],
            (fit) => this.update({ fit }),
            webtoon,
          ),
          hoard.el("p", { class: "cr-zoom-info" }, [
            `目前 ${Math.round(this.zoom * 100)}%（Ctrl＋滾輪）`,
            this.zoom !== 1
              ? hoard.el("button", { class: "cr-zoom-reset", onclick: () => this.setZoom(1) }, ["還原"])
              : null,
          ]),
        ]),
        section("版面", [
          slider("左右邊距", "marginX", 0, 400, 8, "px"),
          slider("上下邊距", "marginY", 0, 200, 4, "px"),
          slider("裁上", "cropTop", 0, 20, 0.5, "%"),
          slider("裁下", "cropBottom", 0, 20, 0.5, "%"),
          slider("裁左", "cropLeft", 0, 20, 0.5, "%"),
          slider("裁右", "cropRight", 0, 20, 0.5, "%"),
        ]),
        section("濾鏡", [
          slider("亮度", "brightness", 30, 170, 1, "%"),
          slider("對比", "contrast", 30, 170, 1, "%"),
          slider("飽和度", "saturate", 0, 200, 1, "%"),
          slider("懷舊", "sepia", 0, 100, 1, "%"),
          check("負片（反相）", s.invert, (invert) => this.update({ invert })),
          link("還原濾鏡", () =>
            this.update({
              brightness: DEFAULT_SETTINGS.brightness,
              contrast: DEFAULT_SETTINGS.contrast,
              saturate: DEFAULT_SETTINGS.saturate,
              sepia: DEFAULT_SETTINGS.sepia,
              invert: DEFAULT_SETTINGS.invert,
            }),
          ),
        ]),
        section("快捷鍵", [
          hoard.el(
            "dl",
            { class: "cr-shortcuts" },
            shortcuts.flatMap(([key, label]) => [
              hoard.el("dt", { class: "cr-shortcut-key" }, [key]),
              hoard.el("dd", { class: "cr-shortcut-desc" }, [label]),
            ]),
          ),
        ]),
      ],
    );
  }

  /** @param {number} zoom */
  setZoom(zoom) {
    this.zoom = clamp(zoom, ZOOM_MIN, ZOOM_MAX);
    this.sizeRows();
    if (this.panel === "settings") this.renderPanel();
  }

  toggleMagnifier() {
    this.magnifier = !this.magnifier;
    if (this.stage) this.stage.style.cursor = this.magnifier ? "none" : "";
    if (!this.magnifier) this.lens?.classList.add("cr-lens-hidden");
    this.renderHeader();
  }

  /** OpenComic 風格的放大鏡（G）：滑鼠底下那頁的放大圓鏡。 @param {MouseEvent} e */
  moveLens(e) {
    const lens = this.lens;
    if (!this.magnifier || !lens) return;
    const hit = document.elementFromPoint(e.clientX, e.clientY);
    if (!(hit instanceof HTMLImageElement) || hit.dataset.pageImg === undefined || !this.host.contains(hit)) {
      lens.classList.add("cr-lens-hidden");
      return;
    }
    const LENS = 260;
    const rect = hit.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const ratio = this.magnifierRatio;
    lens.classList.remove("cr-lens-hidden");
    Object.assign(lens.style, {
      left: `${e.clientX - LENS / 2}px`,
      top: `${e.clientY - LENS / 2}px`,
      backgroundImage: `url("${hit.currentSrc || hit.src}")`,
      backgroundSize: `${rect.width * ratio}px ${rect.height * ratio}px`,
      backgroundPosition: `${-(x * ratio - LENS / 2)}px ${-(y * ratio - LENS / 2)}px`,
      filter: this.s ? filterCss(this.s) : "",
    });
  }

  // ---- 輸入 ----

  /** @param {MouseEvent} e */
  onStageClick(e) {
    if (this.swallowClick) {
      this.swallowClick = false;
      return;
    }
    if (this.panel) {
      this.panel = null;
      this.renderPanel();
      this.renderHeader();
      return;
    }
    const rect = /** @type {HTMLElement} */ (this.stage).getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    if (this.s?.view === "slide" && x < 1 / 3) return this.rtl ? this.next() : this.prev();
    if (this.s?.view === "slide" && x > 2 / 3) return this.rtl ? this.prev() : this.next();
  }

  /** 觸控左右滑翻頁：往左滑看右邊那頁。 @param {PointerEvent} e */
  onSwipeEnd(e) {
    const start = this.swipe;
    this.swipe = null;
    if (!start || this.s?.view !== "slide") return;
    const dx = e.clientX - start.x;
    const dy = e.clientY - start.y;
    if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(dy) * 1.5) return;
    this.swallowClick = true;
    if (dx < 0 !== this.rtl) this.next();
    else this.prev();
  }

  /** Ctrl 縮放、放大鏡調倍率、翻頁檢視用滾輪翻頁。 @param {WheelEvent} e */
  onWheel(e) {
    if (/** @type {Element} */ (e.target).closest("aside")) return;
    if (e.ctrlKey) {
      e.preventDefault();
      this.setZoom(this.zoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1));
      return;
    }
    if (this.magnifier) {
      e.preventDefault();
      this.magnifierRatio = clamp(this.magnifierRatio + (e.deltaY < 0 ? 0.25 : -0.25), 1.5, 8);
      this.moveLens(e);
      return;
    }
    if (this.s?.view !== "slide") return;
    const el = this.scroller;
    const dir = e.deltaY > 0 ? 1 : -1;
    const room = el ? (dir > 0 ? el.scrollHeight - el.clientHeight - el.scrollTop : el.scrollTop) : 0;
    if (room > 2) return; // 高的頁先捲
    e.preventDefault();
    const now = Date.now();
    if (now - this.wheelLock < 350) return;
    this.wheelLock = now;
    if (dir > 0) this.next();
    else this.prev();
  }

  /** @param {KeyboardEvent} e */
  onKey(e) {
    const s = this.s;
    if (!s || e.isComposing) return;
    const typing = isTyping(e.target);
    // 別的地方（指令面板、對話框）在打字時不攔。
    if (typing && !this.host.contains(/** @type {Node} */ (e.target))) return;
    const handled = () => {
      e.preventDefault();
      e.stopPropagation();
    };
    if (e.key === "Escape") {
      handled();
      if (this.panel) this.togglePanel(this.panel);
      else if (document.fullscreenElement) this.toggleFullscreen();
      else this.close();
      return;
    }
    if (typing) return;
    const ctrl = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();
    if (ctrl && key === "m") return handled(), this.update({ mode: this.settings.mode === "manga" ? "normal" : "manga" });
    if (ctrl && key === "w") return handled(), this.update({ mode: this.settings.mode === "webtoon" ? "normal" : "webtoon" });
    if (ctrl && key === "d") return handled(), this.update({ spread: this.double ? "single" : "double" });
    if (ctrl && (key === "0" || key === "=" || key === "+" || key === "-")) {
      handled();
      this.setZoom(key === "0" ? 1 : this.zoom * (key === "-" ? 1 / 1.15 : 1.15));
      return;
    }
    if (ctrl || e.altKey) return;
    if (key === "g") return handled(), this.toggleMagnifier();
    if (key === "b") return handled(), this.toggleBookmark();
    if (e.key === "F11") return handled(), this.toggleFullscreen();
    if (e.key === "Home") return handled(), this.goToSpread(0);
    if (e.key === "End") return handled(), this.goToSpread(this.spreads.length - 1);

    if (s.view === "scroll") {
      const el = this.scroller;
      if (el && (e.key === " " || e.key === "PageDown" || e.key === "PageUp")) {
        handled();
        const back = e.key === "PageUp" || (e.key === " " && e.shiftKey);
        el.scrollBy({ top: (back ? -1 : 1) * el.clientHeight * 0.7, behavior: "smooth" });
      }
      return;
    }
    const forward = e.key === "ArrowRight" ? !this.rtl : e.key === "ArrowLeft" ? this.rtl : null;
    if (forward !== null) return handled(), forward ? this.next() : this.prev();
    if (e.key === "ArrowDown" || e.key === "PageDown" || (e.key === " " && !e.shiftKey)) {
      handled();
      if (!this.slideStep(1)) this.next();
    } else if (e.key === "ArrowUp" || e.key === "PageUp" || (e.key === " " && e.shiftKey)) {
      handled();
      if (!this.slideStep(-1)) this.prev();
    }
  }
}

hoard.registerView({
  id: "reader",
  label: "閱讀器",
  icon: "book-open",
  hidden: true,
  render(el, ctx) {
    const reader = new Reader(el, ctx);
    if (opening) void reader.open(opening.id, opening.page);
    else reader.message("沒有開啟中的作品。", true);
    return () => reader.destroy();
  },
});

// ---- 漫畫詳情頁 ----

/** 壓縮檔格式照原樣顯示，只有資料夾要翻。 */
const FORMAT_LABELS = /** @type {Record<string, string>} */ ({ folder: "圖片資料夾" });

/** 詳情頁按鈕。 @param {string} cls @param {Array<Node | string>} children @param {() => void} onclick */
const detailButton = (cls, children, onclick) => hoard.el("button", { class: cls, onclick }, children);

/**
 * 本機漫畫的詳情頁：封面與檔案資訊、開始／繼續閱讀、從頭讀、標為已讀、書籤、下一卷，
 * 下面是所有頁的縮圖（點了從那頁開始讀），「編輯頁面」在這裡排序、移出（pageEditor）。
 * @param {HTMLElement} root @param {HoardItemDetail} item @param {HoardRenderCtx} ctx
 */
function renderComicDetail(root, item, ctx) {
  let alive = true;
  /** 編輯頁面中：頁面那一塊歸它。 @type {{ destroy(): void } | null} */
  let editor = null;
  const pages = item.files.filter((f) => f.kind === "image");
  const pageCount = pages.length;
  const cover = item.cover_path ?? item.thumbnail_path;
  const coverImg = hoard.el("img", {
    src: cover ? hoard.fileSrc(cover) : pages[0] ? hoard.pageSrc(item.id, pages[0].file_index) : "",
    alt: item.title,
    class: "cr-detail-cover",
  });
  const format = String(item.metadata.format ?? "folder");
  const series = seriesOf(item);
  const volume = volumeOf(item);
  const path = String(item.metadata.folder_path ?? item.metadata.file_path ?? "");
  // 資訊欄：上面每次重畫；「下一卷」晚到（要找同系列的其他卷），自己一格，找到時淡入、下面的路徑跟著滑。
  const body = hoard.el("div", { class: "cr-detail-body" });
  const nextSlot = hoard.el("div", { class: "cr-detail-next-slot" });
  const info = hoard.el("div", { class: "cr-detail-info" }, [body, nextSlot, hoard.el("p", { class: "cr-detail-path" }, [path])]);
  const thumbs = hoard.el("section", { class: "cr-detail-pages" });
  root.append(
    hoard.el("div", { class: "cr-detail" }, [
      hoard.el("div", { class: "cr-detail-top" }, [cover || pages.length > 0 ? coverImg : null, info]),
      thumbs,
    ]),
  );

  const draw = () => {
    if (!alive) return;
    const progress = store.progress[item.id];
    const finished = Boolean(progress?.finished);
    const bookmarks = store.bookmarks[item.id] ?? [];
    const facts = [FORMAT_LABELS[format] ?? format.toUpperCase(), `${pageCount} 頁`];
    if (series) facts.push(series);
    if (volume !== null) facts.push(`第 ${volume} 卷`);

    /** @type {Array<Node | null>} */
    const actions = [
      detailButton(
        "cr-detail-read-btn",
        [hoard.icon("book-open", { size: 16 }), progress && !finished ? `繼續閱讀（第 ${progress.position + 1} 頁）` : "開始閱讀"],
        () => openReader(item.id, finished ? 0 : undefined),
      ),
      progress ? detailButton("cr-quiet-btn", ["從頭閱讀"], () => openReader(item.id, 0)) : null,
      detailButton(
        finished ? "cr-detail-finish-btn cr-done" : "cr-detail-finish-btn",
        [hoard.icon("check", { size: 13 }), finished ? "已讀完" : "標為已讀"],
        () => {
          setFinished(item.id, !finished, pageCount);
          draw();
        },
      ),
    ];

    /** @type {Array<Node | null>} */
    const lines = [
      hoard.el("p", { class: "cr-detail-facts" }, [facts.join(" · ")]),
      hoard.el("div", { class: "cr-detail-actions" }, actions),
      bookmarks.length > 0
        ? hoard.el(
            "div",
            { class: "cr-detail-bookmarks" },
            bookmarks.map((page) =>
              detailButton(
                "cr-detail-bookmark",
                [hoard.icon("bookmark", { size: 11 }), `p.${page + 1}`],
                () => openReader(item.id, page),
              ),
            ),
          )
        : null,
    ];
    body.replaceChildren(.../** @type {Node[]} */ (lines.filter(Boolean)));

    if (editor) return;
    if (pages.length === 0) {
      thumbs.replaceChildren();
      return;
    }
    const current = progress && !finished ? progress.position : -1;
    thumbs.replaceChildren(
      hoard.el("div", { class: "cr-detail-pages-head" }, [
        hoard.el("h3", { class: "cr-detail-pages-title" }, [`全部頁面（${pages.length}）`]),
        detailButton("cr-pages-edit-btn", [hoard.icon("pencil", { size: 12 }), "編輯頁面"], () => {
          editor = pageEditor(item, thumbs, coverImg, () => {
            editor = null;
            draw();
            fadeIn(thumbs);
          });
        }),
      ]),
      hoard.el(
        "div",
        { class: "cr-thumb-grid", style: "grid-template-columns: repeat(auto-fill, minmax(110px, 1fr))" },
        pages.map((file, index) =>
          hoard.el(
            "button",
            {
              class: "cr-thumb-btn",
              title: `從第 ${index + 1} 頁開始讀`,
              onclick: () => openReader(item.id, index),
            },
            [
              hoard.el(
                "span",
                {
                  class: index === current ? "cr-thumb cr-current" : "cr-thumb",
                },
                [
                  hoard.el("img", {
                    src: hoard.pageSrc(item.id, file.file_index),
                    alt: `第 ${index + 1} 頁`,
                    loading: "lazy",
                    draggable: "false",
                    class: "cr-thumb-img",
                  }),
                  bookmarks.includes(index)
                    ? hoard.el("span", { class: "cr-thumb-bookmark" }, [hoard.icon("bookmark", { size: 13, class: "cr-thumb-bookmark-icon" })])
                    : null,
                ],
              ),
              hoard.el("span", { class: "cr-thumb-num" }, [String(index + 1)]),
            ],
          ),
        ),
      ),
    );
  };

  // 頁序變了（編輯之後、Ctrl+Z 復原）：進度與書籤先換算過來再畫。
  const sync = () => syncPageOrder(item.id, pages.map((f) => f.file_index));
  if (loaded) sync();
  draw();
  if (!loaded) {
    void loadStore().then(() => {
      sync();
      draw();
    });
  }
  // 有系列才可能有下一卷：找的時候先放一條骨架佔位置（等 200ms 才出現）。
  const since = performance.now();
  if (series) nextSlot.append(hoard.el("div", { class: "cr-detail-next-skeleton", "aria-hidden": "true" }));
  void nextVolume(item).then((found) => {
    if (!alive || !series) return;
    settle(
      nextSlot,
      found
        ? [detailButton("cr-detail-next", ["下一卷：", hoard.el("span", { class: "cr-detail-next-title" }, [found.title])], () => ctx.openItem(found.id))]
        : [],
      since,
    );
  });
  return () => {
    alive = false;
    editor?.destroy();
  };
}

/** 換了內容的一塊淡入。 @param {HTMLElement} el */
function fadeIn(el) {
  if (motionOn()) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 160, easing: EASE_OUT });
}

/** 兩個 file_index 清單一樣。 @param {number[]} a @param {number[]} b */
const sameList = (a, b) => a.length === b.length && a.every((value, i) => value === b[i]);

/**
 * 詳情頁的「編輯頁面」：點頁選取（Shift 連選、Ctrl+A 全選），拖曳排序，移出這一本（「移出」、Delete，或拖到「已移出」），
 * 從「已移出」放回（「放回」或拖回去），選一頁「設為封面」（上面的封面先換給你看）；Ctrl+Z 退一步，Esc 或「取消」放棄（改過的先問）。
 * 按「完成」才一次存進核心（hoard.items.setCover、setPages：頁的變更 App 跳出「復原」，也能 Ctrl+Z），之後整頁照新的作品重畫。
 * 縮圖換位置一律從原處滑過去（FLIP），移出的飛進「已移出」，放下的從拖著的那張落下。
 * @param {HoardItemDetail} item @param {HTMLElement} host 頁面那一塊 @param {HTMLElement} coverImg 詳情頁上方的封面
 * @param {() => void} close 結束編輯（放棄或沒改）
 */
function pageEditor(item, host, coverImg, close) {
  const original = item.files.filter((f) => f.kind === "image").map((f) => f.file_index);
  // 不是圖片的檔案不在這裡編輯，照原樣留在最後。
  const others = item.files.filter((f) => f.kind !== "image").map((f) => f.file_index);
  let order = [...original];
  let out = item.removed_files.filter((f) => f.kind === "image").map((f) => f.file_index);
  /** @type {Set<number>} */
  let selected = new Set();
  /** @type {number | null} */
  let anchor = null;
  /** 選來當封面的頁（「完成」才換）；null 是不換。 @type {number | null} */
  let cover = null;
  const coverSrc = coverImg.getAttribute("src") ?? "";
  /** @type {Array<{ order: number[]; out: number[]; cover: number | null }>} */
  const history = [];
  let saving = false;
  let alive = true;
  const changed = () => !sameList(order, original) || cover !== null;

  /** 每一頁一個格子，在兩個格線之間搬來搬去（同一個元素，圖不重新載入）。 @type {Map<number, HTMLElement>} */
  const tiles = new Map();
  /** @param {number} page */
  const tileOf = (page) => {
    let tile = tiles.get(page);
    if (!tile) {
      tile = hoard.el("div", { class: "cr-edit-tile", "data-page": String(page) }, [
        hoard.el("span", { class: "cr-thumb" }, [
          hoard.el("img", { src: hoard.pageSrc(item.id, page), alt: "", loading: "lazy", draggable: "false", class: "cr-thumb-img" }),
          hoard.el("span", { class: "cr-edit-check" }, [hoard.icon("check", { size: 12 })]),
          hoard.el("span", { class: "cr-edit-cover-badge" }, [hoard.icon("image", { size: 11 }), "封面"]),
        ]),
        hoard.el("span", { class: "cr-thumb-num" }),
      ]);
      tiles.set(page, tile);
    }
    return tile;
  };

  const title = hoard.el("h3", { class: "cr-detail-pages-title" });
  /** @param {string} icon @param {string} label @param {() => void} onclick @param {string} [cls] @returns {HTMLButtonElement} */
  const button = (icon, label, onclick, cls = "") =>
    /** @type {HTMLButtonElement} */ (
      hoard.el("button", { class: `hoard-button ${cls}`, type: "button", onclick }, [hoard.icon(icon, { size: 13 }), label])
    );
  const takeOutBtn = button("arrow-down-to-line", "移出", () => takeOut());
  const putBackBtn = button("arrow-up-from-line", "放回", () => putBack());
  const coverBtn = button("image", "設為封面", () => chooseCover());
  const doneBtn = button("check", "完成", () => void finish(), "cr-edit-done");
  const columns = "grid-template-columns: repeat(auto-fill, minmax(110px, 1fr))";
  const marker = hoard.el("div", { class: "cr-edit-marker", "aria-hidden": "true" });
  const grid = hoard.el("div", { class: "cr-thumb-grid cr-edit-grid", style: columns });
  const trayTitle = hoard.el("h3", { class: "cr-detail-pages-title" });
  const trayGrid = hoard.el("div", { class: "cr-thumb-grid cr-edit-tray-grid", style: "grid-template-columns: repeat(auto-fill, minmax(80px, 1fr))" });
  const tray = hoard.el("div", { class: "cr-edit-tray" }, [trayTitle, trayGrid]);
  host.replaceChildren(
    hoard.el("div", { class: "cr-detail-pages-head" }, [
      title,
      hoard.el("div", { class: "cr-edit-actions" }, [coverBtn, takeOutBtn, putBackBtn, button("x", "取消", () => void cancel()), doneBtn]),
    ]),
    grid,
    tray,
  );
  fadeIn(host);

  /**
   * 量下每個格子現在的位置；回傳的函式在換好位置之後，讓它們從原處滑過去。
   * `from` 指定某些格子的起點（放下時從拖著的那張落下）。
   * @param {Map<HTMLElement, DOMRect>} [from]
   */
  const flip = (from) => {
    if (!motionOn()) return () => {};
    /** @type {Map<HTMLElement, DOMRect>} */
    const before = new Map();
    for (const tile of tiles.values()) if (tile.isConnected) before.set(tile, from?.get(tile) ?? tile.getBoundingClientRect());
    return () => {
      const height = innerHeight;
      for (const [tile, was] of before) {
        for (const a of tile.getAnimations()) a.cancel();
        const now = tile.getBoundingClientRect();
        // 前後都在畫面外的不用動。
        if ((was.bottom < 0 || was.top > height) && (now.bottom < 0 || now.top > height)) continue;
        const dx = was.left - now.left;
        const dy = was.top - now.top;
        const scale = now.width > 0 ? was.width / now.width : 1;
        if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5 && Math.abs(scale - 1) < 0.01) continue;
        tile.animate(
          [
            { transformOrigin: "0 0", transform: `translate(${dx}px, ${dy}px) scale(${scale})` },
            { transformOrigin: "0 0", transform: "none" },
          ],
          { duration: 240, easing: EASE_OUT },
        );
      }
    };
  };

  /** 照 order／out／selected 排好格子與按鈕。 @param {boolean} [animate] @param {Map<HTMLElement, DOMRect>} [from] */
  const render = (animate = false, from) => {
    const settle = animate ? flip(from) : () => {};
    grid.replaceChildren(...order.map(tileOf), marker);
    trayGrid.replaceChildren(...out.map(tileOf));
    order.forEach((page, i) => {
      const tile = tileOf(page);
      tile.classList.remove("cr-edit-out");
      /** @type {HTMLElement} */ (tile.lastElementChild).textContent = String(i + 1);
    });
    for (const page of out) {
      const tile = tileOf(page);
      tile.classList.add("cr-edit-out");
      /** @type {HTMLElement} */ (tile.lastElementChild).textContent = "";
    }
    for (const [page, tile] of tiles) {
      tile.toggleAttribute("data-selected", selected.has(page));
      tile.toggleAttribute("data-cover", page === cover);
    }
    showCover();
    const picked = order.filter((page) => selected.has(page)).length;
    const pickedOut = out.filter((page) => selected.has(page)).length;
    title.textContent = selected.size > 0 ? `已選 ${selected.size} 頁` : `編輯頁面（${order.length} 頁）`;
    trayTitle.textContent = `已移出（${out.length}）`;
    takeOutBtn.disabled = picked === 0 || picked >= order.length;
    putBackBtn.disabled = pickedOut === 0;
    coverBtn.disabled = !(selected.size === 1 && picked === 1 && !selected.has(/** @type {number} */ (cover)));
    settle();
  };

  /** 上面的封面先換成選的那頁（放棄時換回來），換的時候淡入。 */
  const showCover = () => {
    const src = cover === null ? coverSrc : hoard.pageSrc(item.id, cover);
    if (coverImg.getAttribute("src") === src) return;
    coverImg.setAttribute("src", src);
    fadeIn(coverImg);
  };

  /** 選的那一頁當封面。 */
  const chooseCover = () => {
    const page = order.find((other) => selected.has(other));
    if (page === undefined || selected.size !== 1 || page === cover) return;
    commit(() => {
      cover = page;
    });
  };

  /** 改一步（記下來給 Ctrl+Z），然後滑到新位置。 @param {() => void} change @param {Map<HTMLElement, DOMRect>} [from] */
  const commit = (change, from) => {
    history.push({ order: [...order], out: [...out], cover });
    change();
    render(true, from);
  };

  /** 拿掉 `pages`、照 file_index 排進「已移出」；至少要留下一頁。 @param {number[]} pages @param {Map<HTMLElement, DOMRect>} [from] */
  const moveOut = (pages, from) => {
    const leaving = new Set(pages.filter((page) => order.includes(page)));
    if (leaving.size === 0) return;
    if (leaving.size >= order.length) return void hoard.toast("至少要留下一頁", { kind: "info" });
    commit(() => {
      order = order.filter((page) => !leaving.has(page));
      out = [...out, ...leaving].sort((a, b) => a - b);
      for (const page of leaving) selected.delete(page);
      // 移出這一本的頁不當封面。
      if (cover !== null && leaving.has(cover)) cover = null;
    }, from);
  };
  const takeOut = () => moveOut(order.filter((page) => selected.has(page)));

  /** 「已移出」裡選的放回去：排在原本在它前面、還在的那一頁後面。 */
  const putBack = () => {
    const back = out.filter((page) => selected.has(page));
    if (back.length === 0) return;
    commit(() => {
      out = out.filter((page) => !selected.has(page));
      for (const page of back) {
        const before = order.filter((other) => other < page);
        const at = before.length === 0 ? 0 : order.indexOf(Math.max(...before)) + 1;
        order.splice(at, 0, page);
      }
    });
  };

  const stepBack = () => {
    const last = history.pop();
    if (!last) return;
    order = last.order;
    out = last.out;
    cover = last.cover;
    for (const page of [...selected]) if (!order.includes(page) && !out.includes(page)) selected.delete(page);
    render(true);
  };

  const leave = () => {
    if (!alive) return;
    destroy();
    close();
  };

  const cancel = async () => {
    if (saving) return;
    if (changed() && !(await hoard.confirm("放棄這次對頁面的變更？", { confirmLabel: "放棄", danger: true }))) return;
    cover = null;
    showCover();
    leave();
  };

  const finish = async () => {
    if (saving) return;
    if (!changed()) return leave();
    saving = true;
    doneBtn.disabled = true;
    try {
      // 封面先換：頁的變更最後存，它的「復原」留在最上面。
      if (cover !== null) await setCover(item, cover, coverImg);
      if (!sameList(order, original)) {
        // 進度與書籤從現在的頁序換算過去（syncPageOrder）；重畫可能先到，換算只會做一次。
        store.pageOrder[item.id] = original;
        await hoard.items.setPages(item.id, [...order, ...others]);
        syncPageOrder(item.id, order);
      }
      // 存好後 App 會帶著新的作品重畫整頁；萬一沒有，自己收起來。
      leave();
    } catch (err) {
      saving = false;
      doneBtn.disabled = false;
      hoard.toast(`無法儲存頁面：${err}`, { kind: "error" });
    }
  };

  // ---- 點選與拖曳（pointer 事件：WebView 接了檔案拖放，HTML5 拖放不能用） ----

  /** @type {{ x: number; y: number; page: number; shift: boolean } | null} */
  let press = null;
  /** @type {{ moving: number[]; ghost: HTMLElement; dx: number; dy: number; target: { at: number } | "out" | null } | null} */
  let drag = null;
  let pointer = { x: 0, y: 0 };
  let frame = 0;
  const scroller = (() => {
    for (let el = host.parentElement; el; el = el.parentElement) {
      const overflow = getComputedStyle(el).overflowY;
      if (overflow === "auto" || overflow === "scroll") return el;
    }
    return /** @type {HTMLElement} */ (document.scrollingElement ?? document.documentElement);
  })();

  /** @param {DOMRect} r @param {number} x @param {number} y @param {number} [pad] */
  const inside = (r, x, y, pad = 0) => x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad;

  /** 拖著的頁會放到哪裡：「已移出」，或排在格線的第幾個（不算拖著的）。 */
  const aim = () => {
    if (!drag) return;
    const { x, y } = pointer;
    const moving = new Set(drag.moving);
    const overTray = inside(tray.getBoundingClientRect(), x, y) && drag.moving.some((page) => order.includes(page));
    tray.classList.toggle("cr-edit-over", overTray);
    if (overTray) {
      drag.target = "out";
      marker.removeAttribute("data-on");
      return;
    }
    const box = grid.getBoundingClientRect();
    if (!inside(box, x, y, 48)) {
      drag.target = null;
      marker.removeAttribute("data-on");
      return;
    }
    const rest = order.filter((page) => !moving.has(page));
    let at = rest.length;
    for (let i = 0; i < rest.length; i++) {
      const r = tileOf(rest[i]).getBoundingClientRect();
      if (y < r.top || (y <= r.bottom && x < r.left + r.width / 2)) {
        at = i;
        break;
      }
    }
    drag.target = { at };
    const gap = parseFloat(getComputedStyle(grid).columnGap) || 0;
    const ref = rest[at] ?? rest[rest.length - 1];
    const r = ref === undefined ? null : tileOf(ref).querySelector(".cr-thumb")?.getBoundingClientRect();
    if (!r) {
      marker.style.transform = "translate(0px, 0px)";
      marker.style.height = "8rem";
    } else {
      const left = at < rest.length ? r.left - gap / 2 : r.right + gap / 2;
      marker.style.transform = `translate(${left - box.left - 1.5}px, ${r.top - box.top}px)`;
      marker.style.height = `${r.height}px`;
    }
    marker.setAttribute("data-on", "");
  };

  /** 拖到捲動區的上下緣就捲過去。 */
  const scrollTick = () => {
    if (!drag) return;
    const box = scroller === document.scrollingElement ? { top: 0, bottom: innerHeight } : scroller.getBoundingClientRect();
    const edge = 64;
    const step =
      pointer.y < box.top + edge
        ? -Math.ceil((box.top + edge - pointer.y) / 4)
        : pointer.y > box.bottom - edge
          ? Math.ceil((pointer.y - (box.bottom - edge)) / 4)
          : 0;
    if (step !== 0) {
      scroller.scrollTop += step;
      aim();
    }
    frame = requestAnimationFrame(scrollTick);
  };

  const lift = () => {
    if (!press) return;
    const page = press.page;
    if (!selected.has(page)) {
      selected = new Set([page]);
      anchor = page;
      render();
    }
    const moving = [...order, ...out].filter((other) => selected.has(other));
    const face = /** @type {HTMLElement} */ (tileOf(page).querySelector(".cr-thumb"));
    const r = face.getBoundingClientRect();
    const ghost = hoard.el("div", { class: "cr-edit-ghost", style: `width: ${r.width}px; height: ${r.height}px` }, [
      hoard.el("img", { src: hoard.pageSrc(item.id, page), alt: "", draggable: "false" }),
      moving.length > 1 ? hoard.el("span", { class: "cr-edit-ghost-count" }, [String(moving.length)]) : null,
    ]);
    document.body.append(ghost);
    drag = { moving, ghost, dx: press.x - r.left, dy: press.y - r.top, target: null };
    for (const other of moving) tileOf(other).classList.add("cr-edit-lifted");
    follow();
    if (motionOn()) ghost.firstElementChild?.animate([{ scale: 1 }, { scale: 1.05 }], { duration: 140, easing: EASE_OUT, fill: "forwards" });
    frame = requestAnimationFrame(scrollTick);
  };

  const follow = () => {
    if (drag) drag.ghost.style.transform = `translate(${pointer.x - drag.dx}px, ${pointer.y - drag.dy}px)`;
  };

  /** 放下：照目標搬過去，搬的頁從拖著的那張落下；沒有目標就滑回原處。 */
  const drop = () => {
    if (!drag) return;
    const { moving, ghost, target } = drag;
    drag = null;
    cancelAnimationFrame(frame);
    marker.removeAttribute("data-on");
    tray.classList.remove("cr-edit-over");
    for (const page of moving) tileOf(page).classList.remove("cr-edit-lifted");
    const landing = ghost.getBoundingClientRect();
    ghost.remove();
    /** @type {Map<HTMLElement, DOMRect>} */
    const from = new Map(moving.map((page) => [tileOf(page), landing]));
    if (target === "out") return moveOut(moving, from);
    if (!target) return render(true, from);
    const leaving = new Set(moving);
    const next = order.filter((page) => !leaving.has(page));
    next.splice(target.at, 0, ...moving);
    if (sameList(next, order)) return render(true, from);
    commit(() => {
      order = next;
      out = out.filter((page) => !leaving.has(page));
    }, from);
  };

  /** 沒拖動就是點：切換這頁的選取，Shift 從上一次點的連選過來。 @param {{ page: number; shift: boolean }} at */
  const pick = ({ page, shift }) => {
    const list = out.includes(page) ? out : order;
    if (shift && anchor !== null && list.includes(anchor)) {
      const [a, b] = [list.indexOf(anchor), list.indexOf(page)].sort((m, n) => m - n);
      for (const other of list.slice(a, b + 1)) selected.add(other);
    } else {
      if (selected.has(page)) selected.delete(page);
      else selected.add(page);
      anchor = page;
    }
    render();
  };

  /** @param {PointerEvent} e */
  const onMove = (e) => {
    pointer = { x: e.clientX, y: e.clientY };
    if (!drag && press && Math.hypot(e.clientX - press.x, e.clientY - press.y) > 5) lift();
    if (drag) {
      follow();
      aim();
    }
  };
  /** @param {PointerEvent} e */
  const onUp = (e) => {
    stopTracking();
    pointer = { x: e.clientX, y: e.clientY };
    if (drag) drop();
    else if (press) pick(press);
    press = null;
  };
  const onCancelPointer = () => {
    stopTracking();
    press = null;
    if (drag) {
      drag.target = null;
      drop();
    }
  };
  const stopTracking = () => {
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    window.removeEventListener("pointercancel", onCancelPointer);
  };
  /** @param {PointerEvent} e */
  const onDown = (e) => {
    if (e.button !== 0 || saving || drag) return;
    const tile = /** @type {Element} */ (e.target).closest?.(".cr-edit-tile");
    if (!(tile instanceof HTMLElement) || !host.contains(tile)) return;
    e.preventDefault();
    press = { x: e.clientX, y: e.clientY, page: Number(tile.dataset.page), shift: e.shiftKey };
    pointer = { x: e.clientX, y: e.clientY };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onCancelPointer);
  };
  host.addEventListener("pointerdown", onDown);

  // 編輯中的按鍵先到這裡：Delete、Ctrl+A、Ctrl+Z、Esc 是編輯的，不交給 App（不會把整本丟進垃圾桶或離開詳情頁）。
  /** @param {KeyboardEvent} e */
  const onKey = (e) => {
    if (e.isComposing) return;
    const target = e.target instanceof Element ? e.target : null;
    if (target?.closest('[role="dialog"], input, textarea, select, [contenteditable="true"]')) return;
    const mod = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();
    /** @param {() => void} run */
    const take = (run) => {
      e.preventDefault();
      e.stopPropagation();
      run();
    };
    if (e.key === "Escape") take(() => (drag ? onCancelPointer() : void cancel()));
    else if (e.key === "Delete" || e.key === "Backspace") take(takeOut);
    else if (mod && key === "a") {
      take(() => {
        selected = new Set(order);
        render();
      });
    } else if (mod && (key === "z" || key === "y")) take(() => (key === "z" && !e.shiftKey ? stepBack() : undefined));
  };
  document.addEventListener("keydown", onKey, true);

  render();

  function destroy() {
    alive = false;
    stopTracking();
    cancelAnimationFrame(frame);
    drag?.ghost.remove();
    drag = null;
    host.removeEventListener("pointerdown", onDown);
    document.removeEventListener("keydown", onKey, true);
  }
  return { destroy };
}

/**
 * 把第 fileIndex 頁設為封面，詳情頁的封面跟著換。
 * @param {HoardItemDetail} item @param {number} fileIndex @param {HTMLElement} img
 */
async function setCover(item, fileIndex, img) {
  try {
    await hoard.items.setCover(item.id, { fileIndex });
    const fresh = await hoard.items.get(item.id);
    if (fresh.cover_path) img.setAttribute("src", hoard.fileSrc(fresh.cover_path));
    hoard.toast("已設為封面");
  } catch (err) {
    hoard.toast(`無法設為封面：${err}`, { kind: "error" });
  }
}

// ---- 卡片：一本書 ----

/**
 * 封面後面那一頁的網址（翻開封面看到的那一頁，見 innerPage）。
 * 鍵是作品 id；作品改了（換封面、改頁序）就丟掉重讀。
 * @type {Map<number, Promise<string | null>>}
 */
const innerPages = new Map();
/** @param {{ ids: number[] }} change */
const forgetInnerPages = ({ ids }) => ids.forEach((id) => innerPages.delete(id));
hoard.on("items-changed", forgetInnerPages);
hoard.on("items-removed", forgetInnerPages);

/** @param {HoardItemFile} file @param {number} itemId */
function pageUrl(file, itemId) {
  if (file.entry !== null) return hoard.pageSrc(itemId, file.file_index);
  // 原圖可能一張十幾 MB：有較小的預覽就用它
  return hoard.fileSrc(file.preview_path || file.path);
}

/** 封面後面那一頁最多往後找幾頁：封面後面接著跨頁（攤開的封面、拉頁）也找得到。 */
const INNER_PAGE_SCAN = 6;

/** 一頁的網址，與它是不是橫向的跨頁（寬比高大）。 @typedef {{ url: string; wide: boolean }} LeadingPage */

/** @param {HoardItemFile} file @param {string} url @returns {LeadingPage} */
const leadingPage = (file, url) => ({ url, wide: (file.width ?? 0) > (file.height ?? 0) });

/**
 * 一件作品的前 count 頁。
 * @param {number} id @param {number} count @returns {Promise<LeadingPage[]>}
 */
async function leadingPages(id, count) {
  const pages = (await hoard.items.get(id)).files.filter((f) => f.kind === "image" && !f.missing);
  return pages.slice(0, count).map((f) => leadingPage(f, pageUrl(f, id)));
}

/** 封面之後第一個不是跨頁的頁（第一頁就是封面）。 @param {LeadingPage[]} pages */
const afterCover = (pages) => pages.slice(1).find((p) => !p.wide);

/**
 * 封面後面那一頁：封面之後第一個不是跨頁的頁。攤開的封面（封底連封面的橫圖）、拉頁不算，
 * 那些翻開來看起來還是封面，也塞不進一頁的位置。都是跨頁時用第二頁；只有一頁時就是它。
 * @param {number} id @returns {Promise<string | null>}
 */
function innerPage(id) {
  let pending = innerPages.get(id);
  if (!pending) {
    pending = (async () => {
      const pages = await leadingPages(id, INNER_PAGE_SCAN);
      return (afterCover(pages) ?? pages[1] ?? pages[0])?.url ?? null;
    })().catch((err) => {
      console.error("[comic-reader] 讀封面後面那一頁：", err);
      innerPages.delete(id);
      return null;
    });
    innerPages.set(id, pending);
  }
  return pending;
}

/**
 * 一本沒有任何文字的漫畫書：封面蓋在紙頁上，書口露出一點頁的厚度，封面靠書背那一側有裝訂的摺痕。
 * 封面後面那一頁跟封面一起讀好，滑鼠停上去封面以書背為軸微微翻開，馬上就看得到它；右到左讀的書（漫畫模式）書背在右邊，從右邊翻開。
 * 翻開的動畫是 styles.css 的 transition。交給這裡的作品在網格、瀑布流、分頁版型裡的卡片。
 * @param {HTMLElement} root @param {HoardItemSummary} item @param {HoardCardCtx} ctx
 */
function renderBookCard(root, item, ctx) {
  const cover = item.cover_path ?? item.thumbnail_path;
  // 封面後面那一頁跟封面一起讀（同樣是 lazy：捲到附近才載），滑鼠停上去翻開時已經在了
  const page = hoard.el("img", { class: "cr-bc-page", alt: "", loading: "lazy", draggable: "false", decoding: "async" });
  const card = hoard.el("div", { class: "cr-bc" }, [
    hoard.el("div", { class: "cr-bc-book", style: `aspect-ratio: ${ctx.coverAspect}` }, [
      hoard.el("div", { class: "cr-bc-pages" }, [page]),
      hoard.el("div", { class: "cr-bc-cover" }, [
        cover
          ? hoard.el("img", {
              class: "cr-bc-cover-img",
              src: hoard.fileSrc(cover),
              alt: item.title,
              loading: "lazy",
              decoding: "async",
              draggable: "false",
            })
          : hoard.el("span", { class: "cr-bc-cover-blank" }, [hoard.icon("book-image", { size: 20 })]),
      ]),
    ]),
  ]);
  // 讀進來之前是空白的紙，讀到了才淡入
  page.addEventListener("load", () => page.setAttribute("data-loaded", ""));
  const hinge = () =>
    card.setAttribute("data-hinge", settingsFor(/** @type {any} */ (item)).settings.mode === "manga" ? "right" : "left");
  hinge();

  void innerPage(item.id).then((src) => {
    if (src && page.isConnected) page.setAttribute("src", src);
  });
  // 閱讀方向可能在別處改過（插件資料晚點才讀進來也是）：翻開前再看一次
  card.addEventListener("pointerenter", hinge);
  root.append(card);
  return () => card.removeEventListener("pointerenter", hinge);
}

// 能讀任何有圖的作品，但哪些是漫畫由使用者在「開啟方式」選，不自己接手。
hoard.registerPresenter({ auto: false, accepts: readable, detail: renderComicDetail, card: renderBookCard, cardFrame: false });

// ---- 進入點 ----

/**
 * 交給這裡的作品（右鍵「標記為已讀」只對它們出現）。選單的 when 要馬上回答，所以先查好，
 * 作品加入或改了（例如換了開啟方式）時重查那幾件。 @type {Set<number>}
 */
const comicIds = new Set();
async function loadComicIds() {
  for (let offset = 0; offset < 100000; offset += 500) {
    const page = await hoard.items.list({ presenter: PLUGIN_ID }, { offset, limit: 500 });
    page.items.forEach((item) => comicIds.add(item.id));
    if (offset + 500 >= page.total) break;
  }
}
void loadComicIds().catch(() => {});
void loadStore().catch((err) => console.error("[comic-reader] 讀取資料失敗：", err));
/** @param {{ ids: number[] }} payload */
function recheckComics({ ids }) {
  for (let i = 0; i < ids.length; i += 500) {
    const chunk = ids.slice(i, i + 500);
    void hoard.items
      .list({ presenter: PLUGIN_ID, ids: chunk }, { limit: chunk.length })
      .then((page) => {
        const found = new Set(page.items.map((item) => item.id));
        for (const id of chunk) {
          if (found.has(id)) comicIds.add(id);
          else comicIds.delete(id);
        }
      })
      .catch(() => {});
  }
}
hoard.on("items-added", recheckComics);
hoard.on("items-changed", recheckComics);
hoard.on("items-removed", ({ ids }) => ids.forEach((id) => comicIds.delete(id)));

/** 交給這裡的作品。 @param {number} id */
const isComic = (id) => comicIds.has(id);
hoard.registerMenuItem("item", {
  label: "標記為已讀",
  icon: "book-check",
  when: (ids) => ids.length === 1 && isComic(ids[0]) && !store.progress[ids[0]]?.finished,
  run: async ([id]) => {
    const item = await hoard.items.get(id);
    // 跟閱讀器一樣：容器的頁，或貼文的圖片。
    setFinished(id, true, item.files.filter((f) => f.kind === "image").length);
  },
});
hoard.registerMenuItem("item", {
  label: "標記為未讀",
  icon: "book-x",
  when: (ids) => ids.length === 1 && isComic(ids[0]) && Boolean(store.progress[ids[0]]?.finished),
  run: ([id]) => setFinished(id, false, store.progress[id]?.total ?? 0),
});
hoard.addCommand({
  id: "read",
  label: "用閱讀器開啟這件作品",
  // 只給交給這裡的作品：一件作品只用它的「開啟方式」打開。
  when: (ctx) => ctx.view === "detail" && ctx.itemId !== null && isComic(ctx.itemId),
  run: (ctx) => ctx.itemId !== null && openReader(ctx.itemId),
});
