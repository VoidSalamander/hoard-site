// @ts-check
/// <reference path="../hoard-app.d.ts" />
/* Pixiv App 端：
   - 卡片（renderCard）：照 Pixiv 的作品縮圖，不要 App 的外框：圓角 4px 的圖，下方是標題與作者；
     小說在瀑布流（高度由卡片決定）裡照 Pixiv 小說清單的橫式：封面在左，右邊是標題、作者、簡介與標籤。
     多張的作品滑過時出現左右箭頭與圓點，動圖與 GIF 滑過時會動。前 4 張用 item.previews，更多張時第一次換圖才讀完整的 files。
   - 詳情頁仿 Pixiv 作品頁（白底、灰色作品舞台），單欄置中：作品在上、標題說明標籤、留言與作者的其他收藏在下方。
     作者（頭像、名字、作者頁面）在 App 的頁首，這裡不再畫作者列。
   - 小說（work_type 是 novel）仿 Pixiv 小說頁：封面與標題並排，本文照擷取器存的原文（.txt）還原 [newpage] 的分頁、章節、注音、傍點、插圖，
     一次一頁、下面是頁碼列；卡片不換圖。
   樣式見 styles.css：卡片用 hp- 前綴的全域 class，詳情頁限定在 [data-hoard-skin="pixiv"] 之下。 */

/** 留言者的頭像：名字的第一個字（Pixiv 的留言者頭像沒有存）。 @param {string | null | undefined} name @param {string} cls */
function avatar(name, cls) {
  return hoard.el("div", { class: cls }, [(name || "?").trim().charAt(0).toUpperCase()]);
}

// ---- 動畫（App 的 docs/conventions.md〈動畫〉：插件拿不到 App 的動畫程式，照同一組時長、曲線自己做） ----

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場、移動、變大。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/** 元素現在（滑到一半也算）的水平位移，px。 @param {Element} el */
function shiftOf(el) {
  const value = parseFloat(getComputedStyle(el).translate);
  return Number.isFinite(value) ? value : 0;
}

/** 每個框裡還在滑走的圖，與最近一次換圖的記號。 @type {WeakMap<HTMLElement, { gone: HTMLElement[]; token: object }>} */
const tracks = new WeakMap();

/**
 * 換一張：舊的整張往反方向滑出框、新的從另一邊整張滑進來，兩張同時走、不淡出（跟 App 換作品的 slideWorks 同一套）。
 * 像一條每格一個框寬的軌道：連按時從目前的位置接著走，還在滑走的跟著一起走；按反方向時，剛滑走的那張由新的一張接回它的位置。
 * fresh 要先放進框裡；它也可以是還在滑走的那一張（拉回來）。滑動期間才裁掉框外。
 * @param {HTMLElement} clip @param {HTMLElement} shown @param {HTMLElement} fresh
 * @param {1 | -1} d 1：往後一張（整條往左走）
 * @param {(el: HTMLElement) => void} gone 滑出去的那張怎麼收
 */
function slideTo(clip, shown, fresh, d, gone) {
  const ms = 220;
  const live = (tracks.get(clip)?.gone ?? []).filter((el) => el.isConnected && el !== shown && el !== fresh);
  if (!motionOn()) {
    tracks.delete(clip);
    for (const el of [shown, ...live]) gone(el);
    return;
  }
  const D = clip.clientWidth;
  const cur = shiftOf(shown);
  const rest = live.map((el) => /** @type {const} */ ([el, shiftOf(el)]));
  for (const el of [shown, fresh, ...live]) for (const a of el.getAnimations()) a.cancel();
  clip.style.overflowX = "clip";
  const delta = -d * D - cur; // 整條這次走多遠
  const start = cur + d * D; // 新的一張緊接在舊的後面
  /** @param {HTMLElement} el @param {number} from */
  const out = (el, from) => {
    const a = el.animate([{ translate: `${from}px 0` }, { translate: `${from + delta}px 0` }], { duration: ms, easing: EASE_OUT, fill: "forwards" });
    return a.finished.then(
      () => {
        gone(el);
        a.cancel();
      },
      () => {},
    );
  };
  const leaving = [shown];
  /** @type {Promise<unknown>[]} */
  const runs = [out(shown, cur)];
  for (const [el, at] of rest) {
    if (Math.abs(at - start) < 1) {
      gone(el); // 按反方向：新的一張接回它的位置
      continue;
    }
    leaving.push(el);
    runs.push(out(el, at));
  }
  runs.push(fresh.animate([{ translate: `${start}px 0` }, { translate: "0 0" }], { duration: ms, easing: EASE_OUT }).finished.catch(() => {}));
  const token = {};
  tracks.set(clip, { gone: leaving, token });
  void Promise.all(runs).then(() => {
    if (tracks.get(clip)?.token !== token) return;
    tracks.delete(clip);
    clip.style.overflowX = "";
  });
}

/**
 * 晚到的區塊（box 裡先放好骨架佔位置；CSS 讓骨架等 200ms 才淡入，很快就到的看不到它）換成內容：
 * 骨架淡出、內容淡入（骨架已經出現過時 160ms 交叉，沒出現過時內容直接淡入 120ms），
 * 高度從骨架補間到內容的實際高度 200ms，下面的東西跟著滑，不是跳。沒有內容就整塊收起來。
 * @param {HTMLElement} box @param {HTMLElement[]} content @param {number} since 骨架放上去的時間（performance.now()）
 */
function settle(box, content, since) {
  if (!motionOn()) return void box.replaceChildren(...content);
  const seen = performance.now() - since >= 200;
  const skeleton = /** @type {HTMLElement[]} */ ([...box.children]);
  const from = { height: `${box.getBoundingClientRect().height}px`, marginTop: getComputedStyle(box).marginTop };
  for (const a of box.getAnimations()) a.cancel();
  box.style.overflow = "clip";
  if (content.length === 0) {
    // 沒有內容：骨架淡出、整塊收起來，收完才拿掉。
    for (const el of skeleton) el.animate([{ opacity: getComputedStyle(el).opacity }, { opacity: 0 }], { duration: 160, easing: EASE_IN, fill: "forwards" });
    const fold = box.animate([from, { height: "0px", marginTop: "0px", paddingTop: "0px", borderTopWidth: "0px" }], { duration: 200, easing: EASE_OUT, fill: "forwards" });
    void fold.finished.then(
      () => {
        box.replaceChildren();
        box.style.overflow = "";
        fold.cancel();
      },
      () => {},
    );
    return;
  }
  // 骨架停在現在的樣子（搬進疊層時 CSS 動畫會重來），再疊到內容上面淡出。
  for (const el of skeleton) {
    el.style.opacity = getComputedStyle(el).opacity;
    el.style.animation = "none";
  }
  box.replaceChildren(...content);
  const to = { height: `${box.getBoundingClientRect().height}px`, marginTop: getComputedStyle(box).marginTop };
  const grow = box.animate([from, to], { duration: 200, easing: EASE_OUT });
  void grow.finished.then(
    () => (box.style.overflow = ""),
    () => {},
  );
  for (const el of content) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: seen ? 160 : 120, easing: EASE_OUT, fill: "backwards" });
  if (!seen) return;
  const ghost = hoard.el("div", { class: "hp-late-ghost", "aria-hidden": "true" }, skeleton);
  box.prepend(ghost);
  void ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 160, easing: EASE_IN, fill: "forwards" }).finished.then(
    () => ghost.remove(),
    () => ghost.remove(),
  );
}

/** 頁尾「作者的其他收藏」：從收藏庫撈同作者的其他作品。讀好之前先放骨架（標題與一排縮圖）佔好位置。 */
function moreByAuthor(item, ctx) {
  const wrap = hoard.el("section", { class: "hp-more" });
  if (!item.author) return wrap;
  const since = performance.now();
  wrap.append(
    hoard.el("div", { class: "hp-more-skeleton", "aria-hidden": "true" }, [
      hoard.el("div", { class: "hp-more-skeleton-title" }),
      hoard.el("div", { class: "hp-more-grid" }, Array.from({ length: 6 }, () => hoard.el("div", { class: "hp-thumb" }))),
    ]),
  );
  ctx
    .listItems({ author_id: item.author.id }, { sort: "published", limit: 13 })
    .then((page) => {
      const others = page.items.filter((other) => other.id !== item.id).slice(0, 12);
      if (others.length === 0) return settle(wrap, [], since);
      settle(
        wrap,
        [
          hoard.el("h3", { class: "hp-more-title" }, [`作者的其他收藏 · ${page.total - 1}`]),
          hoard.el(
            "div",
            { class: "hp-more-grid" },
            others.map((other) => {
              const cover = other.cover_path || other.thumbnail_path;
              const thumb = hoard.el("button", { class: "hp-thumb", title: other.title }, [
                cover ? hoard.el("img", { src: hoard.fileSrc(cover), alt: "", loading: "lazy" }) : null,
              ]);
              // 點開那件、右鍵開那件的選單（不是目前這件的）、拖出檔案。
              ctx.bindItem(thumb, other);
              return thumb;
            }),
          ),
        ],
        since,
      );
    })
    .catch(() => settle(wrap, [], since));
  return wrap;
}

function commentNode(node) {
  const c = node.comment;
  const row = hoard.el("div", { class: "hp-comment" }, [
    avatar(c.author_name, "hp-avatar hp-avatar-sm"),
    hoard.el("div", { class: "hp-comment-body" }, [
      hoard.el("p", { class: "hp-comment-name" }, [c.author_name || "匿名"]),
      hoard.el("p", { class: "hp-comment-text" }, [c.content]),
      c.posted_at ? hoard.el("p", { class: "hp-muted" }, [hoard.formatDateTime(c.posted_at)]) : null,
    ]),
  ]);
  if (node.replies.length === 0) return row;
  return hoard.el("div", {}, [row, hoard.el("div", { class: "hp-replies" }, node.replies.map(commentNode))]);
}


/** 圖片的 width／height 屬性（原圖的像素尺寸；還沒量測時不給）。 @param {HoardItemFile} file */
const sizeAttrs = (file) => (file.width && file.height ? { width: String(file.width), height: String(file.height) } : {});

// ---- 卡片 ----

/** @param {HoardItemFile} file */
const isImage = (file) => file.kind === "image";

/** @param {HoardItemFile} file */
const slideSrc = (file) => hoard.fileSrc(file.preview_path || file.path);

/** 作品 id → 全部圖片的網址（超過 previews 的 4 張時才讀）。作品變動時丟掉。 */
const fullSlides = new Map();
hoard.on("items-changed", ({ ids }) => {
  for (const id of ids) fullSlides.delete(id);
});

/** @param {HoardItemSummary} item @returns {Promise<string[]>} */
async function loadAllSlides(item) {
  const cached = fullSlides.get(item.id);
  if (cached) return cached;
  const detail = await hoard.items.get(item.id);
  const slides = detail.files.filter(isImage).map(slideSrc);
  fullSlides.set(item.id, slides);
  return slides;
}

/**
 * 卡片上的換圖：第 0 張是封面本身（App 縮小過的），其他張是疊在上面的 <img>；按箭頭往那個方向整張滑過去。
 * 底部的圓點是第幾張。
 * @param {HTMLElement} cover
 * @param {HoardItemSummary} item
 * @param {HTMLElement | null} base 封面的 <img>；封面是 App 畫的（mountCover）時是 null
 */
function attachSlider(cover, item, base) {
  let slides = item.previews.filter(isImage).map(slideSrc);
  let loaded = item.file_count <= item.previews.length;
  let index = 0;
  // 第 0 張：封面的 <img>；App 畫的封面不能移動，就用一層透明的代替（滑走時露出底下的封面）。
  const zero = base ?? hoard.el("span", { class: "hp-slide" });
  /** 現在這張。 */
  let current = zero;
  /** 滑出去的：第 0 張藏起來（下次還要用），其他張拿掉。 @param {HTMLElement} el */
  const gone = (el) => {
    if (el === zero) el.style.visibility = "hidden";
    else el.remove();
  };

  const dots = hoard.el("div", { class: "hp-dots" });
  const show = () => {
    // 最多 10 個圓點；張數更多時每個圓點代表一段（30 張時第 1–3 張亮第一個，第 4–6 張亮第二個…）。
    const pages = loaded ? slides.length : item.file_count;
    const count = Math.min(pages, 10);
    const on = Math.floor((index * count) / pages);
    dots.replaceChildren(
      ...Array.from({ length: count }, (_, i) => hoard.el("span", { class: i === on ? "hp-dot hp-dot-on" : "hp-dot" })),
    );
  };

  /** @param {number} step */
  const go = async (step) => {
    if (!loaded) {
      try {
        slides = await loadAllSlides(item);
      } catch {
        // 讀不到就只在前幾張之間換。
      }
      loaded = true;
    }
    if (slides.length < 2) return;
    index = (index + step + slides.length) % slides.length;
    const shown = current;
    const fresh = index === 0 ? zero : hoard.el("img", { class: "hp-slide", src: slides[index], alt: "", draggable: "false" });
    current = fresh;
    fresh.style.visibility = "";
    // 疊在封面上、箭頭下（跟以前那層 <img> 同一個位置）。
    if (fresh !== zero || !base) prev.before(fresh);
    show();
    slideTo(cover, shown, fresh, step > 0 ? 1 : -1, gone);
    // 先載入下一張，按下去時不會閃。
    const next = slides[(index + 1) % slides.length];
    if (next) new Image().src = next;
  };

  /** @param {string} cls @param {string} icon @param {string} label @param {number} step */
  const arrow = (cls, icon, label, step) =>
    hoard.el("button", { class: `hp-nav ${cls}`, title: label, "aria-label": label, onclick: () => void go(step) }, [
      hoard.icon(icon, { size: 16 }),
    ]);

  const prev = arrow("hp-prev", "chevron-left", "上一張", -1);
  show();
  cover.append(prev, arrow("hp-next", "chevron-right", "下一張", 1), dots);
  if (!base) prev.before(zero);
}

// ---- 小說：擷取器把本文照 Pixiv 的原文存成 .txt，這裡照標記還原分頁、章節、注音、插圖與連結 ----

/** @param {HoardItemSummary | HoardItemDetail} item */
const isNovel = (item) => item.metadata.work_type === "novel";

/**
 * 行內的標記：[[rb:漢字 > かんじ]]（注音）、[[emphasismark:文字 > ﹅]]（傍點）、[b:文字]（粗體）。
 * 粗體與章節標題裡面還可以有注音、傍點。
 */
const NOVEL_INLINE = String.raw`\[\[rb:(?<rb>[^\]\n>]+?)\s*>\s*(?<rt>[^\]\n]+?)\]\]|\[\[emphasismark:(?<em>[^\]\n>]+?)\s*>\s*(?<mark>[^\]\n]+?)\]\]`;
/** 標記裡面可以再包行內標記的文字（[b:…]、[chapter:…] 的內容）。 */
const NOVEL_NESTED = String.raw`(?:\[\[(?:rb|emphasismark):[^\]\n]*\]\]|[^\]\n])*`;

/**
 * 本文裡的標記：行內的（見 NOVEL_INLINE、[b:]）、[[jumpuri:文字 > 網址]]、[chapter:標題]、[jump:頁碼]、
 * [uploadedimage:123]、[pixivimage:456-2]。分頁的 [newpage] 先切開，不在這裡。認不得的標記照原文顯示。
 */
const NOVEL_TOKEN = new RegExp(
  [
    NOVEL_INLINE,
    String.raw`\[b:(?<bold>${NOVEL_NESTED})\]`,
    String.raw`\[\[jumpuri:(?<link>[^\]\n>]+?)\s*>\s*(?<url>[^\]\n]+?)\]\]`,
    String.raw`\[chapter:(?<chapter>${NOVEL_NESTED})\]`,
    String.raw`\[jump:(?<jump>\d+)\]`,
    String.raw`\[(?<image>uploadedimage|pixivimage):(?<imageId>\d+(?:-\d+)?)\]`,
  ].join("|"),
  "g",
);

/**
 * 行內標記換成節點：注音是 <ruby>，傍點用 text-emphasis 畫在字上（標記的字照原文，通常是「﹅」）。
 * @param {RegExpMatchArray} m @returns {Node | null}
 */
function inlineNode(m) {
  const g = m.groups ?? {};
  if (g.rb !== undefined) return hoard.el("ruby", {}, [g.rb, hoard.el("rt", {}, [g.rt])]);
  if (g.em !== undefined) return hoard.el("span", { class: "hp-novel-em", style: `text-emphasis-style: ${JSON.stringify(g.mark.trim())}` }, [g.em]);
  if (g.bold !== undefined) return hoard.el("b", {}, inlineText(g.bold));
  return null;
}

/** 只有行內標記的文字（粗體、章節標題的內容）。 @param {string} text @returns {Array<Node | string>} */
function inlineText(text) {
  /** @type {Array<Node | string>} */
  const out = [];
  let last = 0;
  for (const m of text.matchAll(new RegExp(NOVEL_INLINE, "g"))) {
    out.push(text.slice(last, m.index));
    const node = inlineNode(m);
    out.push(node ?? m[0]);
    last = (m.index ?? 0) + m[0].length;
  }
  out.push(text.slice(last));
  return out;
}

/**
 * 小說的插圖：檔名是擷取器取的 `{作品id}_{種類}-{標記的值}.{副檔名}`，對回本文的標記（"uploadedimage-123"）。
 * @param {HoardItemDetail} item @returns {Map<string, HoardItemFile>}
 */
function novelImageFiles(item) {
  const map = new Map();
  for (const file of item.files) {
    const key = file.kind === "image" ? file.path.match(/_((?:uploadedimage|pixivimage)-\d+(?:-\d+)?)\.\w+$/)?.[1] : null;
    if (key) map.set(key, file);
  }
  return map;
}

/**
 * 插圖：存到的照原圖畫（點了開大圖）；沒存到的（引用的作品已刪除或不公開）是佔位，引用 Pixiv 作品的點了開作品頁。
 * @param {string} kind @param {string} id @param {{ images: Map<string, HoardItemFile>; open: (file: HoardItemFile) => void }} opts
 */
function novelFigure(kind, id, opts) {
  const file = opts.images.get(`${kind}-${id}`);
  if (file) {
    const img = hoard.el("img", { src: hoard.fileSrc(file.path), alt: "", loading: "lazy", decoding: "async", ...sizeAttrs(file) });
    img.addEventListener("click", () => opts.open(file));
    return hoard.el("figure", { class: "hp-novel-figure" }, [img]);
  }
  const url = kind === "pixivimage" ? `https://www.pixiv.net/artworks/${id.split("-")[0]}` : null;
  return hoard.el(
    url ? "button" : "div",
    url ? { class: "hp-novel-missing", type: "button", title: url, onclick: () => hoard.openUrl(url) } : { class: "hp-novel-missing" },
    [hoard.icon("image-off", { size: 20 }), hoard.el("span", {}, [url ? "插圖未收錄 · 在 Pixiv 開啟" : "插圖未收錄"])],
  );
}

/**
 * 一頁本文畫成節點。文字照原樣保留換行（white-space: pre-wrap）；章節與插圖是區塊，緊跟在後面的那個換行拿掉，
 * 不然會多空一行。
 * @param {string} source 一頁的原文
 * @param {{ images: Map<string, HoardItemFile>; open: (file: HoardItemFile) => void; jump: (page: number) => void }} opts
 */
function novelPage(source, opts) {
  const page = hoard.el("div", { class: "hp-novel-text" });
  const text = source.replace(/^\n/, "");
  let last = 0;
  let afterBlock = false;
  /** @param {string} s */
  const pushText = (s) => {
    const kept = afterBlock ? s.replace(/^\n/, "") : s;
    if (kept) page.append(kept);
  };
  for (const m of text.matchAll(NOVEL_TOKEN)) {
    pushText(text.slice(last, m.index));
    afterBlock = false;
    last = (m.index ?? 0) + m[0].length;
    const g = m.groups ?? {};
    const inline = inlineNode(m);
    if (inline) {
      page.append(inline);
    } else if (g.link !== undefined) {
      const url = g.url.trim();
      page.append(
        /^https?:\/\//i.test(url)
          ? hoard.el("a", { class: "hp-novel-link", href: url, title: url, onclick: (e) => (e.preventDefault(), hoard.openUrl(url)) }, [g.link])
          : g.link,
      );
    } else if (g.chapter !== undefined) {
      page.append(hoard.el("h2", { class: "hp-novel-chapter" }, inlineText(g.chapter)));
      afterBlock = true;
    } else if (g.jump !== undefined) {
      const to = Number(g.jump);
      page.append(hoard.el("button", { class: "hp-novel-link", type: "button", onclick: () => opts.jump(to) }, [`跳到第 ${to} 頁`]));
    } else if (g.image !== undefined) {
      page.append(novelFigure(g.image, g.imageId, opts));
      afterBlock = true;
    }
  }
  pushText(text.slice(last));
  return page;
}

/**
 * 頁碼列：‹ 1 … 4 5 [6] 7 8 … 20 ›，目前頁前後各兩頁，頭尾一定在。
 * @param {number} count @param {number} current 從 1 起 @param {(page: number) => void} go
 */
function novelPager(count, current, go) {
  /** @type {Array<number | null>} */
  const shown = [];
  for (let p = 1; p <= count; p++) {
    if (p === 1 || p === count || Math.abs(p - current) <= 2) shown.push(p);
    else if (shown[shown.length - 1] !== null) shown.push(null);
  }
  /** @param {string} icon @param {string} label @param {number} to */
  const step = (icon, label, to) =>
    hoard.el("button", { class: "hp-pager-step", type: "button", title: label, "aria-label": label, ...(to < 1 || to > count ? { disabled: "" } : {}), onclick: () => go(to) }, [
      hoard.icon(icon, { size: 16 }),
    ]);
  return [
    step("chevron-left", "上一頁", current - 1),
    ...shown.map((p) =>
      p === null
        ? hoard.el("span", { class: "hp-pager-gap" }, ["…"])
        : hoard.el("button", { class: p === current ? "hp-pager-page hp-pager-on" : "hp-pager-page", type: "button", ...(p === current ? { "aria-current": "page" } : {}), onclick: () => go(p) }, [String(p)]),
    ),
    step("chevron-right", "下一頁", current + 1),
  ];
}

/** 數字（Pixiv 的計數）：不是正數時是 null。 @param {unknown} value */
const positive = (value) => (typeof value === "number" && value > 0 ? value : null);

/**
 * 標題下那一行：字數與閱讀時間（照 Pixiv：「3,589字　7分鐘」）。
 * @param {Record<string, unknown>} meta
 */
function novelFacts(meta) {
  const chars = positive(meta.character_count);
  const seconds = positive(meta.reading_time);
  return [
    chars ? hoard.el("span", {}, [`${chars.toLocaleString()}字`]) : null,
    seconds ? hoard.el("span", {}, [`${Math.max(1, Math.round(seconds / 60))}分鐘`]) : null,
  ].filter((el) => el !== null);
}

/** 讚、收藏、瀏覽數（照 Pixiv 的圖示順序）。 @param {Record<string, unknown>} meta */
function novelStats(meta) {
  return /** @type {const} */ ([
    ["face-slightly-smiling", "讚！", meta.like_count],
    ["heart", "收藏", meta.bookmark_count],
    ["eye", "瀏覽", meta.view_count],
  ])
    .filter(([, , value]) => typeof value === "number")
    .map(([icon, label, value]) =>
      hoard.el("span", { class: "hp-novel-stat", title: label }, [hoard.icon(icon, { size: 12 }), hoard.formatCount(/** @type {number} */ (value))]),
    );
}

/**
 * 小說的詳情頁：照 Pixiv 的小說頁。灰底上一張白卡：封面與系列、標題、字數、說明、標籤、計數、日期 →
 * 本文（一次一頁，[newpage] 分開的頁照原樣；頁首是「往前」、頁尾是「下一頁」，頁碼列貼在畫面底部）→ 留言 → 作者的其他收藏。
 * 作者在 App 的頁首，這裡不畫作者列。換頁時新的一頁從側邊整頁推進來（跟收藏庫的分頁版型一樣），推完捲回本文開頭。
 * @param {HTMLElement} root @param {HoardItemDetail} item @param {HoardDetailCtx} ctx
 */
function renderNovel(root, item, ctx) {
  const meta = item.metadata;
  const series = typeof meta.series === "string" ? meta.series : null;
  const volume = positive(meta.volume);
  const cover = item.files.find((f) => f.kind === "image" && /_cover\.\w+$/.test(f.path)) ?? null;
  const images = novelImageFiles(item);
  const figures = [...images.values()];

  const info = [];
  if (series) info.push(hoard.el("p", { class: "hp-novel-series" }, [volume ? `${series} #${volume}` : series]));
  info.push(hoard.el("h1", { class: "hp-novel-title" }, [item.title]));
  const facts = novelFacts(meta);
  if (facts.length > 0) info.push(hoard.el("p", { class: "hp-novel-facts" }, facts));
  if (item.description) info.push(hoard.el("p", { class: "hp-novel-caption" }, [item.description]));
  const tags = Array.isArray(meta.tags) ? meta.tags : [];
  if (tags.length > 0) {
    info.push(
      hoard.el(
        "p",
        { class: "hp-novel-tags" },
        tags.map((tag) =>
          hoard.el("span", { class: "hp-novel-tag" }, [
            `#${tag.name}`,
            tag.translation ? hoard.el("span", { class: "hp-novel-tag-tr" }, [tag.translation]) : null,
          ]),
        ),
      ),
    );
  }
  const stats = novelStats(meta);
  if (stats.length > 0) info.push(hoard.el("p", { class: "hp-novel-stats" }, stats));
  info.push(hoard.el("p", { class: "hp-novel-date" }, [hoard.formatDateTime(item.published_at) || "發布時間未知"]));
  const head = hoard.el("header", { class: "hp-novel-head" }, [
    cover
      ? (() => {
          const img = hoard.el("img", { class: "hp-novel-cover", src: hoard.fileSrc(cover.path), alt: "", decoding: "async", ...sizeAttrs(cover) });
          img.addEventListener("click", () => ctx.openViewer([cover], 0));
          return img;
        })()
      : null,
    hoard.el("div", { class: "hp-novel-info" }, info),
  ]);

  const pagesBox = hoard.el("div", { class: "hp-novel-pages" });
  const pager = hoard.el("nav", { class: "hp-pager", "aria-label": "頁碼" });
  const bar = hoard.el("div", { class: "hp-novel-bar" }, [pager]);
  const article = hoard.el("article", { class: "hp-novel" }, [pagesBox, bar]);

  /** @type {string[]} */
  let sources = [];
  let current = 1;
  /** @type {HTMLElement | null} */
  let shown = null;
  /**
   * 頁首、頁尾的整條換頁鈕（照 Pixiv：箭頭在上、字在下）。
   * @param {string} icon @param {string} label @param {number} to
   */
  const turn = (icon, label, to) =>
    hoard.el("button", { class: "hp-novel-turn", type: "button", onclick: () => go(to) }, [hoard.icon(icon, { size: 16 }), hoard.el("span", {}, [label])]);
  /** 一頁：第 2 頁起頂端有「往前」，最後一頁以外底部有「下一頁」，跟著頁一起推。 @param {number} p */
  const build = (p) =>
    hoard.el("div", { class: "hp-novel-sheet" }, [
      p > 1 ? turn("chevron-up", "往前", p - 1) : null,
      novelPage(sources[p - 1] ?? "", {
        images,
        open: (file) => ctx.openViewer(figures, Math.max(0, figures.indexOf(file))),
        jump: (to) => go(to),
      }),
      p < sources.length ? turn("chevron-down", "下一頁", p + 1) : null,
    ]);
  const drawPager = () => {
    bar.hidden = sources.length < 2;
    pager.replaceChildren(...(sources.length > 1 ? novelPager(sources.length, current, go) : []));
  };
  /** @param {number} p */
  function go(p) {
    if (p < 1 || p > sources.length || p === current || !shown) return;
    const d = p > current ? 1 : -1;
    current = p;
    const fresh = build(p);
    pagesBox.append(fresh);
    const old = shown;
    shown = fresh;
    slideTo(pagesBox, old, fresh, d, (el) => el.remove());
    drawPager();
    // 推完再捲回本文開頭（本文開頭已經在畫面裡就不捲）。
    setTimeout(() => {
      if (article.getBoundingClientRect().top < 0) article.scrollIntoView({ behavior: motionOn() ? "smooth" : "auto", block: "start" });
    }, motionOn() ? 220 : 0);
  }

  const since = performance.now();
  bar.hidden = true;
  pagesBox.append(hoard.el("div", { class: "hp-novel-skeleton", "aria-hidden": "true" }, Array.from({ length: 8 }, () => hoard.el("span"))));
  const textFile = item.files.find((f) => f.ext === "txt" || /\.txt$/i.test(f.path));
  (textFile ? fetch(hoard.fileSrc(textFile.path)).then((res) => (res.ok ? res.text() : Promise.reject(new Error(`HTTP ${res.status}`)))) : Promise.reject(new Error("沒有本文檔")))
    .then((text) => {
      sources = text.replace(/\r\n?/g, "\n").split("[newpage]");
      shown = build(1);
      settle(pagesBox, [shown], since);
      drawPager();
    })
    .catch((err) => {
      console.warn("[pixiv] 讀不到小說本文：", err);
      settle(pagesBox, [hoard.el("p", { class: "hp-muted hp-novel-error" }, ["讀不到本文"])], since);
    });

  const card = [head, article];
  if (item.comments.length > 0) {
    card.push(
      hoard.el("section", { class: "hp-comments hp-novel-comments" }, [
        hoard.el("h3", { class: "hp-section-title" }, [`留言 ${item.comments.length}`]),
        ...hoard.buildCommentTree(item.comments).map(commentNode),
      ]),
    );
  }
  card.push(moreByAuthor(item, ctx));
  root.append(hoard.el("div", { class: "hp-page hp-novel-page" }, [hoard.el("main", { class: "hp-novel-card" }, card)]));
}

hoard.register({
  renderDetail(root, item, ctx) {
    if (isNovel(item)) return renderNovel(root, item, ctx);
    const series = typeof item.metadata.series === "string" ? item.metadata.series : null;
    const media = item.files.filter((f) => f.kind === "image" || f.kind === "video");

    // 作品區：灰底舞台，圖片依序排列，點擊開啟全螢幕檢視器。
    const stage = hoard.el(
      "div",
      { class: "hp-stage" },
      media.map((file, i) => {
        if (file.kind === "video") {
          return hoard.el("video", { src: hoard.fileSrc(file.path), controls: "", preload: "metadata" });
        }
        // 原圖可能幾千萬像素：畫的時候才解碼會讓每一格都等它，交給背景解碼。
        // 先照原圖的尺寸佔好位置：還沒載入的圖高度不是 0，lazy 才只載入畫面附近的幾張，頁面也不會一張張被推開。
        const img = hoard.el("img", { src: hoard.fileSrc(file.path), alt: file.alt ?? `${item.title} ${i + 1}`, ...(file.alt ? { title: file.alt } : {}), loading: "lazy", decoding: "async", ...sizeAttrs(file) });
        img.addEventListener("click", () => ctx.openViewer(media, i));
        return img;
      }),
    );

    const info = [];
    if (series) info.push(hoard.el("p", { class: "hp-series" }, [hoard.icon("book-open", { size: 14 }), series]));
    info.push(hoard.el("h1", { class: "hp-title" }, [item.title]));
    if (item.description) info.push(hoard.el("p", { class: "hp-caption" }, [item.description]));
    // 標籤只是作品資訊（擷取時存的文字），照 Pixiv：藍色的 #原文，後面是翻譯。
    const tags = Array.isArray(item.metadata.tags) ? item.metadata.tags : [];
    if (tags.length > 0) {
      info.push(
        hoard.el(
          "p",
          { class: "hp-tags" },
          tags.map((tag) =>
            hoard.el("span", { class: "hp-tag" }, [
              hoard.el("span", { class: "hp-tag-name" }, [`#${tag.name}`]),
              tag.translation ? hoard.el("span", { class: "hp-tag-tr" }, [tag.translation]) : null,
            ]),
          ),
        ),
      );
    }
    info.push(hoard.el("p", { class: "hp-muted" }, [hoard.formatDateTime(item.published_at) || "發布時間未知"]));

    const main = [stage, hoard.el("div", { class: "hp-info" }, info)];
    if (item.comments.length > 0) {
      main.push(
        hoard.el("section", { class: "hp-comments" }, [
          hoard.el("h3", { class: "hp-section-title" }, [`留言 ${item.comments.length}`]),
          ...hoard.buildCommentTree(item.comments).map(commentNode),
        ]),
      );
    }

    main.push(moreByAuthor(item, ctx));
    root.append(hoard.el("div", { class: "hp-page" }, [hoard.el("main", { class: "hp-main" }, main)]));
  },

  // 照 Pixiv 的作品縮圖：圓角的圖與下方的標題、作者，不要 App 的卡片外框。
  cardFrame: false,

  renderCard(root, item, ctx) {
    // 小說在瀑布流（高度由卡片決定）裡照 Pixiv 小說清單的橫式，封面在左、文字在右；插畫照 Pixiv 的縮圖維持直式。
    // 封面的比例收在直式到略寬之間，太寬的圖在左邊會扁成一條。
    const novel = isNovel(item);
    const wide = novel && ctx.freeHeight && ctx.density === "full";
    const aspect = wide ? Math.min(4 / 3, Math.max(0.7, ctx.coverAspect)) : ctx.coverAspect;
    const card = hoard.el("div", { class: `hp-card hp-d-${ctx.density}${wide ? " hp-wide" : ""}` });
    const cover = hoard.el("div", { class: "hp-cover", style: `aspect-ratio: ${aspect}` });
    const src = item.cover_path || item.thumbnail_path;
    if (src) {
      const still = hoard.fileSrc(src);
      const img = hoard.el("img", { class: "hp-img", src: still, alt: item.title, loading: "lazy", draggable: "false" });
      cover.append(img);
      // 封面是靜態的縮圖；動圖（存成動態 WebP）與 GIF 滑過時換成原檔，就會動。
      const moving = item.previews.find(
        (file) => isImage(file) && (file.ext === "gif" || (file.ext === "webp" && item.metadata.work_type === "ugoira")),
      );
      if (moving) {
        const src = hoard.fileSrc(moving.path);
        card.addEventListener("mouseenter", () => img.setAttribute("src", src));
        card.addEventListener("mouseleave", () => img.setAttribute("src", still));
      }
    } else {
      ctx.mountCover(cover);
    }
    // 小說的檔案是封面、本文與插圖，不是一張張的圖：不換圖。
    if (item.metadata.work_type === "ugoira") cover.append(hoard.el("span", { class: "hp-ugoira" }, [hoard.icon("play", { size: 10 })]));
    // 太小的卡片放不下箭頭。
    if (!novel && item.file_count > 1 && ctx.density !== "cover") attachSlider(cover, item, /** @type {HTMLElement | null} */ (cover.querySelector(".hp-img")));
    card.append(cover);
    if (ctx.density === "full") {
      const text = [hoard.el("p", { class: "hp-card-title" }, [item.title])];
      if (item.author_name) {
        text.push(
          hoard.el("p", { class: "hp-card-author" }, [
            item.author_avatar
              ? hoard.el("img", { class: "hp-card-avatar", src: hoard.fileSrc(item.author_avatar), alt: "", draggable: "false" })
              : hoard.el("span", { class: "hp-card-avatar" }, [item.author_name.trim().charAt(0).toUpperCase()]),
            hoard.el("span", { class: "hp-card-name" }, [item.author_name]),
          ]),
        );
      }
      if (wide) {
        const caption = item.description?.trim();
        if (caption) text.push(hoard.el("p", { class: "hp-card-caption" }, [caption]));
        const tags = Array.isArray(item.metadata.tags) ? item.metadata.tags : [];
        if (tags.length > 0) {
          text.push(hoard.el("p", { class: "hp-card-tags" }, tags.map((tag) => hoard.el("span", { class: "hp-card-tag" }, [`#${tag.name}`]))));
        }
        card.append(hoard.el("div", { class: "hp-card-info" }, text));
      } else {
        card.append(...text);
      }
    }
    root.append(card);
  },
});

// ---- 插件設定：整批收藏的範圍 ----

/**
 * 改擷取器設定（`hoard.storage` 的 `extractor`）的一項。用 `storage.update` 一次讀改寫：
 * 快速連切兩個開關時，後一個不會蓋掉前一個。
 * @param {string} key @param {unknown} value
 */
function saveExtractorSetting(key, value) {
  return hoard.storage.update("extractor", (/** @type {Record<string, unknown> | undefined} */ saved) => ({ ...saved, [key]: value }));
}

/** 擷取器讀得到的設定（hoard.storage 的 extractor 鍵，見擷取器的 hoard.getSettings）。 */
hoard.registerSettingTab({
  label: "整批收藏",
  render(el) {
    const name = "hp-batch-scope";
    /** @param {string} value @param {string} label @param {string} hint */
    const option = (value, label, hint) =>
      hoard.el("label", { class: "hp-setting-option" }, [
        hoard.el("input", { type: "radio", name, value }),
        hoard.el("span", {}, [hoard.el("strong", {}, [label]), hoard.el("span", { class: "hp-setting-hint" }, [hint])]),
      ]);
    const options = [
      option("page", "只抓目前這一頁", "作者頁、收藏頁照網址的頁碼抓那 48 件，小說系列頁抓那 30 話。要更多就換頁再抓一次。"),
      option("all", "抓全部", "作者的全部作品、收藏的全部作品（自己的收藏頁連非公開的也抓），或小說系列的每一話。"),
    ];
    el.append(
      hoard.el("div", { class: "hp-setting" }, [
        hoard.el("p", { class: "hp-setting-title" }, ["在作者頁、收藏頁、小說系列頁按擴充的「抓取此頁」時要抓多少："]),
        ...options,
      ]),
    );
    const inputs = /** @type {HTMLInputElement[]} */ ([...el.querySelectorAll(`input[name="${name}"]`)]);
    void hoard.storage.get("extractor").then((saved) => {
      const scope = /** @type {{ batchScope?: string } | undefined} */ (saved)?.batchScope === "all" ? "all" : "page";
      for (const input of inputs) input.checked = input.value === scope;
    });
    for (const input of inputs) {
      input.addEventListener("change", async () => {
        if (!input.checked) return;
        await saveExtractorSetting("batchScope", input.value);
        hoard.toast(input.value === "all" ? "整批收藏會抓全部作品" : "整批收藏只抓目前這一頁");
      });
    }
  },
});

// ---- 插件設定：在網頁上的行為（擴充端用 page.settings 讀，每個網站有的動作不同） ----

/** @type {Array<{ key: string; label: string; hint: string; fallback: boolean }>} */
const PAGE_OPTIONS = [
  { key: "savedMarks", label: "已收藏的作品顯示 hoard 標記", hint: "縮圖左下角與作品頁「讚！」的左邊。", fallback: true },
  { key: "saveOnLike", label: "按「讚！」時一起收藏", hint: "作品頁的「讚！」。", fallback: false },
  { key: "saveOnBookmark", label: "加入收藏（愛心）時一起收藏", hint: "作品頁與縮圖上的愛心；取消收藏不會動到 hoard。", fallback: false },
  { key: "saveComments", label: "收藏時一起抓留言", hint: "含留言的回覆；關掉後收藏比較快，也少打幾次 Pixiv 的介面。", fallback: true },
];

hoard.registerSettingTab({
  label: "在網頁上",
  render(el) {
    const inputs = PAGE_OPTIONS.map((option) => {
      const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hp-switch" }));
      el.append(
        hoard.el("label", { class: "hp-setting-row" }, [
          hoard.el("span", {}, [hoard.el("strong", {}, [option.label]), hoard.el("span", { class: "hp-setting-hint" }, [option.hint])]),
          input,
        ]),
      );
      return { option, input };
    });
    el.append(hoard.el("p", { class: "hp-setting-hint" }, ["改完後重新整理網頁就生效，不用同步插件。"]));
    void hoard.storage.get("extractor").then((saved) => {
      const settings = /** @type {Record<string, unknown>} */ (saved ?? {});
      for (const { option, input } of inputs) input.checked = typeof settings[option.key] === "boolean" ? Boolean(settings[option.key]) : option.fallback;
    });
    for (const { option, input } of inputs) {
      input.addEventListener("change", async () => {
        await saveExtractorSetting(option.key, input.checked);
      });
    }
  },
});

// ---- 作者頭像：插件找網址、下載，交給核心存（創作者清單、創作者頁顯示） ----

// Pixiv 的圖不帶 Referer 會被擋。
const AVATAR_HEADERS = { Referer: "https://www.pixiv.net/" };

/**
 * 帳號的頭像網址：Pixiv 的使用者資料（不用登入，handle 是使用者 id）；沒設頭像的預設圖不算。
 * @param {HoardAuthor} author
 */
async function avatarUrl(author) {
  if (!author.handle) return null;
  const res = await hoard.fetch(`https://www.pixiv.net/ajax/user/${encodeURIComponent(author.handle)}`, {
    headers: AVATAR_HEADERS,
  });
  if (!res.ok) throw new Error(`使用者資料 HTTP ${res.status}`);
  const body = /** @type {any} */ (await res.json())?.body;
  const url = body?.imageBig || body?.image;
  return typeof url === "string" && url && !url.includes("no_profile") ? url : null;
}

/** 這次開 App 試過的帳號（抓到或失敗）不再試。 */
const avatarTried = new Set();
/** @type {Promise<void> | null} */
let avatarRun = null;
let avatarAgain = false;
let avatarStopped = false;
hoard.onUnload(() => {
  avatarStopped = true;
});

/** 替還沒有頭像的 Pixiv 帳號補上：一次一個、間隔一下；跑的時候又有新收藏就再跑一輪。 */
function fillAvatars() {
  if (avatarRun) {
    avatarAgain = true;
    return;
  }
  avatarRun = (async () => {
    do {
      avatarAgain = false;
      const authors = await hoard.authors.list({ source: "pixiv" });
      for (const author of authors) {
        if (avatarStopped) return;
        if (author.avatar_path || avatarTried.has(author.id)) continue;
        avatarTried.add(author.id);
        try {
          const url = await avatarUrl(author);
          if (!url) continue;
          const res = await hoard.fetch(url, { headers: AVATAR_HEADERS });
          if (!res.ok) throw new Error(`頭像 HTTP ${res.status}`);
          await hoard.authors.setAvatar(author.id, await res.arrayBuffer(), { source: url });
        } catch (err) {
          console.warn(`[pixiv] 抓不到 ${author.name} 的頭像：`, err);
        }
        await new Promise((resolve) => setTimeout(resolve, 1200));
      }
    } while (avatarAgain && !avatarStopped);
  })()
    .catch((err) => console.warn("[pixiv] 補頭像失敗：", err))
    .finally(() => {
      avatarRun = null;
    });
}

// 開 App 後先讓畫面載完再補；之後每有新收藏就補新的作者。
const avatarStart = setTimeout(fillAvatars, 8000);
hoard.onUnload(() => clearTimeout(avatarStart));
hoard.on("items-added", () => fillAvatars());

// ---- 從小說系列頁整批收的：放進以系列名為名的資料夾 ----

/** 一次只處理一批，免得同時建立兩個同名資料夾。 @type {Promise<unknown>} */
let seriesQueue = Promise.resolve();

/**
 * 擷取器替從系列頁收的小說記下 `collected_series`（系列名），這裡把它們放進同名的資料夾（全部收藏的最上層，沒有就建立），
 * 照話數排。已經收藏過、這次被跳過的話不會經過這裡，要的話自己拖進資料夾。
 * @param {HoardItemSummary[]} items
 */
async function fileBySeries(items) {
  const collected = items.filter((item) => typeof item.metadata.collected_series === "string" && item.metadata.collected_series.trim());
  if (collected.length === 0) return;
  const folders = await hoard.folders.list();
  /** @type {Map<string, HoardItemSummary[]>} */
  const bySeries = new Map();
  for (const item of collected) {
    const name = String(item.metadata.collected_series).trim();
    bySeries.set(name, [...(bySeries.get(name) ?? []), item]);
  }
  for (const [name, list] of bySeries) {
    // 全部收藏的資料夾（不屬於某個使用者頁面），名字一樣就用它。
    const folder =
      folders.find((f) => f.page_id === null && f.parent_id === null && f.name.toLowerCase() === name.toLowerCase()) ??
      (await hoard.folders.create(name));
    if (!folders.includes(folder)) folders.push(folder);
    list.sort((a, b) => (Number(a.metadata.volume) || 0) - (Number(b.metadata.volume) || 0));
    await hoard.folders.add(folder.id, list.map((item) => item.id));
  }
}

hoard.on("items-added", ({ ids }) => {
  seriesQueue = seriesQueue
    .then(async () => {
      const { items } = await hoard.items.list({ ids, source_type: "pixiv" }, { limit: ids.length });
      await fileBySeries(items);
    })
    .catch((err) => console.error("[pixiv] 放進系列資料夾失敗：", err));
});

// ---- 標籤自動匯入（預設關閉）：把 Pixiv 作品的標籤加進標籤庫，並貼到作品上 ----

/** Pixiv 的標籤（原文；翻譯只是顯示用）。 @param {HoardItemSummary} item @returns {string[]} */
function siteTagsOf(item) {
  const tags = Array.isArray(item.metadata.tags) ? item.metadata.tags : [];
  return tags.map((tag) => (tag && typeof tag.name === "string" ? tag.name.trim() : "")).filter(Boolean);
}

/**
 * 替這些作品加上網站的標籤；同一個標籤的作品合成一次呼叫，標籤庫沒有的由核心建立。
 * @param {HoardItemSummary[]} items
 */
async function importSiteTags(items) {
  /** @type {Map<string, number[]>} */
  const byName = new Map();
  for (const item of items) {
    for (const name of new Set(siteTagsOf(item))) {
      const ids = byName.get(name);
      if (ids) ids.push(item.id);
      else byName.set(name, [item.id]);
    }
  }
  for (const [name, ids] of byName) await hoard.items.addTags(ids, [name]);
}

hoard.on("items-added", async ({ ids }) => {
  if ((await hoard.storage.get("autoTags")) !== true) return;
  const { items } = await hoard.items.list({ ids, source_type: "pixiv" }, { limit: ids.length });
  if (items.length > 0) await importSiteTags(items);
});

/** 替已經收藏的作品補上；使用者打開開關時問過才做。 */
async function importAllSiteTags() {
  hoard.toast("正在替已收藏的 Pixiv 作品加上標籤…", { kind: "busy" });
  try {
    let done = 0;
    for (let offset = 0; ; offset += 200) {
      const { items } = await hoard.items.list({ source_type: "pixiv" }, { offset, limit: 200 });
      await importSiteTags(items);
      done += items.length;
      if (items.length < 200) break;
    }
    hoard.toast(`已替 ${done} 件 Pixiv 作品加上標籤`);
  } catch (err) {
    hoard.toast(`加標籤失敗：${err instanceof Error ? err.message : err}`, { kind: "error" });
  }
}

hoard.registerSettingTab({
  label: "標籤",
  render(el) {
    const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hp-switch" }));
    el.append(
      hoard.el("label", { class: "hp-setting-row" }, [
        hoard.el("span", {}, [
          hoard.el("strong", {}, ["自動匯入標籤"]),
          hoard.el("span", { class: "hp-setting-hint" }, ["收藏的 Pixiv 作品自動加上作品的標籤（原文），標籤庫沒有的會建立。預設關閉：標籤一多，標籤庫會變得很雜。"]),
        ]),
        input,
      ]),
    );
    void hoard.storage.get("autoTags").then((value) => (input.checked = value === true));
    input.addEventListener("change", async () => {
      await hoard.storage.set("autoTags", input.checked);
      if (!input.checked) return;
      const { total } = await hoard.items.list({ source_type: "pixiv" }, { limit: 1 });
      if (total > 0 && (await hoard.confirm(`也替已經收藏的 ${total} 件 Pixiv 作品加上標籤？`, { confirmLabel: "加上標籤" }))) {
        await importAllSiteTags();
      }
    });
  },
});
