// @ts-check
/// <reference path="../hoard-extractor.d.ts" />
/* Pixiv 擷取器：走官方 ajax API（/ajax/illust/{id}、/ajax/novel/{id}），在 pixiv.net 上呼叫才帶得到登入 cookie。
   原圖只給網址，由擴充背景下載（manifest 的 refererRules 會替 pximg 帶 Referer），交出去後重新整理分頁也不會中斷。
   動圖（ugoira）在頁面裡把分格的 zip 轉成動態 WebP；標籤只存文字當作品資訊。
   小說：本文照 Pixiv 的原文（含 [newpage]、[chapter:]、[[rb:]] 這些標記）存成 {id}.txt，App 端照標記還原分頁、章節與注音；
   封面與插圖另外存（插圖的檔名帶它在本文裡的標記，App 端靠它放回原位）。
   另外有：留言（含回覆）、作者作品與收藏的整批收藏（listCreatorPosts，單頁或全部看插件設定）、拖作品到左側投放區、
   已收藏作品上的 hoard 標記、按讚／加入收藏時自動收藏。 */

const ARTWORK_PATH = /\/artworks\/(\d+)/;

/** @param {string} id */
const canonicalUrl = (id) => `https://www.pixiv.net/artworks/${id}`;
/** @param {string} id */
const novelUrl = (id) => `https://www.pixiv.net/novel/show.php?id=${id}`;

/** @param {URL} url */
function artworkId(url) {
  const match = url.pathname.match(ARTWORK_PATH);
  return match ? match[1] : null;
}

/** 小說頁：/novel/show.php?id=123（網址可以帶語言前綴與 #頁碼）。 @param {URL} url */
function novelId(url) {
  if (!/^\/(?:[a-z]{2}\/)?novel\/show\.php$/.test(url.pathname)) return null;
  const id = url.searchParams.get("id");
  return id && /^\d+$/.test(id) ? id : null;
}

/** 作品（插畫、漫畫、動圖）或小說的正規網址；都不是時是 null。 @param {URL} url */
function workUrl(url) {
  const id = artworkId(url);
  if (id) return canonicalUrl(id);
  const novel = novelId(url);
  return novel ? novelUrl(novel) : null;
}

/** 連到作品或小說的連結。 */
const WORK_LINK = 'a[href*="/artworks/"], a[href*="novel/show.php?id="]';

/** @param {string} path */
async function pixivApi(path) {
  const res = await fetch(`https://www.pixiv.net${path}`, {
    credentials: "include",
    headers: { Accept: "application/json" },
  });
  if (res.status === 404) {
    /** @type {Error & { skipped?: boolean }} */
    const err = new Error("找不到這件作品（可能已刪除或不公開）");
    err.skipped = true;
    throw err;
  }
  if (!res.ok) throw new Error(`Pixiv API ${path} 回應 ${res.status}`);
  const json = await res.json();
  if (json.error) throw new Error(`Pixiv API 錯誤：${json.message}`);
  return json.body;
}

/** DOMParser 解析不會載入圖片或執行腳本（說明來自作品頁）。 @param {string} html */
function htmlToText(html) {
  const doc = new DOMParser().parseFromString((html ?? "").replace(/<br\s*\/?>/gi, "\n"), "text/html");
  return doc.body.textContent?.trim() ?? "";
}

/** Pixiv 的留言時間是日本時間的 "2026-08-08 12:20"，轉成 ISO；讀不懂時是 undefined。 @param {unknown} value */
function jstDate(value) {
  if (typeof value !== "string") return undefined;
  const match = value.match(/^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2})/);
  if (!match) return undefined;
  const date = new Date(`${match[1]}T${match[2]}:00+09:00`);
  return Number.isNaN(date.getTime()) ? undefined : date.toISOString();
}

// ---- 動圖（ugoira）：分格的 zip 轉成動態 WebP ----

/**
 * zip 裡的檔案（檔名 → 內容）。Pixiv 的動圖 zip 是不壓縮的（method 0）；壓縮過的用瀏覽器的 deflate-raw 解。
 * @param {Uint8Array} bytes @returns {Promise<Map<string, Uint8Array>>}
 */
async function unzip(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let end = -1;
  for (let i = bytes.length - 22; i >= 0; i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      end = i;
      break;
    }
  }
  if (end < 0) throw new Error("動圖的 zip 讀不懂");
  const files = new Map();
  const decoder = new TextDecoder();
  let at = view.getUint32(end + 16, true);
  for (let n = view.getUint16(end + 10, true); n > 0; n--) {
    const method = view.getUint16(at + 10, true);
    const size = view.getUint32(at + 20, true);
    const nameLength = view.getUint16(at + 28, true);
    const name = decoder.decode(bytes.subarray(at + 46, at + 46 + nameLength));
    const local = view.getUint32(at + 42, true);
    const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    const data = bytes.subarray(start, start + size);
    if (method === 0) {
      files.set(name, data);
    } else if (method === 8) {
      const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      files.set(name, new Uint8Array(await new Response(stream).arrayBuffer()));
    }
    at += 46 + nameLength + view.getUint16(at + 30, true) + view.getUint16(at + 32, true);
  }
  return files;
}

/** WebP 的 RIFF chunk：4 字元代號、little-endian 長度、內容，長度是奇數時補一個 0。 @param {string} fourcc @param {Uint8Array} payload */
function riffChunk(fourcc, payload) {
  const out = new Uint8Array(8 + payload.length + (payload.length % 2));
  out.set(new TextEncoder().encode(fourcc), 0);
  new DataView(out.buffer).setUint32(4, payload.length, true);
  out.set(payload, 8);
  return out;
}

/** @param {Uint8Array[]} parts */
function concatBytes(parts) {
  const out = new Uint8Array(parts.reduce((n, part) => n + part.length, 0));
  let at = 0;
  for (const part of parts) {
    out.set(part, at);
    at += part.length;
  }
  return out;
}

/** 24-bit little-endian。 @param {Uint8Array} out @param {number} at @param {number} value */
function put24(out, at, value) {
  out[at] = value & 0xff;
  out[at + 1] = (value >> 8) & 0xff;
  out[at + 2] = (value >> 16) & 0xff;
}

/**
 * 每一格是單張的 WebP，組成一個動態 WebP（VP8X + ANIM + 每格一個 ANMF）。
 * @param {Array<{ webp: Uint8Array; width: number; height: number; delay: number }>} frames
 */
function animatedWebp(frames) {
  const width = Math.max(...frames.map((f) => f.width));
  const height = Math.max(...frames.map((f) => f.height));
  let alpha = false;
  const anmf = frames.map((frame) => {
    // 單張 WebP 去掉 RIFF 標頭，只留影像資料（VP8／VP8L，有透明度時加 ALPH）。
    const view = new DataView(frame.webp.buffer, frame.webp.byteOffset, frame.webp.byteLength);
    const keep = [];
    for (let at = 12; at + 8 <= frame.webp.length; ) {
      const fourcc = new TextDecoder().decode(frame.webp.subarray(at, at + 4));
      const size = view.getUint32(at + 4, true);
      const total = 8 + size + (size % 2);
      if (fourcc === "VP8 " || fourcc === "VP8L" || fourcc === "ALPH") keep.push(frame.webp.subarray(at, at + total));
      if (fourcc === "ALPH" || fourcc === "VP8L") alpha = true;
      at += total;
    }
    const header = new Uint8Array(16);
    put24(header, 6, frame.width - 1);
    put24(header, 9, frame.height - 1);
    put24(header, 12, Math.max(frame.delay, 10));
    header[15] = 0b10; // 不和前一格混合（每格都是完整的畫面）
    return riffChunk("ANMF", concatBytes([header, ...keep]));
  });
  const vp8x = new Uint8Array(10);
  vp8x[0] = 0b10 | (alpha ? 0b10000 : 0); // 動畫、透明度
  put24(vp8x, 4, width - 1);
  put24(vp8x, 7, height - 1);
  const anim = new Uint8Array(6); // 背景色 0、無限循環
  const body = concatBytes([new TextEncoder().encode("WEBP"), riffChunk("VP8X", vp8x), riffChunk("ANIM", anim), ...anmf]);
  const riff = new Uint8Array(8);
  riff.set(new TextEncoder().encode("RIFF"), 0);
  new DataView(riff.buffer).setUint32(4, body.length, true);
  return concatBytes([riff, body]);
}

/**
 * 動圖：下載原尺寸的分格 zip，每格照 Pixiv 給的時間轉成一個動態 WebP。轉檔要用到畫布，所以在頁面裡做。
 * @param {string} id @param {(text: string) => void} progress @returns {Promise<HoardMediaPayload>}
 */
async function ugoiraMedia(id, progress) {
  const meta = await pixivApi(`/ajax/illust/${id}/ugoira_meta`);
  progress("下載動圖");
  const res = await fetch(meta.originalSrc || meta.src);
  if (!res.ok) throw new Error(`動圖下載失敗（${res.status}）`);
  const files = await unzip(new Uint8Array(await res.arrayBuffer()));
  const frames = [];
  for (const [i, frame] of meta.frames.entries()) {
    progress(`轉換動圖 ${i + 1}/${meta.frames.length}`);
    const data = files.get(frame.file);
    if (!data) continue;
    const bitmap = await createImageBitmap(new Blob([data], { type: meta.mime_type || "image/jpeg" }));
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    canvas.getContext("2d")?.drawImage(bitmap, 0, 0);
    const blob = await canvas.convertToBlob({ type: "image/webp", quality: 0.92 });
    if (blob.type !== "image/webp") throw new Error("這個瀏覽器不能輸出 WebP");
    frames.push({ webp: new Uint8Array(await blob.arrayBuffer()), width: bitmap.width, height: bitmap.height, delay: frame.delay });
    bitmap.close();
  }
  if (frames.length === 0) throw new Error("動圖沒有任何一格");
  return { filename: `${id}_ugoira.webp`, data: hoard.bytesToBase64(animatedWebp(frames).buffer) };
}

/**
 * 作品的標籤：原文與目前語言的翻譯（Pixiv 的翻譯放在 translation.en，實際是使用者設定的語言）。
 * @returns {Array<{ name: string; translation?: string }> | undefined}
 */
function tagsOf(meta) {
  const tags = (meta.tags?.tags ?? [])
    .filter((t) => typeof t.tag === "string" && t.tag)
    .map((t) => {
      const translation = t.translation?.en || Object.values(t.translation ?? {})[0];
      return translation && translation !== t.tag ? { name: t.tag, translation: String(translation) } : { name: t.tag };
    });
  return tags.length > 0 ? tags : undefined;
}

// ---- 留言 ----

/** @returns {HoardCommentPayload | null} */
function toComment(item) {
  // 貼圖留言沒有文字，只有 stampId。
  const content = item.stampId ? "（貼圖）" : String(item.comment ?? "").trim();
  if (!content) return null;
  return {
    author_name: item.userName || undefined,
    author_handle: item.userId ? String(item.userId) : undefined,
    content,
    posted_at: jstDate(item.commentDate),
  };
}

/** 作品與小說的留言各走各的端點，格式相同。 @typedef {"illusts" | "novels"} CommentKind */

/** 一則留言的回覆（最多 5 頁）。 @param {CommentKind} kind @param {string} commentId @returns {Promise<HoardCommentPayload[]>} */
async function fetchReplies(kind, commentId) {
  /** @type {HoardCommentPayload[]} */
  const replies = [];
  for (let page = 1; page <= 5; page++) {
    const body = await pixivApi(`/ajax/${kind}/comments/replies?comment_id=${commentId}&page=${page}`);
    for (const item of body?.comments ?? []) {
      const reply = toComment(item);
      if (reply) replies.push(reply);
    }
    if (!body?.hasNext) break;
  }
  // 回覆是新的在前，照時間順序排回來。
  return replies.reverse();
}

/**
 * 留言與回覆，最多 500 則。讀不到時記一個警告，收藏照常。
 * @param {CommentKind} kind @param {string} id @param {string[]} warnings @returns {Promise<HoardCommentPayload[]>}
 */
async function fetchComments(kind, id, warnings) {
  /** @type {HoardCommentPayload[]} */
  const comments = [];
  try {
    for (let offset = 0; offset < 500; offset += 50) {
      const target = kind === "novels" ? `novel_id=${id}` : `illust_id=${id}`;
      const body = await pixivApi(`/ajax/${kind}/comments/roots?${target}&offset=${offset}&limit=50`);
      for (const item of body?.comments ?? []) {
        const comment = toComment(item);
        if (!comment) continue;
        if (item.hasReplies) {
          try {
            comment.replies = await fetchReplies(kind, String(item.id));
          } catch {
            // 回覆讀不到不影響留言本身。
          }
        }
        comments.push(comment);
      }
      if (!body?.hasNext) break;
    }
  } catch (err) {
    warnings.push(`留言讀取失敗：${err instanceof Error ? err.message : String(err)}`);
  }
  return comments;
}

// ---- 作者作品、收藏：在這些頁面按彈出視窗的「抓取此頁」就整批收藏（只抓這一頁或全部，看插件設定） ----

/** Pixiv 的作者作品頁、收藏頁一頁 48 件。 */
const PAGE_SIZE = 48;

/**
 * 作者頁（/users/1/artworks、/illustrations、/manga、/novels）或收藏頁（/users/1/bookmarks/artworks?rest=hide、/bookmarks/novels）。
 * @param {URL} url
 */
function userPage(url) {
  const match = url.pathname.match(/^\/(?:[a-z]{2}\/)?users\/(\d+)(?:\/(bookmarks|artworks|illustrations|manga|novels)(?:\/(artworks|novels))?)?/);
  if (!match) return null;
  const bookmarks = match[2] === "bookmarks";
  return {
    userId: match[1],
    bookmarks,
    /** 作者頁只看插畫、只看漫畫或小說時；收藏頁是插畫（含漫畫）或小說。 */
    kind: bookmarks
      ? match[3] === "novels" ? "novels" : null
      : match[2] === "illustrations" ? "illusts" : match[2] === "manga" ? "manga" : match[2] === "novels" ? "novels" : null,
    page: Math.max(1, Number(url.searchParams.get("p")) || 1),
    rest: url.searchParams.get("rest") === "hide" ? "hide" : "show",
  };
}

/** 小說系列頁一頁 30 話。 */
const SERIES_PAGE_SIZE = 30;

/** 小說系列頁：/novel/series/123（?p=2 是第 2 頁）。 @param {URL} url */
function novelSeriesPage(url) {
  const match = url.pathname.match(/^\/(?:[a-z]{2}\/)?novel\/series\/(\d+)/);
  if (!match) return null;
  return { seriesId: match[1], page: Math.max(1, Number(url.searchParams.get("p")) || 1) };
}

/**
 * 小說系列頁的「抓取此頁」：照話數順序列出（series_content 從 last_order 之後讀 limit 話）。
 * 只抓這一頁時讀那 30 話，抓全部時一直讀到沒有下一批。
 * @param {{ seriesId: string; page: number }} series @param {boolean} all @param {HoardListContext} ctx
 * @returns {Promise<HoardCreatorListing>}
 */
async function listNovelSeries(series, all, ctx) {
  const info = await pixivApi(`/ajax/novel/series/${series.seriesId}`);
  /** @type {HoardListedPost[]} */
  const posts = [];
  for (let order = all ? 0 : (series.page - 1) * SERIES_PAGE_SIZE; ; order += SERIES_PAGE_SIZE) {
    ctx.progress(`讀取系列：${posts.length} 話`);
    const body = await pixivApi(`/ajax/novel/series_content/${series.seriesId}?limit=${SERIES_PAGE_SIZE}&last_order=${order}&order_by=asc`);
    const contents = body?.page?.seriesContents ?? [];
    for (const novel of contents) {
      // data 交給 extract()：從系列頁收的記下系列名，App 端把它們放進同名資料夾。
      if (novel?.id) posts.push({ url: novelUrl(String(novel.id)), title: novel.title || undefined, data: { series: info?.title || undefined } });
    }
    if (!all || contents.length < SERIES_PAGE_SIZE) break;
  }
  const where = all ? "" : `（第 ${series.page} 頁）`;
  return { creator: `${info?.userName ?? ""}《${info?.title ?? "小說系列"}》${where}`, posts };
}

/**
 * 作者頁、收藏頁的「抓取此頁」：插件設定（App 的插件設定頁）決定只抓目前這一頁，還是作者或收藏的全部。
 * @param {HoardListContext} ctx @returns {Promise<HoardCreatorListing>}
 */
async function listWorks(ctx) {
  const settings = await hoard.getSettings();
  const all = settings.batchScope === "all";
  // 作品頁是單篇，「抓取此頁」直接抓那一件，不會走到這裡。
  const series = novelSeriesPage(ctx.url);
  if (series) return listNovelSeries(series, all, ctx);
  const page = userPage(ctx.url);
  if (!page) throw new Error("請在作者頁、作者的收藏頁或小說系列頁使用");
  const user = await pixivApi(`/ajax/user/${page.userId}`);
  const where = all ? "" : `（第 ${page.page} 頁）`;

  if (page.bookmarks) {
    const novels = page.kind === "novels";
    /** @type {HoardListedPost[]} */
    const posts = [];
    /** @param {string} rest @param {number} offset @param {number} limit */
    const read = async (rest, offset, limit) => {
      const body = await pixivApi(`/ajax/user/${page.userId}/${novels ? "novels" : "illusts"}/bookmarks?tag=&offset=${offset}&limit=${limit}&rest=${rest}`);
      const works = body?.works ?? [];
      for (const work of works) {
        // 已刪除或不公開的作品還留在收藏裡，但點不開。
        const id = String(work.id);
        posts.push({ url: novels ? novelUrl(id) : canonicalUrl(id), title: work.title || undefined, unavailable: Boolean(work.isMasked) });
      }
      return works.length;
    };
    if (all) {
      // 自己的收藏頁也讀非公開的（rest=hide）；別人的只讀得到公開的。
      for (const rest of ["show", "hide"]) {
        try {
          for (let offset = 0; ; offset += 100) {
            ctx.progress(`讀取收藏：${posts.length} 件`);
            if ((await read(rest, offset, 100)) < 100) break;
          }
        } catch (err) {
          if (rest === "show") throw err;
        }
      }
    } else {
      await read(page.rest, (page.page - 1) * PAGE_SIZE, PAGE_SIZE);
    }
    return { creator: `${user.name} 的${novels ? "小說" : ""}收藏${where}`, posts };
  }

  ctx.progress("讀取作品清單…");
  const works = await pixivApi(`/ajax/user/${page.userId}/profile/all`);
  if (page.kind === "novels") {
    const ids = Object.keys(works?.novels ?? {}).sort((a, b) => Number(b) - Number(a));
    const listed = all ? ids : ids.slice((page.page - 1) * PAGE_SIZE, page.page * PAGE_SIZE);
    return { creator: `${user.name} 的小說${where}`, posts: listed.map((id) => ({ url: novelUrl(id) })) };
  }
  const ids = [
    ...(page.kind === "manga" ? [] : Object.keys(works?.illusts ?? {})),
    ...(page.kind === "illusts" ? [] : Object.keys(works?.manga ?? {})),
  ];
  // 新的在前，跟作者頁一樣；單頁模式取目前這一頁的 48 件。
  ids.sort((a, b) => Number(b) - Number(a));
  const listed = all ? ids : ids.slice((page.page - 1) * PAGE_SIZE, page.page * PAGE_SIZE);
  return { creator: `${user.name}${where}`, posts: listed.map((id) => ({ url: canonicalUrl(id) })) };
}

// ---- 拖曳收藏：投放區由擴充提供，這裡只說拖的是哪件作品 ----

/**
 * 拖曳中的作品網址：拖縮圖時是作品或小說連結，拖作品頁的大圖時是圖片網址（檔名開頭是作品編號，例如 146694363_p0.jpg）。
 * @param {DataTransfer} dt
 */
function draggedArtworkUrl(dt) {
  for (const line of (dt.getData("text/uri-list") || dt.getData("text/plain") || "").split(/\r?\n/)) {
    try {
      const url = new URL(line.trim(), location.href);
      const work = workUrl(url);
      if (work) return work;
      const id = url.pathname.match(/\/(\d+)_(?:p\d+|ugoira)/)?.[1];
      if (id) return canonicalUrl(id);
    } catch {
      // 不是網址
    }
  }
  return null;
}

/** 目前在作品頁或小說頁時是這件作品。 */
function pageArtwork() {
  return workUrl(new URL(location.href));
}

/**
 * 拖作品、小說的縮圖（連到作品頁）或作品頁的大圖時收整件作品；其他圖片（頭像、廣告）交給擴充只存那一張。
 * @param {DragEvent} event
 * @returns {HoardDragCapture | null}
 */
function dragCapture(event) {
  if (!(event.target instanceof Element)) return null;
  const thumb = event.target.closest(WORK_LINK);
  // 作品頁的大圖連到原圖，不是作品頁，用目前網址判斷。
  const onArtworkPage = pageArtwork() !== null && event.target.closest("img");
  if (!thumb && !onArtworkPage) return null;
  return {
    element: thumb,
    resolve: (dt) => (dt ? draggedArtworkUrl(dt) : null) ?? pageArtwork(),
  };
}

// ---- 已收藏的標記與按讚／收藏時自動收藏 ----

/**
 * 已經收進 hoard 的作品常駐顯示 hoard 的 logo（縮圖左下角、作品頁的「讚！」左邊）。
 * 還沒收的不顯示：收藏用拖曳、按讚或加入收藏。
 */
const MARK_STYLE = `
  [data-hoard-thumb] {
    position: absolute; left: 4px; bottom: 4px; z-index: 5;
    border-radius: 999px; background: rgb(255 255 255 / 0.92);
  }
  [data-hoard-work] { align-items: center; margin-right: 8px; }
  [data-hoard-thumb]:not([data-saved]), [data-hoard-work]:not([data-saved]) { display: none; }
  [data-hoard-thumb][data-saved], [data-hoard-work][data-saved] { display: flex; }
`;

/** 縮圖的方塊（裡面有作品連結與圖片）；不在縮圖裡是 null。 @param {Element} el */
function thumbBoxOf(el) {
  for (let box = el; box && box !== document.body; box = box.parentElement) {
    if (box.querySelector('a[href*="/artworks/"] img, a[href*="novel/show.php?id="] img')) return box;
  }
  return null;
}

/** @param {Element} box */
function thumbUrl(box) {
  const href = box.querySelector(WORK_LINK)?.getAttribute("href");
  return href ? workUrl(new URL(href, location.href)) : null;
}

/** 標記的 holder → 它的作品網址，用來重查收藏狀態。 @type {WeakMap<Element, string>} */
const markUrls = new WeakMap();

/** @param {HoardPage} page @param {Element} holder */
function refreshMark(page, holder) {
  const url = markUrls.get(holder);
  if (!url) return;
  void page.isSaved(url).then((saved) => {
    if (saved) holder.setAttribute("data-saved", "");
    else holder.removeAttribute("data-saved");
  });
}

/**
 * @param {HoardPage} page @param {string} url @param {Element | null} element
 * @param {string} attribute @param {number} size
 */
function createMark(page, url, element, attribute, size) {
  const holder = document.createElement("div");
  holder.setAttribute(attribute, "");
  // 用擴充的收藏按鈕：已收藏時是 logo 加綠色勾勾，按了會重新檢查。
  holder.append(page.createButton(url, element, { size, color: "#111" }));
  markUrls.set(holder, url);
  refreshMark(page, holder);
  return holder;
}

/** 縮圖：每個縮圖的收藏愛心外層都有 data-ga4-label="bookmark_button"。 @param {HoardPage} page */
function mountThumbMarks(page) {
  for (const heart of document.querySelectorAll('[data-ga4-label="bookmark_button"]')) {
    const box = thumbBoxOf(heart);
    if (!box || box.querySelector("[data-hoard-thumb]")) continue;
    const url = thumbUrl(box);
    if (url) box.append(createMark(page, url, box, "data-hoard-thumb", 28));
  }
}

/** 作品頁的「讚！」按鈕。 */
function likeButton() {
  return [...document.querySelectorAll("main button, section button")].find((b) =>
    /^(讚！|いいね！|Like!?|좋아요!?|赞！)$/.test(b.textContent?.trim() ?? ""),
  );
}

/** @param {HoardPage} page */
function mountWorkMark(page) {
  const url = pageArtwork();
  const like = likeButton();
  if (!url || !like?.parentElement || like.parentElement.querySelector("[data-hoard-work]")) return;
  like.before(createMark(page, url, null, "data-hoard-work", 32));
}

/** @param {HoardPage} page */
function installSavedMarks(page) {
  const style = document.createElement("style");
  style.textContent = MARK_STYLE;
  document.head.append(style);
  const marks = () => document.querySelectorAll("[data-hoard-thumb], [data-hoard-work]");
  // 頁面隨時重繪，用 MutationObserver 補標記（每幀最多掃一次）。
  let scheduled = false;
  const scan = () => {
    scheduled = false;
    if (page.settings.savedMarks === false) {
      for (const el of marks()) el.remove();
      return;
    }
    mountThumbMarks(page);
    mountWorkMark(page);
  };
  new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(scan);
  }).observe(document.body, { childList: true, subtree: true });
  scan();
  // 剛收進來的（拖曳、按讚、收藏、彈出視窗）過一下就出現標記；查詢有快取，很便宜。
  setInterval(() => {
    for (const holder of marks()) refreshMark(page, holder);
  }, 2000);
}

/**
 * 按讚（插件設定「在網頁上」的 saveOnLike）或加入收藏（saveOnBookmark）時一起收進 hoard：
 * 作品頁的「讚！」與愛心、縮圖上的愛心。已經在 hoard 裡的不再收（取消收藏時也不會動 hoard）。
 * @param {HoardPage} page
 */
function installAutoSave(page) {
  document.addEventListener(
    "click",
    (event) => {
      if (!(event.target instanceof Element)) return;
      const like = likeButton();
      const isLike = like?.contains(event.target) && !(/** @type {HTMLButtonElement} */ (like).disabled);
      const bookmark =
        event.target.closest('a[href*="bookmark_add.php"]') ?? event.target.closest('[data-ga4-label="bookmark_button"]');
      if (isLike ? page.settings.saveOnLike !== true : !bookmark || page.settings.saveOnBookmark !== true) return;
      const box = bookmark && !bookmark.matches('a[href*="bookmark_add.php"]') ? thumbBoxOf(bookmark) : null;
      const url = box ? thumbUrl(box) : pageArtwork();
      if (!url) return;
      void page.isSaved(url).then((saved) => {
        if (!saved) void page.capture(url, box);
      });
    },
    true,
  );
}

// ---- 小說：本文照原文存成文字檔，封面、插圖另外存 ----

/** 本文裡的插圖標記：[uploadedimage:123]（作者上傳的）、[pixivimage:456] 或 [pixivimage:456-2]（引用 Pixiv 作品的第幾張）。 */
const NOVEL_IMAGE = /\[(uploadedimage|pixivimage):(\d+(?:-\d+)?)\]/g;

/** 網址最後一段的副檔名，讀不到時是 jpg。 @param {string} url */
const extOf = (url) => url.match(/\.(\w+)(?:\?.*)?$/)?.[1]?.toLowerCase() ?? "jpg";

/**
 * 本文裡每個插圖標記的原圖網址。檔名是 `{作品id}_{種類}-{標記的值}.{副檔名}`，App 端靠檔名把圖放回標記的位置。
 * 引用的作品讀不到（已刪除、不公開）時略過，App 端在原位放佔位。
 * @param {string} id @param {any} meta @param {string[]} warnings @returns {Promise<HoardRemoteMedia[]>}
 */
async function novelImages(id, meta, warnings) {
  /** @type {HoardRemoteMedia[]} */
  const media = [];
  /** @type {Set<string>} */
  const seen = new Set();
  /** @type {string[]} */
  const illusts = [];
  for (const [, kind, value] of meta.content.matchAll(NOVEL_IMAGE)) {
    const key = `${kind}-${value}`;
    if (seen.has(key)) continue;
    seen.add(key);
    if (kind === "pixivimage") {
      illusts.push(value);
      continue;
    }
    const url = meta.textEmbeddedImages?.[value]?.urls?.original;
    if (url) media.push({ url, filename: `${id}_${key}.${extOf(url)}` });
  }
  // 引用的作品一次查一批（insert_illusts 照標記的值回傳，例如 "456-2"）。
  for (let at = 0; at < illusts.length; at += 50) {
    const batch = illusts.slice(at, at + 50);
    try {
      const body = await pixivApi(`/ajax/novel/${id}/insert_illusts?${batch.map((v) => `id%5B%5D=${encodeURIComponent(v)}`).join("&")}`);
      for (const value of batch) {
        const url = body?.[value]?.illust?.images?.original;
        if (typeof url === "string" && url) media.push({ url, filename: `${id}_pixivimage-${value}.${extOf(url)}` });
      }
    } catch (err) {
      warnings.push(`插圖讀取失敗：${err instanceof Error ? err.message : String(err)}`);
    }
  }
  return media;
}

/**
 * 小說：本文（含 Pixiv 的排版標記）存成 `{id}.txt`，封面排第一（卡片用它），插圖在後面。
 * @param {string} id @param {HoardExtractContext} ctx @returns {Promise<HoardExtractResult>}
 */
async function extractNovel(id, ctx) {
  ctx.progress("讀取小說");
  const meta = await pixivApi(`/ajax/novel/${id}`);
  if (typeof meta?.content !== "string") throw new Error("讀不到小說的本文，Pixiv 的介面可能改版了");
  /** @type {string[]} */
  const warnings = [];
  /** @type {Array<HoardMediaPayload | HoardRemoteMedia>} */
  const media = [];
  if (typeof meta.coverUrl === "string" && meta.coverUrl) media.push({ url: meta.coverUrl, filename: `${id}_cover.${extOf(meta.coverUrl)}` });
  media.push({ filename: `${id}.txt`, data: hoard.bytesToBase64(new TextEncoder().encode(meta.content).buffer) });
  ctx.progress("讀取插圖");
  media.push(...(await novelImages(id, meta, warnings)));

  ctx.progress("讀取留言");
  const saveComments = (await hoard.getSettings()).saveComments !== false;
  const comments = saveComments && meta.commentCount > 0 ? await fetchComments("novels", id, warnings) : [];

  return {
    payload: {
      source_type: "pixiv",
      source_url: novelUrl(id),
      title: meta.title,
      description: htmlToText(meta.description),
      author: {
        name: meta.userName,
        handle: meta.userId,
        url: `https://www.pixiv.net/users/${meta.userId}`,
      },
      published_at: meta.createDate,
      metadata: {
        work_type: "novel",
        series: meta.seriesNavData?.title,
        volume: meta.seriesNavData?.order,
        // 本文的頁數（[newpage] 分開的頁）。
        page_count: meta.content.split("[newpage]").length,
        character_count: meta.characterCount,
        word_count: meta.wordCount,
        reading_time: meta.readingTime,
        language: meta.language || undefined,
        // 從小說系列頁整批收的：系列名（App 端放進同名資料夾）。單篇收的沒有。
        collected_series: /** @type {{ series?: string } | undefined} */ (ctx.listing?.data)?.series,
        bookmark_count: meta.bookmarkCount,
        like_count: meta.likeCount,
        view_count: meta.viewCount,
        tags: tagsOf(meta),
      },
      media,
      comments: comments.length > 0 ? comments : undefined,
    },
    warnings,
  };
}

hoard.registerExtractor({
  sourceType: "pixiv",

  dragCapture,

  integrate(page) {
    installSavedMarks(page);
    installAutoSave(page);
  },

  sourceUrl(url) {
    return workUrl(url);
  },

  listCreatorPosts: listWorks,

  async extract(ctx) {
    const novel = novelId(ctx.url);
    if (novel) return extractNovel(novel, ctx);
    const id = artworkId(ctx.url);
    if (!id) throw new Error("無法從網址取得作品 ID");
    ctx.progress("讀取作品資料");
    const [meta, pages] = await Promise.all([pixivApi(`/ajax/illust/${id}`), pixivApi(`/ajax/illust/${id}/pages`)]);

    /** @type {string[]} */
    const warnings = [];
    // 原圖只給網址，由擴充背景下載：交出去之後重新整理或關掉分頁，收藏也會完成。
    /** @type {Array<HoardMediaPayload | HoardRemoteMedia>} */
    let media = pages.map((p) => ({ url: p.urls.original }));
    if (meta.illustType === 2) {
      try {
        media = [await ugoiraMedia(id, ctx.progress)];
      } catch (err) {
        warnings.push(`動圖轉檔失敗，只存第一格：${err instanceof Error ? err.message : String(err)}`);
      }
    }
    ctx.progress("讀取留言");
    const saveComments = (await hoard.getSettings()).saveComments !== false;
    const comments = saveComments && meta.commentCount > 0 ? await fetchComments("illusts", id, warnings) : [];

    return {
      payload: {
        source_type: "pixiv",
        source_url: canonicalUrl(id),
        title: meta.illustTitle,
        description: htmlToText(meta.description),
        author: {
          name: meta.userName,
          handle: meta.userId,
          url: `https://www.pixiv.net/users/${meta.userId}`,
        },
        published_at: meta.createDate,
        metadata: {
          series: meta.seriesNavData?.title,
          // 系列裡的第幾話：閱讀器與書架的「下一話」照它排。
          volume: meta.seriesNavData?.order,
          // illustType 1 是漫畫：閱讀器預設由右至左雙頁。
          work_type: meta.illustType === 1 ? "manga" : meta.illustType === 0 ? "illust" : meta.illustType === 2 ? "ugoira" : undefined,
          page_count: meta.pageCount,
          bookmark_count: meta.bookmarkCount,
          like_count: meta.likeCount,
          view_count: meta.viewCount,
          // 標籤只當作品資訊（詳情頁照 Pixiv 顯示），不會變成 hoard 的標籤。
          tags: tagsOf(meta),
        },
        media,
        comments: comments.length > 0 ? comments : undefined,
      },
      warnings,
    };
  },
});
