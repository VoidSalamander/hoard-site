// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 網頁插件在沙盒框架裡的腳本（app.js 用 hoard.mountFrame 的 script 指定），每一頁都比網頁自己的程式先跑。
 * 網頁的程式看得到 hoardFrame、也送得出同樣的訊息，所以 app.js 把收到的一律當成網頁的內容。
 *  - 數被擋下的網路資源與沒有執行的程式，告訴詳情頁。
 *  - 快速預覽的 ↑ ↓、PageUp／PageDown、Home／End（焦點在 App 時）捲網頁。
 *  - 背景分析要封面時，交出程式畫好之後的網頁（HTML）。
 */
(() => {
  "use strict";
  /** 這個框架自己的網址開頭：底下的不是網路上的資源。 */
  const own = `${location.protocol}//${location.host}/`;
  /** @type {Set<string>} */
  const seen = new Set();
  let network = 0;
  let scripts = 0;
  /** @type {ReturnType<typeof setTimeout> | undefined} */
  let timer;
  const report = () => {
    timer = undefined;
    hoardFrame.send({ kind: "blocked", network, scripts });
  };
  document.addEventListener(
    "securitypolicyviolation",
    (event) => {
      const uri = event.blockedURI;
      if (/^(https?|wss?|ftp):/i.test(uri) && !uri.startsWith(own)) {
        if (seen.has(uri)) return;
        seen.add(uri);
        network++;
      } else if (event.effectiveDirective.startsWith("script-src")) {
        scripts++;
      } else {
        return;
      }
      timer ??= setTimeout(report, 200);
    },
    true,
  );
  // 每一頁都回報一次（換頁時數字歸零）。
  window.addEventListener("load", () => {
    timer ??= setTimeout(report, 0);
  });

  /** @type {Record<string, () => number>} */
  const steps = {
    ArrowDown: () => 60,
    ArrowUp: () => -60,
    PageDown: () => window.innerHeight * 0.9,
    PageUp: () => -window.innerHeight * 0.9,
  };

  hoardFrame.on((message) => {
    if (!message || typeof message !== "object") return;
    const { kind, key } = /** @type {{ kind?: unknown; key?: unknown }} */ (message);
    if (kind === "scroll" && typeof key === "string") {
      if (Object.hasOwn(steps, key)) window.scrollBy({ top: steps[key]() });
      else if (key === "Home") window.scrollTo({ top: 0 });
      else if (key === "End") window.scrollTo({ top: (document.scrollingElement ?? document.documentElement).scrollHeight });
    } else if (kind === "snapshot") {
      const root = document.documentElement;
      hoardFrame.send({ kind: "snapshot", html: root ? (document.doctype ? "<!doctype html>" : "") + root.outerHTML : "" });
    }
  });
})();
