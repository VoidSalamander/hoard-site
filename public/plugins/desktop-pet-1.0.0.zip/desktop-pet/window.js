// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 桌寵的浮動視窗：畫小龍「囤囤」、接拖曳收藏、舉著抽到的圖片。查作品都交給 app.js（hoardWindow.send）。
 *
 *  - 角色是 16×15 的像素圖，畫在 canvas 上再用最近鄰放大（CSS image-rendering: pixelated）。
 *  - 狀態：待機（呼吸、偶爾眨眼）、有東西拖過來時張嘴、收下時咀嚼後開心、沒收到時歪頭、舉著圖片。
 *  - 住在地上（螢幕工作區的底部，工作列上面）：按住角色拖動是把牠提起來，放開會掉回地上；
 *    閒著時偶爾左右走幾步。只點一下是抽一張圖。
 *  - 使用者在瀏覽器開始拖可以收藏的東西時（hoardWindow.onBrowserDrag），牠會跑到游標底下等著接。
 *  - 走路是移動整個視窗（hoardWindow.moveTo），面向左邊時把畫面左右翻過來。
 */

// ---- 像素圖 ----

/** 調色盤：o 輪廓、t 身體、l 亮面、y 肚子、c 角、k 眼睛與嘴、w 眼睛的反光、p 臉頰。 */
const PALETTE = {
  o: "#1f2a30",
  t: "#0c8599",
  l: "#3bc9db",
  y: "#ffd43b",
  c: "#ffe8a3",
  k: "#111418",
  w: "#ffffff",
  p: "#ff8fab",
};

/** 待機的樣子，其他表情只換幾列。 */
const BASE = [
  "....c......c....",
  "...oco....oco...",
  "...oooooooooo...",
  "..otllttttttto..",
  ".otltttttttttto.",
  ".otkwttttttkwto.",
  ".otkkttttttkkto.",
  ".otptttootttpto.",
  ".otttyyyyyyttto.",
  ".otyyyyyyyyyyto.",
  ".otyyyyyyyyyyto.",
  ".ottyyyyyyyytto.",
  "..otttttttttto..",
  "...oto....oto...",
  "...ooo....ooo...",
];

/** @param {Record<number, string>} rows */
const face = (rows) => BASE.map((row, i) => rows[i] ?? row);

const EYES_CLOSED = { 5: ".otttttttttttto.", 6: ".otoottttttooto." };
const MOUTH_OPEN = { 7: ".otptttkktttpto.", 8: ".otttyykkyyttto." };

const FRAMES = {
  idle: BASE,
  blink: face(EYES_CLOSED),
  open: face(MOUTH_OPEN),
  chomp: face({ ...EYES_CLOSED, ...MOUTH_OPEN }),
  happy: face(EYES_CLOSED),
  /** 沒收到：眼睛看一邊。 */
  huh: face({ 5: ".otwkttttttwkto." }),
  /** 走路（面向右邊；向左時整個翻過來）：眼睛看前面，兩隻腳輪流抬起來。 */
  walkA: face({ 5: ".otwkttttttwkto.", 13: "...ooo....oto...", 14: "..........ooo..." }),
  walkB: face({ 5: ".otwkttttttwkto.", 13: "...oto....ooo...", 14: "...ooo.........." }),
  /** 被提起來：嚇一跳張著嘴。 */
  carried: face({ 5: ".otwkttttttwkto.", ...MOUTH_OPEN }),
};

const WIDTH = 16;
const HEIGHT = BASE.length;

/** @param {CanvasRenderingContext2D} ctx @param {string[]} frame */
function draw(ctx, frame) {
  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  frame.forEach((row, y) => {
    [...row].forEach((ch, x) => {
      const color = PALETTE[/** @type {keyof typeof PALETTE} */ (ch)];
      if (!color) return;
      ctx.fillStyle = color;
      ctx.fillRect(x, y, 1, 1);
    });
  });
}

// ---- 畫面 ----

const stage = document.createElement("div");
stage.className = "stage";

const bubble = document.createElement("div");
bubble.className = "bubble";
bubble.hidden = true;
const picture = document.createElement("img");
picture.className = "picture";
picture.draggable = false;
picture.alt = "";
const closeButton = document.createElement("button");
closeButton.className = "close";
closeButton.title = "放下";
closeButton.textContent = "×";
const empty = document.createElement("div");
empty.className = "empty";
empty.textContent = "這裡沒有圖片";
empty.hidden = true;
bubble.append(picture, empty, closeButton);

/** 翻面用的外框（canvas 自己的 transform 給呼吸動畫用）。 */
const body = document.createElement("div");
body.className = "body";
const canvas = document.createElement("canvas");
canvas.className = "pet";
body.append(canvas);
canvas.width = WIDTH;
canvas.height = HEIGHT;
const ctx = /** @type {CanvasRenderingContext2D} */ (canvas.getContext("2d"));

stage.append(bubble, body);
document.body.append(stage);

/** @param {number} scale */
function applyScale(scale) {
  canvas.style.width = `${WIDTH * scale}px`;
  canvas.style.height = `${HEIGHT * scale}px`;
}
applyScale(4);

// ---- 表情 ----

/** 目前的表情；"walk" 是走路中（兩格輪流，見 step）。 @type {keyof typeof FRAMES | "walk"} */
let mood = "idle";
let moodTimer = 0;

/**
 * 換表情；給了 ms 就在那之後回到待機。
 * @param {keyof typeof FRAMES} next @param {number} [ms]
 */
function setMood(next, ms) {
  mood = next;
  draw(ctx, FRAMES[next]);
  canvas.dataset.mood = next;
  clearTimeout(moodTimer);
  if (ms) moodTimer = window.setTimeout(() => setMood("idle"), ms);
}
setMood("idle");

// 待機時偶爾眨眼。
(function blinkLater() {
  window.setTimeout(() => {
    if (mood === "idle") {
      draw(ctx, FRAMES.blink);
      window.setTimeout(() => mood === "idle" && draw(ctx, FRAMES.idle), 140);
    }
    blinkLater();
  }, 2500 + Math.random() * 3500);
})();

/** 咀嚼幾下，最後開心或歪頭。 @param {boolean} gotIt */
function chew(gotIt) {
  let n = 0;
  clearTimeout(moodTimer);
  const step = () => {
    draw(ctx, n % 2 ? FRAMES.open : FRAMES.chomp);
    if (++n < 5) moodTimer = window.setTimeout(step, 110);
    else setMood(gotIt ? "happy" : "huh", 1400);
  };
  mood = "chomp";
  step();
}

// ---- 拖曳收藏 ----

void hoardWindow.setDropTarget(true);

let dragDepth = 0;
document.addEventListener("dragenter", (event) => {
  event.preventDefault();
  if (dragDepth++ === 0) setMood("open");
});
document.addEventListener("dragover", (event) => {
  event.preventDefault();
  if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
});
document.addEventListener("dragleave", () => {
  if (--dragDepth <= 0) {
    dragDepth = 0;
    if (mood === "open") setMood("idle");
  }
});
document.addEventListener("drop", (event) => {
  event.preventDefault();
  dragDepth = 0;
  // 接到了就不再追（瀏覽器那邊的拖曳結束通知稍後才到）。
  if (motion === "chase") motion = "stand";
  const taken = hoardWindow.takeDrop(event);
  setMood("chomp");
  void taken.then((result) => chew(result.kind !== "none"));
});

// ---- 點一下抽圖、按住拖動搬家 ----

/** @type {{ id: number } | null} */
let holding = null;

function askForImage() {
  hoardWindow.send({ type: "random", except: holding?.id ?? null });
}

/**
 * 按下後移動超過幾像素就是拖曳（onDrag，拿到按下時的事件），否則放開時是點一下（onClick）。
 * @param {HTMLElement} el @param {() => void} onClick @param {(down: PointerEvent) => void} onDrag
 */
function pressable(el, onClick, onDrag) {
  el.addEventListener("pointerdown", (down) => {
    if (down.button !== 0) return;
    const move = (/** @type {PointerEvent} */ e) => {
      if (Math.hypot(e.clientX - down.clientX, e.clientY - down.clientY) < 4) return;
      done();
      onDrag(down);
    };
    const up = () => {
      done();
      onClick();
    };
    const done = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
  });
}

pressable(canvas, askForImage, carry);

// 圖片：點一下換一張、雙擊開詳情頁、拖出去變成檔案。
let clickTimer = 0;
pressable(
  picture,
  () => {
    clearTimeout(clickTimer);
    clickTimer = window.setTimeout(askForImage, 260);
  },
  () => {
    if (holding) void hoardWindow.dragOut([holding.id]);
  },
);
picture.addEventListener("dblclick", () => {
  clearTimeout(clickTimer);
  if (!holding) return;
  void hoardWindow.showApp();
  hoardWindow.send({ type: "open", id: holding.id });
});

closeButton.addEventListener("click", () => {
  holding = null;
  bubble.hidden = true;
  setMood("idle");
});

/** @param {{ id: number; title: string; src: string } | null} item */
function hold(item) {
  bubble.hidden = false;
  holding = item ? { id: item.id } : null;
  picture.hidden = !item;
  empty.hidden = !!item;
  if (item) {
    picture.src = item.src;
    picture.title = `${item.title}\n點一下換一張，雙擊在 hoard 打開，拖出去變成檔案`;
    setMood("happy", 900);
  } else setMood("huh", 1400);
}

// ---- 在地上走：位置、掉落、走路、追著拖曳跑 ----

/** 每秒幾像素：閒逛、跑去接東西；重力是每秒平方幾像素。 */
const WALK_SPEED = 55;
const RUN_SPEED = 460;
const GRAVITY = 2600;
/** 走路時換腳的間隔（毫秒）。 */
const STEP_MS = { walk: 220, run: 110 };

/** 視窗在桌面上的左上角（邏輯像素）。都是自己移動時順手記下的，不必每次問。 */
const at = { x: 0, y: 0 };
/** 目前螢幕的工作區（扣掉工作列），底部就是地面。 @type {{ x: number; y: number; width: number; height: number } | null} */
let area = null;

/**
 * 現在在做什麼：站著、掉下來、被提著、閒逛（往 target 走）、跑去接拖曳。
 * @type {"stand" | "fall" | "carry" | "walk" | "chase"}
 */
let motion = "stand";
let velocity = 0;
/** 閒逛的目的地（視窗的 x）。 */
let target = 0;
/** 1 面向右，-1 面向左。 */
let facing = 1;
let stepAt = 0;
let stepFrame = false;
/** 瀏覽器裡正在拖可以收藏的東西。 */
let browserDragging = false;
/** 游標在桌面上的 x，追的時候每隔一下問一次。 */
let cursorX = 0;
let cursorAsked = 0;

const ground = () => (area ? area.y + area.height - window.innerHeight : at.y);
/** 視窗的 x 留在螢幕裡。 @param {number} x */
const clampX = (x) => (area ? Math.min(Math.max(x, area.x), area.x + area.width - window.innerWidth) : x);

/** 移動視窗；上一次還沒做完就只送最新的位置。 */
let moving = false;
let pendingMove = false;
function place() {
  if (moving) {
    pendingMove = true;
    return;
  }
  moving = true;
  void hoardWindow.moveTo(at.x, at.y).finally(() => {
    moving = false;
    if (pendingMove) {
      pendingMove = false;
      place();
    }
  });
}

/** 轉向；向左時把畫面左右翻過來。 @param {number} dir */
function turn(dir) {
  if (dir === 0 || dir === facing) return;
  facing = dir;
  body.classList.toggle("left", facing < 0);
}

async function refreshArea() {
  area = (await hoardWindow.screen()) ?? area;
}

/** 放開或一開始不在地上：掉下去。 */
function fall() {
  motion = "fall";
  velocity = 0;
  setMood("carried");
}

/** 落地：壓扁一下，回到站著（瀏覽器還在拖的話接著跑過去）。 */
function land() {
  at.y = ground();
  place();
  body.classList.remove("landed");
  void body.offsetWidth;
  body.classList.add("landed");
  // 壓扁的動畫只播一次，之後回到呼吸。
  window.setTimeout(() => body.classList.remove("landed"), 260);
  setMood("idle");
  motion = browserDragging ? "chase" : "stand";
}

/**
 * 按住角色拖動：把牠提起來跟著游標，放開就掉下去。
 * 自己移動視窗（不用 startMove），才知道什麼時候放開。
 * @param {PointerEvent} down
 */
function carry(down) {
  motion = "carry";
  setMood("carried");
  body.classList.add("held");
  const offsetX = down.screenX - at.x;
  const offsetY = down.screenY - at.y;
  try {
    // 游標甩出視窗外也還收得到移動。
    canvas.setPointerCapture(down.pointerId);
  } catch {
    // 捕捉不到（指標不在了）：沒有捕捉也照樣跟著移動，放開時一樣掉下去。
  }
  const move = (/** @type {PointerEvent} */ e) => {
    at.x = e.screenX - offsetX;
    at.y = e.screenY - offsetY;
    place();
  };
  const release = () => {
    canvas.removeEventListener("pointermove", move);
    canvas.removeEventListener("pointerup", release);
    canvas.removeEventListener("pointercancel", release);
    body.classList.remove("held");
    // 可能被提到另一個螢幕上。
    void refreshArea().then(() => {
      at.x = clampX(at.x);
      fall();
    });
  };
  canvas.addEventListener("pointermove", move);
  canvas.addEventListener("pointerup", release);
  canvas.addEventListener("pointercancel", release);
}

/** 換腳：走路的兩格輪流畫。 @param {number} now @param {number} interval */
function step(now, interval) {
  if (mood === "walk" && now - stepAt < interval) return;
  stepAt = now;
  stepFrame = !stepFrame;
  clearTimeout(moodTimer);
  mood = "walk";
  canvas.dataset.mood = "walk";
  draw(ctx, stepFrame ? FRAMES.walkA : FRAMES.walkB);
}

/** 用 speed 的速度往 goal 走一格；到了回傳 true。 @param {number} goal @param {number} speed @param {number} dt */
function walkTo(goal, speed, dt) {
  const dx = goal - at.x;
  if (Math.abs(dx) < 2) return true;
  turn(Math.sign(dx));
  at.x += Math.sign(dx) * Math.min(Math.abs(dx), speed * dt);
  place();
  return false;
}

let lastFrame = performance.now();
let restUntil = performance.now() + 6000;
/** @param {number} now */
function tick(now) {
  const dt = Math.min((now - lastFrame) / 1000, 0.05);
  lastFrame = now;
  if (motion === "fall") {
    velocity += GRAVITY * dt;
    at.y += velocity * dt;
    if (at.y >= ground()) land();
    else place();
  } else if (motion === "chase") {
    if (now - cursorAsked > 60) {
      cursorAsked = now;
      void hoardWindow.cursor().then((c) => (cursorX = c.x));
    }
    // 東西已經拖到牠身上，或已經在游標底下：停下來張嘴接。
    const arrived = dragDepth > 0 || walkTo(clampX(cursorX - window.innerWidth / 2), RUN_SPEED, dt);
    if (arrived) {
      if (mood !== "open") setMood("open");
    } else step(now, STEP_MS.run);
  } else if (motion === "walk") {
    if (walkTo(target, WALK_SPEED, dt)) {
      motion = "stand";
      setMood("idle");
      restUntil = now + 8000 + Math.random() * 14000;
    } else step(now, STEP_MS.walk);
  } else if (motion === "stand" && now > restUntil && mood === "idle" && bubble.hidden && area) {
    // 閒著時偶爾走幾步（舉著圖片時不走，免得圖片晃來晃去）。
    const distance = (40 + Math.random() * 120) * (Math.random() < 0.5 ? -1 : 1);
    target = clampX(at.x + distance);
    if (Math.abs(target - at.x) > 4) motion = "walk";
    restUntil = now + 4000;
  }
  requestAnimationFrame(tick);
}

hoardWindow.onBrowserDrag((active) => {
  browserDragging = active;
  if (active) {
    if (motion === "stand" || motion === "walk") motion = "chase";
    void hoardWindow.cursor().then((c) => (cursorX = c.x));
  } else if (motion === "chase") {
    motion = "stand";
    // 正在咀嚼的話讓牠吃完。
    if (mood === "open" || mood === "walk") setMood("idle");
    restUntil = performance.now() + 8000;
  }
});

void Promise.all([hoardWindow.position(), refreshArea()]).then(([pos]) => {
  at.x = pos.x;
  at.y = pos.y;
  // 上次停在半空中（或工作列變高了）：掉回地上。
  if (Math.abs(at.y - ground()) > 1) fall();
  requestAnimationFrame(tick);
});

hoardWindow.on((message) => {
  if (message?.type === "config") applyScale(message.scale);
  else if (message?.type === "image") hold(message.item);
});
hoardWindow.send({ type: "ready" });
