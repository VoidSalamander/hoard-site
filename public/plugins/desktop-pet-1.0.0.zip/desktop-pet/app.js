// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：桌寵。
 *
 *  - 桌面上的小龍「囤囤」（原創的像素角色，畫在 window.js）住在一個浮動視窗裡（hoard.openWindow），
 *    主視窗縮在系統匣時也在。
 *  - 拖曳收藏：視窗是投放目標（hoardWindow.setDropTarget），開著時擴充不再從網頁左邊滑出投放區；
 *    拖到牠身上的由那個網頁照投放區的規則收（插件網站收整篇，其他網站只存那張圖），從檔案總管拖來的檔案收成本機作品。
 *  - 點牠：從收藏裡抽一張圖片舉起來（只要圖片；設定頁可以限定某個頁面）。再點一下換一張，拖出去變成檔案，雙擊開詳情頁。
 *  - 這裡（主視窗）負責查作品、讀寫設定與位置；視窗只畫畫面，兩邊用訊息溝通。
 */

/** 像素的放大倍數，角色是 16×15 像素。 */
const SCALES = [3, 4, 5];

/** @typedef {{ pageId: number | null; scale: number; visible: boolean }} Settings */
/** @type {Settings} */
const settings = { pageId: null, scale: 4, visible: true };
const settingsLoaded = hoard.storage.get("settings").then((saved) => {
  if (saved && typeof saved === "object") Object.assign(settings, saved);
});
/** @param {Partial<Settings>} changes */
function updateSettings(changes) {
  Object.assign(settings, changes);
  void hoard.storage.set("settings", settings);
  void openPet();
}

// ---- 視窗 ----

/** @type {HoardWindowHandle | null} */
let pet = null;
let moveTimer = 0;

/** 視窗大小：上面留給舉起來的圖片，角色在底部置中。 */
function windowSize() {
  return { width: 200, height: 196 + 15 * settings.scale };
}

async function openPet() {
  pet?.close();
  pet = null;
  if (!settings.visible) return;
  /** @type {{ x: number; y: number } | undefined} */
  const position = await hoard.storage.get("position");
  const handle = hoard.openWindow({ id: "pet", script: "window.js", style: "window.css", ...windowSize(), position });
  pet = handle;
  handle.on((message) => void onMessage(handle, message));
  handle.onMoved((pos) => {
    // 拖動時一路都有，停下來再存。
    clearTimeout(moveTimer);
    moveTimer = window.setTimeout(() => void hoard.storage.set("position", pos), 400);
  });
}

/** @param {HoardWindowHandle} handle @param {any} message */
async function onMessage(handle, message) {
  if (!message || typeof message !== "object") return;
  if (message.type === "ready") {
    handle.send({ type: "config", scale: settings.scale });
  } else if (message.type === "random") {
    handle.send({ type: "image", item: await randomImage(message.except ?? null) });
  } else if (message.type === "open" && typeof message.id === "number") {
    hoard.openItem(message.id);
  }
}

/**
 * 抽一張圖片：全部收藏，或設定的那一頁。盡量不要跟剛剛那張一樣。
 * @param {number | null} except
 */
async function randomImage(except) {
  /** @type {HoardItemFilter} */
  const filter = { kinds: ["image"] };
  if (settings.pageId !== null) filter.page_id = settings.pageId;
  try {
    const { items } = await hoard.items.list(filter, { sort: "random", seed: Math.floor(Math.random() * 2 ** 31), limit: 2 });
    const item = items.find((i) => i.id !== except) ?? items[0];
    const path = item?.cover_path ?? item?.thumbnail_path;
    if (!item || !path) return null;
    return { id: item.id, title: item.title, src: hoard.fileSrc(path), width: item.cover_width, height: item.cover_height };
  } catch (err) {
    console.error("[desktop-pet] picking an image failed:", err);
    return null;
  }
}

void settingsLoaded.then(openPet);
hoard.onUnload(() => clearTimeout(moveTimer));

// ---- 設定 ----

hoard.registerSettingTab({
  label: "桌寵",
  render(root) {
    /** @param {string} label @param {HTMLElement} control @param {string} [hint] */
    const field = (label, control, hint) =>
      hoard.el("label", { class: "dp-field" }, [
        hoard.el("span", { class: "dp-field-text" }, [
          hoard.el("span", {}, [label]),
          hint ? hoard.el("span", { class: "dp-field-hint" }, [hint]) : null,
        ]),
        control,
      ]);

    const visible = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox" }));
    visible.addEventListener("change", () => updateSettings({ visible: visible.checked }));

    const scale = /** @type {HTMLSelectElement} */ (
      hoard.el(
        "select",
        { class: "dp-select" },
        SCALES.map((s, i) => hoard.el("option", { value: String(s) }, [["小", "中", "大"][i]])),
      )
    );
    scale.addEventListener("change", () => updateSettings({ scale: Number(scale.value) }));

    const page = /** @type {HTMLSelectElement} */ (hoard.el("select", { class: "dp-select" }, [hoard.el("option", { value: "" }, ["全部收藏"])]));
    page.addEventListener("change", () => updateSettings({ pageId: page.value ? Number(page.value) : null }));

    const show = () => {
      visible.checked = settings.visible;
      scale.value = String(settings.scale);
      page.value = settings.pageId === null ? "" : String(settings.pageId);
    };
    void Promise.all([settingsLoaded, hoard.pages.list()]).then(([, pages]) => {
      for (const p of pages) page.append(hoard.el("option", { value: String(p.id) }, [p.name]));
      // 設定的頁面被刪掉了：當作全部收藏。
      if (settings.pageId !== null && !pages.some((p) => p.id === settings.pageId)) settings.pageId = null;
      show();
    });
    show();

    root.append(
      hoard.el("div", { class: "dp-settings" }, [
        field("顯示在桌面上", visible, "關掉時擴充回到網頁左邊的投放區"),
        field("大小", scale),
        field("叼出來的圖片", page, "從哪裡抽圖片"),
      ]),
    );
  },
});
