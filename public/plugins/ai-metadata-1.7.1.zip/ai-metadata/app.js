// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：AI 生成參數。
 *
 *  - 接手讀得懂的本機圖片的詳情頁（registerDetail("local", …, { when })）：圖片欄與檔案資訊照 App 內建的畫；
 *    影片、其他檔案仍是 App 內建的頁面。讀到生成參數時改成兩欄，左邊圖片（固定在畫面上），右邊檔案資訊與「生成參數」；
 *    視窗窄時疊成一欄。檔案裡沒有參數時就是原本的單欄頁面。
 *  - 本機圖片的快速預覽（registerQuickLook）：圖片照 App 內建的畫，讀到生成參數時右邊多一欄「生成參數」。
 *  - 每次打開詳情頁或快速預覽才讀檔（先用 Range 讀開頭 256 KB，不夠再讀整個檔）。
 *  - 篩選值（items.setFields）：每張本機圖片的模型、LoRA，「篩選」裡有「模型」「LoRA」兩個篩選器，搜尋也找得到。
 *    載入時補算還沒讀過的圖片（`scanned` 鍵），新收進來的也算；只寫篩選值，不改原檔、不加標籤。
 *    詳情頁參數表的模型、LoRA 可以點，用 hoard.openLibrary 跳到收藏庫篩選。
 *  - 分兩層：先把檔案裡的資料原樣讀出來（容器），再依各工具的格式解讀。
 *    容器：PNG 的 tEXt／iTXt／zTXt／eXIf，JPEG 的 EXIF、XMP、註解，WebP 的 EXIF、XMP，GIF 的註解，
 *    TIFF；AVIF、JXL 等其他格式找檔案裡的 EXIF。都沒有時，PNG 與 WebP 再試 Stealth（藏在像素最低位元）。
 *  - 認得的工具（偵測順序和欄位對照 sd-prompt-reader、Infinite Image Browsing、Image-MetaHub 與各工具的原始碼）：
 *      Stable Diffusion WebUI、Forge、reForge、SD.Next、Civitai（WebUI 文字格式）
 *      SwarmUI、Fooocus（兩種格式）、InvokeAI（3 以後、2.x 的 sd-metadata、更早的 Dream）
 *      NovelAI（v3、v4 的角色提示詞，含 Stealth）、Easy Diffusion、ComfyUI（從節點圖找取樣器、提示詞、模型、LoRA）
 *      Draw Things（XMP）、Midjourney／Niji
 *    C2PA 內容憑證（DALL·E、Firefly）只標示有，不解析。認不出的文字照原樣列在「原始資料」；
 *    但認不出工具時，原始資料要像生成參數才顯示（繪圖軟體寫的 Software、XMP、JPEG 註解不算）。
 *  - 參數表的名稱照 WebUI 的寫法（Steps、Sampler、CFG scale…），所以「複製（WebUI 格式）」貼進 WebUI／Forge
 *    的提示詞框後，按「讀取參數」就能套用；ComfyUI、NovelAI 等其他工具的圖也一樣。
 */

const HEAD_BYTES = 256 * 1024;
/** 試著讀取的副檔名；實際格式看檔頭。 */
const READABLE = new Set(["png", "jpg", "jpeg", "jfif", "webp", "gif", "avif", "jxl", "tif", "tiff", "heic", "heif"]);

/**
 * @typedef {{
 *   texts: Record<string, string>;
 *   exif: Record<string, string>;
 *   comment: string | null;
 *   xmp: string | null;
 *   c2pa: boolean;
 *   format: string;
 * }} Container
 * @typedef {{ complete: boolean }} Completeness
 * @typedef {{ label: string; text: string }} Section
 * @typedef {{
 *   tool: string;
 *   prompt: string;
 *   negative: string;
 *   sections: Section[];
 *   params: Array<[string, string]>;
 *   loras: Array<{ name: string; weight: string }>;
 *   infotext: string | null;
 * }} Generation
 * @typedef {{ generation: Generation | null; raw: Section[]; c2pa: boolean }} Analysis
 */

// ---- 位元組工具 ----

/** @param {string} url @param {boolean} head */
async function fetchBytes(url, head) {
  const res = await fetch(url, head ? { headers: { Range: `bytes=0-${HEAD_BYTES - 1}` } } : undefined);
  if (!res.ok) {
    if (head) return fetchBytes(url, false);
    throw new Error(`HTTP ${res.status}`);
  }
  return new Uint8Array(await res.arrayBuffer());
}

/** @param {Uint8Array} bytes @param {number} start @param {number} length */
function ascii(bytes, start, length) {
  let text = "";
  for (let i = start; i < Math.min(start + length, bytes.length); i++) text += String.fromCharCode(bytes[i]);
  return text;
}

/** 規格是 Latin-1，但很多工具直接塞 UTF-8。 @param {Uint8Array} bytes */
function decodeText(bytes) {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    return new TextDecoder("latin1").decode(bytes);
  }
}

/** @param {Uint8Array} bytes @param {"deflate" | "gzip"} format */
async function inflate(bytes, format = "deflate") {
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream(format));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/** @param {Uint8Array} bytes @param {number[]} pattern @param {number} from */
function indexOf(bytes, pattern, from = 0) {
  outer: for (let i = from; i <= bytes.length - pattern.length; i++) {
    for (let j = 0; j < pattern.length; j++) if (bytes[i + j] !== pattern[j]) continue outer;
    return i;
  }
  return -1;
}

/** @returns {Container} */
function emptyContainer(format = "") {
  return { texts: {}, exif: {}, comment: null, xmp: null, c2pa: false, format };
}

// ---- EXIF ----

/** 會用到的標籤：WebUI、SwarmUI、Easy Diffusion 放 UserComment；ComfyUI 放 Model／Make；Fooocus 放 MakerNote。 */
const EXIF_TAGS = /** @type {Record<number, string>} */ ({
  0x010e: "ImageDescription",
  0x010f: "Make",
  0x0110: "Model",
  0x0131: "Software",
  0x9286: "UserComment",
  0x927c: "MakerNote",
});

/**
 * UserComment 的前 8 個位元組是字元碼。WebUI（piexif）寫 `UNICODE\0` 加 UTF-16BE；
 * Fooocus（Pillow）寫在 IFD0 而且沒有前綴。
 * @param {Uint8Array} raw @param {boolean} littleEndian
 */
function decodeUserComment(raw, littleEndian) {
  const prefix = ascii(raw, 0, 8);
  const body = raw.subarray(8);
  if (prefix.startsWith("UNICODE")) {
    if (body[0] === 0xfe && body[1] === 0xff) return new TextDecoder("utf-16be").decode(body.subarray(2));
    if (body[0] === 0xff && body[1] === 0xfe) return new TextDecoder("utf-16le").decode(body.subarray(2));
    // 沒有 BOM：ASCII 字元的 0 落在偶數位是 BE，奇數位是 LE；看不出來時照 TIFF 的位元組順序。
    let even = 0;
    let odd = 0;
    for (let i = 0; i + 1 < Math.min(body.length, 256); i += 2) {
      if (body[i] === 0 && body[i + 1] !== 0) even++;
      if (body[i + 1] === 0 && body[i] !== 0) odd++;
    }
    const big = even === odd ? !littleEndian : even > odd;
    return new TextDecoder(big ? "utf-16be" : "utf-16le").decode(body);
  }
  if (prefix.startsWith("JIS")) return new TextDecoder("shift_jis").decode(body);
  if (prefix.startsWith("ASCII") || prefix === "\0\0\0\0\0\0\0\0") return decodeText(body);
  return decodeText(raw);
}

/** 讀 TIFF 結構（EXIF 的本體）裡 IFD0 與 Exif IFD 的文字標籤；Exif IFD 的值優先。 @param {Uint8Array} tiff */
function readExif(tiff) {
  /** @type {Record<string, string>} */
  const out = {};
  if (tiff.length < 8) return out;
  const le = tiff[0] === 0x49;
  if (!le && tiff[0] !== 0x4d) return out;
  const view = new DataView(tiff.buffer, tiff.byteOffset, tiff.byteLength);
  const u16 = (/** @type {number} */ o) => view.getUint16(o, le);
  const u32 = (/** @type {number} */ o) => view.getUint32(o, le);
  /** @param {number} ifd @param {boolean} sub */
  const readIfd = (ifd, sub) => {
    if (ifd <= 0 || ifd + 2 > tiff.length) return;
    const count = u16(ifd);
    for (let k = 0; k < count; k++) {
      const entry = ifd + 2 + k * 12;
      if (entry + 12 > tiff.length) return;
      const tag = u16(entry);
      if (tag === 0x8769 && !sub) {
        readIfd(u32(entry + 8), true);
        continue;
      }
      const name = EXIF_TAGS[tag];
      const type = u16(entry + 2);
      if (!name || ![1, 2, 7].includes(type)) continue;
      const size = u32(entry + 4);
      const offset = size > 4 ? u32(entry + 8) : entry + 8;
      if (size === 0 || offset + size > tiff.length) continue;
      const raw = tiff.subarray(offset, offset + size);
      const text = (name === "UserComment" ? decodeUserComment(raw, le) : decodeText(raw)).replace(/\0+$/, "").trim();
      if (text && (sub || !out[name])) out[name] = text;
    }
  };
  readIfd(u32(4), false);
  return out;
}

/** 有些容器在 TIFF 前面加 `Exif\0\0`。 @param {Uint8Array} data */
function stripExifHeader(data) {
  return ascii(data, 0, 6) === "Exif\0\0" ? data.subarray(6) : data;
}

// ---- 容器 ----

/** @param {Uint8Array} data @param {string} type */
async function pngText(data, type) {
  const nul = data.indexOf(0);
  if (nul < 0) return null;
  const key = ascii(data, 0, nul);
  if (type === "tEXt") return { key, text: decodeText(data.subarray(nul + 1)) };
  if (type === "zTXt") return { key, text: decodeText(await inflate(data.subarray(nul + 2))) };
  // iTXt：關鍵字\0 壓縮旗標 壓縮方式 語言\0 翻譯關鍵字\0 內文（UTF-8）
  const compressed = data[nul + 1] === 1;
  const langEnd = data.indexOf(0, nul + 3);
  const transEnd = langEnd < 0 ? -1 : data.indexOf(0, langEnd + 1);
  if (transEnd < 0) return null;
  const body = data.subarray(transEnd + 1);
  return { key, text: new TextDecoder("utf-8").decode(compressed ? await inflate(body) : body) };
}

/**
 * 文字區塊通常在圖片資料（IDAT）之前，但也可能在後面。讀到 IEND 算完整；讀到 IDAT 時前面已經有資料也算，
 * 不必為了檔尾可能還有的區塊讀整個檔。
 * @param {Uint8Array} bytes
 */
async function readPng(bytes) {
  const c = emptyContainer("png");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let i = 8;
  while (i + 8 <= bytes.length) {
    const length = view.getUint32(i);
    const type = ascii(bytes, i + 4, 4);
    if (type === "IEND") return { container: c, complete: true };
    if (type === "IDAT" && hasData(c)) return { container: c, complete: true };
    const end = i + 8 + length;
    if (end > bytes.length) break;
    const data = bytes.subarray(i + 8, end);
    if (type === "tEXt" || type === "iTXt" || type === "zTXt") {
      const entry = await pngText(data, type).catch(() => null);
      if (entry && !(entry.key in c.texts)) c.texts[entry.key] = entry.text;
    } else if (type === "eXIf") {
      Object.assign(c.exif, readExif(stripExifHeader(data)));
    } else if (type === "caBX") {
      c.c2pa = true;
    }
    i = end + 4;
  }
  return { container: c, complete: false };
}

/** @param {Uint8Array} bytes */
function readJpeg(bytes) {
  const c = emptyContainer("jpeg");
  let i = 2;
  while (i + 4 <= bytes.length) {
    if (bytes[i] !== 0xff) return { container: c, complete: true };
    const marker = bytes[i + 1];
    if (marker === 0xd8 || (marker >= 0xd0 && marker <= 0xd7) || marker === 0x01) {
      i += 2;
      continue;
    }
    if (marker === 0xda || marker === 0xd9) return { container: c, complete: true };
    const length = (bytes[i + 2] << 8) | bytes[i + 3];
    const end = i + 2 + length;
    if (end > bytes.length) return { container: c, complete: false };
    const data = bytes.subarray(i + 4, end);
    if (marker === 0xe1 && ascii(data, 0, 6) === "Exif\0\0") Object.assign(c.exif, readExif(data.subarray(6)));
    else if (marker === 0xe1 && ascii(data, 0, 29) === "http://ns.adobe.com/xap/1.0/\0") c.xmp = decodeText(data.subarray(29));
    else if (marker === 0xfe) c.comment = decodeText(data);
    else if (marker === 0xeb && ascii(data, 0, 2) === "JP") c.c2pa = true;
    i = end;
  }
  return { container: c, complete: false };
}

/** EXIF、XMP 在 WebP 的最後面，要讀整個檔。 @param {Uint8Array} bytes */
function readWebp(bytes) {
  const c = emptyContainer("webp");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let i = 12;
  while (i + 8 <= bytes.length) {
    const type = ascii(bytes, i, 4);
    const size = view.getUint32(i + 4, true);
    const end = i + 8 + size;
    if (end > bytes.length) return { container: c, complete: false };
    const data = bytes.subarray(i + 8, end);
    if (type === "EXIF") Object.assign(c.exif, readExif(stripExifHeader(data)));
    else if (type === "XMP ") c.xmp = decodeText(data);
    i = end + (size & 1);
  }
  return { container: c, complete: true };
}

/** WebUI 存 GIF 時把參數放在註解延伸區塊。 @param {Uint8Array} bytes */
function readGif(bytes) {
  const c = emptyContainer("gif");
  let i = 13;
  if (bytes[10] & 0x80) i += 3 * (1 << ((bytes[10] & 7) + 1));
  /** 跳過一串子區塊，回傳內容。 @param {boolean} keep */
  const blocks = (keep) => {
    /** @type {number[]} */
    const out = [];
    while (i < bytes.length && bytes[i] !== 0) {
      const size = bytes[i];
      if (keep) for (let k = 1; k <= size; k++) out.push(bytes[i + k]);
      i += size + 1;
    }
    i++;
    return new Uint8Array(out);
  };
  while (i < bytes.length) {
    const block = bytes[i];
    if (block === 0x3b) return { container: c, complete: true };
    if (block === 0x21) {
      const label = bytes[i + 1];
      i += 2;
      const data = blocks(label === 0xfe);
      if (label === 0xfe && !c.comment) c.comment = decodeText(data);
    } else if (block === 0x2c) {
      const packed = bytes[i + 9];
      i += 10;
      if (packed & 0x80) i += 3 * (1 << ((packed & 7) + 1));
      i++;
      blocks(false);
    } else {
      break;
    }
  }
  return { container: c, complete: false };
}

/** AVIF、JXL、HEIC 等：直接在檔案裡找 EXIF 的 TIFF 檔頭。 @param {Uint8Array} bytes @param {string} format */
function scanForExif(bytes, format) {
  const c = emptyContainer(format);
  for (const header of [[0x4d, 0x4d, 0x00, 0x2a], [0x49, 0x49, 0x2a, 0x00]]) {
    let at = indexOf(bytes, header);
    while (at >= 0) {
      const exif = readExif(bytes.subarray(at));
      if (Object.keys(exif).length > 0) {
        Object.assign(c.exif, exif);
        break;
      }
      at = indexOf(bytes, header, at + 1);
    }
  }
  const xmp = indexOf(bytes, [...new TextEncoder().encode("<x:xmpmeta")]);
  if (xmp >= 0) {
    const end = indexOf(bytes, [...new TextEncoder().encode("</x:xmpmeta>")], xmp);
    if (end > 0) c.xmp = decodeText(bytes.subarray(xmp, end + 12));
  }
  return { container: c, complete: true };
}

/** @param {Uint8Array} bytes @returns {Promise<{ container: Container; complete: boolean }>} */
async function readContainer(bytes) {
  if (bytes[0] === 0x89 && ascii(bytes, 1, 3) === "PNG") return readPng(bytes);
  if (bytes[0] === 0xff && bytes[1] === 0xd8) return readJpeg(bytes);
  if (ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WEBP") return readWebp(bytes);
  if (ascii(bytes, 0, 3) === "GIF") return readGif(bytes);
  if (ascii(bytes, 0, 4) === "II*\0" || ascii(bytes, 0, 4) === "MM\0*") {
    return { container: { ...emptyContainer("tiff"), exif: readExif(bytes) }, complete: true };
  }
  return scanForExif(bytes, "other");
}

/** @param {Container} c */
function hasData(c) {
  return Object.keys(c.texts).length > 0 || Object.keys(c.exif).length > 0 || Boolean(c.comment || c.xmp || c.c2pa);
}

// ---- Stealth：資料藏在像素的最低位元 ----

const STEALTH_SIGNATURES = {
  alpha: ["stealth_pnginfo", "stealth_pngcomp"],
  rgb: ["stealth_rgbinfo", "stealth_rgbcomp"],
};

/**
 * 依 sd_webui_stealth_pnginfo 的編碼讀出內容：像素直欄優先（x 外層、y 內層），每個位元組高位先；
 * 15 個位元組的簽名，接 32 位元的長度（單位是位元），再接內容。alpha 模式每像素 1 位元（A 的最低位），
 * RGB 模式每像素 3 位元（R、G、B 的最低位）。
 * @param {(x: number) => Uint8ClampedArray} column 第 x 欄的 RGBA，由上到下
 * @param {number} width @param {number} height
 * @returns {{ compressed: boolean; payload: Uint8Array } | null}
 */
function decodeStealth(column, width, height) {
  for (const mode of /** @type {const} */ (["alpha", "rgb"])) {
    const perPixel = mode === "alpha" ? 1 : 3;
    const capacity = width * height * perPixel;
    if (capacity < 160) return null;
    /** @type {Map<number, Uint8ClampedArray>} */
    const columns = new Map();
    let index = 0;
    const bit = () => {
      const pixel = Math.floor(index / perPixel);
      const channel = mode === "alpha" ? 3 : index % perPixel;
      index++;
      const x = Math.floor(pixel / height);
      let data = columns.get(x);
      if (!data) {
        data = column(x);
        columns.set(x, data);
      }
      return data[(pixel % height) * 4 + channel] & 1;
    };
    /** @param {number} count */
    const bytes = (count) => {
      const out = new Uint8Array(count);
      for (let b = 0; b < count; b++) {
        let value = 0;
        for (let k = 0; k < 8; k++) value = (value << 1) | bit();
        out[b] = value;
      }
      return out;
    };
    const signature = ascii(bytes(15), 0, 15);
    if (!STEALTH_SIGNATURES[mode].includes(signature)) continue;
    let length = 0;
    for (let k = 0; k < 32; k++) length = length * 2 + bit();
    if (length <= 0 || length % 8 !== 0 || index + length > capacity) continue;
    return { compressed: signature.endsWith("comp"), payload: bytes(length / 8) };
  }
  return null;
}

/** 解碼整張圖讀像素；不做色彩轉換與預乘，最低位元才不會被改掉。 @param {Uint8Array} bytes */
async function readStealth(bytes) {
  const bitmap = await createImageBitmap(new Blob([bytes]), { premultiplyAlpha: "none", colorSpaceConversion: "none" });
  const { width, height } = bitmap;
  const canvas = new OffscreenCanvas(width, height);
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  ctx.drawImage(bitmap, 0, 0);
  bitmap.close();
  const found = decodeStealth((x) => ctx.getImageData(x, 0, 1, height).data, width, height);
  if (!found) return null;
  return decodeText(found.compressed ? await inflate(found.payload, "gzip") : found.payload);
}

// ---- 解讀：共用 ----

/**
 * JSON.parse，但先把超過 2^53 的整數（ComfyUI 的種子）包成字串免得失去精度，NaN 改成 null。
 * @param {string} text @returns {any}
 */
function parseJson(text) {
  if (!/^\s*[[{]/.test(text)) return undefined;
  try {
    return JSON.parse(text.replace(/([:[,]\s*)(-?\d{16,})(?=\s*[,}\]])/g, '$1"$2"').replace(/:\s*NaN\b/g, ": null"));
  } catch {
    return undefined;
  }
}

/** @param {unknown} value */
function show(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean" || typeof value === "bigint") return String(value);
  return JSON.stringify(value);
}

/** @param {unknown} value */
function isScalar(value) {
  return value !== null && value !== undefined && value !== "" && typeof value !== "object";
}

/** 路徑或檔名只留檔名，去掉副檔名。 @param {unknown} value */
function modelName(value) {
  const text = show(value).trim();
  return text.split(/[\\/]/).pop()?.replace(/\.(safetensors|ckpt|pt|pth|bin|gguf|sft)$/i, "") ?? text;
}

/** @param {string} tool @returns {Generation} */
function blank(tool) {
  return { tool, prompt: "", negative: "", sections: [], params: [], loras: [], infotext: null };
}

/**
 * 把常用欄位依 WebUI 的名稱放進參數表；名稱相同的不重複。
 * @param {Generation} g @param {string} key @param {unknown} value
 */
function put(g, key, value) {
  const text = show(value).trim();
  if (!text || g.params.some(([k]) => k === key)) return;
  g.params.push([key, text]);
}

/** 其餘欄位照原名附在後面。 @param {Generation} g @param {Record<string, unknown>} obj @param {Set<string>} used */
function putRest(g, obj, used) {
  for (const [key, value] of Object.entries(obj)) {
    if (used.has(key) || value === null || value === undefined || value === "") continue;
    if (typeof value === "object" && show(value).length > 400) continue;
    put(g, key, value);
  }
}

/** @param {unknown} w @param {unknown} h */
function size(w, h) {
  return isScalar(w) && isScalar(h) ? `${show(w)}x${show(h)}` : "";
}

/**
 * 轉成 WebUI 的參數文字，貼進 WebUI／Forge 的提示詞框按「讀取參數」就能套用。LoRA 沒有寫在提示詞裡時補上 `<lora:名稱:權重>`。
 * @param {Generation} g
 */
function toInfotext(g) {
  let prompt = g.prompt;
  for (const lora of g.loras) {
    if (!prompt.includes(`<lora:${lora.name}`)) prompt += `${prompt ? ", " : ""}<lora:${lora.name}:${lora.weight || "1"}>`;
  }
  const quote = (/** @type {string} */ v) => (/[,:\n]/.test(v) ? JSON.stringify(v) : v);
  const settings = g.params
    .filter(([k]) => k !== "LoRA")
    .map(([k, v]) => `${k}: ${quote(v)}`)
    .join(", ");
  return [prompt, g.negative ? `Negative prompt: ${g.negative}` : "", settings].filter(Boolean).join("\n");
}

/** @param {Generation} g */
function finish(g) {
  if (g.loras.length > 0 && !g.params.some(([k]) => k === "LoRA")) {
    // 放在 Model 那列後面。
    const model = g.params.findIndex(([k]) => k === "Model");
    const at = model < 0 ? g.params.length : model + 1;
    g.params.splice(at, 0, ["LoRA", g.loras.map((l) => (l.weight ? `${l.name} (${l.weight})` : l.name)).join("\n")]);
  }
  if (g.infotext === null) g.infotext = toInfotext(g);
  return g;
}

// ---- WebUI 文字格式（Stable Diffusion WebUI、Forge、reForge、SD.Next、Civitai、Fooocus 的 a1111 格式） ----

/** WebUI 的 re_param_code，鍵可以含空白、`-`、`/`。 */
const PARAM_RE = /\s*(\w[\w \-/]+):\s*("(?:\\.|[^\\"])+"|[^,]*)(?:,|$)/g;
const LORA_TAG_RE = /<(lora|lyco):([^:>]+)(?::([^:>]+))?(?::[^>]*)?>/gi;

/** @param {string} value */
function unquote(value) {
  if (value.length < 2 || !value.startsWith('"') || !value.endsWith('"')) return value;
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}

/** 把 `鍵: [ … ]`、`鍵: { … }` 這種沒加引號的 JSON（Civitai）先抽出來，免得被逗號切壞。 @param {string} line */
function takeJsonParams(line) {
  /** @type {Array<[string, string]>} */
  const taken = [];
  let rest = line;
  for (const key of ["Civitai resources", "Civitai metadata"]) {
    const at = rest.indexOf(`${key}: `);
    if (at < 0) continue;
    const start = at + key.length + 2;
    const open = rest[start];
    if (open !== "[" && open !== "{") continue;
    const close = open === "[" ? "]" : "}";
    let depth = 0;
    let inString = false;
    let end = -1;
    for (let i = start; i < rest.length; i++) {
      const ch = rest[i];
      if (inString) {
        if (ch === "\\") i++;
        else if (ch === '"') inString = false;
      } else if (ch === '"') inString = true;
      else if (ch === open) depth++;
      else if (ch === close && --depth === 0) {
        end = i + 1;
        break;
      }
    }
    if (end < 0) continue;
    taken.push([key, rest.slice(start, end)]);
    rest = rest.slice(0, at) + rest.slice(end).replace(/^\s*,/, "");
  }
  return { taken, rest };
}

/** @param {string} text */
function parseInfotext(text) {
  const lines = text.trim().split("\n");
  /** @type {Array<[string, string]>} */
  let params = [];
  const { taken, rest } = takeJsonParams(lines.at(-1) ?? "");
  const matches = [...rest.matchAll(PARAM_RE)];
  if (matches.length >= 3) {
    params = matches.map((m) => /** @type {[string, string]} */ ([m[1].trim(), unquote(m[2].trim())]));
    params.push(...taken);
    lines.pop();
  }
  /** @type {string[]} */
  const prompt = [];
  /** @type {string[]} */
  const negative = [];
  let inNegative = false;
  for (const line of lines) {
    if (!inNegative && line.startsWith("Negative prompt:")) {
      inNegative = true;
      negative.push(line.slice("Negative prompt:".length).trimStart());
    } else {
      (inNegative ? negative : prompt).push(line);
    }
  }
  return { prompt: prompt.join("\n").trim(), negative: negative.join("\n").trim(), params };
}

/** @param {string} text @param {string | null} hint */
function fromInfotext(text, hint) {
  const parsed = parseInfotext(text);
  const version = parsed.params.find(([k]) => k === "Version")?.[1] ?? "";
  let tool = hint ?? "Stable Diffusion WebUI";
  if (!hint) {
    if (/^neo\b/i.test(version)) tool = "Forge Neo";
    else if (/^f\d/.test(version)) tool = "Forge";
    else if (/^classic\b/i.test(version)) tool = "Forge Classic";
    else if (/fooocus/i.test(version)) tool = "Fooocus";
    else if (parsed.params.some(([k]) => k === "Civitai resources" || k === "Civitai metadata")) tool = "Civitai";
  }
  const g = blank(tool);
  g.prompt = parsed.prompt;
  g.negative = parsed.negative;
  g.params = parsed.params;
  for (const m of g.prompt.matchAll(LORA_TAG_RE)) g.loras.push({ name: m[2].trim(), weight: m[3]?.trim() ?? "" });
  g.infotext = text.trim();
  return finish(g);
}

// ---- 各工具的 JSON 格式 ----

/** @param {any} p SwarmUI 的 `sui_image_params` 那一包 */
function fromSwarm(p) {
  const params = p.sui_image_params ?? {};
  const g = blank("SwarmUI");
  g.prompt = show(params.prompt);
  g.negative = show(params.negativeprompt);
  put(g, "Steps", params.steps);
  put(g, "Sampler", params.sampler ?? params.comfyuisampler ?? params.autowebuisampler);
  put(g, "Schedule type", params.scheduler ?? params.comfyuischeduler ?? params.autowebuischeduler);
  put(g, "CFG scale", params.cfgscale);
  put(g, "Seed", params.seed);
  put(g, "Size", size(params.width, params.height));
  put(g, "Model", params.model);
  const model = (p.sui_models ?? []).find((/** @type {any} */ m) => m?.param === "model");
  if (model?.hash) put(g, "Model hash", model.hash);
  const list = (/** @type {unknown} */ v) => (Array.isArray(v) ? v.map(show) : show(v).split(",").map((s) => s.trim()).filter(Boolean));
  const names = list(params.loras);
  const weights = list(params.loraweights);
  names.forEach((name, i) => g.loras.push({ name, weight: weights[i] ?? "" }));
  put(g, "Version", params.swarm_version);
  const used = new Set(["prompt", "negativeprompt", "steps", "sampler", "comfyuisampler", "autowebuisampler", "scheduler", "comfyuischeduler", "autowebuischeduler", "cfgscale", "seed", "width", "height", "model", "loras", "loraweights", "swarm_version"]);
  putRest(g, params, used);
  putRest(g, p.sui_extra_data ?? {}, new Set(["original_prompt", "original_negativeprompt"]));
  return finish(g);
}

/** Fooocus 的 fooocus 格式（2.2 以後），與更早寫在 `Comment` 的 JSON。 @param {any} p */
function fromFooocus(p) {
  const g = blank(show(p.version) || "Fooocus");
  g.prompt = show(p.prompt);
  g.negative = show(p.negative_prompt);
  for (const [key, label] of [["full_prompt", "完整提示詞（套用風格後）"], ["full_negative_prompt", "完整反向提示詞"]]) {
    const value = Array.isArray(p[key]) ? p[key].join("\n") : show(p[key]);
    if (value && value !== g.prompt && value !== g.negative) g.sections.push({ label, text: value });
  }
  put(g, "Steps", p.steps);
  put(g, "Sampler", p.sampler);
  put(g, "Schedule type", p.scheduler);
  put(g, "CFG scale", p.guidance_scale ?? p.cfg);
  put(g, "Seed", p.seed);
  const resolution = show(p.resolution).match(/(\d+)\D+(\d+)/);
  put(g, "Size", resolution ? `${resolution[1]}x${resolution[2]}` : size(p.width, p.height));
  put(g, "Model", p.base_model);
  put(g, "Model hash", p.base_model_hash);
  if (Array.isArray(p.loras)) {
    for (const l of p.loras) if (Array.isArray(l)) g.loras.push({ name: modelName(l[0]), weight: show(l[1]) });
  } else {
    for (const [key, value] of Object.entries(p)) {
      const m = key.startsWith("lora_combined_") ? show(value).match(/^(.*) : ([-\d.]+)$/) : null;
      if (m) g.loras.push({ name: modelName(m[1]), weight: m[2] });
    }
  }
  const used = new Set(["prompt", "negative_prompt", "full_prompt", "full_negative_prompt", "steps", "sampler", "scheduler", "guidance_scale", "cfg", "seed", "resolution", "width", "height", "base_model", "base_model_hash", "loras", "version"]);
  putRest(g, Object.fromEntries(Object.entries(p).filter(([k]) => !k.startsWith("lora_combined_"))), used);
  return finish(g);
}

/** InvokeAI 3 以後的 core metadata（3.x 與 4.x 以後的模型欄位形狀不同）。 @param {any} m */
function fromInvoke(m) {
  const g = blank(m.app_version ? `InvokeAI ${m.app_version}` : "InvokeAI");
  g.prompt = show(m.positive_prompt);
  g.negative = show(m.negative_prompt);
  if (m.positive_style_prompt) g.sections.push({ label: "風格提示詞", text: show(m.positive_style_prompt) });
  if (m.negative_style_prompt) g.sections.push({ label: "反向風格提示詞", text: show(m.negative_style_prompt) });
  const name = (/** @type {any} */ v) => (typeof v === "string" ? v : v?.name ?? v?.model_name ?? "");
  put(g, "Steps", m.steps);
  // InvokeAI 的 scheduler 其實是取樣器（euler、dpmpp_2m_k）。
  put(g, "Sampler", m.scheduler);
  put(g, "CFG scale", m.cfg_scale);
  put(g, "Seed", m.seed);
  put(g, "Size", size(m.width, m.height));
  put(g, "Model", name(m.model));
  put(g, "VAE", name(m.vae));
  put(g, "Denoising strength", m.strength);
  put(g, "Clip skip", m.clip_skip);
  for (const l of Array.isArray(m.loras) ? m.loras : []) {
    g.loras.push({ name: name(l.model ?? l.lora), weight: show(l.weight) });
  }
  put(g, "Refiner", name(m.refiner_model));
  const used = new Set(["positive_prompt", "negative_prompt", "positive_style_prompt", "negative_style_prompt", "steps", "scheduler", "cfg_scale", "seed", "width", "height", "model", "vae", "strength", "clip_skip", "loras", "refiner_model", "app_version", "canvas_v2_metadata"]);
  putRest(g, m, used);
  return finish(g);
}

/** InvokeAI 2.x 的 `sd-metadata`：負向提示詞寫在方括號裡。 @param {any} m */
function fromInvokeLegacy(m) {
  const image = m.image ?? {};
  const raw = Array.isArray(image.prompt) ? image.prompt.map((/** @type {any} */ p) => show(p?.prompt ?? p)).join(" ") : show(image.prompt);
  const split = raw.match(/^(.*?)\[(.*?)\]\s*$/s);
  const g = blank(m.app_version ? `InvokeAI ${m.app_version}` : "InvokeAI");
  g.prompt = (split ? split[1] : raw).trim();
  g.negative = split ? split[2].trim() : "";
  put(g, "Steps", image.steps);
  put(g, "Sampler", image.sampler);
  put(g, "CFG scale", image.cfg_scale);
  put(g, "Seed", image.seed);
  put(g, "Size", size(image.width, image.height));
  put(g, "Model", m.model_weights);
  put(g, "Model hash", m.model_hash);
  return finish(g);
}

/** 更早的 InvokeAI（`Dream`）：`"正向 [反向]" -s 50 -S 1234 -W 512 -H 512 -C 7.5 -A k_lms`。 @param {string} text */
function fromDream(text) {
  const m = text.match(/"(.*?)"\s*(.*)$/s);
  const g = blank("InvokeAI（Dream）");
  const raw = m ? m[1] : text;
  const split = raw.match(/^(.*?)\[(.*?)\]\s*$/s);
  g.prompt = (split ? split[1] : raw).trim();
  g.negative = split ? split[2].trim() : "";
  /** @type {Record<string, string>} */
  const flags = {};
  for (const f of (m?.[2] ?? "").matchAll(/-(\w+)\s+([\w.-]+)/g)) flags[f[1]] = f[2];
  put(g, "Steps", flags.s);
  put(g, "Sampler", flags.A);
  put(g, "CFG scale", flags.C);
  put(g, "Seed", flags.S);
  put(g, "Size", size(flags.W, flags.H));
  return finish(g);
}

/** NovelAI：`Comment` 是參數 JSON；v4 起提示詞在 `v4_prompt`，可以有多個角色。 @param {Record<string, any>} chunks */
function fromNovelAI(chunks) {
  const c = typeof chunks.Comment === "string" ? parseJson(chunks.Comment) ?? {} : chunks.Comment ?? {};
  const g = blank("NovelAI");
  const v4 = c.v4_prompt?.caption;
  const v4n = c.v4_negative_prompt?.caption;
  g.prompt = show(v4?.base_caption ?? c.prompt ?? chunks.Description);
  g.negative = show(v4n?.base_caption ?? c.uc);
  (v4?.char_captions ?? []).forEach((/** @type {any} */ ch, /** @type {number} */ i) => {
    if (ch?.char_caption) g.sections.push({ label: `角色 ${i + 1}`, text: show(ch.char_caption) });
    const neg = v4n?.char_captions?.[i]?.char_caption;
    if (neg) g.sections.push({ label: `角色 ${i + 1}（反向）`, text: show(neg) });
  });
  put(g, "Steps", c.steps);
  put(g, "Sampler", c.sampler);
  put(g, "Schedule type", c.noise_schedule);
  put(g, "CFG scale", c.scale);
  put(g, "Seed", c.seed);
  put(g, "Size", size(c.width, c.height));
  put(g, "Model", chunks.Source);
  put(g, "Generation time", chunks["Generation time"]);
  const used = new Set(["prompt", "uc", "v4_prompt", "v4_negative_prompt", "steps", "sampler", "noise_schedule", "scale", "seed", "width", "height", "signed_hash"]);
  putRest(g, c, used);
  return finish(g);
}

/** Easy Diffusion：PNG 每個欄位一個文字區塊，JPEG／WebP 是一包 JSON；鍵有兩種寫法。 @param {Record<string, any>} d */
function fromEasyDiffusion(d) {
  const get = (/** @type {string[]} */ ...keys) => keys.map((k) => d[k]).find((v) => v !== undefined && v !== "");
  const g = blank("Easy Diffusion");
  g.prompt = show(get("prompt", "Prompt"));
  g.negative = show(get("negative_prompt", "Negative Prompt"));
  put(g, "Steps", get("num_inference_steps", "Steps"));
  put(g, "Sampler", get("sampler_name", "Sampler"));
  put(g, "Schedule type", get("scheduler_name", "Scheduler"));
  put(g, "CFG scale", get("guidance_scale", "Guidance Scale"));
  put(g, "Seed", get("seed", "Seed"));
  put(g, "Size", size(get("width", "Width"), get("height", "Height")));
  const model = get("use_stable_diffusion_model", "Stable Diffusion model");
  put(g, "Model", model ? modelName(model) : "");
  put(g, "VAE", get("use_vae_model", "VAE model"));
  put(g, "Clip skip", get("clip_skip", "Clip Skip"));
  const loras = get("use_lora_model", "LoRA model");
  const weights = get("lora_alpha", "LoRA Strength");
  const list = (/** @type {unknown} */ v) => (Array.isArray(v) ? v.map(show) : show(v).split(",").map((s) => s.trim()).filter(Boolean));
  const w = list(weights);
  list(loras).forEach((name, i) => g.loras.push({ name: modelName(name), weight: w[i] ?? "" }));
  const used = new Set(["prompt", "Prompt", "negative_prompt", "Negative Prompt", "num_inference_steps", "Steps", "sampler_name", "Sampler", "scheduler_name", "Scheduler", "guidance_scale", "Guidance Scale", "seed", "Seed", "width", "Width", "height", "Height", "use_stable_diffusion_model", "Stable Diffusion model", "use_vae_model", "VAE model", "clip_skip", "Clip Skip", "use_lora_model", "LoRA model", "lora_alpha", "LoRA Strength"]);
  putRest(g, d, used);
  return finish(g);
}

/** Draw Things：XMP 的 exif:UserComment 是 JSON（c＝提示詞、uc＝反向）。 @param {any} d */
function fromDrawThings(d) {
  const g = blank("Draw Things");
  g.prompt = show(d.c);
  g.negative = show(d.uc);
  put(g, "Steps", d.steps);
  put(g, "Sampler", d.sampler);
  put(g, "CFG scale", d.scale);
  put(g, "Seed", d.seed);
  put(g, "Size", d.size);
  put(g, "Model", d.model);
  put(g, "Denoising strength", d.strength);
  for (const l of [...(Array.isArray(d.lora) ? d.lora : []), ...(Array.isArray(d.loras) ? d.loras : [])]) {
    g.loras.push({ name: modelName(l?.file ?? l?.model ?? l), weight: show(l?.weight) });
  }
  putRest(g, d, new Set(["c", "uc", "steps", "sampler", "scale", "seed", "size", "model", "strength", "lora", "loras"]));
  return finish(g);
}

/** Midjourney／Niji：提示詞後面接 `--ar 16:9 --v 6` 這類參數。 @param {string} text @param {Record<string, string>} texts */
function fromMidjourney(text, texts) {
  const g = blank(/--niji\b/.test(text) ? "Niji" : "Midjourney");
  const job = text.match(/Job ID:\s*([\w-]+)/);
  const body = text.replace(/\s*Job ID:.*$/s, "");
  const at = body.search(/\s--\w/);
  g.prompt = (at < 0 ? body : body.slice(0, at)).trim();
  for (const m of (at < 0 ? "" : body.slice(at)).matchAll(/--(\w+)(?:\s+([^-\s][^\s]*(?:\s+[^-\s][^\s]*)*))?/g)) {
    put(g, `--${m[1]}`, m[2] ?? "✓");
  }
  put(g, "Job ID", job?.[1]);
  put(g, "Author", texts.Author);
  g.infotext = text;
  return finish(g);
}

// ---- ComfyUI：從節點圖找出參數 ----

/** @param {any} value */
function isLink(value) {
  return Array.isArray(value) && value.length === 2 && (typeof value[0] === "string" || typeof value[0] === "number");
}

/** 字串節點（Primitive、Text、wildcard…）的輸出。 @param {Record<string, any>} graph @param {any} value @param {Set<string>} seen */
function resolveText(graph, value, seen) {
  if (!isLink(value)) return typeof value === "string" ? value : "";
  const id = String(value[0]);
  const node = graph[id];
  if (!node || seen.has(id)) return "";
  seen.add(id);
  const inputs = node.inputs ?? {};
  const slotKey = value[1] === 1 ? ["text_negative", "negative"] : ["text_positive", "positive"];
  for (const key of ["populated_text", "text", "string", "value", "prompt", "text_g", "t5xxl", "clip_l", "wildcard_text", ...slotKey]) {
    if (key in inputs) {
      const text = resolveText(graph, inputs[key], seen);
      if (text) return text;
    }
  }
  return "";
}

/**
 * 條件（conditioning）往上追到文字編碼節點；途中的 ControlNet、合併、FluxGuidance 等照對應的輸入往上走。
 * @param {Record<string, any>} graph @param {any} link @param {"positive" | "negative"} side @param {Set<string>} seen
 * @returns {string[]}
 */
function traceConditioning(graph, link, side, seen) {
  if (!isLink(link)) return [];
  const id = String(link[0]);
  const node = graph[id];
  if (!node || seen.has(id)) return [];
  seen.add(id);
  const type = String(node.class_type ?? "");
  const inputs = node.inputs ?? {};
  if (type === "ConditioningZeroOut") return [];
  if (type === "CLIPTextEncodeSDXL") {
    const gText = resolveText(graph, inputs.text_g, new Set());
    const lText = resolveText(graph, inputs.text_l, new Set());
    return [gText, lText !== gText ? lText : ""].filter(Boolean);
  }
  for (const key of ["text", "t5xxl", "clip_l", "prompt", "wildcard_text", "populated_text"]) {
    if (key in inputs) {
      const text = resolveText(graph, inputs[key], new Set());
      if (text) return [text];
    }
  }
  // 有正反兩個輸出的節點（ControlNetApplyAdvanced 等）：第 0 個輸出是正向、第 1 個是反向。
  const pass = "positive" in inputs && "negative" in inputs ? (link[1] === 1 ? "negative" : "positive") : side;
  /** @type {string[]} */
  const out = [];
  for (const key of [pass, "conditioning", "conditioning_1", "conditioning_2", "conditioning_to", "conditioning_from", "base_cond", "cond"]) {
    if (isLink(inputs[key])) out.push(...traceConditioning(graph, inputs[key], side, seen));
  }
  return out;
}

/** 沿 model 輸入往上走到載入器，途中收集 LoRA。 @param {Record<string, any>} graph @param {any} link */
function traceModel(graph, link) {
  /** @type {Array<{ name: string; weight: string }>} */
  const loras = [];
  let model = "";
  const seen = new Set();
  let current = link;
  while (isLink(current) && !seen.has(String(current[0]))) {
    const id = String(current[0]);
    seen.add(id);
    const node = graph[id];
    if (!node) break;
    const inputs = node.inputs ?? {};
    if (typeof inputs.lora_name === "string") loras.push({ name: modelName(inputs.lora_name), weight: show(inputs.strength_model ?? inputs.strength ?? "") });
    // rgthree 的 Power Lora Loader：lora_1、lora_2… 各是 { on, lora, strength }。
    for (const [key, value] of Object.entries(inputs)) {
      if (/^lora_\d+$/.test(key) && value && typeof value === "object" && !Array.isArray(value) && value.on !== false && value.lora) {
        loras.push({ name: modelName(value.lora), weight: show(value.strength ?? "") });
      }
    }
    const name = inputs.ckpt_name ?? inputs.unet_name ?? inputs.model_name ?? inputs.gguf_name;
    if (typeof name === "string") {
      model = modelName(name);
      break;
    }
    current = inputs.model;
  }
  return { model, loras: loras.reverse() };
}

/** 種子、步數這類可能接到 Primitive 節點的數值。 @param {Record<string, any>} graph @param {any} value */
function resolveValue(graph, value) {
  for (let depth = 0; isLink(value) && depth < 5; depth++) {
    const inputs = graph[String(value[0])]?.inputs ?? {};
    value = inputs.seed ?? inputs.noise_seed ?? inputs.value ?? inputs.int ?? inputs.Value ?? inputs.number;
  }
  return isLink(value) ? "" : value;
}

/** @param {Record<string, any>} graph @param {string} id */
function ancestors(graph, id) {
  const seen = new Set();
  const stack = [id];
  while (stack.length > 0) {
    const node = graph[/** @type {string} */ (stack.pop())];
    for (const value of Object.values(node?.inputs ?? {})) {
      if (isLink(value) && !seen.has(String(value[0]))) {
        seen.add(String(value[0]));
        stack.push(String(value[0]));
      }
    }
  }
  return seen;
}

/** @param {Record<string, any>} graph */
function fromComfy(graph) {
  const g = blank("ComfyUI");
  const ids = Object.keys(graph).filter((id) => graph[id] && typeof graph[id] === "object");
  const samplers = ids.filter((id) => {
    const node = graph[id];
    const inputs = node.inputs ?? {};
    return /sampler/i.test(String(node.class_type)) && ("positive" in inputs || "guider" in inputs || "model" in inputs);
  });
  // 主要的取樣器：latent 來自空白 latent 的（第一段，不是放大那段）；都不是就取上游最多的。
  const fromEmpty = samplers.filter((id) => {
    const latent = graph[id].inputs?.latent_image;
    return isLink(latent) && /^Empty/.test(String(graph[String(latent[0])]?.class_type));
  });
  const pick = (/** @type {string[]} */ list) => list.sort((a, b) => ancestors(graph, b).size - ancestors(graph, a).size)[0];
  const main = pick(fromEmpty.length > 0 ? fromEmpty : samplers);
  if (main) {
    const node = graph[main];
    let inputs = node.inputs ?? {};
    // SamplerCustomAdvanced：參數分散在 guider、noise、sigmas、sampler 幾個節點。
    const guider = isLink(inputs.guider) ? graph[String(inputs.guider[0])]?.inputs ?? {} : {};
    const sigmas = isLink(inputs.sigmas) ? graph[String(inputs.sigmas[0])]?.inputs ?? {} : {};
    const samplerNode = isLink(inputs.sampler) ? graph[String(inputs.sampler[0])]?.inputs ?? {} : {};
    const noise = isLink(inputs.noise) ? graph[String(inputs.noise[0])]?.inputs ?? {} : {};
    inputs = { ...sigmas, ...samplerNode, ...noise, ...guider, ...inputs };
    const positive = inputs.positive ?? inputs.conditioning;
    g.prompt = traceConditioning(graph, positive, "positive", new Set()).join("\n");
    g.negative = traceConditioning(graph, inputs.negative, "negative", new Set()).join("\n");
    put(g, "Steps", resolveValue(graph, inputs.steps));
    put(g, "Sampler", resolveValue(graph, inputs.sampler_name));
    put(g, "Schedule type", resolveValue(graph, inputs.scheduler));
    put(g, "CFG scale", resolveValue(graph, inputs.cfg));
    put(g, "Seed", resolveValue(graph, inputs.seed ?? inputs.noise_seed));
    const latent = isLink(inputs.latent_image) ? graph[String(inputs.latent_image[0])]?.inputs ?? {} : {};
    put(g, "Size", size(resolveValue(graph, latent.width), resolveValue(graph, latent.height)));
    const { model, loras } = traceModel(graph, inputs.model);
    put(g, "Model", model);
    g.loras = loras;
    const denoise = resolveValue(graph, inputs.denoise);
    if (isScalar(denoise) && Number(denoise) !== 1) put(g, "Denoising strength", denoise);
    for (const guidance of ids.filter((id) => graph[id].class_type === "FluxGuidance")) put(g, "Distilled CFG Scale", graph[guidance].inputs?.guidance);
  }
  const vae = ids.map((id) => graph[id]).find((n) => typeof n.inputs?.vae_name === "string");
  if (vae) put(g, "VAE", modelName(vae.inputs.vae_name));
  if (!main) {
    // 沒有取樣器時至少列出文字編碼節點的內容。
    ids.forEach((id) => {
      const text = graph[id].class_type?.startsWith("CLIPTextEncode") ? resolveText(graph, graph[id].inputs?.text, new Set()) : "";
      if (text) g.sections.push({ label: `${graph[id]._meta?.title ?? graph[id].class_type}（#${id}）`, text });
    });
  }
  return finish(g);
}

/** @param {any} value */
function isComfyGraph(value) {
  return value && typeof value === "object" && !Array.isArray(value) && Object.values(value).some((n) => n && typeof n === "object" && "class_type" in n);
}

// ---- 偵測 ----

/** EXIF 字串裡 ComfyUI 寫的 `prompt:{…}`、`workflow:{…}`。 @param {Container} c */
function comfyFromExif(c) {
  /** @type {Record<string, string>} */
  const found = {};
  for (const value of Object.values(c.exif)) {
    const m = value.match(/^(prompt|workflow):\s*([[{].*)$/is);
    if (m) found[m[1].toLowerCase()] = m[2];
  }
  return found;
}

/** XMP 裡 exif:UserComment 的內容（Draw Things）。 @param {string} xmp */
function xmpUserComment(xmp) {
  const m = xmp.match(/<exif:UserComment[^>]*>([\s\S]*?)<\/exif:UserComment>/);
  if (!m) return null;
  const li = m[1].match(/<rdf:li[^>]*>([\s\S]*?)<\/rdf:li>/);
  const text = (li ? li[1] : m[1]).trim();
  const doc = new DOMParser().parseFromString(`<x>${text}</x>`, "text/xml");
  return doc.documentElement.textContent ?? text;
}

/**
 * 依競品的偵測順序判斷是哪個工具：
 * `parameters` 最優先（SwarmUI、Fooocus 的 JSON 在 WebUI 文字之前判斷），再來 InvokeAI、NovelAI、Easy Diffusion、
 * ComfyUI，最後是 EXIF、XMP、註解。
 * @param {Container} c @returns {Generation | null}
 */
function interpret(c) {
  const t = c.texts;
  const lower = Object.fromEntries(Object.entries(t).map(([k, v]) => [k.toLowerCase(), v]));
  const fooocusScheme = (t.fooocus_scheme ?? c.exif.MakerNote ?? "").toLowerCase();

  /** `parameters` 或 UserComment 這種「一段文字」。 @param {string} text @returns {Generation | null} */
  const fromText = (text) => {
    const json = parseJson(text);
    if (json && typeof json === "object") {
      if (json.sui_image_params) return fromSwarm(json);
      if (json.metadata_scheme || fooocusScheme === "fooocus" || ("base_model" in json && "prompt" in json)) return fromFooocus(json);
      if ("prompt" in json && ("negative_prompt" in json || "use_stable_diffusion_model" in json || "num_inference_steps" in json)) {
        return fromEasyDiffusion(json);
      }
      if ("c" in json && ("uc" in json || "sampler" in json)) return fromDrawThings(json);
      if (isComfyGraph(json)) return fromComfy(json);
      return null;
    }
    const fooocus = fooocusScheme === "a1111" || /Fooocus/i.test(c.exif.Software ?? "");
    const hint = fooocus ? "Fooocus" : t.prompt && isComfyGraph(parseJson(t.prompt)) ? "ComfyUI（WebUI 相容格式）" : null;
    return fromInfotext(text, hint);
  };

  if (t.parameters) {
    const g = fromText(t.parameters);
    if (g) return g;
  }
  if (t.invokeai_metadata) {
    const m = parseJson(t.invokeai_metadata);
    if (m) return fromInvoke(m);
  }
  if (t.invokeai_graph) {
    const graph = parseJson(t.invokeai_graph);
    const nodes = graph?.nodes ?? {};
    const core = Object.entries(nodes).find(([k]) => k.startsWith("core_metadata"))?.[1];
    if (core) return fromInvoke(core);
  }
  if (t["sd-metadata"]) {
    const m = parseJson(t["sd-metadata"]);
    if (m) return fromInvokeLegacy(m);
  }
  if (t.Dream) return fromDream(t.Dream);
  if (/novelai/i.test(`${t.Software ?? ""} ${t.Source ?? ""}`) || (t.Comment && /"(uc|v4_prompt)"/.test(t.Comment))) return fromNovelAI(t);
  if ("negative_prompt" in t || "Negative Prompt" in t || "use_stable_diffusion_model" in t || "num_inference_steps" in t) {
    return fromEasyDiffusion(t);
  }
  const prompt = parseJson(t.prompt ?? "");
  if (isComfyGraph(prompt)) return fromComfy(prompt);
  if (t.Comment) {
    const json = parseJson(t.Comment);
    if (json && "prompt" in json) return fromFooocus(json);
  }
  const comfy = comfyFromExif(c);
  if (comfy.prompt) {
    const graph = parseJson(comfy.prompt);
    if (isComfyGraph(graph)) return fromComfy(graph);
  }
  const legacySwarm = parseJson(c.exif.Model ?? "");
  if (legacySwarm?.sui_image_params) return fromSwarm(legacySwarm);
  if (c.exif.UserComment) {
    // 一般照片也可能有 UserComment：不是 JSON 時要有 WebUI 的參數行才算。
    const g = fromText(c.exif.UserComment);
    if (g && (parseJson(c.exif.UserComment) || g.params.some(([k]) => k !== "LoRA"))) return g;
  }
  if (c.comment) {
    const json = parseJson(c.comment);
    if (json && "prompt" in json) return fromFooocus(json);
    if (/\nSteps: /.test(c.comment)) return fromInfotext(c.comment, null);
  }
  // PNG 的 XMP 放在文字區塊 `XML:com.adobe.xmp`。
  const xmp = c.xmp ?? t["XML:com.adobe.xmp"];
  if (xmp) {
    const comment = xmpUserComment(xmp);
    const json = comment ? parseJson(comment) : undefined;
    if (json && "c" in json) return fromDrawThings(json);
  }
  const description = t.Description ?? lower.description ?? c.exif.ImageDescription ?? "";
  if (/Midjourney|--niji\b|\s--(v|ar|q|s|c|iw|style|stylize|chaos)\s/.test(description) || /Job ID:/.test(description)) {
    return fromMidjourney(description, t);
  }
  if (c.exif.ImageDescription) {
    const json = parseJson(c.exif.ImageDescription);
    if (json && typeof json === "object") {
      const g = fromText(c.exif.ImageDescription);
      if (g) return g;
    }
  }
  return null;
}

/** 原始資料：檔案裡讀到的每段文字。相機的廠牌、型號這類短字串不算。 @param {Container} c @param {string | null} stealth */
function rawSections(c, stealth) {
  /** @type {Section[]} */
  const out = Object.entries(c.texts).map(([key, text]) => ({ label: key, text }));
  for (const [key, text] of Object.entries(c.exif)) {
    if (key === "UserComment" || text.length > 64 || /^(prompt|workflow):/i.test(text)) out.push({ label: `EXIF ${key}`, text });
  }
  if (c.comment) out.push({ label: "註解", text: c.comment });
  if (c.xmp) out.push({ label: "XMP", text: c.xmp });
  if (stealth) out.push({ label: "Stealth", text: stealth });
  return out;
}

/** @param {string} stealth */
function interpretStealth(stealth) {
  const json = parseJson(stealth);
  if (json && typeof json === "object") {
    if (json.Comment || /novelai/i.test(`${json.Software ?? ""} ${json.Source ?? ""}`)) return fromNovelAI(json);
    if (json.sui_image_params) return fromSwarm(json);
    return null;
  }
  return fromInfotext(stealth, null);
}

/**
 * 讀檔用的網址多一個查詢字串，和畫面上那張圖的網址不同：用同一個網址 fetch 會把 webview 已經載入的圖擠出快取，
 * 從詳情頁打開大圖時原圖得重新載入，大圖先顯示預覽再換成原圖，畫面會閃一下。檔案伺服器不看查詢字串。
 * @param {string} path @returns {Promise<Analysis>}
 */
async function analyze(path) {
  const url = `${hoard.fileSrc(path)}?ai-metadata`;
  let bytes = await fetchBytes(url, true);
  let read = await readContainer(bytes);
  const full = bytes.length < HEAD_BYTES;
  if (!read.complete && !full) {
    bytes = await fetchBytes(url, false);
    read = await readContainer(bytes);
  }
  let generation = interpret(read.container);
  let stealth = null;
  if (!generation && (read.container.format === "png" || read.container.format === "webp")) {
    if (!full && bytes.length === HEAD_BYTES) bytes = await fetchBytes(url, false);
    stealth = await readStealth(bytes).catch(() => null);
    if (stealth) generation = interpretStealth(stealth);
  }
  return { generation, raw: rawSections(read.container, stealth), c2pa: read.container.c2pa };
}

/**
 * 最近讀過的檔案（最多 40 個；ComfyUI 的 workflow 一份可能好幾百 KB）。鍵含修改時間與大小，
 * 原檔改過就重讀。 @type {Map<string, Promise<Analysis>>}
 */
const cache = new Map();
const CACHE_LIMIT = 40;

/** @param {HoardItemFile} file */
function analyzeFile(file) {
  const key = `${file.path}
${file.modified_at ?? ""}
${file.size ?? ""}`;
  let pending = cache.get(key);
  if (pending) {
    cache.delete(key); // 移到最新
  } else {
    pending = analyze(file.path);
    pending.catch(() => cache.delete(key));
  }
  cache.set(key, pending);
  if (cache.size > CACHE_LIMIT) cache.delete(/** @type {string} */ (cache.keys().next().value));
  return pending;
}

// ---- 篩選值（「篩選」裡的「模型」「LoRA」） ----

/** 解讀方式改了、要重讀全部作品時提高；記在每件作品的 `scanned`。 */
const SCAN_VERSION = "1";
/** 一批讀幾件、寫一次。 */
const SCAN_BATCH = 50;

/** 「Lora hashes」的名稱（`名稱: 雜湊, 名稱: 雜湊`）。 @param {Generation} g */
function loraHashNames(g) {
  const text = g.params.find(([k]) => k === "Lora hashes")?.[1] ?? "";
  return text
    .split(",")
    .map((part) => part.split(":")[0].trim())
    .filter(Boolean);
}

/** 篩選值一個最多 200 字。 @param {string} value */
function fit(value) {
  return value.slice(0, 200);
}

/** 存成篩選值的模型：Model，沒有時是 Model hash。 @param {Generation} g */
function modelValue(g) {
  const param = (/** @type {string} */ key) => g.params.find(([k]) => k === key)?.[1].trim() ?? "";
  return param("Model") || param("Model hash");
}

/**
 * 一件作品的篩選值：模型（沒有名稱時用 Model hash）、LoRA（去重），加上讀過的記號 `scanned`，
 * 沒有參數的圖片也寫，下次才不會重讀。
 * @param {number} id @param {Generation | null} g
 */
function fieldsOf(id, g) {
  const model = g ? modelValue(g) : "";
  const loras = g ? [...new Set([...g.loras.map((l) => l.name.trim()), ...loraHashNames(g)].filter(Boolean))] : [];
  return [
    { id, key: "model", values: model ? [fit(model)] : [] },
    { id, key: "lora", values: loras.map(fit) },
    { id, key: "scanned", values: [SCAN_VERSION] },
  ];
}

/**
 * 讀一件作品的檔案。不是圖片、沒有參數時是 null（讀過了）；這次讀不到時是 undefined（不記成讀過）。
 * 不經過 `cache`，補算幾千件時不留在記憶體裡。
 * @param {HoardItemSummary} item @returns {Promise<Generation | null | undefined>}
 */
async function generationOf(item) {
  const file = item.previews[0];
  if (item.metadata.format != null || !file || !readable(file)) return null;
  // 檔案現在不在（外接硬碟沒接、被搬走）：不算讀過，下次再試。
  if (item.missing) return undefined;
  try {
    return (await analyze(file.path)).generation;
  } catch (err) {
    console.warn("[ai-metadata] 讀不到檔案，下次載入再試：", file.path, err);
    return undefined;
  }
}

hoard.registerFilter({ id: "model", label: "模型", icon: "box", key: "model" });
hoard.registerFilter({ id: "lora", label: "LoRA", icon: "layers", key: "lora" });

let unloaded = false;
let scanning = false;
/** 這次載入讀不到的作品：補算時跳過，免得每一批都撈到它們；下次載入再試。 @type {Set<number>} */
const unreadable = new Set();
let scanAgain = false;
/**
 * 移到垃圾桶的作品從查詢結果消失；還原時又回來，可能排在讀不到的那幾件中間，
 * 這時下一輪從頭數，不能直接跳過 unreadable.size 件。
 */
const removedIds = new Set();
let recount = false;
hoard.onUnload(() => {
  unloaded = true;
});
hoard.on("items-removed", ({ ids }) => {
  for (const id of ids) {
    unreadable.delete(id);
    removedIds.add(id);
  }
});
hoard.on("items-changed", ({ ids }) => {
  if (!ids.some((id) => removedIds.delete(id))) return;
  recount = true;
  void scan();
});

/**
 * 替還沒讀過的本機圖片算篩選值：插件載入時補舊的，之後新收進來的也走這裡。
 * 一批一批讀、寫，批與批之間讓出主執行緒；同時只跑一輪，跑的時候又有新作品就再跑一輪。
 */
async function scan() {
  if (scanning) {
    scanAgain = true;
    return;
  }
  scanning = true;
  try {
    do {
      scanAgain = false;
      // 由舊到新：讀不到的作品留在最前面，通常直接從第 unreadable.size 件開始；新收進來的接在最後。
      // 有作品從垃圾桶還原時從頭數。寫過的作品離開結果，留下來的（讀不到的）往後跳過。
      let offset = recount ? 0 : unreadable.size;
      recount = false;
      for (;;) {
        if (unloaded) return;
        const page = await hoard.items.list(
          { source_type: "local", exts: [...READABLE], fields: [{ owner: "ai-metadata", key: "scanned", none: true }] },
          { limit: SCAN_BATCH, offset, sort: "added", ascending: true },
        );
        if (page.items.length === 0 || unloaded) break;
        /** @type {Array<{ id: number; key: string; values: string[] }>} */
        const entries = [];
        let written = 0;
        for (const item of page.items) {
          if (unreadable.has(item.id)) continue;
          const generation = await generationOf(item);
          if (generation === undefined) unreadable.add(item.id);
          else {
            entries.push(...fieldsOf(item.id, generation));
            written++;
          }
        }
        if (unloaded) return;
        if (entries.length > 0) await hoard.items.setFields(entries);
        offset += page.items.length - written;
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    } while (scanAgain || recount);
  } catch (err) {
    console.error("[ai-metadata] 篩選值補算中斷：", err);
  } finally {
    scanning = false;
  }
}

hoard.on("items-added", () => void scan());
void scan();

// ---- 詳情頁 ----

/** @param {number} bytes */
function formatSize(bytes) {
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit++;
  }
  return `${unit === 0 ? value : value.toFixed(1)} ${units[unit]}`;
}

/** @param {string} text @param {string} [title] */
function copyButton(text, title = "複製") {
  return hoard.el(
    "button",
    {
      class: "am-copy",
      title,
      onclick: (event) => {
        event.preventDefault();
        navigator.clipboard.writeText(text).then(
          () => hoard.toast("已複製"),
          () => hoard.toast("複製失敗", { kind: "error" }),
        );
      },
    },
    [hoard.icon("copy", { size: 12 })],
  );
}

/** @param {string} label @param {string} text */
function textBlock(label, text) {
  return hoard.el("div", { class: "am-block" }, [
    hoard.el("div", { class: "am-label-row" }, [
      hoard.el("span", { class: "am-label" }, [label]),
      copyButton(text),
    ]),
    hoard.el("p", { class: "am-text" }, [text]),
  ]);
}

/** @param {Array<[string, Node | string]>} rows */
function table(rows) {
  return hoard.el(
    "dl",
    { class: "am-table" },
    rows.flatMap(([label, value]) => [
      hoard.el("dt", { class: "am-table-label" }, [label]),
      hoard.el("dd", { class: "am-table-value" }, [value]),
    ]),
  );
}

/** 和 App 內建的本機詳情頁同一份檔案資訊。 @param {HoardItemDetail} item */
function fileInfo(item) {
  const meta = item.metadata;
  const file = item.files[0];
  const page = item.source_url ?? (typeof meta.page_url === "string" ? meta.page_url : null);
  /** @type {Array<[string, Node | string]>} */
  const rows = [];
  if (typeof meta.original_name === "string") rows.push(["檔名", meta.original_name]);
  if (file?.ext) rows.push(["格式", file.ext.toUpperCase()]);
  if (typeof file?.size === "number") rows.push(["大小", formatSize(file.size)]);
  if (file?.width && file.height) rows.push(["尺寸", `${file.width} × ${file.height}`]);
  rows.push(["加入時間", hoard.formatDate(item.added_at)]);
  if (file?.original_path) rows.push(["原始位置", file.original_path]);
  if (page) {
    rows.push([
      "來源網頁",
      hoard.el("button", { class: "am-link", onclick: () => hoard.openUrl(page) }, [page]),
    ]);
  }
  return table(rows);
}

/** 原始資料收在可展開的區塊裡；JSON 排版。 @param {Section} entry */
function rawBlock(entry) {
  const json = parseJson(entry.text);
  const text = json === undefined ? entry.text : JSON.stringify(json, null, 2);
  return hoard.el("details", { class: "am-raw" }, [
    hoard.el("summary", { class: "am-raw-summary" }, [
      entry.label,
      copyButton(entry.text),
    ]),
    hoard.el("pre", { class: "am-raw-text" }, [text]),
  ]);
}

/**
 * 點了跳到收藏庫，篩出用了同一個模型或 LoRA 的作品。
 * @param {string} text @param {"model" | "lora"} key @param {string} value
 */
function filterLink(text, key, value) {
  return hoard.el(
    "button",
    {
      class: "am-link am-filter-link",
      title: key === "model" ? "在收藏庫找用這個模型的作品" : "在收藏庫找用這個 LoRA 的作品",
      onclick: () => hoard.openLibrary({ fields: [{ owner: "ai-metadata", key, any: [fit(value.trim())] }] }),
    },
    [text],
  );
}

/**
 * 參數表；`linked` 時模型與 LoRA 可以點（詳情頁。快速預覽不跳走）。
 * @param {Generation} g @param {boolean} linked @returns {Array<[string, Node | string]>}
 */
function paramRows(g, linked) {
  if (!linked) return g.params;
  const model = modelValue(g);
  const modelKey = g.params.some(([k]) => k === "Model") ? "Model" : "Model hash";
  return g.params.map(([key, value]) => {
    if (key === modelKey && model) return [key, filterLink(value, "model", model)];
    if (key === "LoRA" && g.loras.length > 0) {
      const links = g.loras.map((l) => filterLink(l.weight ? `${l.name} (${l.weight})` : l.name, "lora", l.name));
      return [key, hoard.el("span", { class: "am-filter-links" }, links)];
    }
    return [key, value];
  });
}

/** @param {Analysis} a @param {boolean} [linked] */
function generationSection(a, linked = false) {
  const g = a.generation;
  /** @type {Array<Node | null>} */
  const body = [];
  if (g) {
    if (g.prompt) body.push(textBlock("提示詞", g.prompt));
    if (g.negative) body.push(textBlock("反向提示詞", g.negative));
    for (const s of g.sections) body.push(textBlock(s.label, s.text));
    if (g.params.length > 0) body.push(table(paramRows(g, linked)));
  }
  if (a.c2pa) {
    body.push(hoard.el("p", { class: "am-note" }, ["這張圖帶有 C2PA 內容憑證（DALL·E、Firefly 等），目前不解析內容。"]));
  }
  if (a.raw.length > 0) {
    body.push(
      hoard.el("div", { class: "am-raw-list" }, [
        hoard.el("span", { class: "am-label" }, ["原始資料"]),
        ...a.raw.map(rawBlock),
      ]),
    );
  }
  return hoard.el("section", { class: "am-generation" }, [
    hoard.el("div", { class: "am-header" }, [
      hoard.icon("sparkles", { size: 14, class: "am-header-icon" }),
      hoard.el("h3", { class: "am-title" }, ["生成參數"]),
      g ? hoard.el("span", { class: "am-tool" }, [g.tool]) : null,
      g?.infotext ? copyButton(g.infotext, "複製（WebUI 格式，可貼進 WebUI／Forge 讀取參數）") : null,
    ]),
    ...body,
  ]);
}

/** 試著讀的檔案：一般的圖片檔（不是壓縮檔裡的頁）。 @param {HoardItemFile} file */
function readable(file) {
  const ext = file.path.split(".").pop()?.toLowerCase() ?? "";
  return file.kind === "image" && file.entry === null && READABLE.has(ext);
}

/**
 * 認不出工具時，原始資料像生成參數的才算：有「鍵: 值」寫法的生成欄位（WebUI 的參數行、JSON、XML 屬性），
 * 或 IPTC 標示的 AI 生成。繪圖軟體、相機、網站寫的 Software、XMP、JPEG 註解這些都不是生成參數。
 */
const GENERATION_HINT =
  /(?<![a-z])(?:prompt|steps|sampler|cfg[ _]?scale|seed|scheduler|denoising[ _]?strength|checkpoint|lora)\w*["']?\s*[:=]|trainedAlgorithmicMedia/i;

/** 認出工具、有 C2PA 或 Stealth、或原始資料像生成參數才顯示。 @param {Analysis} a */
function worthShowing(a) {
  return Boolean(
    a.generation || a.c2pa || a.raw.some((r) => r.label === "Stealth" || GENERATION_HINT.test(r.text)),
  );
}

/** 有生成參數時左圖右參數；視窗窄於 lg 時照樣疊成一欄。 */
const TWO_COLUMNS = "am-two-columns";
/** 圖片固定在畫面上、整張看得到，右欄的參數自己捲動。 */
const STICKY_MEDIA = "am-sticky-media";
const ONE_COLUMN = "am-one-column";

// ---- 動畫（App 的 docs/conventions.md〈動畫〉：插件拿不到 App 的動畫程式，照同一組時長、曲線自己做） ----

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場、收起。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/**
 * 「讀取生成參數…」換成內容：提示已經出現過（CSS 讓它等 200ms 才淡入）時內容淡入 180ms、提示疊在上面同時淡出；
 * 很快就讀好、提示還沒出現時內容直接淡入 120ms。
 * @param {HTMLElement} box @param {HTMLElement[]} content
 */
function swapLoaded(box, content) {
  const note = /** @type {HTMLElement | null} */ (box.querySelector(".am-loading"));
  if (!motionOn()) return void box.replaceChildren(...content);
  const seen = note ? parseFloat(getComputedStyle(note).opacity) > 0.05 : false;
  if (note) {
    // 提示停在現在的樣子（搬進疊層時 CSS 動畫會重來）。
    note.style.opacity = getComputedStyle(note).opacity;
    note.style.animation = "none";
  }
  box.replaceChildren(...content);
  for (const el of content) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: seen ? 180 : 120, easing: EASE_OUT, fill: "backwards" });
  if (!note || !seen) return;
  const ghost = hoard.el("div", { class: "am-late-ghost", "aria-hidden": "true" }, [note]);
  box.prepend(ghost);
  void ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 180, easing: EASE_IN, fill: "forwards" }).finished.then(
    () => ghost.remove(),
    () => ghost.remove(),
  );
}

/**
 * 版面換了以後，元素從原本的位置滑到新的位置（FLIP）。圖片連大小一起補（等比例縮放），文字欄只移動不縮放（不然字會變形）。
 * @param {Array<[HTMLElement, DOMRect, boolean]>} moves [元素, 換版面前的位置, 要不要補大小]
 * @param {number} ms @param {string} easing
 */
function glide(moves, ms, easing) {
  for (const [el, from, sized] of moves) {
    const to = el.getBoundingClientRect();
    if (to.width === 0 || to.height === 0) continue;
    const scale = sized ? from.width / to.width : 1;
    const dx = from.left - to.left;
    const dy = from.top - to.top;
    if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5 && Math.abs(scale - 1) < 0.005) continue;
    el.animate(
      [
        { transformOrigin: "0 0", translate: `${dx}px ${dy}px`, scale: String(scale) },
        { transformOrigin: "0 0", translate: "0 0", scale: "1" },
      ],
      { duration: ms, easing },
    );
  }
}

/**
 * 上一件有沒有參數欄（詳情頁與快速預覽共用）。讀檔太久、得先畫出來時照它猜：連著看 AI 圖片時先留好右欄，
 * 連著看一般圖片時也不會每張都先出現再收回。
 */
let lastHadPanel = false;

/** 讀生成參數最多等多久才先把畫面畫出來（App 的 docs/conventions.md：要查才等，最多 300ms）；大多數圖片幾十毫秒就讀完。 */
const LAYOUT_WAIT_MS = 300;

/**
 * 讀完才排版面、整個放上去：圖片一出現就在最後的位置（從清單打開時卡片的圖飛到大圖第一次出現的地方、
 * 換作品整頁滑進來），不會先排兩欄再收回一欄。讀過的檔案有快取，下一次 microtask 就到，畫面出來前就排好了。
 * 超過 LAYOUT_WAIT_MS 才先叫 `early` 照猜的畫出來，讀完再叫 `then(a, true)` 修正。
 * @param {HoardItemFile} file
 * @param {() => void} early 等太久：先照 `lastHadPanel` 畫出來
 * @param {(a: Analysis | null, late: boolean) => void} then 讀完（讀不到是 null）；`late` 表示畫面已經先畫出來了
 * @returns {() => void} 不要了（作品換掉、頁面拆掉）
 */
function whenAnalyzed(file, early, then) {
  let alive = true;
  let late = false;
  const timer = setTimeout(() => {
    if (!alive) return;
    late = true;
    early();
  }, LAYOUT_WAIT_MS);
  analyzeFile(file)
    .catch((err) => {
      console.warn("[ai-metadata] 讀不到檔案：", file.path, err);
      return null;
    })
    .then((a) => {
      if (!alive) return;
      clearTimeout(timer);
      then(a, late);
    });
  return () => {
    alive = false;
    clearTimeout(timer);
  };
}

/** @param {HTMLElement} root @param {HoardItemDetail} item @param {HoardRenderCtx} ctx */
function renderLocalDetail(root, item, ctx) {
  const media = hoard.el("div");
  ctx.mountImageColumn(media, item);
  const generation = hoard.el("div", { class: "am-late" });
  const side = hoard.el("div", { class: "am-side" }, [fileInfo(item), generation]);
  const page = hoard.el("div", { class: ONE_COLUMN }, [media, side]);
  /**
   * @param {boolean} two
   * @param {boolean} [animate] 先畫出來以後才知道要改版面時：圖片與檔案資訊從原本的位置滑到新的位置
   *   （收回一欄 180ms ease-in，展開兩欄 180ms ease-out）
   */
  const setColumns = (two, animate = false) => {
    const before = animate && motionOn() ? [media.getBoundingClientRect(), side.getBoundingClientRect()] : null;
    page.className = two ? TWO_COLUMNS : ONE_COLUMN;
    media.className = two ? STICKY_MEDIA : "";
    if (before) {
      glide(
        [
          [media, before[0], true],
          [side, before[1], false],
        ],
        180,
        two ? EASE_OUT : EASE_IN,
      );
    }
  };

  const file = item.files[0];
  if (!file || !readable(file)) {
    root.append(page);
    return () => {};
  }
  return whenAnalyzed(
    file,
    () => {
      if (lastHadPanel) {
        setColumns(true);
        generation.replaceChildren(loadingNote());
      }
      root.append(page);
    },
    (a, late) => {
      const worth = a !== null && worthShowing(a);
      lastHadPanel = worth;
      if (!late) {
        if (a && worth) {
          setColumns(true);
          generation.replaceChildren(generationSection(a, true));
        }
        root.append(page);
        return;
      }
      if (worth !== (page.className === TWO_COLUMNS)) setColumns(worth, true);
      if (a && worth) swapLoaded(generation, [generationSection(a, true)]);
      else generation.replaceChildren();
    },
  );
}

/** 讀檔時右欄的佔位。 */
function loadingNote() {
  return hoard.el("div", { class: "am-loading" }, [
    hoard.icon("sparkles", { size: 14 }),
    "讀取生成參數…",
  ]);
}


// ---- 快速預覽 ----

/** 跟詳情頁一樣讀完才排版面（`whenAnalyzed`）。 @param {HTMLElement} root @param {HoardItemSummary} item @param {HoardQuickLookCtx} ctx */
function renderQuickLook(root, item, ctx) {
  const media = hoard.el("div", { class: "am-ql-media" });
  ctx.mountDefault(media);
  const side = hoard.el("aside", { class: "am-ql-side" });
  const page = hoard.el("div", { class: "am-ql" }, [media]);
  /** @param {boolean} on */
  const setPanel = (on) => {
    lastHadPanel = on;
    if (on && !side.isConnected) page.append(side);
    if (!on) side.remove();
  };

  return whenAnalyzed(
    item.previews[0],
    () => {
      if (lastHadPanel) {
        side.replaceChildren(loadingNote());
        setPanel(true);
      }
      root.append(page);
    },
    (a, late) => {
      const worth = a !== null && worthShowing(a);
      if (a && worth) side.replaceChildren(generationSection(a));
      setPanel(worth);
      if (!late) root.append(page);
    },
  );
}

/**
 * 第一個檔案是讀得懂的圖片（不是多頁作品）。第一個檔案是圖片時它就是 `previews[0]`。
 * @param {HoardItemSummary} item
 */
function takesItem(item) {
  return (
    item.metadata.format == null &&
    READABLE.has((item.ext ?? "").toLowerCase()) &&
    item.previews.length > 0 &&
    readable(item.previews[0])
  );
}

// 詳情頁與快速預覽：圖片照 App 內建的畫，讀到生成參數時多一欄。
hoard.registerPresenter({
  sources: ["local"],
  accepts: takesItem,
  detail: renderLocalDetail,
  quickLook: renderQuickLook,
});
