// @ts-check
/// <reference path="../hoard-extractor.d.ts" />
/* X.com 貼文擷取器：DOM 擷取（data-testid），X 改版時需要更新這裡。
 * 除了彈出視窗的「抓取此頁」，integrate() 也會在貼文動作列（書籤旁）加「加到 hoard」按鈕、
 * 並可在按讚／加入書籤時自動收藏（開關在 App 的插件設定「在網頁上」）；
 * 拖貼文裡的圖片到擴充的投放區時只收那一張（dragCapture）。 */

/** 把 pbs.twimg.com 圖片網址升級成原始尺寸。 */
function toOriginalSize(src) {
  try {
    const url = new URL(src);
    url.searchParams.set("name", "orig");
    return url.toString();
  } catch {
    return src;
  }
}

/**
 * X 的 <video> 用 blob: MSE 串流，DOM 讀不到真正的檔案網址。影片本身交給 App 端的
 * yt-dlp 下載（能處理敏感／R18 內容），這裡只負責：抓圖片、判斷貼文是否含影片。
 *
 * 圖片優先走公開的 syndication API（embed 用、免登入）取原始尺寸；被敏感內容擋下
 * （TweetTombstone）時改問 GraphQL（帶登入狀態），都失敗才退回 DOM 抓到的圖片。token 演算法沿用 X embed 前端。
 */
function syndicationToken(id) {
  return ((Number(id) / 1e15) * Math.PI).toString(36).replace(/(0+|\.)/g, "");
}

/** syndication 的貼文物件；取不到、或被 TweetTombstone 擋下（敏感／年齡限制）時為 null。 */
async function fetchSyndication(statusId) {
  const token = syndicationToken(statusId);
  const url = `https://cdn.syndication.twimg.com/tweet-result?id=${statusId}&token=${token}&lang=en`;
  // X.com 的 CSP 會擋掉頁面環境對 syndication 的跨網域請求；hoard.fetchJson 會先試
  // 頁面、被擋下時退回 background fetch（有 host 權限、不受頁面 CSP 限制）。
  const data = await hoard.fetchJson(url);
  if (!data || data.__typename === "TweetTombstone") return null;
  return data;
}

/** 從 syndication 的 mediaDetails 取圖片網址，並判斷是否含影片。 */
function collectSyndicationMedia(data) {
  return collectMedia(Array.isArray(data.mediaDetails) ? data.mediaDetails : []);
}

/**
 * GraphQL 的 extended_entities.media 與 syndication 的 mediaDetails 同形：
 * 圖片取原圖並帶上作者寫的替代文字（ext_alt_text）；純影片貼文沒有圖片時，
 * 影片封面只給 payload 的 `poster` 當卡片縮圖，不放進 `media`：放進去會變成作品的一張靜態圖，
 * 排在影片前面，打開時先看到它，像是動畫沒在播。
 * X 不保留上傳的 GIF 檔，會轉成無聲循環的 MP4（type 是 animated_gif）；照樣當影片下載，
 * isGif 讓 App 端像 GIF 一樣自動循環播放。
 * 圖片和影片混在一起時（X 一篇最多 20 個），videoAt 記每段影片前面有幾張圖，
 * App 下載完影片照它插回原貼文的位置（payload 的 video_at）；影片都在圖片後面時不用給。
 */
function collectMedia(list) {
  const imageUrls = [];
  /** @type {number[]} */
  const videoAt = [];
  /** @type {{ url: string } | undefined} */
  let poster;
  let hasVideo = false;
  let isGif = false;
  for (const m of list) {
    const alt = m.ext_alt_text || undefined;
    if (m.type === "photo") {
      if (m.media_url_https) imageUrls.push({ url: toOriginalSize(m.media_url_https), alt });
    } else if (m.type === "video" || m.type === "animated_gif") {
      hasVideo = true;
      videoAt.push(imageUrls.length);
      if (m.type === "animated_gif") isGif = true;
      if (m.media_url_https) poster ??= { url: m.media_url_https };
    }
  }
  return {
    imageUrls,
    hasVideo,
    isGif,
    videoAt: videoAt.some((n) => n < imageUrls.length) ? videoAt : undefined,
    poster: imageUrls.length === 0 ? poster : undefined,
  };
}

// ---- 不在頁面上的貼文（從資料封存匯入按讚） ----------------------------------
//
// 封存的按讚只有推文 ID 和文字，要逐篇向 X 查。用 X 網頁自己的 GraphQL（帶登入狀態，
// 敏感內容也查得到）；queryId、bearer、功能開關都從目前頁面的 main.js 與
// __INITIAL_STATE__ 讀，X 改版時跟著變。讀不到（沒登入、改版）時退回 syndication。

/** 封存匯入的作品的 added_via。 */
const ARCHIVE_VIA = "x-archive";
/** localStorage：拿不到的推文 { [id]: "gone" | "restricted" }，下次匯入直接略過。 */
const ARCHIVE_SKIP_KEY = "hoard-x-archive-skip";

function readSkipList() {
  try {
    return JSON.parse(localStorage.getItem(ARCHIVE_SKIP_KEY) ?? "{}") ?? {};
  } catch {
    return {};
  }
}

/** 記下拿不到的推文，回傳讓批次算「略過」的錯誤。 */
function unavailable(statusId, state, message) {
  try {
    const skip = readSkipList();
    skip[statusId] = state;
    localStorage.setItem(ARCHIVE_SKIP_KEY, JSON.stringify(skip));
  } catch {
    // 記不住就下次再查一次。
  }
  const err = new Error(message);
  /** @type {any} */ (err).skipped = true;
  return err;
}

/** @type {Promise<{ queryId: string; bearer: string; features: Record<string, boolean> }> | null} */
let graphqlSetup = null;
/** 上一次回應說額度用完時，額度重置的時間（毫秒）。 */
let graphqlCooldown = 0;

async function loadGraphql() {
  const main = Array.from(document.scripts, (s) => s.src).find((src) => /\/main\.[^/]+\.js$/.test(src));
  if (!main) throw new Error("找不到 X 的 main.js");
  const code = await (await fetch(main)).text();
  const at = code.indexOf('operationName:"TweetResultByRestId"');
  const bearer = code.match(/"(AAAAAAAAA[A-Za-z0-9%]{60,})"/)?.[1];
  if (at < 0 || !bearer) throw new Error("main.js 裡找不到 TweetResultByRestId");
  const def = code.slice(code.lastIndexOf("{queryId:", at), code.indexOf("}}", at) + 2);
  const queryId = def.match(/queryId:"([^"]+)"/)?.[1];
  const switches = JSON.parse(def.match(/featureSwitches:(\[[^\]]*\])/)?.[1] ?? "[]");
  if (!queryId) throw new Error("讀不到 TweetResultByRestId 的 queryId");

  const PREFIX = "window.__INITIAL_STATE__=";
  const script = Array.from(document.scripts).find((s) => s.textContent?.startsWith(PREFIX));
  const text = script?.textContent ?? "";
  const end = text.indexOf(";window.__META_DATA__");
  const state = JSON.parse(text.slice(PREFIX.length, end < 0 ? undefined : end) || "{}");
  const config = state.featureSwitch?.user?.config ?? state.featureSwitch?.defaultConfig ?? {};
  const features = Object.fromEntries(switches.map((name) => [name, config[name]?.value ?? false]));
  return { queryId, bearer, features };
}

function graphql() {
  graphqlSetup ??= loadGraphql().catch((err) => {
    graphqlSetup = null;
    throw err;
  });
  return graphqlSetup;
}

/**
 * 用 GraphQL 查一篇。{ tweet } 是查到了；{ state } 是已刪除（gone）或看不到（restricted）。
 * 到了查詢上限（每 15 分鐘 500 次）就等到重置再查；`patient` 是 false 時不等，直接丟出錯誤。
 */
async function fetchTweetGraphql(statusId, progress, patient = true) {
  const { queryId, bearer, features } = await graphql();
  const csrf = document.cookie.match(/(?:^|; )ct0=([^;]+)/)?.[1];
  if (!csrf) throw new Error("沒有登入 X");
  const variables = { tweetId: statusId, withCommunity: false, includePromotedContent: false, withVoice: false };
  const url =
    `https://x.com/i/api/graphql/${queryId}/TweetResultByRestId` +
    `?variables=${encodeURIComponent(JSON.stringify(variables))}` +
    `&features=${encodeURIComponent(JSON.stringify(features))}`;
  for (;;) {
    const res = await fetch(url, {
      credentials: "include",
      headers: {
        authorization: `Bearer ${bearer}`,
        "x-csrf-token": csrf,
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-active-user": "yes",
      },
    });
    const reset = Number(res.headers.get("x-rate-limit-reset")) * 1000;
    const remaining = Number(res.headers.get("x-rate-limit-remaining") ?? 1);
    if (res.status === 429) {
      if (!patient) throw new Error("已到 X 的查詢上限");
      await waitForReset(reset, progress);
      continue;
    }
    if (!res.ok) throw new Error(`X 回應 ${res.status}`);
    const body = await res.json();
    // 先回傳這一篇，下一篇查之前再等，免得這篇卡在等待裡。
    if (remaining <= 1) graphqlCooldown = reset;
    let result = body?.data?.tweetResult?.result;
    if (!result) return { state: "gone" };
    if (result.__typename === "TweetWithVisibilityResults") result = result.tweet;
    if (result?.__typename !== "Tweet") return { state: "restricted" };
    return { tweet: result };
  }
}

/**
 * 頁面上的貼文被 syndication 擋下（敏感內容）時，改用 GraphQL（帶登入狀態）讀它的媒體：
 * 原圖、替代文字與圖片影片的順序。查不到、或已到查詢上限就是 null，照頁面上讀到的收，不等。
 */
async function graphqlMedia(statusId) {
  if (graphqlCooldown > Date.now()) return null;
  try {
    const found = await fetchTweetGraphql(statusId, undefined, false);
    return found.tweet ? collectMedia(found.tweet.legacy?.extended_entities?.media ?? []) : null;
  } catch {
    return null;
  }
}

async function waitForReset(reset, progress) {
  const until = reset > Date.now() ? reset : Date.now() + 60_000;
  const time = new Date(until).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  progress?.(`已到 X 的查詢上限，${time} 繼續…`);
  await hoard.sleep(until - Date.now() + 2000);
}

/** 還原 X 文字裡的跳脫，t.co 換回原網址，拿掉指向媒體的短網址。 */
function tweetText(legacy, note) {
  let text = note ?? legacy.full_text ?? "";
  for (const u of legacy.entities?.urls ?? []) {
    if (u.url && u.expanded_url) text = text.split(u.url).join(u.expanded_url);
  }
  for (const m of legacy.extended_entities?.media ?? legacy.entities?.media ?? []) {
    if (m.url) text = text.split(m.url).join("");
  }
  return text
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .trim();
}

/** 只有網址、不在頁面上的一篇（封存匯入）：GraphQL 優先，退回 syndication。 */
async function extractRemote(statusId, listing, progress) {
  progress?.("讀取貼文資訊…");
  if (graphqlCooldown > Date.now()) await waitForReset(graphqlCooldown, progress);
  let found = null;
  try {
    found = await fetchTweetGraphql(statusId, progress);
  } catch (err) {
    // GraphQL 用不了（沒登入、X 改版）：改用 syndication，敏感內容拿不到。
    const syn = await fetchSyndication(statusId);
    if (!syn) {
      throw new Error(`查不到這則貼文（${err instanceof Error ? err.message : String(err)}）`);
    }
    return syndicationPayload(statusId, syn, listing, progress);
  }
  if (found.state === "gone") throw unavailable(statusId, "gone", "原文已刪除");
  if (found.state === "restricted") throw unavailable(statusId, "restricted", "原文看不到（受保護或帳號已停用）");

  const tweet = found.tweet;
  const legacy = tweet.legacy ?? {};
  const user = tweet.core?.user_results?.result;
  const handle = user?.core?.screen_name ?? user?.legacy?.screen_name;
  const name = user?.core?.name ?? user?.legacy?.name ?? handle;
  if (!handle) throw new Error("讀不到作者");

  const { imageUrls, hasVideo, isGif, videoAt, poster } = collectMedia(legacy.extended_entities?.media ?? []);

  const warnings = [];
  if (imageUrls.length) progress?.("下載圖片…");
  const media = await hoard.fetchAllMedia(imageUrls, warnings, progress);
  const note = tweet.note_tweet?.note_tweet_results?.result?.text;
  return {
    payload: {
      source_type: "twitter",
      source_url: `https://x.com/${handle}/status/${statusId}`,
      description: tweetText(legacy, note) || listing?.data?.text || "",
      author: { name, handle, url: `https://x.com/${handle}` },
      published_at: legacy.created_at ? new Date(legacy.created_at).toISOString() : undefined,
      metadata: {
        status_id: statusId,
        author_avatar: avatarOf(user?.avatar?.image_url ?? user?.legacy?.profile_image_url_https),
        like_count: legacy.favorite_count ?? 0,
        retweet_count: legacy.retweet_count ?? 0,
        reply_count: legacy.reply_count ?? 0,
        has_video: hasVideo,
        is_gif: isGif || undefined,
      },
      media,
      video_at: videoAt,
      poster,
      comments: [],
    },
    warnings,
  };
}

/** syndication 的貼文物件 → 匯入資料（GraphQL 用不了時的退路）。 */
async function syndicationPayload(statusId, syn, listing, progress) {
  const handle = syn.user?.screen_name;
  if (!handle) throw new Error("讀不到作者");
  const { imageUrls, hasVideo, isGif, videoAt, poster } = collectSyndicationMedia(syn);
  const warnings = [];
  if (imageUrls.length) progress?.("下載圖片…");
  const media = await hoard.fetchAllMedia(imageUrls, warnings, progress);
  return {
    payload: {
      source_type: "twitter",
      source_url: `https://x.com/${handle}/status/${statusId}`,
      description:
        tweetText({ full_text: syn.text, entities: syn.entities, extended_entities: { media: syn.mediaDetails } }, null) ||
        listing?.data?.text ||
        "",
      author: { name: syn.user.name ?? handle, handle, url: `https://x.com/${handle}` },
      published_at: syn.created_at ? new Date(syn.created_at).toISOString() : undefined,
      metadata: {
        status_id: statusId,
        author_avatar: avatarOf(syn.user.profile_image_url_https),
        like_count: syn.favorite_count ?? 0,
        reply_count: syn.conversation_count ?? 0,
        has_video: hasVideo,
        is_gif: isGif || undefined,
      },
      media,
      video_at: videoAt,
      poster,
      comments: [],
    },
    warnings,
  };
}

/** 封存裡 like.js（或 like-part1.js…）的內容 → [{ id, text }]，檔案裡新的在前。 */
function parseLikes(text) {
  const json = text.slice(text.indexOf("=") + 1);
  const rows = JSON.parse(json);
  if (!Array.isArray(rows)) return [];
  return rows
    .map((row) => row?.like)
    .filter((like) => like && /^\d+$/.test(String(like.tweetId)))
    .map((like) => ({ id: String(like.tweetId), text: String(like.fullText ?? "") }));
}

/**
 * 彈出視窗「從 X 資料封存匯入按讚」選好的 like.js（分成多個檔案時是 like-part1.js…），跑批次。
 * 最舊的按讚先收，依「加入時間」排序就是按讚的先後。
 */
async function importArchiveLikes(page, files) {
  const toast = page.toast();
  toast.title("從 X 封存匯入按讚");
  let likes = [];
  try {
    files = [...files].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
    for (const file of files) {
      if (!file.text.includes("window.YTD.like.")) throw new Error(`${file.name} 不是封存裡的按讚檔（like.js）`);
      likes.push(...parseLikes(file.text));
    }
  } catch (err) {
    toast.finish("error", "讀不到封存", [err instanceof Error ? err.message : String(err)]);
    return;
  }
  const seen = new Set();
  likes = likes.filter((like) => !seen.has(like.id) && seen.add(like.id)).reverse();
  const skip = readSkipList();
  const posts = likes
    .filter((like) => !skip[like.id])
    .map((like) => ({
      url: `https://x.com/i/status/${like.id}`,
      title: like.text.replace(/\s*https:\/\/t\.co\/\S+/g, "").slice(0, 40) || like.id,
      data: { archive: true, text: like.text },
    }));
  const skipped = likes.length - posts.length;
  toast.finish(
    "info",
    `封存裡有 ${likes.length} 則按讚`,
    skipped ? [`${skipped} 則上次已確認拿不到，這次略過`] : [],
  );
  try {
    await page.runBatch(posts, {
      title: "從 X 封存匯入按讚",
      addedVia: ARCHIVE_VIA,
      // 查詢上限每 15 分鐘 500 次，平均 1.8 秒一次。
      intervalMs: 2000,
    });
  } catch (err) {
    page.toast().finish("error", "無法開始匯入", [err instanceof Error ? err.message : String(err)]);
  }
}

function statCount(article, testId) {
  const button = article.querySelector(`[data-testid="${testId}"]`);
  return hoard.parseCount(button?.getAttribute("aria-label"));
}

/** 作者頭像的網址（App 端的插件拿來補創作者頭像）；不是頭像圖片時為 undefined。 */
function avatarOf(url) {
  return typeof url === "string" && url.includes("/profile_images/") ? url : undefined;
}

/** 沒寫替代文字的圖片，X 頁面上的 alt 是這些預設字。 */
const GENERIC_ALTS = new Set(["", "Image", "圖片", "图片", "图像", "画像", "이미지"]);

function readTweet(article) {
  const text = article.querySelector('[data-testid="tweetText"]')?.innerText ?? "";

  // User-Name 區塊包含顯示名稱與 @handle 連結。
  let authorName;
  let authorHandle;
  const nameBlock = article.querySelector('[data-testid="User-Name"]');
  if (nameBlock) {
    authorName = nameBlock.querySelector("span")?.innerText || undefined;
    for (const link of nameBlock.querySelectorAll("a[href^='/']")) {
      const handle = link.getAttribute("href")?.slice(1);
      if (handle && !handle.includes("/")) {
        authorHandle = handle;
        break;
      }
    }
  }

  const imageUrls = Array.from(article.querySelectorAll('[data-testid="tweetPhoto"] img'), (img) => ({
    url: toOriginalSize(img.src),
    alt: GENERIC_ALTS.has(img.alt.trim()) ? undefined : img.alt,
  }));

  return {
    authorName,
    authorHandle,
    authorAvatar: avatarOf(article.querySelector('[data-testid="Tweet-User-Avatar"] img')?.src),
    text,
    postedAt: article.querySelector("time")?.getAttribute("datetime") ?? undefined,
    imageUrls,
    likeCount: statCount(article, "like"),
    retweetCount: statCount(article, "retweet"),
    replyCount: statCount(article, "reply"),
  };
}

const STATUS_PATH = /^\/([^/]+)\/status\/(\d+)/;

/** 從貼文 article 找出它自己的 status 網址（時間戳連結）。 */
function statusOf(article) {
  for (const time of article.querySelectorAll("a[href*='/status/'] time")) {
    const match = time.closest("a")?.getAttribute("href")?.match(STATUS_PATH);
    if (match) return { handle: match[1], id: match[2] };
  }
  return null;
}

function statusUrl(info) {
  return `https://x.com/${info.handle}/status/${info.id}`;
}

/**
 * 在貼文底部的動作列（書籤／分享旁）放收藏按鈕。右上角「⋯」那一列會跟 Grok 按鈕
 * 一起晚渲染、結構不穩，按鈕常被擠到上方；動作列（role="group"）本身就是橫向排列。
 * 從書籤按鈕往上找到第一個「還有其他兄弟元素」的容器（書籤＋分享那一組，或動作列本身），
 * 插在書籤那一格後面。書籤還沒渲染就先跳過，MutationObserver 會再掃。
 */
function mountButton(page, article) {
  if (article.querySelector("hoard-button")) return;
  const info = statusOf(article);
  const group = article.querySelector('[role="group"]');
  const bookmark = group?.querySelector('[data-testid="bookmark"], [data-testid="removeBookmark"]');
  if (!info || !group || !bookmark) return;
  let anchor = bookmark;
  while (anchor.parentElement && anchor.parentElement !== group && anchor.parentElement.children.length < 2) {
    anchor = anchor.parentElement;
  }
  const button = page.createButton(statusUrl(info), article, { size: 34 });
  anchor.after(button);
}

/** 觸發按鈕所屬貼文的網址；在圖片燈箱裡（沒有 article）用目前網址。 */
function targetOf(el) {
  const article = el.closest('article[data-testid="tweet"]');
  if (article) {
    const info = statusOf(article);
    return info ? { url: statusUrl(info), article } : null;
  }
  const match = location.pathname.match(STATUS_PATH);
  return match ? { url: `https://x.com/${match[1]}/status/${match[2]}`, article: null } : null;
}

// ---- 拖曳收藏：投放區由擴充提供，這裡只說拖的是哪一則貼文的第幾張 ----

const PHOTO_PATH = /^\/([^/]+)\/status\/(\d+)\/photo\/(\d+)/;

/**
 * 拖曳中的圖片是哪一則貼文的第幾張：時間軸上圖片包在 …/status/ID/photo/N 的連結裡；
 * 燈箱（圖片全螢幕）裡沒有連結，用目前網址。回傳單張圖片的網址，不是貼文就是 null。
 * @param {Element} img
 */
function photoTarget(img) {
  if (!(img instanceof HTMLImageElement) || !img.src.includes("pbs.twimg.com/media/")) return null;
  const href = img.closest('a[href*="/photo/"]')?.getAttribute("href");
  const match = (href ?? location.pathname).match(PHOTO_PATH);
  return match ? `https://x.com/${match[1]}/status/${match[2]}/photo/${match[3]}` : null;
}

/**
 * 拖貼文裡的圖片時只收那一張（…/status/ID/photo/N）；其他圖片（頭像、預覽卡）交給擴充只存那張圖。
 * @param {DragEvent} event
 * @returns {HoardDragCapture | null}
 */
function dragCapture(event) {
  if (!(event.target instanceof Element)) return null;
  // 時間軸上拖的可能是包住圖片的連結，不是 <img> 本身。
  const img = event.target.closest("img") ?? event.target.querySelector('img[src*="pbs.twimg.com/media/"]');
  const url = img ? photoTarget(img) : null;
  if (!img || !url) return null;
  return { element: img, resolve: () => url };
}

/**
 * 拖曳收的單張圖片：只存那一張，來源網址是 X 自己的 …/status/ID/photo/N。
 * 抓取前的查重用網址裡的貼文 ID，整篇已收過就算已收藏；存進去的去重鍵（status_id）是「ID/photo/N」，
 * 所以同一篇的其他張、或之後再收整篇，都不會被當成這一張的重複。
 * 圖片從拖的那張 <img> 取原圖；沒有元素時（彈出視窗在燈箱網址上按）照 syndication 的第 N 張。
 * @param {string} handle @param {string} statusId @param {number} index @param {Element | null} element
 * @param {((text: string) => void) | undefined} progress
 */
async function extractPhoto(handle, statusId, index, element, progress) {
  const article =
    element?.closest('article[data-testid="tweet"]') ??
    Array.from(document.querySelectorAll('article[data-testid="tweet"]')).find((a) =>
      a.querySelector(`a[href*="/status/${statusId}"] time`),
    ) ??
    null;
  const dom = article ? readTweet(article) : null;

  progress?.("讀取貼文資訊…");
  const syn = await fetchSyndication(statusId);
  const synImages = syn ? collectSyndicationMedia(syn).imageUrls : [];

  /** @type {{ url: string; alt?: string } | undefined} */
  let image;
  if (element instanceof HTMLImageElement && element.src.includes("pbs.twimg.com/media/")) {
    const url = toOriginalSize(element.src);
    const base = (/** @type {string} */ u) => new URL(u).pathname;
    image = synImages.find((s) => base(s.url) === base(url)) ?? {
      url,
      alt: GENERIC_ALTS.has(element.alt.trim()) ? undefined : element.alt,
    };
  }
  image ??= synImages[index - 1] ?? dom?.imageUrls[index - 1];
  if (!image) throw new Error("找不到這張圖片");

  const warnings = [];
  progress?.("下載圖片…");
  const media = await hoard.fetchAllMedia([image], warnings, progress);
  if (media.length === 0) throw new Error("圖片下載失敗");

  const author = dom?.authorHandle ?? syn?.user?.screen_name ?? handle;
  const text =
    dom?.text ??
    (syn ? tweetText({ full_text: syn.text, entities: syn.entities, extended_entities: { media: syn.mediaDetails } }, null) : "");
  const postedAt = dom?.postedAt ?? (syn?.created_at ? new Date(syn.created_at).toISOString() : undefined);
  return {
    payload: {
      source_type: "twitter",
      source_url: `https://x.com/${author}/status/${statusId}/photo/${index}`,
      description: text,
      author: { name: dom?.authorName ?? syn?.user?.name ?? author, handle: author, url: `https://x.com/${author}` },
      published_at: postedAt,
      metadata: {
        status_id: `${statusId}/photo/${index}`,
        photo_index: index,
        post_url: `https://x.com/${author}/status/${statusId}`,
        author_avatar: dom?.authorAvatar ?? avatarOf(syn?.user?.profile_image_url_https),
        has_video: false,
      },
      media,
      comments: [],
    },
    warnings,
  };
}

hoard.registerExtractor({
  sourceType: "twitter",

  // …/photo/N 是單張圖片（拖曳收藏、或在燈箱網址上按「抓取此頁」），其餘是整篇貼文。
  sourceUrl(url) {
    const photo = url.pathname.match(PHOTO_PATH);
    if (photo) return `https://x.com/${photo[1]}/status/${photo[2]}/photo/${photo[3]}`;
    const match = url.pathname.match(STATUS_PATH);
    return match ? `https://x.com/${match[1]}/status/${match[2]}` : null;
  },

  async extract(ctx) {
    const url = ctx?.url ?? new URL(location.href);
    const pathMatch = url.pathname.match(STATUS_PATH);
    if (!pathMatch) throw new Error("無法從網址取得貼文 ID");
    const [, pathHandle, statusId] = pathMatch;
    const progress = ctx?.progress;
    const photo = url.pathname.match(PHOTO_PATH);
    if (photo && !ctx?.listing) return extractPhoto(pathHandle, statusId, Number(photo[3]), ctx?.element ?? null, progress);
    // 封存匯入：貼文不在頁面上，改向 X 查。
    if (/** @type {any} */ (ctx?.listing?.data)?.archive) return extractRemote(statusId, ctx.listing, progress);
    // 只有在這則貼文自己的頁面上，主推文之後的每一則才是它的回覆。
    const onOwnPage = location.pathname.match(STATUS_PATH)?.[2] === statusId;

    const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
    // 從按鈕觸發時直接用該則；否則找時間戳連到這個 status id 的那則。
    const main =
      ctx?.element ??
      articles.find((article) => article.querySelector(`a[href*="/status/${statusId}"] time`)) ??
      (onOwnPage ? articles[0] : undefined);
    if (!main) {
      throw new Error("頁面上找不到這則貼文，請等頁面載入完成後再試");
    }
    const mainInfo = readTweet(main);
    // 純影片貼文的 <video> 不在 tweetPhoto 裡，DOM 圖片會是空的，別誤判成讀取失敗。
    const hasVideoEl = Boolean(
      main.querySelector('[data-testid="videoPlayer"], [data-testid="videoComponent"], video'),
    );
    if (!mainInfo.text && mainInfo.imageUrls.length === 0 && !hasVideoEl) {
      throw new Error("讀不到貼文內容，X 的頁面結構可能已改版");
    }

    // 從時間軸觸發時不抓留言（那些 article 不是這則的回覆）；設定裡關掉時也不抓。
    const saveComments = onOwnPage && (await hoard.getSettings()).saveComments !== false;
    const comments = [];
    if (saveComments) {
      for (const article of articles.slice(articles.indexOf(main) + 1)) {
        const reply = readTweet(article);
        if (!reply.text) continue;
        comments.push({
          author_name: reply.authorName,
          author_handle: reply.authorHandle,
          content: reply.text,
          posted_at: reply.postedAt,
          like_count: reply.likeCount,
        });
      }
    }

    const warnings = [];

    // 圖片：優先 syndication 原圖，被擋下時問 GraphQL，再退回 DOM。影片交給 App 端 yt-dlp（依 has_video）。
    let imageUrls = mainInfo.imageUrls;
    let hasVideo = hasVideoEl;
    // GIF 在頁面上是直接連到 MP4 的 <video>（tweet_video），不是一般影片的 blob 串流；
    // syndication 讀不到時也認得出來。
    let isGif = Boolean(main.querySelector('video[poster*="/tweet_video_thumb/"], video[src*="/tweet_video/"]'));
    /** @type {{ url: string } | undefined} */
    let poster;
    /** @type {number[] | undefined} */
    let videoAt;
    progress?.("讀取貼文資訊…");
    const syn = await fetchSyndication(statusId);
    const collected = syn ? collectSyndicationMedia(syn) : await graphqlMedia(statusId);
    if (collected) {
      if (collected.imageUrls.length > 0) imageUrls = collected.imageUrls;
      if (collected.hasVideo) hasVideo = true;
      if (collected.isGif) isGif = true;
      if (imageUrls.length === 0) poster = collected.poster;
      videoAt = collected.videoAt;
    }

    if (imageUrls.length) progress?.("下載圖片…");
    const media = await hoard.fetchAllMedia(imageUrls, warnings, progress);
    if (saveComments && comments.length === 0) {
      warnings.push("沒有抓到留言（如需留言請先捲動載入回覆再抓取）");
    }

    const handle = mainInfo.authorHandle ?? pathHandle;
    return {
      payload: {
        source_type: "twitter",
        source_url: `https://x.com/${handle}/status/${statusId}`,
        description: mainInfo.text,
        author: {
          name: mainInfo.authorName ?? handle,
          handle,
          url: `https://x.com/${handle}`,
        },
        published_at: mainInfo.postedAt,
        metadata: {
          author_avatar: mainInfo.authorAvatar,
          like_count: mainInfo.likeCount,
          retweet_count: mainInfo.retweetCount,
          reply_count: mainInfo.replyCount,
          // App 端據此用 yt-dlp 下載影片（會帶擴充功能匯出的登入 cookie）。
          has_video: hasVideo,
          // X 的 GIF 其實是 MP4，App 端像 GIF 一樣自動循環播放。
          is_gif: isGif || undefined,
        },
        media,
        // 圖片和影片混在一起時，影片下載完插回原貼文的位置。
        video_at: videoAt,
        poster,
        comments,
      },
      warnings,
    };
  },

  importArchive(page, files) {
    void importArchiveLikes(page, files);
  },

  dragCapture,

  integrate(page) {
    // 貼文是虛擬捲動、隨時重繪的，用 MutationObserver 補按鈕（每幀最多掃一次）。
    let scheduled = false;
    const scan = () => {
      scheduled = false;
      if (page.settings.showButton === false) return;
      for (const article of document.querySelectorAll('article[data-testid="tweet"]')) {
        mountButton(page, article);
      }
    };
    const schedule = () => {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(scan);
    };
    new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
    schedule();

    // 按讚／加入書籤：只在「還沒按」的狀態被按下時觸發（testid 是 like / bookmark；
    // 已按的是 unlike / removeBookmark）。取消讚或書籤不會動到收藏。
    const trigger = (button) => {
      const testId = button.getAttribute("data-testid");
      if (testId === "like" && page.settings.saveOnLike !== true) return;
      if (testId === "bookmark" && page.settings.saveOnBookmark !== true) return;
      const target = targetOf(button);
      if (target) void page.capture(target.url, target.article);
    };
    document.addEventListener(
      "click",
      (event) => {
        const button =
          event.target instanceof Element
            ? event.target.closest('[data-testid="like"], [data-testid="bookmark"]')
            : null;
        if (button) trigger(button);
      },
      true,
    );
    // X 的鍵盤快捷鍵：L 按讚、B 加入書籤（作用在目前選取的貼文）。
    document.addEventListener(
      "keydown",
      (event) => {
        if (event.ctrlKey || event.metaKey || event.altKey || event.repeat) return;
        const key = event.key.toLowerCase();
        if (key !== "l" && key !== "b") return;
        const active = document.activeElement;
        if (!active || active.closest("input, textarea, [contenteditable='true']")) return;
        const article = active.closest('article[data-testid="tweet"]');
        const button = article?.querySelector(
          key === "l" ? '[data-testid="like"]' : '[data-testid="bookmark"]',
        );
        if (button) trigger(button);
      },
      true,
    );
  },
});
