// @ts-check
/// <reference path="../hoard-app.d.ts" />
/* X.com App 端：詳情頁仿 X 貼文頁（回覆串；淺色／深色跟著 App 主題），樣式見 styles.css。
   時間軸卡片與書架卡片沿用 App 主題。快速預覽裡 GIF 會靜音循環播放。 */

/**
 * 頭像：插件存的頭像（`path`），沒有或讀不到時用名字第一個字。
 * @param {string | null | undefined} name @param {string} cls @param {string | null | undefined} [path]
 */
function avatar(name, cls, path) {
  const initial = () => hoard.el("div", { class: cls }, [(name || "?").trim().charAt(0).toUpperCase()]);
  if (!path) return initial();
  // 插件抓到的頭像；讀不到就退回首字。
  const img = hoard.el("img", { class: cls, src: hoard.fileSrc(path), alt: "", draggable: "false" });
  img.addEventListener("error", () => img.replaceWith(initial()), { once: true });
  return img;
}

/**
 * X 的 GIF 存成 MP4（擷取時標 is_gif）：像 GIF 一樣靜音、自動循環播放，不顯示播放控制列。
 * @param {Record<string, unknown>} metadata @param {string} src @param {string} [cls]
 */
function videoEl(metadata, src, cls) {
  if (metadata.is_gif !== true) {
    return hoard.el("video", { ...(cls ? { class: cls } : {}), src, controls: "", preload: "metadata" });
  }
  const video = /** @type {HTMLVideoElement} */ (
    hoard.el("video", { ...(cls ? { class: cls } : {}), src, autoplay: "", loop: "", muted: "", playsinline: "" })
  );
  // muted 屬性不會讓已建立的元素靜音，要設屬性值才能自動播放。
  video.muted = true;
  return video;
}

const motionOn = () => !matchMedia("(prefers-reduced-motion: reduce)").matches;

/** 檔案的寬高比；沒有尺寸時影片當 16:9、圖片當正方形。 @param {HoardItemFile} file */
function aspectOf(file) {
  return file.width && file.height ? file.width / file.height : file.kind === "video" ? 16 / 9 : 1;
}

// ---- 多張：X 的輪播版面 ----
//
// X 從 2026-11 起，兩張以上的貼文一律排成橫向捲動的一列（只有廣告還是 2×2 格），版面照 x.com 前端
// mediaCarouselLayout 的 ny() 整理成下面幾個函式。尺寸都是「內容寬」（列寬扣掉左右各 16px）的比例：
// 列高預設 0.68；每格寬 = 列高 × 圖片比例，最多 0.8；全部擺得下就拉高到剛好擺滿（最高 1.24），
// 兩張擺不下但第 2 張露出三成以上就縮到兩張都擺得下，三張以上第 2 張露出太多就拉高到只露出約 67%。
// X 把比 0.8 還寬的橫圖左右裁掉；這裡不裁，整張縮到 0.8 寬、比同一列矮，在列裡上下置中。

const CAROUSEL = {
  /** 預設列高。 */
  height: 0.68,
  /** 一格最寬。 */
  maxItem: 0.8,
  /** 列高最高。 */
  maxHeight: 1.24446,
  /** 格與格的間距（px）。 */
  gap: 4,
  /** 兩張時，第 2 張露出少於這個比例就不縮小。 */
  fitPeek: 0.33,
  /** 三張以上時，第 2 張藏起來不到這個比例（露出太多、看不出還有下一張）就拉高。 */
  minHidden: 0.33,
};

/** @typedef {{ ratio: number; offset: number }} RowHeight 列高 = ratio × 內容寬 + offset（px） */

/** @param {RowHeight} a @param {RowHeight} b */
const lower = (a, b) => (a.ratio <= b.ratio ? a : b);
/** @param {RowHeight} a @param {RowHeight} b */
const higher = (a, b) => (a.ratio >= b.ratio ? a : b);
/** @param {number[]} list */
const sum = (list) => list.reduce((a, b) => a + b, 0);

/** 列高 ratio 時一格的寬（內容寬的比例）。 @param {number} ratio @param {number} aspect */
const itemWidth = (ratio, aspect) => Math.min(ratio * aspect, CAROUSEL.maxItem);

/** 全部剛好擺滿一列的列高（被 0.8 寬卡住的格子先扣掉）；擺不出來是 null。 @param {number[]} aspects @returns {RowHeight | null} */
function fitAll(aspects) {
  if (aspects.length < 2) return null;
  const gaps = CAROUSEL.gap * (aspects.length - 1);
  let rest = aspects;
  let capped = 0;
  while (rest.length > 0) {
    const ratio = (1 - capped * CAROUSEL.maxItem) / sum(rest);
    if (ratio <= 0) return null;
    const under = rest.filter((a) => ratio * a <= CAROUSEL.maxItem);
    if (under.length === rest.length) return { ratio, offset: -gaps * ratio };
    capped += rest.length - under.length;
    rest = under;
  }
  return null;
}

/** 列高 ratio 時，第 2 張露出多少（0–1）。 @param {number} ratio @param {number[]} aspects */
function secondShown(ratio, aspects) {
  const first = itemWidth(ratio, aspects[0]);
  const second = itemWidth(ratio, aspects[1]);
  return second <= 0 ? 0 : Math.min(Math.max(1 - first, 0), second) / second;
}

/** 第 1 張擺滿、第 2 張剛好露出約 67% 的列高（取最矮的）；沒有就是 null。 @param {number[]} aspects */
function peekHeight(aspects) {
  const [a, b] = aspects;
  // 比 0.67 小一點點（X 原碼就是 .6699999999999999），剛好 67% 的那格算露出不到。
  const peek = 0.6699999999999999;
  /** @type {RowHeight[]} */
  const found = [];
  /** @param {number} width @param {number} per */
  const add = (width, per) => {
    const ratio = per > 0 ? width / per : 0;
    if (ratio > 0) found.push({ ratio, offset: -CAROUSEL.gap * ratio });
  };
  // 兩張都沒被 0.8 寬卡住。
  const both = a + peek * b;
  if (both > 0 && a / both <= CAROUSEL.maxItem && b / both <= CAROUSEL.maxItem) add(1, both);
  // 第 1 張卡在 0.8 寬，剩下的 0.2 給第 2 張露出。
  const rest = 1 - CAROUSEL.maxItem;
  const r1 = rest / (peek * b);
  if (r1 * a >= CAROUSEL.maxItem && r1 * b <= CAROUSEL.maxItem) add(rest, peek * b);
  // 第 2 張卡在 0.8 寬。
  const left = 1 - peek * CAROUSEL.maxItem;
  const r2 = left / a;
  if (r2 * b >= CAROUSEL.maxItem && r2 * a <= CAROUSEL.maxItem) add(left, a);
  return found.length > 0 ? found.reduce(lower) : null;
}

/** 這些比例的圖排成一列時的列高（X 的 ny()）。 @param {number[]} aspects @returns {RowHeight} */
function carouselHeight(aspects) {
  const max = { ratio: CAROUSEL.maxHeight, offset: 0 };
  let height = lower({ ratio: CAROUSEL.height, offset: 0 }, max);
  // 全部擺得下、而且比預設高：拉高到剛好擺滿。
  const all = fitAll(aspects);
  if (all && all.ratio >= height.ratio) height = lower(all, max);
  if (aspects.length === 2) {
    // 兩張擺不下，但第 2 張已經露出三成以上：縮到兩張都擺得下。
    if (all && all.ratio < height.ratio && secondShown(height.ratio, aspects) >= CAROUSEL.fitPeek) height = all;
  } else if (aspects.length > 2 && 1 - secondShown(height.ratio, aspects) < CAROUSEL.minHidden) {
    // 第 2 張露出太多，看不出還有下一張：拉高到只露出約 67%。
    const peek = peekHeight(aspects);
    if (peek) {
      const firstTwoCap = Math.min(...aspects.slice(0, 2).map((a) => CAROUSEL.maxItem / a));
      const taller = lower(lower(peek, max), higher({ ratio: firstTwoCap, offset: 0 }, height));
      if (taller.ratio > height.ratio) height = taller;
    }
  }
  return height;
}

/**
 * 兩張以上：照 X 排成橫向捲動的一列、每格停在中間（見上面的 CAROUSEL）；每格大小是內容寬的比例，跟著列寬縮放。
 * 左右箭頭一次移到下一格的中間，到頭的那一邊淡出。
 * @param {HoardItemFile[]} media @param {HTMLElement[]} tiles
 */
function mediaCarousel(media, tiles) {
  const aspects = media.map(aspectOf);
  const height = carouselHeight(aspects);
  tiles.forEach((tile, i) => {
    const aspect = aspects[i];
    // X 的格寬 = 列高 × 比例（最多 0.8 內容寬），比它還寬的橫圖整張縮進來、比列矮，不裁切。
    // 寫成內容寬的百分比（列裡的 % 就是扣掉左右 16px 的內容寬），第一次排版就是對的大小：
    // 等量好寬度再設的話，進詳情頁那幾格會先照原圖尺寸畫出來（快取的大圖會先放超大），卡片放大的動畫也會落錯地方。
    const scale = Math.min(aspect, CAROUSEL.maxItem / height.ratio);
    tile.style.width = `calc(${scale * height.ratio * 100}% + ${scale * height.offset}px)`;
    tile.style.aspectRatio = String(aspect);
  });
  const strip = hoard.el("div", { class: "hx-strip" }, tiles);
  /** @param {1 | -1} step */
  const go = (step) => {
    // 現在停在中間的那格，往按的方向的下一格移到中間。
    const center = strip.scrollLeft + strip.clientWidth / 2;
    const middle = (/** @type {HTMLElement} */ tile) => tile.offsetLeft + tile.offsetWidth / 2;
    let at = 0;
    tiles.forEach((tile, i) => {
      if (Math.abs(middle(tile) - center) < Math.abs(middle(tiles[at]) - center)) at = i;
    });
    const target = tiles[Math.max(0, Math.min(tiles.length - 1, at + step))];
    strip.scrollTo({ left: middle(target) - strip.clientWidth / 2, behavior: motionOn() ? "smooth" : "auto" });
  };
  const prev = hoard.el("button", { class: "hx-nav hx-nav-prev", "aria-label": "上一張", onclick: () => go(-1) }, [
    hoard.icon("chevron-left", { size: 18 }),
  ]);
  const next = hoard.el("button", { class: "hx-nav hx-nav-next", "aria-label": "下一張", onclick: () => go(1) }, [
    hoard.icon("chevron-right", { size: 18 }),
  ]);
  const update = () => {
    const end = strip.scrollWidth - strip.clientWidth;
    prev.classList.toggle("hx-nav-off", strip.scrollLeft <= 1);
    next.classList.toggle("hx-nav-off", strip.scrollLeft >= end - 1);
  };
  strip.addEventListener("scroll", update, { passive: true });
  // 箭頭要等排好版才知道捲不捲得動，列寬變了也重看；離開詳情頁就不再觀察。
  const watch = new ResizeObserver(() => (strip.isConnected ? update() : watch.disconnect()));
  watch.observe(strip);
  return hoard.el("div", { class: "hx-carousel" }, [strip, prev, next]);
}

/**
 * 照 X 排圖，但每張都照自己的比例完整呈現、不裁切：一張照原比例（最高到視窗的 8 成），
 * 兩張以上是橫向捲動的一列（mediaCarousel）。點擊開啟全螢幕檢視器。
 */
function mediaGrid(item, ctx) {
  const media = item.files.filter((f) => f.kind === "image" || f.kind === "video");
  if (media.length === 0) return null;
  const tiles = media.map((file, i) => {
    const node =
      file.kind === "video"
        ? videoEl(item.metadata, hoard.fileSrc(file.path))
        : // 原圖可能幾千萬像素：畫的時候才解碼會讓每一格都等它，交給背景解碼。
          hoard.el("img", { src: hoard.fileSrc(file.path), alt: file.alt ?? "", ...(file.alt ? { title: file.alt } : {}), loading: "lazy", decoding: "async" });
    if (file.kind !== "video") node.addEventListener("click", () => ctx.openViewer(media, i));
    return hoard.el("div", { class: "hx-tile" }, [node]);
  });
  if (media.length > 1) return mediaCarousel(media, tiles);
  const single = hoard.el("div", { class: "hx-media" }, tiles);
  const file = media[0];
  // 沒有尺寸時照圖片自己的高度。
  if (file.width && file.height) {
    const aspect = file.width / file.height;
    single.style.aspectRatio = String(aspect);
    single.style.width = `min(100%, calc(80vh * ${aspect}))`;
  }
  return single;
}

/** 回覆串：每則一列，巢狀回覆以左側連線縮排。 */
function replyNode(node) {
  const c = node.comment;
  const head = [hoard.el("span", { class: "hx-name" }, [c.author_name || "匿名"])];
  if (c.author_handle) head.push(hoard.el("span", { class: "hx-handle" }, [`@${c.author_handle}`]));
  if (c.posted_at) head.push(hoard.el("span", { class: "hx-handle" }, [`· ${hoard.formatDate(c.posted_at)}`]));
  const body = [
    hoard.el("div", { class: "hx-reply-head" }, head),
    hoard.el("p", { class: "hx-reply-text" }, [c.content]),
  ];
  if (c.like_count > 0) {
    body.push(
      hoard.el("span", { class: "hx-reply-like" }, [hoard.icon("heart", { size: 14 }), hoard.formatCount(c.like_count)]),
    );
  }
  const row = hoard.el("div", { class: "hx-reply" }, [
    avatar(c.author_name, "hx-avatar hx-avatar-sm"),
    hoard.el("div", { class: "hx-reply-body" }, body),
  ]);
  if (node.replies.length === 0) return row;
  return hoard.el("div", {}, [row, hoard.el("div", { class: "hx-thread" }, node.replies.map(replyNode))]);
}

hoard.register({
  renderDetail(root, item, ctx) {
    const meta = item.metadata;
    const author = item.author;

    const who = [hoard.el("span", author ? { class: "hx-name", style: "cursor:pointer", title: "查看這位創作者的所有收藏", onclick: () => ctx.openAuthor(author.id) } : { class: "hx-name" }, [author ? author.name : "未知作者"])];
    if (author && author.handle) who.push(hoard.el("span", { class: "hx-handle" }, [`@${author.handle}`]));
    const head = [avatar(author && author.name, "hx-avatar", author && author.avatar_path), hoard.el("div", { class: "hx-who" }, who)];
    if (author && author.url) {
      const url = author.url;
      head.push(
        hoard.el("button", { class: "hx-icon-btn", title: "開啟作者頁面", onclick: () => hoard.openUrl(url) }, [
          hoard.icon("external-link", { size: 16 }),
        ]),
      );
    }

    const post = [hoard.el("div", { class: "hx-author" }, head)];
    if (item.description) post.push(hoard.el("p", { class: "hx-text" }, [item.description]));
    const grid = mediaGrid(item, ctx);
    if (grid) post.push(grid);
    post.push(hoard.el("p", { class: "hx-time" }, [hoard.formatDateTime(item.published_at) || "發布時間未知"]));
    post.push(
      hoard.el("div", { class: "hx-stats" }, [
        hoard.el("span", { class: "hx-like" }, [
          hoard.icon("heart", { size: 16 }),
          hoard.el("b", {}, [hoard.formatCount(meta.like_count ?? 0)]),
        ]),
      ]),
    );

    const page = [hoard.el("article", { class: "hx-post" }, post)];
    for (const node of hoard.buildCommentTree(item.comments)) page.push(replyNode(node));
    root.append(hoard.el("div", { class: "hx-page" }, page));
  },

  renderFeedItem(root, item, ctx) {
    // 時間軸卡片：仿 X 動態，作者列、內文、圖片格、統計列。
    const meta = item.metadata;
    const head = hoard.el("div", { class: "hx-feed-head" }, [
      hoard.el("span", { class: "hx-feed-name" }, [item.author_name || "未知作者"]),
      hoard.el("span", { class: "hx-feed-date" }, [`· ${hoard.formatDate(item.published_at)}`]),
    ]);
    const parts = [head];
    const text = item.description;
    if (text) {
      parts.push(
        hoard.el("p", { class: "hx-feed-text" }, [
          text,
        ]),
      );
    }
    const media = hoard.el("div", { class: "hx-feed-media" });
    ctx.mountMediaGrid(media, item);
    parts.push(media);
    parts.push(
      hoard.el("div", { class: "hx-feed-stats" }, [
        hoard.el("span", { class: "hx-feed-like" }, [
          hoard.icon("heart", { size: 14 }),
          hoard.formatCount(meta.like_count ?? 0),
        ]),
      ]),
    );
    root.append(...parts);
  },

  renderCard(root, item, ctx) {
    const cover = hoard.el("div", { class: "hx-card-cover" });
    if (item.cover_path || item.thumbnail_path) {
      cover.style.aspectRatio = String(ctx.coverAspect);
      ctx.mountCover(cover);
      const gif = item.metadata.is_gif === true ? item.previews.find((file) => file.kind === "video") : undefined;
      if (gif) {
        // GIF 滑過時靜音循環播放，滑開就移除（不在背景繼續下載）。
        cover.append(hoard.el("span", { class: "hx-gif" }, ["GIF"]));
        /** @type {HTMLVideoElement | null} */
        let player = null;
        cover.addEventListener("mouseenter", () => {
          if (player) return;
          player = /** @type {HTMLVideoElement} */ (videoEl(item.metadata, hoard.fileSrc(gif.path), "hx-hover-video"));
          cover.append(player);
        });
        cover.addEventListener("mouseleave", () => {
          player?.removeAttribute("src");
          player?.load();
          player?.remove();
          player = null;
        });
      }
    } else {
      // 純文字貼文以內文本身當封面，不照封面比例：瀑布流裡跟內文一樣高，網格裡撐滿格子。
      cover.append(
        hoard.el("div", { class: "hx-cover" }, [
          hoard.el("p", { class: "hx-cover-text" }, [item.title]),
        ]),
      );
    }
    const body = hoard.el("div");
    ctx.mountBody(body);
    root.append(cover, body);
  },

  renderCardMeta(root, item) {
    const meta = item.metadata;
    const children = [];
    if (item.author_name) children.push(hoard.el("span", { class: "hx-card-author" }, [`@${item.author_name}`]));
    children.push(
      hoard.el("span", { class: "hx-card-like" }, [
        hoard.icon("heart", { size: 12 }),
        hoard.formatCount(meta.like_count ?? 0),
      ]),
    );
    root.append(
      hoard.el("div", { class: "hx-card-meta" }, children),
    );
  },
});

// 快速預覽：GIF 要像 GIF 一樣靜音循環播放（App 內建的會顯示成有控制列的影片）。
// 多張圖的貼文用 App 內建的就好：↑ ↓ 換張、點圖看大圖。
hoard.registerPresenter({
  sources: ["twitter"],
  accepts: (item) => item.metadata.is_gif === true,
  quickLook(root, item, ctx) {
    const file = item.previews.find((f) => f.kind === "video" && f.entry === null);
    if (!file) return ctx.mountDefault(root);
    const stage = hoard.el("div", {
      class: "hx-ql-stage",
      onclick: (event) => {
        if (event.target === stage) ctx.close();
      },
    });
    stage.append(videoEl(item.metadata, hoard.fileSrc(file.path), "hx-ql-media"));
    root.append(stage);
  },
});

// ---- 插件設定：在網頁上的行為（擴充端用 page.settings 讀，每個網站有的動作不同） ----

/** @type {Array<{ key: string; label: string; hint: string; fallback: boolean }>} */
const PAGE_OPTIONS = [
  { key: "showButton", label: "貼文上顯示「加到 hoard」按鈕", hint: "在書籤按鈕旁邊，已收藏的會打勾。", fallback: true },
  { key: "saveOnLike", label: "按愛心（喜歡）時一起收藏", hint: "也包括鍵盤快捷鍵 L。", fallback: false },
  { key: "saveOnBookmark", label: "加入書籤時一起收藏", hint: "也包括鍵盤快捷鍵 B。", fallback: false },
  { key: "saveComments", label: "收藏時一起抓留言", hint: "只在貼文自己的頁面上抓，讀的是已經捲動載入的回覆。", fallback: true },
];

/**
 * 改擷取器設定（`hoard.storage` 的 `extractor`）的一項。用 `storage.update` 一次讀改寫：
 * 快速連切兩個開關時，後一個不會蓋掉前一個。
 * @param {string} key @param {unknown} value
 */
function saveExtractorSetting(key, value) {
  return hoard.storage.update("extractor", (/** @type {Record<string, unknown> | undefined} */ saved) => ({ ...saved, [key]: value }));
}

hoard.registerSettingTab({
  label: "在網頁上",
  render(el) {
    const inputs = PAGE_OPTIONS.map((option) => {
      const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hx-switch" }));
      el.append(
        hoard.el("label", { class: "hx-setting-row" }, [
          hoard.el("span", {}, [hoard.el("strong", {}, [option.label]), hoard.el("span", { class: "hx-setting-hint" }, [option.hint])]),
          input,
        ]),
      );
      return { option, input };
    });
    el.append(hoard.el("p", { class: "hx-setting-hint" }, ["改完後重新整理網頁就生效，不用同步插件。"]));
    void hoard.storage.get("extractor").then((saved) => {
      const settings = /** @type {Record<string, unknown>} */ (saved ?? {});
      for (const { option, input } of inputs) input.checked = typeof settings[option.key] === "boolean" ? Boolean(settings[option.key]) : option.fallback;
    });
    for (const { option, input } of inputs) {
      input.addEventListener("change", async () => {
        await saveExtractorSetting(option.key, input.checked);
      });
    }
  },
});

// ---- 作者頭像：插件找網址、下載，交給核心存（創作者清單、創作者頁顯示） ----

/** @type {Record<string, string>} */
const AVATAR_HEADERS = {};

/** 與擷取器相同的 syndication token 演算法（沿用 X embed 前端）。 */
function syndicationToken(id) {
  return ((Number(id) / 1e15) * Math.PI).toString(36).replace(/(0+|\.)/g, "");
}

/** 400×400 的版本（X 的頭像網址後綴是尺寸）。 */
function largeAvatar(url) {
  return url.replace(/_(normal|bigger|mini|x96|200x200)(\.\w+)$/, "_400x400$2");
}

/**
 * 帳號的頭像網址：收藏時擷取器記下的（`metadata.author_avatar`，最新的收藏在前）；舊收藏沒有，
 * 就用貼文的 syndication 問（不用登入，但敏感內容會被擋下，所以最多試三篇）。沒設頭像的預設圖不算。
 * @param {HoardAuthor} author
 */
async function avatarUrl(author) {
  const { items } = await hoard.items.list({ author_id: author.id }, { limit: 10 });
  for (const item of items) {
    const url = item.metadata.author_avatar;
    if (typeof url === "string" && url.includes("/profile_images/")) return largeAvatar(url);
  }
  for (const item of items.slice(0, 3)) {
    const id = item.source_url?.match(/\/status\/(\d+)/)?.[1];
    if (!id) continue;
    const res = await hoard.fetch(
      `https://cdn.syndication.twimg.com/tweet-result?id=${id}&token=${syndicationToken(id)}&lang=en`,
    );
    if (!res.ok) continue;
    const url = /** @type {any} */ (await res.json().catch(() => null))?.user?.profile_image_url_https;
    if (typeof url === "string" && url.includes("/profile_images/")) return largeAvatar(url);
  }
  return null;
}

/** 這次開 App 試過的帳號（抓到或失敗）不再試。 */
const avatarTried = new Set();
/** @type {Promise<void> | null} */
let avatarRun = null;
let avatarAgain = false;
let avatarStopped = false;
hoard.onUnload(() => {
  avatarStopped = true;
});

/** 替還沒有頭像的 X 帳號補上：一次一個、間隔一下；跑的時候又有新收藏就再跑一輪。 */
function fillAvatars() {
  if (avatarRun) {
    avatarAgain = true;
    return;
  }
  avatarRun = (async () => {
    do {
      avatarAgain = false;
      const authors = await hoard.authors.list({ source: "twitter" });
      for (const author of authors) {
        if (avatarStopped) return;
        if (author.avatar_path || avatarTried.has(author.id)) continue;
        avatarTried.add(author.id);
        try {
          const url = await avatarUrl(author);
          if (!url) continue;
          const res = await hoard.fetch(url, { headers: AVATAR_HEADERS });
          if (!res.ok) throw new Error(`頭像 HTTP ${res.status}`);
          await hoard.authors.setAvatar(author.id, await res.arrayBuffer(), { source: url });
        } catch (err) {
          console.warn(`[twitter] 抓不到 ${author.name} 的頭像：`, err);
        }
        await new Promise((resolve) => setTimeout(resolve, 1200));
      }
    } while (avatarAgain && !avatarStopped);
  })()
    .catch((err) => console.warn("[twitter] 補頭像失敗：", err))
    .finally(() => {
      avatarRun = null;
    });
}

// 開 App 後先讓畫面載完再補；之後每有新收藏就補新的作者。
const avatarStart = setTimeout(fillAvatars, 8000);
hoard.onUnload(() => clearTimeout(avatarStart));
hoard.on("items-added", () => fillAvatars());

// ---- 標籤自動匯入（預設關閉）：把 X 作品的標籤加進標籤庫，並貼到作品上 ----

/** 推文裡的 hashtag（不含 #）；全是數字的不算，和 X 的規則一樣。 @param {HoardItemSummary} item @returns {string[]} */
function siteTagsOf(item) {
  const text = item.description ?? "";
  return [...text.matchAll(/(?:^|[^\p{L}\p{N}_&/])[#＃]([\p{L}\p{N}_]*[\p{L}_][\p{L}\p{N}_]*)/gu)].map((m) => m[1]);
}

/**
 * 替這些作品加上網站的標籤；同一個標籤的作品合成一次呼叫，標籤庫沒有的由核心建立。
 * @param {HoardItemSummary[]} items
 */
async function importSiteTags(items) {
  /** @type {Map<string, number[]>} */
  const byName = new Map();
  for (const item of items) {
    for (const name of new Set(siteTagsOf(item))) {
      const ids = byName.get(name);
      if (ids) ids.push(item.id);
      else byName.set(name, [item.id]);
    }
  }
  for (const [name, ids] of byName) await hoard.items.addTags(ids, [name]);
}

hoard.on("items-added", async ({ ids }) => {
  if ((await hoard.storage.get("autoTags")) !== true) return;
  const { items } = await hoard.items.list({ ids, source_type: "twitter" }, { limit: ids.length });
  if (items.length > 0) await importSiteTags(items);
});

/** 替已經收藏的作品補上；使用者打開開關時問過才做。 */
async function importAllSiteTags() {
  hoard.toast("正在替已收藏的 X 作品加上標籤…", { kind: "busy" });
  try {
    let done = 0;
    for (let offset = 0; ; offset += 200) {
      const { items } = await hoard.items.list({ source_type: "twitter" }, { offset, limit: 200 });
      await importSiteTags(items);
      done += items.length;
      if (items.length < 200) break;
    }
    hoard.toast(`已替 ${done} 件 X 作品加上標籤`);
  } catch (err) {
    hoard.toast(`加標籤失敗：${err instanceof Error ? err.message : err}`, { kind: "error" });
  }
}

hoard.registerSettingTab({
  label: "標籤",
  render(el) {
    const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hx-switch" }));
    el.append(
      hoard.el("label", { class: "hx-setting-row" }, [
        hoard.el("span", {}, [
          hoard.el("strong", {}, ["自動匯入標籤"]),
          hoard.el("span", { class: "hx-setting-hint" }, ["收藏的推文自動把 hashtag 加成標籤（不含 #），標籤庫沒有的會建立。預設關閉：標籤一多，標籤庫會變得很雜。"]),
        ]),
        input,
      ]),
    );
    void hoard.storage.get("autoTags").then((value) => (input.checked = value === true));
    input.addEventListener("change", async () => {
      await hoard.storage.set("autoTags", input.checked);
      if (!input.checked) return;
      const { total } = await hoard.items.list({ source_type: "twitter" }, { limit: 1 });
      if (total > 0 && (await hoard.confirm(`也替已經收藏的 ${total} 件 X 作品加上標籤？`, { confirmLabel: "加上標籤" }))) {
        await importAllSiteTags();
      }
    });
  },
});
