// @ts-check
/// <reference path="../hoard-extractor.d.ts" />
/* Patreon 貼文擷取器。
   - 彈出視窗抓取目前這篇：DOM 擷取（data-tag），Patreon 改版時需要更新這裡。
   - 批次抓取整位創作者：走站方 JSON:API（/api/posts），清單上已有貼文內容，
     不必一篇篇開頁面；留言另走 /api/posts/{id}/comments。 */

const API = "https://www.patreon.com/api";

async function patreonApi(url) {
  const res = await fetch(url, {
    credentials: "include",
    headers: { Accept: "application/vnd.api+json" },
  });
  if (!res.ok) throw new Error(`Patreon API 回應 ${res.status}`);
  return res.json();
}

/**
 * 創作者替貼文加的標籤（App 端的「自動匯入標籤」用它）。另外問一次，讀不到就當作沒有，不影響收藏本身。
 * @returns {Promise<string[] | undefined>}
 */
async function postTags(postId) {
  try {
    const json = await patreonApi(
      `${API}/posts/${postId}?include=user_defined_tags&fields[post]=title&fields[post_tag]=value&json-api-version=1.0`,
    );
    const tags = related(json.data ?? {}, "user_defined_tags", indexIncluded(json.included))
      .map((tag) => tag.attributes?.value)
      .filter((value) => typeof value === "string" && value.trim());
    return tags.length > 0 ? tags : undefined;
  } catch {
    return undefined;
  }
}

/** JSON:API 的 included 依 `type:id` 建表。 */
function indexIncluded(included) {
  const map = new Map();
  for (const entry of included ?? []) map.set(`${entry.type}:${entry.id}`, entry);
  return map;
}

/** 取出 resource 某個 relationship 指向的 included 物件（一律回陣列）。 */
function related(resource, name, included) {
  const data = resource.relationships?.[name]?.data;
  if (!data) return [];
  return (Array.isArray(data) ? data : [data])
    .map((ref) => included.get(`${ref.type}:${ref.id}`))
    .filter(Boolean);
}

/** DOMParser 解析不會載入圖片或執行腳本。 */
function parseHtml(html) {
  return new DOMParser().parseFromString(html ?? "", "text/html");
}

function htmlToText(html) {
  const doc = parseHtml(
    (html ?? "").replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|h\d|li)>/gi, "$&\n"),
  );
  return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
}

/** 同一張圖在不同欄位的網址參數不同，用路徑中 32 碼的檔案雜湊去重。 */
function mediaKey(url) {
  const path = url.split("?")[0];
  return path.split("/").find((part) => /^[0-9a-f]{32}$/i.test(part)) ?? path;
}

const IMAGE_EXT = /\.(jpe?g|png|gif|webp|avif|bmp)$/i;

/**
 * 貼文網址有 `/posts/{slug}-{id}`（舊）、`/{vanity}/posts/{slug}-{id}`、`/c/{vanity}/posts/…`（新）
 * 幾種寫法，取出最後的 `{slug}-{id}`。創作者的貼文列表頁（`/c/{vanity}/posts`）沒有這段，回傳 null。
 */
function parsePostSlug(url) {
  return url.pathname.match(/^\/(?:c\/)?(?:[^/]+\/)?posts\/([^/]*\d)\/?$/)?.[1] ?? null;
}

/** 一律正規化成舊格式（站方會轉址），和先前收藏的網址一致才能去重。 */
function canonicalPostUrl(url) {
  const slug = parsePostSlug(url);
  return slug ? `https://www.patreon.com/posts/${slug}` : null;
}

/** 首頁／關於等頁面網址裡的創作者代稱（vanity），用來確認找到的 campaign 是這位。 */
function parseVanity(url) {
  const parts = url.pathname.split("/").filter(Boolean);
  if (parts[0] === "c" || parts[0] === "cw") return parts[1] ?? null;
  const reserved = ["posts", "home", "messages", "settings", "search", "notifications", "explore", "user", "login", "library", "collection"];
  return parts[0] && !reserved.includes(parts[0]) ? parts[0] : null;
}

/** 找出目前頁面所屬創作者的 campaign id。 */
async function findCampaignId(url) {
  // 貼文頁：直接問這篇屬於哪個 campaign。
  const postId = parsePostSlug(url)?.match(/(\d+)$/)?.[1];
  if (postId) {
    const json = await patreonApi(
      `${API}/posts/${postId}?include=campaign&fields[post]=title&fields[campaign]=name,url&json-api-version=1.0`,
    );
    const id = json.data?.relationships?.campaign?.data?.id;
    if (id) return id;
  }

  // 創作者頁：重抓一次頁面原始碼（SPA 換頁後 DOM 裡的資料可能還是上一頁的），
  // 從 Next.js 帶的初始資料裡找 campaign id（RSC 格式的引號會被跳脫，兩種都比對）。
  const html = await (await fetch(url.href, { credentials: "include" })).text();
  const candidates = [];
  const patterns = [
    /\\?"campaign\\?":\s*\{\\?"data\\?":\s*\{\\?"id\\?":\s*\\?"(\d+)/g,
    /\/api\/campaigns\/(\d+)/g,
  ];
  for (const pattern of patterns) {
    for (const match of html.matchAll(pattern)) {
      if (!candidates.includes(match[1])) candidates.push(match[1]);
    }
  }
  if (candidates.length === 0) {
    throw new Error("找不到這位創作者的資料，請開啟創作者首頁或其中一篇貼文再試");
  }

  // 頁面上可能還有推薦的其他創作者；網址有代稱時挑代稱相符的那個。
  const vanity = parseVanity(url)?.toLowerCase();
  if (vanity && candidates.length > 1) {
    for (const id of candidates.slice(0, 5)) {
      try {
        const json = await patreonApi(
          `${API}/campaigns/${id}?fields[campaign]=name,url,vanity&json-api-version=1.0`,
        );
        const attrs = json.data?.attributes ?? {};
        const campaignVanity = (attrs.vanity ?? new URL(attrs.url ?? "", "https://www.patreon.com").pathname.split("/").filter(Boolean).pop() ?? "").toLowerCase();
        if (campaignVanity === vanity) return id;
      } catch {
        // 試下一個。
      }
    }
  }
  return candidates[0];
}

const POST_QUERY =
  "include=campaign,images,attachments_media,user" +
  "&fields[post]=title,content,published_at,url,patreon_url,post_type,current_user_can_view," +
  "image,post_file,embed,like_count,comment_count,min_cents_pledged_to_view" +
  "&fields[media]=image_urls,download_url,file_name,metadata" +
  "&fields[campaign]=name,url" +
  "&fields[user]=full_name,url" +
  "&json-api-version=1.0";

/** API 的 url 是新格式（`/{vanity}/posts/…`），轉成正規化網址；認不出時退回只用 id。 */
function postUrl(post) {
  const attrs = post.attributes ?? {};
  const url = new URL(attrs.url ?? attrs.patreon_url ?? "/", "https://www.patreon.com");
  return canonicalPostUrl(url) ?? `https://www.patreon.com/posts/${post.id}`;
}

function toApiComment(comment, included) {
  const user = related(comment, "commenter", included)[0];
  return {
    author_name: user?.attributes?.full_name,
    content: comment.attributes?.body ?? "",
    posted_at: comment.attributes?.created,
    like_count: comment.attributes?.vote_sum,
    replies: related(comment, "replies", included)
      .map((reply) => toApiComment(reply, included))
      .filter((reply) => reply.content),
  };
}

async function loadApiComments(postId, warnings) {
  const comments = [];
  try {
    let url =
      `${API}/posts/${postId}/comments?include=commenter,replies,replies.commenter` +
      "&fields[comment]=body,created,vote_sum&fields[user]=full_name" +
      "&page[count]=50&sort=-created&json-api-version=1.0";
    const MAX_PAGES = 20;
    for (let page = 0; page < MAX_PAGES && url; page++) {
      const json = await patreonApi(url);
      const included = indexIncluded(json.included);
      for (const comment of json.data ?? []) {
        const parsed = toApiComment(comment, included);
        if (parsed.content) comments.push(parsed);
      }
      url = json.links?.next;
      if (url && page === MAX_PAGES - 1) warnings.push("留言太多，只儲存了部分留言");
    }
  } catch {
    if (comments.length === 0) warnings.push("留言讀取失敗，只會儲存貼文內容");
  }
  return comments;
}

/** 由 API 回傳的貼文資料組 payload（批次抓取用）。 */
async function extractFromApi({ post, included }, progress) {
  const attrs = post.attributes ?? {};
  const warnings = [];

  const urls = [];
  const seen = new Map();
  const add = (url, alt) => {
    if (!url) return;
    const key = mediaKey(url);
    // 同一張圖先由附圖清單加入時沒有 alt，內文裡的 <img> 再補上。
    if (seen.has(key)) {
      if (alt) seen.get(key).alt ||= alt;
      return;
    }
    const entry = { url, alt: alt || undefined };
    seen.set(key, entry);
    urls.push(entry);
  };
  for (const media of related(post, "images", included)) {
    add(media.attributes?.image_urls?.original ?? media.attributes?.download_url);
  }
  for (const img of parseHtml(attrs.content).querySelectorAll("img")) {
    const src = img.getAttribute("src") ?? "";
    if (src.includes("patreonusercontent.com")) add(src, img.getAttribute("alt")?.trim());
  }
  const postFile = attrs.post_file;
  if (urls.length === 0 && postFile?.url && IMAGE_EXT.test(postFile.name ?? new URL(postFile.url).pathname)) {
    add(postFile.url);
  }
  // 純文字／影片貼文沒有內嵌圖片，改用縮圖當封面。
  if (urls.length === 0) add(attrs.image?.large_url ?? attrs.image?.url);

  const media = await hoard.fetchAllMedia(urls, warnings, progress);
  if (media.length === 0 && urls.length > 0) {
    warnings.push("所有圖片都下載失敗，只會儲存 metadata");
  }

  const saveComments = (await hoard.getSettings()).saveComments !== false;
  const comments = !saveComments || attrs.comment_count === 0 ? [] : await loadApiComments(post.id, warnings);

  const campaign = related(post, "campaign", included)[0]?.attributes;
  const user = related(post, "user", included)[0]?.attributes;
  const authorName = campaign?.name || user?.full_name;
  const cents = attrs.min_cents_pledged_to_view;
  const sourceUrl = postUrl(post);
  const tags = await postTags(post.id);

  return {
    payload: {
      source_type: "patreon",
      source_url: sourceUrl,
      title: attrs.title || "Untitled",
      description: htmlToText(attrs.content),
      // 與 DOM 擷取一致：只給名稱，讓兩種方式收藏的作品歸到同一個帳號。
      author: authorName ? { name: authorName, url: campaign?.url ?? user?.url } : undefined,
      published_at: attrs.published_at,
      metadata: {
        tier: cents > 0 ? `$${(cents / 100).toFixed(2).replace(/\.00$/, "")} 以上` : undefined,
        tags,
        like_count: attrs.like_count,
        comment_count: attrs.comment_count,
        post_type: attrs.post_type,
        embed_url: attrs.embed?.url,
        attachments: related(post, "attachments_media", included).map(
          (file) => file.attributes?.file_name ?? file.attributes?.download_url,
        ),
      },
      media,
      comments,
    },
    warnings,
  };
}

/**
 * Patreon 留言是漸進載入的：「載入更多留言」按鈕逐頁載入頂層留言，
 * 每串回覆又藏在自己的展開鈕後面。反覆點到沒有新東西為止。
 */
async function loadAllComments(warnings) {
  const MAX_ROUNDS = 40;
  for (let round = 0; round < MAX_ROUNDS; round++) {
    const buttons = [];

    const loadMore = document.querySelector('[data-tag="loadMoreCommentsCta"]');
    if (loadMore) buttons.push(loadMore);

    for (const button of document.querySelectorAll("button")) {
      const label = button.innerText.trim();
      if (!label) continue;
      if (
        /(load|view|show)\s+(more|previous|all|\d+)|more\s+comments?|\d+\s+(more\s+)?repl/i.test(label) ||
        /(載入|查看|顯示)更多|更多留言|\d+\s*(則|个|條)?回覆/.test(label)
      ) {
        buttons.push(button);
      }
    }

    if (buttons.length === 0) return;
    for (const button of buttons) button.click();
    await hoard.sleep(1200);

    if (round === MAX_ROUNDS - 1) {
      warnings.push("留言太多，只載入了部分留言");
    }
  }
}

function readComments() {
  const comments = [];
  for (const row of document.querySelectorAll('[data-tag="comment-row"]')) {
    const content = row.querySelector('[data-tag="comment-body"]')?.innerText.trim();
    if (!content) continue;
    const likeText = row.querySelector('[data-tag="like-count"]')?.innerText;
    comments.push({
      author_name: row.querySelector('[data-tag="commenter-name"]')?.innerText.trim(),
      content,
      posted_at: row.querySelector("time")?.getAttribute("datetime") ?? undefined,
      like_count: hoard.parseCount(likeText),
    });
  }
  return comments;
}

function firstText(...selectors) {
  for (const selector of selectors) {
    const el = document.querySelector(selector);
    const text = el?.innerText.trim();
    if (text) return text;
  }
  return undefined;
}

hoard.registerExtractor({
  sourceType: "patreon",

  sourceUrl(url) {
    return canonicalPostUrl(url);
  },

  async extract({ listing, progress }) {
    if (listing?.data) return extractFromApi(/** @type {any} */ (listing.data), progress);

    const warnings = [];
    const postId = parsePostSlug(new URL(location.href))?.match(/(\d+)$/)?.[1];

    const title = firstText('[data-tag="post-title"]', "h1");
    const content = firstText('[data-tag="post-content"]');
    if (!title && !content) {
      throw new Error("讀不到貼文內容，Patreon 的頁面結構可能已改版（或貼文未解鎖）");
    }

    // 在載入留言改動頁面之前先收集圖片網址。
    const byUrl = new Map();
    for (const img of document.querySelectorAll(
      '[data-tag="post-content"] img, [data-tag="post-image"] img, img[data-tag="lazy-loaded-image"]',
    )) {
      if (!img.src.includes("patreonusercontent.com")) continue;
      const alt = img.getAttribute("alt")?.trim() || undefined;
      const seen = byUrl.get(img.src);
      if (seen) seen.alt ||= alt;
      else byUrl.set(img.src, { url: img.src, alt });
    }
    const imageUrls = [...byUrl.values()];

    const saveComments = (await hoard.getSettings()).saveComments !== false;
    if (saveComments) await loadAllComments(warnings);
    const comments = saveComments ? readComments() : [];

    const authorName =
      firstText('[data-tag="creator-name"]', '[data-tag="post-published-by"]') ??
      document
        .querySelector('meta[property="og:site_name"]')
        ?.content.replace(/\s*\|\s*Patreon.*$/i, "");

    const attachments = Array.from(
      document.querySelectorAll('a[data-tag="post-attachment-link"]'),
      (link) => link.innerText.trim() || link.href,
    );

    const media = await hoard.fetchAllMedia(imageUrls, warnings);

    return {
      payload: {
        source_type: "patreon",
        source_url: canonicalPostUrl(new URL(location.href)) ?? location.href,
        title: title ?? "Untitled",
        description: content,
        author: authorName ? { name: authorName } : undefined,
        published_at:
          document.querySelector('[data-tag="post-details"] time, time')?.getAttribute("datetime") ??
          firstText('[data-tag="post-published-at"]'),
        metadata: {
          tier: firstText('[data-tag="post-tier"]'),
          attachments,
          tags: postId ? await postTags(postId) : undefined,
        },
        media,
        comments,
      },
      warnings,
    };
  },

  async listCreatorPosts({ url, progress }) {
    progress("尋找創作者…");
    const campaignId = await findCampaignId(url);

    const posts = [];
    let creator;
    let next =
      `${API}/posts?filter[campaign_id]=${campaignId}&filter[contains_exclusive_posts]=true` +
      `&filter[is_draft]=false&sort=-published_at&page[count]=50&${POST_QUERY}`;
    for (let page = 1; next; page++) {
      progress(`讀取作品清單第 ${page} 頁（已列出 ${posts.length} 篇）…`);
      const json = await patreonApi(next);
      const included = indexIncluded(json.included);
      for (const post of json.data ?? []) {
        creator ??= related(post, "campaign", included)[0]?.attributes?.name;
        posts.push({
          url: postUrl(post),
          title: post.attributes?.title,
          locked: post.attributes?.current_user_can_view === false,
          data: { post, included },
        });
      }
      next = json.links?.next;
      if (next) await hoard.sleep(300);
    }
    return { creator, posts };
  },
});
