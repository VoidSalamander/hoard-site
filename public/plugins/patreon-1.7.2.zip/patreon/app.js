// @ts-check
/// <reference path="../hoard-app.d.ts" />
/* Patreon App 端：詳情頁仿 Patreon 貼文頁（白底、方案徽章、內文、附件、留言），
   樣式見 styles.css。書架卡片沿用 App 主題。 */

/**
 * 頭像：插件存的頭像（`path`），沒有或讀不到時用名字第一個字。
 * @param {string | null | undefined} name @param {string} cls @param {string | null | undefined} [path]
 */
function avatar(name, cls, path) {
  const initial = () => hoard.el("div", { class: cls }, [(name || "?").trim().charAt(0).toUpperCase()]);
  if (!path) return initial();
  // 插件抓到的頭像；讀不到就退回首字。
  const img = hoard.el("img", { class: cls, src: hoard.fileSrc(path), alt: "", draggable: "false" });
  img.addEventListener("error", () => img.replaceWith(initial()), { once: true });
  return img;
}

function commentNode(node) {
  const c = node.comment;
  const row = hoard.el("div", { class: "hpt-comment" }, [
    avatar(c.author_name, "hpt-avatar hpt-avatar-sm"),
    hoard.el("div", { class: "hpt-comment-body" }, [
      hoard.el("p", { class: "hpt-comment-head" }, [
        hoard.el("b", {}, [c.author_name || "匿名"]),
        c.posted_at ? hoard.el("span", { class: "hpt-muted" }, [hoard.formatDate(c.posted_at)]) : null,
      ]),
      hoard.el("p", { class: "hpt-comment-text" }, [c.content]),
      c.like_count > 0
        ? hoard.el("p", { class: "hpt-muted hpt-inline" }, [hoard.icon("heart", { size: 12 }), hoard.formatCount(c.like_count)])
        : null,
    ]),
  ]);
  if (node.replies.length === 0) return row;
  return hoard.el("div", {}, [row, hoard.el("div", { class: "hpt-replies" }, node.replies.map(commentNode))]);
}

/** 圖片的 width／height 屬性（原圖的像素尺寸；還沒量測時不給）。 @param {HoardItemFile} file */
const sizeAttrs = (file) => (file.width && file.height ? { width: String(file.width), height: String(file.height) } : {});

hoard.register({
  renderDetail(root, item, ctx) {
    const tier = typeof item.metadata.tier === "string" ? item.metadata.tier : null;
    // 附件沒有下載，擷取器只記下檔名（同 FANBOX）。
    const attachments = Array.isArray(item.metadata.attachments)
      ? item.metadata.attachments.filter((entry) => typeof entry === "string" && entry)
      : [];
    const media = item.files.filter((f) => f.kind === "image" || f.kind === "video");

    const author = item.author;
    const byline = [
      avatar(author && author.name, "hpt-avatar", author && author.avatar_path),
      hoard.el("div", { class: "hpt-who" }, [
        hoard.el("p", author ? { class: "hpt-name", style: "cursor:pointer", title: "查看這位創作者的所有收藏", onclick: () => ctx.openAuthor(author.id) } : { class: "hpt-name" }, [author ? author.name : "未知創作者"]),
        hoard.el("p", { class: "hpt-muted" }, [hoard.formatDateTime(item.published_at) || "發布時間未知"]),
      ]),
    ];
    if (author && author.url) {
      const url = author.url;
      byline.push(hoard.el("button", { class: "hpt-btn", onclick: () => hoard.openUrl(url) }, ["創作者頁面"]));
    }

    const post = [hoard.el("div", { class: "hpt-byline" }, byline)];
    if (tier) post.push(hoard.el("p", { class: "hpt-tier" }, [hoard.icon("lock-open", { size: 13 }), tier]));
    post.push(hoard.el("h1", { class: "hpt-title" }, [item.title]));
    for (const [i, file] of media.entries()) {
      if (file.kind === "video") {
        post.push(hoard.el("video", { class: "hpt-media", src: hoard.fileSrc(file.path), controls: "", preload: "metadata" }));
      } else {
        // 原圖可能幾千萬像素：畫的時候才解碼會讓每一格都等它，交給背景解碼。
        // 先照原圖的尺寸佔好位置：還沒載入的圖高度不是 0，lazy 才只載入畫面附近的幾張，頁面也不會一張張被推開。
        const img = hoard.el("img", { class: "hpt-media", src: hoard.fileSrc(file.path), alt: file.alt ?? "", ...(file.alt ? { title: file.alt } : {}), loading: "lazy", decoding: "async", ...sizeAttrs(file) });
        img.addEventListener("click", () => ctx.openViewer(media, i));
        post.push(img);
      }
    }
    if (item.description) post.push(hoard.el("p", { class: "hpt-body" }, [item.description]));
    if (attachments.length > 0) {
      post.push(
        hoard.el(
          "div",
          { class: "hpt-files" },
          attachments.map((name) =>
            hoard.el("p", { class: "hpt-file" }, [hoard.icon("paperclip", { size: 16 }), hoard.el("span", {}, [name])]),
          ),
        ),
      );
    }
    if (item.comments.length > 0) {
      post.push(
        hoard.el("section", { class: "hpt-comments" }, [
          hoard.el("h3", { class: "hpt-section-title" }, [`${item.comments.length} 則留言`]),
          ...hoard.buildCommentTree(item.comments).map(commentNode),
        ]),
      );
    }
    root.append(hoard.el("div", { class: "hpt-page" }, [hoard.el("article", { class: "hpt-post" }, post)]));
  },

  renderCardMeta(root, item) {
    const meta = item.metadata;
    const children = [];
    if (typeof meta.tier === "string" && meta.tier) {
      children.push(hoard.el("span", { class: "hpt-card-tier" }, [meta.tier]));
    }
    children.push(hoard.el("span", {}, [hoard.formatDate(item.published_at)]));
    root.append(
      hoard.el("div", { class: "hpt-card-meta" }, children),
    );
  },
});

// ---- 插件設定：在網頁上的行為（擴充端用 hoard.getSettings 讀，每個網站有的動作不同） ----

/** @type {Array<{ key: string; label: string; hint: string; fallback: boolean }>} */
const PAGE_OPTIONS = [
  { key: "saveComments", label: "收藏時一起抓留言", hint: "Patreon 的留言與回覆；關掉後也不會去點「載入更多留言」。", fallback: true },
];

/**
 * 改擷取器設定（`hoard.storage` 的 `extractor`）的一項。用 `storage.update` 一次讀改寫：
 * 快速連切兩個開關時，後一個不會蓋掉前一個。
 * @param {string} key @param {unknown} value
 */
function saveExtractorSetting(key, value) {
  return hoard.storage.update("extractor", (/** @type {Record<string, unknown> | undefined} */ saved) => ({ ...saved, [key]: value }));
}

hoard.registerSettingTab({
  label: "在網頁上",
  render(el) {
    const inputs = PAGE_OPTIONS.map((option) => {
      const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hpt-switch" }));
      el.append(
        hoard.el("label", { class: "hpt-setting-row" }, [
          hoard.el("span", {}, [hoard.el("strong", {}, [option.label]), hoard.el("span", { class: "hpt-setting-hint" }, [option.hint])]),
          input,
        ]),
      );
      return { option, input };
    });
    el.append(hoard.el("p", { class: "hpt-setting-hint" }, ["改完後重新整理網頁就生效，不用同步插件。"]));
    void hoard.storage.get("extractor").then((saved) => {
      const settings = /** @type {Record<string, unknown>} */ (saved ?? {});
      for (const { option, input } of inputs) input.checked = typeof settings[option.key] === "boolean" ? Boolean(settings[option.key]) : option.fallback;
    });
    for (const { option, input } of inputs) {
      input.addEventListener("change", async () => {
        await saveExtractorSetting(option.key, input.checked);
      });
    }
  },
});

// ---- 作者頭像：插件找網址、下載，交給核心存（創作者清單、創作者頁顯示） ----

/** @type {Record<string, string>} */
const AVATAR_HEADERS = {};

/**
 * 帳號的頭像網址：用創作者網址的名稱（patreon.com/名稱、/c/名稱）查 campaign（不用登入）。
 * `/user?u=` 這種沒有名稱的網址查不到。
 * @param {HoardAuthor} author
 */
async function avatarUrl(author) {
  if (!author.url) return null;
  const parts = new URL(author.url).pathname.split("/").filter(Boolean);
  const vanity = parts[0] === "c" || parts[0] === "cw" ? parts[1] : parts[0];
  if (!vanity || vanity === "user") return null;
  const query = `filter%5Bvanity%5D=${encodeURIComponent(vanity)}&fields%5Bcampaign%5D=avatar_photo_url`;
  const res = await hoard.fetch(`https://www.patreon.com/api/campaigns?${query}`);
  if (!res.ok) throw new Error(`campaign HTTP ${res.status}`);
  const url = /** @type {any} */ (await res.json())?.data?.[0]?.attributes?.avatar_photo_url;
  return typeof url === "string" && url ? url : null;
}

/** 這次開 App 試過的帳號（抓到或失敗）不再試。 */
const avatarTried = new Set();
/** @type {Promise<void> | null} */
let avatarRun = null;
let avatarAgain = false;
let avatarStopped = false;
hoard.onUnload(() => {
  avatarStopped = true;
});

/** 替還沒有頭像的 Patreon 帳號補上：一次一個、間隔一下；跑的時候又有新收藏就再跑一輪。 */
function fillAvatars() {
  if (avatarRun) {
    avatarAgain = true;
    return;
  }
  avatarRun = (async () => {
    do {
      avatarAgain = false;
      const authors = await hoard.authors.list({ source: "patreon" });
      for (const author of authors) {
        if (avatarStopped) return;
        if (author.avatar_path || avatarTried.has(author.id)) continue;
        avatarTried.add(author.id);
        try {
          const url = await avatarUrl(author);
          if (!url) continue;
          const res = await hoard.fetch(url, { headers: AVATAR_HEADERS });
          if (!res.ok) throw new Error(`頭像 HTTP ${res.status}`);
          await hoard.authors.setAvatar(author.id, await res.arrayBuffer(), { source: url });
        } catch (err) {
          console.warn(`[patreon] 抓不到 ${author.name} 的頭像：`, err);
        }
        await new Promise((resolve) => setTimeout(resolve, 1200));
      }
    } while (avatarAgain && !avatarStopped);
  })()
    .catch((err) => console.warn("[patreon] 補頭像失敗：", err))
    .finally(() => {
      avatarRun = null;
    });
}

// 開 App 後先讓畫面載完再補；之後每有新收藏就補新的作者。
const avatarStart = setTimeout(fillAvatars, 8000);
hoard.onUnload(() => clearTimeout(avatarStart));
hoard.on("items-added", () => fillAvatars());

// ---- 標籤自動匯入（預設關閉）：把 Patreon 作品的標籤加進標籤庫，並貼到作品上 ----

/** 創作者替貼文加的標籤（擷取器存在 metadata.tags；1.7.0 之前收的沒有）。 @param {HoardItemSummary} item @returns {string[]} */
function siteTagsOf(item) {
  const tags = Array.isArray(item.metadata.tags) ? item.metadata.tags : [];
  return tags.filter((tag) => typeof tag === "string" && tag.trim()).map((tag) => tag.trim());
}

/**
 * 替這些作品加上網站的標籤；同一個標籤的作品合成一次呼叫，標籤庫沒有的由核心建立。
 * @param {HoardItemSummary[]} items
 */
async function importSiteTags(items) {
  /** @type {Map<string, number[]>} */
  const byName = new Map();
  for (const item of items) {
    for (const name of new Set(siteTagsOf(item))) {
      const ids = byName.get(name);
      if (ids) ids.push(item.id);
      else byName.set(name, [item.id]);
    }
  }
  for (const [name, ids] of byName) await hoard.items.addTags(ids, [name]);
}

hoard.on("items-added", async ({ ids }) => {
  if ((await hoard.storage.get("autoTags")) !== true) return;
  const { items } = await hoard.items.list({ ids, source_type: "patreon" }, { limit: ids.length });
  if (items.length > 0) await importSiteTags(items);
});

/** 替已經收藏的作品補上；使用者打開開關時問過才做。 */
async function importAllSiteTags() {
  hoard.toast("正在替已收藏的 Patreon 作品加上標籤…", { kind: "busy" });
  try {
    let done = 0;
    for (let offset = 0; ; offset += 200) {
      const { items } = await hoard.items.list({ source_type: "patreon" }, { offset, limit: 200 });
      await importSiteTags(items);
      done += items.length;
      if (items.length < 200) break;
    }
    hoard.toast(`已替 ${done} 件 Patreon 作品加上標籤`);
  } catch (err) {
    hoard.toast(`加標籤失敗：${err instanceof Error ? err.message : err}`, { kind: "error" });
  }
}

hoard.registerSettingTab({
  label: "標籤",
  render(el) {
    const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox", role: "switch", class: "hpt-switch" }));
    el.append(
      hoard.el("label", { class: "hpt-setting-row" }, [
        hoard.el("span", {}, [
          hoard.el("strong", {}, ["自動匯入標籤"]),
          hoard.el("span", { class: "hpt-setting-hint" }, ["收藏的 Patreon 作品自動加上網站上的標籤，標籤庫沒有的會建立。預設關閉：標籤一多，標籤庫會變得很雜。"]),
        ]),
        input,
      ]),
    );
    void hoard.storage.get("autoTags").then((value) => (input.checked = value === true));
    input.addEventListener("change", async () => {
      await hoard.storage.set("autoTags", input.checked);
      if (!input.checked) return;
      const { total } = await hoard.items.list({ source_type: "patreon" }, { limit: 1 });
      if (total > 0 && (await hoard.confirm(`也替已經收藏的 ${total} 件 Patreon 作品加上標籤？`, { confirmLabel: "加上標籤" }))) {
        await importAllSiteTags();
      }
    });
  },
});
