// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：音訊。
 *
 *  - 本機的音訊檔（App 收成「其他檔案」）在這裡才有內容可看：
 *    快速預覽（registerQuickLook）按空白鍵就播；詳情頁（registerDetail("local", …, { when })）整頁畫播放器與資訊；
 *    側欄的「音訊」頁面（registerView）一列一個音訊檔（ctx.virtualList，只建出看得到的列），按播放鍵直接播，不打開作品，可以搜尋。
 *  - 資訊從檔頭讀（用 Range 只讀需要的部分，不讀整個檔）：WAV 的 fmt、LIST INFO、bext；AIFF 的 COMM；
 *    FLAC 的 STREAMINFO 與 Vorbis comment；MP3 的 ID3v2 與 Xing／VBRI（沒有時用位元率估）；Ogg Vorbis／Opus 的
 *    識別與註解標頭、最後一頁的 granule；M4A 的 mvhd、stsd 與 ilst。讀不到長度時用 <audio> 的長度。
 *  - 波形：整個檔案交給 Web Audio 解碼，算出每一段的最大、最小值畫在 canvas 上。超過 512 MB 的不解碼
 *    （「音訊」頁面裡超過 64 MB 的也不解碼），一次只解碼一個檔。
 *  - 卡片的波形封面：每件音訊作品用同一份波形畫一張方形、透明底的 PNG（波形在中間，網格的 3:4 裁切後也完整），交給 items.setCover 當格式封面
 *    （使用者選的封面優先）。載入時用 items.list({ exts }) 補舊作品、items-added 做新作品，一次一件；
 *    做過的記在 storage（id → 封面版本與檔案的 modified_at），檔案改過或 COVER_VERSION 提高時重做。
 *  - 同一時間只有一個聲音在播。音量、循環、快速預覽要不要自動播放、背景播放記在插件 storage（設定頁）。
 *  - 背景播放：打開時，播放器關掉（離開詳情頁、關掉快速預覽、換頁）若正在播，聲音留著繼續播；
 *    再打開同一個檔的播放器就接回來，開始播別的聲音、播完（沒循環）或關掉這個設定時才停。
 *  - WebView 播不了 AIFF：照樣讀檔頭顯示資訊，播放處顯示「無法在 App 內播放」，也沒有波形封面。
 *  - 只讀檔案：不寫入原檔；作品只設格式封面（篩選值之後再做）。
 */

const AUDIO_EXTENSIONS = new Set(["wav", "mp3", "flac", "ogg", "oga", "opus", "m4a", "aac", "aif", "aiff"]);
/** WebView 解不開的格式：只有檔頭資訊。 */
const UNPLAYABLE = new Set(["aif", "aiff"]);
/** 超過這個大小不解碼（沒有波形）。 */
const MAX_DECODE = 512 * 1024 * 1024;
/** 「音訊」頁面一次會畫很多列，大檔的波形等打開時再看。 */
const LIST_MAX_DECODE = 64 * 1024 * 1024;
/** 波形分成幾段。 */
const BUCKETS = 800;
const HEAD_BYTES = 256 * 1024;

// ---- 設定 ----

/** @typedef {{ volume: number; loop: boolean; autoplay: boolean; background: boolean }} Settings */
/** @type {Settings} */
const settings = { volume: 0.8, loop: false, autoplay: true, background: false };
/** 設定改變時要更新的播放器。 @type {Set<() => void>} */
const settingListeners = new Set();
const settingsLoaded = hoard.storage.get("settings").then((saved) => {
  if (saved && typeof saved === "object") Object.assign(settings, saved);
  settingListeners.forEach((fn) => fn());
});

/** @param {Partial<Settings>} changes */
function updateSettings(changes) {
  Object.assign(settings, changes);
  void hoard.storage.set("settings", settings);
  settingListeners.forEach((fn) => fn());
}

// ---- 哪些作品是音訊 ----

/** 小寫副檔名，不含點。 @param {string} path */
function extOf(path) {
  const name = path.split(/[\\/]/).pop() ?? "";
  const dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : "";
}

/** 作品摘要看得出的音訊：本機的單一檔案，第一個檔案是音訊。 @param {HoardItemSummary} item */
function isAudioItem(item) {
  const format = item.ext;
  return item.source_type === "local" && item.metadata.format == null && typeof format === "string" && AUDIO_EXTENSIONS.has(format.toLowerCase());
}

/** 作品的音訊檔。 @param {HoardItemDetail} item */
function audioFileOf(item) {
  return item.files.find((f) => f.kind === "file" && AUDIO_EXTENSIONS.has(extOf(f.path))) ?? null;
}

/**
 * 摘要裡沒有「其他檔案」的路徑，要讀整件作品；最近讀過的留著（最多 300 件），作品改了就丟掉。
 * @type {Map<number, Promise<HoardItemDetail>>}
 */
const details = new Map();
/** @param {number} id */
function detailOf(id) {
  let pending = details.get(id);
  if (pending) {
    details.delete(id); // 移到最新
  } else {
    pending = hoard.items.get(id);
    pending.catch(() => details.delete(id));
  }
  details.set(id, pending);
  if (details.size > 300) details.delete(/** @type {number} */ (details.keys().next().value));
  return pending;
}
hoard.on("items-changed", ({ ids }) => ids.forEach((id) => details.delete(id)));

// ---- 讀檔 ----

/**
 * 讀原檔的一段（含 start，不含 end）。App 一次最多回約 1 MB，拿到的比要的少就接著讀；
 * 伺服器不理 Range 時從整個檔裡切。 @param {string} src @param {number} start @param {number} end
 */
async function readRange(src, start, end) {
  const out = new Uint8Array(Math.max(0, end - start));
  let at = start;
  while (at < end) {
    const res = await fetch(src, { headers: { Range: `bytes=${at}-${end - 1}` } });
    if (!res.ok) throw new Error(`讀不到檔案（${res.status}）`);
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (res.status !== 206) return bytes.subarray(start, end);
    if (bytes.length === 0) break;
    out.set(bytes.subarray(0, end - at), at - start);
    at += bytes.length;
  }
  return out.subarray(0, at - start);
}

/** @param {Uint8Array} b @param {number} at @param {number} n */
const ascii = (b, at, n) => String.fromCharCode(...b.subarray(at, at + n));
/** @param {Uint8Array} b @param {number} at */
const u16le = (b, at) => b[at] | (b[at + 1] << 8);
/** @param {Uint8Array} b @param {number} at */
const u32le = (b, at) => (b[at] | (b[at + 1] << 8) | (b[at + 2] << 16) | (b[at + 3] << 24)) >>> 0;
/** @param {Uint8Array} b @param {number} at */
const u16be = (b, at) => (b[at] << 8) | b[at + 1];
/** @param {Uint8Array} b @param {number} at */
const u32be = (b, at) => ((b[at] << 24) | (b[at + 1] << 16) | (b[at + 2] << 8) | b[at + 3]) >>> 0;
/** @param {Uint8Array} b @param {number} at */
const u64le = (b, at) => u32le(b, at) + u32le(b, at + 4) * 2 ** 32;
/** @param {Uint8Array} b @param {number} at */
const u64be = (b, at) => u32be(b, at) * 2 ** 32 + u32be(b, at + 4);

/** 文字：先試 UTF-8，不是合法 UTF-8 時當 Latin-1；去掉結尾的 NUL 與空白。 @param {Uint8Array} bytes */
function text(bytes) {
  let value;
  try {
    value = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    value = new TextDecoder("latin1").decode(bytes);
  }
  return value.replace(/\0[\s\S]*$/, "").trim();
}

/**
 * @typedef {{
 *   codec: string;
 *   duration?: number;
 *   sampleRate?: number;
 *   bitDepth?: number;
 *   channels?: number;
 *   bitrate?: number;
 *   title?: string;
 *   artist?: string;
 *   description?: string;
 *   comment?: string;
 * }} AudioInfo
 */

/** 只留有值的文字欄位。 @param {AudioInfo} info @param {"title" | "artist" | "description" | "comment"} key @param {string | undefined} value */
function setText(info, key, value) {
  const clean = value?.trim();
  if (clean && !info[key]) info[key] = clean;
}

/**
 * RIFF 類（WAV）與 IFF 類（AIFF）：chunk 一個接一個，資料區可能很大，跳過去用 Range 讀後面的 chunk
 * （LIST INFO 常常在資料後面）。
 * @param {string} src @param {number} size @param {Uint8Array} head @param {boolean} bigEndian
 * @param {(id: string, body: Uint8Array, length: number) => void} onChunk
 */
async function walkChunks(src, size, head, bigEndian, onChunk) {
  let buffer = head;
  let base = 0;
  let at = 12;
  for (let guard = 0; guard < 64 && at + 8 <= size; guard++) {
    if (at + 8 > base + buffer.length) {
      base = at;
      buffer = await readRange(src, at, Math.min(size, at + 64 * 1024));
    }
    const local = at - base;
    if (local + 8 > buffer.length) break; // 檔案比宣稱的短
    const id = ascii(buffer, local, 4);
    const length = bigEndian ? u32be(buffer, local + 4) : u32le(buffer, local + 4);
    const bodyStart = at + 8;
    // 資料區本身不用讀；其他 chunk 都很小，最多讀 1 MB。
    if (id !== "data" && id !== "SSND") {
      const want = Math.min(length, 1024 * 1024);
      let body;
      if (bodyStart + want <= base + buffer.length) {
        body = buffer.subarray(bodyStart - base, bodyStart - base + want);
      } else {
        body = await readRange(src, bodyStart, Math.min(size, bodyStart + want));
      }
      onChunk(id, body, length);
    } else {
      onChunk(id, new Uint8Array(0), length);
    }
    at = bodyStart + length + (length % 2);
  }
}

/** @param {string} src @param {number} size @param {Uint8Array} head @returns {Promise<AudioInfo>} */
async function readWav(src, size, head) {
  /** @type {AudioInfo} */
  const info = { codec: "WAV" };
  let byteRate = 0;
  let dataLength = 0;
  await walkChunks(src, size, head, false, (id, body, length) => {
    if (id === "fmt " && body.length >= 16) {
      const format = u16le(body, 0);
      info.channels = u16le(body, 2);
      info.sampleRate = u32le(body, 4);
      byteRate = u32le(body, 8);
      info.bitDepth = u16le(body, 14);
      // WAVE_FORMAT_EXTENSIBLE：真正的格式在子格式 GUID 的前兩個位元組。
      const real = format === 0xfffe && body.length >= 26 ? u16le(body, 24) : format;
      info.codec = real === 1 ? "PCM" : real === 3 ? "PCM（浮點數）" : real === 0x55 ? "MP3" : `WAV（格式 ${real}）`;
    } else if (id === "data") {
      dataLength = length;
    } else if (id === "bext" && body.length >= 256) {
      setText(info, "description", text(body.subarray(0, 256)));
    } else if (id === "LIST" && ascii(body, 0, 4) === "INFO") {
      for (let at = 4; at + 8 <= body.length; ) {
        const key = ascii(body, at, 4);
        const len = u32le(body, at + 4);
        const value = text(body.subarray(at + 8, at + 8 + len));
        if (key === "INAM") setText(info, "title", value);
        else if (key === "IART") setText(info, "artist", value);
        else if (key === "ICMT") setText(info, "comment", value);
        else if (key === "ISBJ") setText(info, "description", value);
        at += 8 + len + (len % 2);
      }
    }
  });
  if (byteRate > 0 && dataLength > 0) info.duration = dataLength / byteRate;
  return info;
}

/** 80 位元的擴充精度浮點數（AIFF 的取樣率）。 @param {Uint8Array} b @param {number} at */
function extended80(b, at) {
  const exponent = (((b[at] & 0x7f) << 8) | b[at + 1]) - 16383;
  const mantissa = u32be(b, at + 2) * 2 ** 32 + u32be(b, at + 6);
  return mantissa * 2 ** (exponent - 63);
}

/** @param {string} src @param {number} size @param {Uint8Array} head @returns {Promise<AudioInfo>} */
async function readAiff(src, size, head) {
  /** @type {AudioInfo} */
  const info = { codec: ascii(head, 8, 4) === "AIFC" ? "AIFF-C" : "AIFF PCM" };
  await walkChunks(src, size, head, true, (id, body) => {
    if (id === "COMM" && body.length >= 18) {
      info.channels = u16be(body, 0);
      const frames = u32be(body, 2);
      info.bitDepth = u16be(body, 6);
      info.sampleRate = Math.round(extended80(body, 8));
      if (info.sampleRate > 0) info.duration = frames / info.sampleRate;
      if (body.length >= 22) {
        const compression = ascii(body, 18, 4);
        if (compression !== "NONE" && compression !== "twos") info.codec = `AIFF-C（${compression.trim()}）`;
      }
    } else if (id === "NAME") setText(info, "title", text(body));
    else if (id === "AUTH") setText(info, "artist", text(body));
    else if (id === "ANNO") setText(info, "comment", text(body));
  });
  return info;
}

/** Vorbis comment（FLAC、Ogg Vorbis、Opus 共用）：長度都是 little-endian。 @param {Uint8Array} b @param {AudioInfo} info */
function readVorbisComment(b, info) {
  if (b.length < 8) return;
  let at = 4 + u32le(b, 0);
  const count = u32le(b, at);
  at += 4;
  for (let i = 0; i < count && at + 4 <= b.length; i++) {
    const len = u32le(b, at);
    const entry = new TextDecoder().decode(b.subarray(at + 4, at + 4 + len));
    at += 4 + len;
    const eq = entry.indexOf("=");
    if (eq < 0) continue;
    const key = entry.slice(0, eq).toUpperCase();
    const value = entry.slice(eq + 1);
    if (key === "TITLE") setText(info, "title", value);
    else if (key === "ARTIST") setText(info, "artist", value);
    else if (key === "DESCRIPTION") setText(info, "description", value);
    else if (key === "COMMENT") setText(info, "comment", value);
  }
}

/** FLAC：metadata block 在檔案開頭；封面圖（PICTURE）可能很大，跳過去用 Range 讀。 @param {string} src @param {number} size @param {Uint8Array} head @returns {Promise<AudioInfo>} */
async function readFlac(src, size, head) {
  /** @type {AudioInfo} */
  const info = { codec: "FLAC" };
  let buffer = head;
  let base = 0;
  let at = 4;
  for (let guard = 0; guard < 128 && at + 4 <= size; guard++) {
    if (at + 4 > base + buffer.length) {
      base = at;
      buffer = await readRange(src, at, Math.min(size, at + 64 * 1024));
    }
    const local = at - base;
    if (local + 4 > buffer.length) break;
    const last = (buffer[local] & 0x80) !== 0;
    const type = buffer[local] & 0x7f;
    const length = (buffer[local + 1] << 16) | (buffer[local + 2] << 8) | buffer[local + 3];
    const bodyStart = at + 4;
    if (type === 0 || type === 4) {
      const body =
        bodyStart + length <= base + buffer.length
          ? buffer.subarray(bodyStart - base, bodyStart - base + length)
          : await readRange(src, bodyStart, Math.min(size, bodyStart + Math.min(length, 1024 * 1024)));
      if (type === 0 && body.length >= 18) {
        const b = body;
        info.sampleRate = (b[10] << 12) | (b[11] << 4) | (b[12] >> 4);
        info.channels = ((b[12] >> 1) & 7) + 1;
        info.bitDepth = (((b[12] & 1) << 4) | (b[13] >> 4)) + 1;
        const total = (b[13] & 0x0f) * 2 ** 32 + u32be(b, 14);
        if (info.sampleRate > 0 && total > 0) info.duration = total / info.sampleRate;
      } else if (type === 4) {
        readVorbisComment(body, info);
      }
    }
    if (last) break;
    at = bodyStart + length;
  }
  return info;
}

// MP3：位元率（kbps）與取樣率表。
const MP3_BITRATES = {
  "1-1": [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448],
  "1-2": [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384],
  "1-3": [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320],
  "2-1": [0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256],
  "2-2": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
  "2-3": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
};
const MP3_RATES = { 1: [44100, 48000, 32000], 2: [22050, 24000, 16000], 25: [11025, 12000, 8000] };

/** ID3v2 的文字框。 @param {Uint8Array} b */
function id3Text(b) {
  if (b.length === 0) return "";
  const body = b.subarray(1);
  const encoding = b[0];
  if (encoding === 1 || encoding === 2) {
    const le = encoding === 1 && body[0] === 0xff && body[1] === 0xfe;
    const be = encoding === 2 || (body[0] === 0xfe && body[1] === 0xff);
    const start = encoding === 1 ? 2 : 0;
    return new TextDecoder(le || !be ? "utf-16le" : "utf-16be").decode(body.subarray(start)).replace(/\0[\s\S]*$/, "").trim();
  }
  return encoding === 3 ? text(body) : new TextDecoder("latin1").decode(body).replace(/\0[\s\S]*$/, "").trim();
}

/** COMM：編碼、語言（3）、簡述（以 NUL 結尾）、內容。 @param {Uint8Array} b */
function id3Comment(b) {
  if (b.length < 5) return "";
  const encoding = b[0];
  const rest = b.subarray(4);
  const wide = encoding === 1 || encoding === 2;
  let at = 0;
  if (wide) {
    while (at + 1 < rest.length && !(rest[at] === 0 && rest[at + 1] === 0)) at += 2;
    at += 2;
  } else {
    while (at < rest.length && rest[at] !== 0) at++;
    at += 1;
  }
  const value = new Uint8Array(rest.length - at + 1);
  value[0] = encoding;
  value.set(rest.subarray(at), 1);
  return id3Text(value);
}

/** TXXX：編碼、名稱（以 NUL 結尾）、內容。回傳 [名稱, 內容]。 @param {Uint8Array} b @returns {[string, string]} */
function id3UserText(b) {
  if (b.length < 2) return ["", ""];
  const encoding = b[0];
  const wide = encoding === 1 || encoding === 2;
  let at = 1;
  if (wide) {
    while (at + 1 < b.length && !(b[at] === 0 && b[at + 1] === 0)) at += 2;
  } else {
    while (at < b.length && b[at] !== 0) at++;
  }
  const name = new Uint8Array(at);
  name[0] = encoding;
  name.set(b.subarray(1, at), 1);
  const value = new Uint8Array(b.length - at - (wide ? 2 : 1) + 1);
  value[0] = encoding;
  value.set(b.subarray(at + (wide ? 2 : 1)), 1);
  return [id3Text(name), id3Text(value)];
}

/** @param {Uint8Array} head @param {AudioInfo} info @returns {number} 音訊資料從哪裡開始 */
function readId3(head, info) {
  if (ascii(head, 0, 3) !== "ID3") return 0;
  const major = head[3];
  const flags = head[5];
  const tagSize = ((head[6] & 0x7f) << 21) | ((head[7] & 0x7f) << 14) | ((head[8] & 0x7f) << 7) | (head[9] & 0x7f);
  const end = Math.min(head.length, 10 + tagSize);
  const short = major === 2;
  // 延伸標頭（v2.3 的長度不含自己的 4 個位元組，v2.4 是 syncsafe 而且含）。
  let first = 10;
  if (flags & 0x40 && !short) {
    first +=
      major === 4
        ? ((head[10] & 0x7f) << 21) | ((head[11] & 0x7f) << 14) | ((head[12] & 0x7f) << 7) | (head[13] & 0x7f)
        : u32be(head, 10) + 4;
  }
  for (let at = first; at + (short ? 6 : 10) <= end; ) {
    const id = ascii(head, at, short ? 3 : 4);
    if (!/^[A-Z0-9]+$/.test(id)) break;
    const len = short
      ? (head[at + 3] << 16) | (head[at + 4] << 8) | head[at + 5]
      : major === 4
        ? ((head[at + 4] & 0x7f) << 21) | ((head[at + 5] & 0x7f) << 14) | ((head[at + 6] & 0x7f) << 7) | (head[at + 7] & 0x7f)
        : u32be(head, at + 4);
    const bodyStart = at + (short ? 6 : 10);
    const body = head.subarray(bodyStart, Math.min(end, bodyStart + len));
    if (id === "TIT2" || id === "TT2") setText(info, "title", id3Text(body));
    else if (id === "TPE1" || id === "TP1") setText(info, "artist", id3Text(body));
    else if (id === "COMM" || id === "COM") setText(info, "comment", id3Comment(body));
    else if (id === "TXXX" || id === "TXX") {
      // ffmpeg 等工具把註解、描述寫在使用者自訂文字框。
      const [name, value] = id3UserText(body);
      if (/^comments?$/i.test(name)) setText(info, "comment", value);
      else if (/^description$/i.test(name)) setText(info, "description", value);
    }
    at = bodyStart + len;
  }
  return 10 + tagSize + (flags & 0x10 ? 10 : 0);
}

/** @param {string} src @param {number} size @param {Uint8Array} head @returns {Promise<AudioInfo>} */
async function readMp3(src, size, head) {
  /** @type {AudioInfo} */
  const info = { codec: "MP3" };
  const audioStart = readId3(head, info);
  let buffer = head;
  let base = 0;
  if (audioStart + 4 > head.length) {
    base = audioStart;
    buffer = await readRange(src, audioStart, Math.min(size, audioStart + 64 * 1024));
  }
  for (let at = Math.max(0, audioStart - base); at + 4 < buffer.length; at++) {
    if (buffer[at] !== 0xff || (buffer[at + 1] & 0xe0) !== 0xe0) continue;
    const versionBits = (buffer[at + 1] >> 3) & 3;
    const layerBits = (buffer[at + 1] >> 1) & 3;
    const bitrateIndex = buffer[at + 2] >> 4;
    const rateIndex = (buffer[at + 2] >> 2) & 3;
    if (versionBits === 1 || layerBits === 0 || bitrateIndex === 0 || bitrateIndex === 15 || rateIndex === 3) continue;
    const version = versionBits === 3 ? 1 : versionBits === 2 ? 2 : 25;
    const layer = 4 - layerBits;
    const mono = buffer[at + 3] >> 6 === 3;
    const table = /** @type {Record<string, number[]>} */ (MP3_BITRATES)[`${version === 1 ? 1 : 2}-${layer}`];
    const bitrate = table[bitrateIndex] * 1000;
    const rate = /** @type {Record<number, number[]>} */ (MP3_RATES)[version][rateIndex];
    const samplesPerFrame = layer === 1 ? 384 : layer === 2 || version === 1 ? 1152 : 576;
    info.sampleRate = rate;
    info.channels = mono ? 1 : 2;
    info.codec = layer === 3 ? "MP3" : `MPEG Layer ${layer === 1 ? "I" : "II"}`;
    // Xing／Info（VBR 與 LAME 的 CBR）在 side information 後面；VBRI 固定在 32 個位元組後。
    const xing = at + 4 + (version === 1 ? (mono ? 17 : 32) : mono ? 9 : 17);
    let frames = 0;
    const tag = ascii(buffer, xing, 4);
    if ((tag === "Xing" || tag === "Info") && u32be(buffer, xing + 4) & 1) frames = u32be(buffer, xing + 8);
    else if (ascii(buffer, at + 36, 4) === "VBRI") frames = u32be(buffer, at + 36 + 14);
    if (frames > 0) {
      info.duration = (frames * samplesPerFrame) / rate;
      info.bitrate = Math.round(((size - (base + at)) * 8) / info.duration);
    } else {
      info.bitrate = bitrate;
      info.duration = ((size - (base + at)) * 8) / bitrate;
    }
    break;
  }
  return info;
}

/** Ogg：把開頭幾頁接成封包（識別標頭、註解標頭）。 @param {Uint8Array} b @param {number} max */
function oggPackets(b, max) {
  /** @type {Uint8Array[]} */
  const packets = [];
  /** @type {Uint8Array[]} */
  let parts = [];
  for (let at = 0; at + 27 <= b.length && packets.length < max; ) {
    if (ascii(b, at, 4) !== "OggS") break;
    const segments = b[at + 26];
    let data = at + 27 + segments;
    for (let i = 0; i < segments; i++) {
      const len = b[at + 27 + i];
      parts.push(b.subarray(data, data + len));
      data += len;
      if (len < 255) {
        const total = parts.reduce((n, p) => n + p.length, 0);
        const packet = new Uint8Array(total);
        let off = 0;
        for (const p of parts) {
          packet.set(p, off);
          off += p.length;
        }
        packets.push(packet);
        parts = [];
        if (packets.length >= max) break;
      }
    }
    at = data;
  }
  return packets;
}

/** @param {string} src @param {number} size @param {Uint8Array} head @returns {Promise<AudioInfo>} */
async function readOgg(src, size, head) {
  /** @type {AudioInfo} */
  const info = { codec: "Ogg" };
  const [id, comments] = oggPackets(head, 2);
  let preSkip = 0;
  let rate = 0;
  if (id && ascii(id, 1, 6) === "vorbis") {
    info.codec = "Vorbis";
    info.channels = id[11];
    rate = info.sampleRate = u32le(id, 12);
    if (comments && ascii(comments, 1, 6) === "vorbis") readVorbisComment(comments.subarray(7), info);
  } else if (id && ascii(id, 0, 8) === "OpusHead") {
    info.codec = "Opus";
    info.channels = id[9];
    preSkip = u16le(id, 10);
    info.sampleRate = u32le(id, 12) || 48000;
    rate = 48000; // Opus 的 granule 一律以 48 kHz 計
    if (comments && ascii(comments, 0, 8) === "OpusTags") readVorbisComment(comments.subarray(8), info);
  } else if (id && ascii(id, 0, 5) === "\x7fFLAC") {
    info.codec = "FLAC（Ogg）";
  }
  // 長度：最後一頁的 granule position。
  if (rate > 0) {
    const tailStart = Math.max(0, size - 64 * 1024);
    const tail = await readRange(src, tailStart, size);
    for (let at = tail.length - 27; at >= 0; at--) {
      if (tail[at] === 0x4f && ascii(tail, at, 4) === "OggS") {
        const granule = u64le(tail, at + 6);
        if (granule > 0) info.duration = Math.max(0, granule - preSkip) / rate;
        break;
      }
    }
  }
  return info;
}

/** M4A：最上層一個一個 box 走，moov 可能在 mdat 後面。 @param {string} src @param {number} size @param {Uint8Array} head @returns {Promise<AudioInfo>} */
async function readMp4(src, size, head) {
  /** @type {AudioInfo} */
  const info = { codec: "AAC" };
  /** @type {Uint8Array | null} */
  let moov = null;
  for (let at = 0, guard = 0; at + 8 <= size && guard < 64; guard++) {
    const header = at + 16 <= head.length ? head.subarray(at, at + 16) : await readRange(src, at, Math.min(size, at + 16));
    let length = u32be(header, 0);
    const type = ascii(header, 4, 4);
    let headerLength = 8;
    if (length === 1) {
      length = u64be(header, 8);
      headerLength = 16;
    } else if (length === 0) {
      length = size - at;
    }
    if (length < headerLength) break;
    if (type === "moov") {
      const end = Math.min(at + length, at + 32 * 1024 * 1024);
      moov = end <= head.length ? head.subarray(at + headerLength, end) : await readRange(src, at + headerLength, end);
      break;
    }
    at += length;
  }
  if (!moov) return info;
  /** @param {Uint8Array} b @param {(type: string, body: Uint8Array) => void} visit */
  const boxes = (b, visit) => {
    for (let at = 0; at + 8 <= b.length; ) {
      const length = u32be(b, at);
      if (length < 8 || at + length > b.length) break;
      visit(ascii(b, at + 4, 4), b.subarray(at + 8, at + length));
      at += length;
    }
  };
  /** @param {Uint8Array} b */
  const walk = (b) =>
    boxes(b, (type, body) => {
      if (type === "mvhd") {
        const v1 = body[0] === 1;
        const timescale = u32be(body, v1 ? 20 : 12);
        const duration = v1 ? u64be(body, 24) : u32be(body, 16);
        if (timescale > 0) info.duration = duration / timescale;
      } else if (type === "trak" || type === "mdia" || type === "minf" || type === "stbl" || type === "udta" || type === "ilst") {
        walk(body);
      } else if (type === "meta") {
        // ISO 的 meta 是 full box（前 4 個位元組是版本與旗標）；QuickTime 的不是。
        walk(ascii(body, 4, 4) === "hdlr" ? body : body.subarray(4));
      } else if (type === "stsd") {
        const entry = body.subarray(8);
        const format = ascii(entry, 4, 4);
        if (format === "mp4a" || format === "alac" || format === "Opus" || format === "fLaC" || format === "ac-3" || format === "ec-3") {
          info.codec = { mp4a: "AAC", alac: "ALAC", Opus: "Opus", fLaC: "FLAC", "ac-3": "AC-3", "ec-3": "E-AC-3" }[format] ?? format;
          info.channels = u16be(entry, 24);
          info.bitDepth = format === "alac" || format === "fLaC" ? u16be(entry, 26) : undefined;
          info.sampleRate = u32be(entry, 32) / 65536;
        }
      } else if (type === "\xa9nam" || type === "\xa9ART" || type === "\xa9cmt" || type === "desc") {
        boxes(body, (inner, data) => {
          if (inner !== "data") return;
          const value = new TextDecoder().decode(data.subarray(8));
          if (type === "\xa9nam") setText(info, "title", value);
          else if (type === "\xa9ART") setText(info, "artist", value);
          else if (type === "\xa9cmt") setText(info, "comment", value);
          else setText(info, "description", value);
        });
      }
    });
  walk(moov);
  return info;
}

/** App 還不知道大小時，問伺服器整個檔多大（0：不知道）。 @param {string} src */
async function probeSize(src) {
  const probe = await fetch(src, { headers: { Range: "bytes=0-0" } });
  const range = probe.headers.get("content-range");
  return range ? Number(range.split("/")[1]) || 0 : Number(probe.headers.get("content-length")) || 0;
}

/** @param {string} path @param {number} size @returns {Promise<AudioInfo>} */
async function readInfo(path, size) {
  const src = hoard.fileSrc(path);
  if (!size) size = await probeSize(src);
  const head = await readRange(src, 0, Math.min(size || HEAD_BYTES, HEAD_BYTES));
  const magic = ascii(head, 0, 4);
  if (magic === "RIFF" && ascii(head, 8, 4) === "WAVE") return readWav(src, size, head);
  if (magic === "FORM" && (ascii(head, 8, 4) === "AIFF" || ascii(head, 8, 4) === "AIFC")) return readAiff(src, size, head);
  if (magic === "fLaC") return readFlac(src, size, head);
  if (magic === "OggS") return readOgg(src, size, head);
  if (ascii(head, 4, 4) === "ftyp") return readMp4(src, size, head);
  if (ascii(head, 0, 3) === "ID3" || (head[0] === 0xff && (head[1] & 0xe0) === 0xe0 && (head[1] & 0x06) !== 0)) {
    // ADTS（.aac）的同步字也是 0xFFF，但 layer 欄位是 0。
    return readMp3(src, size, head);
  }
  if (head[0] === 0xff && (head[1] & 0xf6) === 0xf0) {
    const rates = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];
    return { codec: "AAC（ADTS）", sampleRate: rates[(head[2] >> 2) & 0x0f], channels: ((head[2] & 1) << 2) | (head[3] >> 6) };
  }
  return { codec: extOf(path).toUpperCase() };
}

/** 最近讀過的檔頭（最多 1000 個）。 @type {Map<string, Promise<AudioInfo>>} */
const infos = new Map();
/** @param {string} path @param {number} size */
function infoOf(path, size) {
  let pending = infos.get(path);
  if (pending) {
    infos.delete(path); // 移到最新
    infos.set(path, pending);
  } else {
    pending = readInfo(path, size).catch((err) => {
      console.warn("[audio] 讀不到檔頭：", path, err);
      return /** @type {AudioInfo} */ ({ codec: extOf(path).toUpperCase() });
    });
    infos.set(path, pending);
    if (infos.size > 1000) infos.delete(/** @type {string} */ (infos.keys().next().value));
  }
  return pending;
}

// ---- 波形 ----

/** 解碼很吃記憶體，一次只做一個。 */
let decoding = Promise.resolve();

/**
 * 每一段的最小、最大值（-1 到 1），[min0, max0, min1, max1, …]。所有聲道合在一起看。
 * @param {string} path @returns {Promise<Float32Array>}
 */
function decodePeaks(path) {
  const run = decoding.then(async () => {
    const bytes = await (await fetch(hoard.fileSrc(path))).arrayBuffer();
    const context = new OfflineAudioContext(1, 1, 44100);
    const audio = await context.decodeAudioData(bytes);
    const peaks = new Float32Array(BUCKETS * 2).fill(0);
    const per = audio.length / BUCKETS;
    for (let c = 0; c < audio.numberOfChannels; c++) {
      const data = audio.getChannelData(c);
      for (let b = 0; b < BUCKETS; b++) {
        const start = Math.floor(b * per);
        const end = Math.min(data.length, Math.floor((b + 1) * per));
        // 一段很長時跳著看，夠畫出形狀就好。
        const step = Math.max(1, Math.floor((end - start) / 2000));
        let min = peaks[b * 2];
        let max = peaks[b * 2 + 1];
        for (let i = start; i < end; i += step) {
          const v = data[i];
          if (v < min) min = v;
          if (v > max) max = v;
        }
        peaks[b * 2] = min;
        peaks[b * 2 + 1] = max;
      }
    }
    return peaks;
  });
  decoding = run.then(
    () => {},
    () => {},
  );
  return run;
}

/** 最近解碼過的波形（記憶體裡，最多 300 個）。 @type {Map<string, Promise<Float32Array | null>>} */
const peakCache = new Map();
/** @param {string} path @param {number} size @param {number} limit */
function peaksOf(path, size, limit) {
  if (size > limit) return Promise.resolve(null);
  let pending = peakCache.get(path);
  if (pending) {
    peakCache.delete(path);
  } else {
    pending = decodePeaks(path).catch((err) => {
      console.warn("[audio] 無法解碼：", path, err);
      return null;
    });
  }
  peakCache.set(path, pending);
  if (peakCache.size > 300) peakCache.delete(/** @type {string} */ (peakCache.keys().next().value));
  return pending;
}

/**
 * 畫波形：每 3 個像素一條，播過的部分用另一個顏色（CSS 變數 --au-wave、--au-wave-played）。
 * @param {HTMLCanvasElement} canvas @param {Float32Array | null} peaks @param {number} progress 0–1
 */
function drawWave(canvas, peaks, progress) {
  const ratio = window.devicePixelRatio || 1;
  const width = Math.max(1, Math.round(canvas.clientWidth * ratio));
  const height = Math.max(1, Math.round(canvas.clientHeight * ratio));
  if (canvas.width !== width) canvas.width = width;
  if (canvas.height !== height) canvas.height = height;
  const g = canvas.getContext("2d");
  if (!g) return;
  const style = getComputedStyle(canvas);
  const idle = style.getPropertyValue("--au-wave").trim() || "#8a8a8a";
  const played = style.getPropertyValue("--au-wave-played").trim() || "#ededed";
  g.clearRect(0, 0, width, height);
  const mid = height / 2;
  const bar = Math.max(1, Math.round(2 * ratio));
  const gap = Math.max(1, Math.round(ratio));
  const playedX = progress * width;
  for (let x = 0; x < width; x += bar + gap) {
    let min = 0;
    let max = 0;
    if (peaks) {
      const from = Math.floor((x / width) * BUCKETS);
      const to = Math.max(from + 1, Math.floor(((x + bar) / width) * BUCKETS));
      for (let b = from; b < to && b < BUCKETS; b++) {
        min = Math.min(min, peaks[b * 2]);
        max = Math.max(max, peaks[b * 2 + 1]);
      }
    }
    const top = mid - Math.max(max, 0.01) * mid * 0.95;
    const bottom = mid - Math.min(min, -0.01) * mid * 0.95;
    g.fillStyle = x < playedX ? played : idle;
    g.fillRect(x, top, bar, Math.max(gap, bottom - top));
  }
}

// ---- 播放器 ----

/** 正在播的聲音；新的開始播時讓它停下。 @type {HTMLAudioElement | null} */
let current = null;
/** 播放器關掉後留在背景播的聲音；同一個檔的播放器再打開時接回去。 @type {{ path: string; audio: HTMLAudioElement } | null} */
let background = null;

/** 停掉並放掉背景的聲音。 */
function stopBackground() {
  if (!background) return;
  const { audio } = background;
  background = null;
  releaseAudio(audio);
}
/** @param {HTMLAudioElement} audio */
function releaseAudio(audio) {
  audio.pause();
  audio.removeAttribute("src");
  audio.load();
  if (current === audio) current = null;
}
/** @param {HTMLAudioElement} audio */
function claim(audio) {
  if (current && current !== audio) {
    if (background?.audio === current) stopBackground();
    else current.pause();
  }
  current = audio;
}
// 背景的聲音沒有播放器，設定直接套上去；關掉背景播放就停。
settingListeners.add(() => {
  if (!background) return;
  if (!settings.background) return stopBackground();
  background.audio.loop = settings.loop;
  background.audio.volume = settings.volume;
});
hoard.onUnload(() => {
  stopBackground();
  current?.pause();
});

/** 0:03.25、1:05、1:02:03。 @param {number} seconds @param {number} [total] */
function formatTime(seconds, total = seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return "—";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  const ss = total < 10 ? s.toFixed(2).padStart(5, "0") : total < 60 ? s.toFixed(1).padStart(4, "0") : String(Math.floor(s)).padStart(2, "0");
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${ss}` : `${m}:${ss}`;
}

/** @param {number} rate */
const formatRate = (rate) => `${Number((rate / 1000).toFixed(rate % 1000 === 0 ? 0 : 1))} kHz`;
/** @param {number} n */
const formatChannels = (n) => (n === 1 ? "單聲道" : n === 2 ? "立體聲" : `${n} 聲道`);

/** 長度 · 48 kHz · 24-bit · 立體聲 @param {AudioInfo} info */
function summaryLine(info) {
  return [
    info.duration !== undefined ? formatTime(info.duration) : null,
    info.sampleRate ? formatRate(info.sampleRate) : null,
    info.bitDepth ? `${info.bitDepth}-bit` : null,
    info.channels ? formatChannels(info.channels) : null,
    info.codec,
  ]
    .filter(Boolean)
    .join(" · ");
}

/**
 * 一個播放器：播放鍵、可以點的波形、時間；`full` 時多循環與音量。
 * 回傳的 destroy 會停止播放並放掉音訊（`keep` 或開了背景播放時，正在播的留在背景，
 * 同一個檔的播放器再出現時接回去）；toggle 播放／暫停。
 * @param {{ path: string; size: number; ext: string; full: boolean; autoplay: boolean; decodeLimit: number }} opts
 */
function createPlayer(opts) {
  const playable = !UNPLAYABLE.has(opts.ext);
  const canvas = /** @type {HTMLCanvasElement} */ (hoard.el("canvas", { class: "au-wave-canvas" }));
  /** @type {Float32Array | null} */
  let peaks = null;
  let duration = NaN;
  /** @type {HTMLAudioElement | null} */
  let audio = null;

  const time = hoard.el("span", { class: "au-time" }, ["—"]);
  const playButton = hoard.el("button", { class: "au-play", title: "播放／暫停" });
  const waveButton = hoard.el("button", { class: "au-wave", title: playable ? "點一下跳到這裡" : "" }, [canvas]);
  const loopButton = hoard.el("button", { class: "au-icon-button", title: "循環播放" });
  const volume = /** @type {HTMLInputElement} */ (
    hoard.el("input", { class: "au-volume", type: "range", min: "0", max: "1", step: "0.05", title: "音量" })
  );

  const progress = () => (audio && duration > 0 ? audio.currentTime / duration : 0);
  const redraw = () => drawWave(canvas, peaks, progress());
  const showTime = () => {
    time.textContent = `${formatTime(audio?.currentTime ?? 0, duration)} / ${formatTime(duration)}`;
  };
  const showState = () => {
    const playing = Boolean(audio && !audio.paused);
    playButton.replaceChildren(hoard.icon(playing ? "pause" : "play", { size: opts.full ? 18 : 14 }));
    loopButton.replaceChildren(hoard.icon(settings.loop ? "repeat-1" : "repeat", { size: 14 }));
    loopButton.classList.toggle("au-on", settings.loop);
    volume.value = String(settings.volume);
  };
  const applySettings = () => {
    if (audio) {
      audio.loop = settings.loop;
      audio.volume = settings.volume;
    }
    showState();
  };

  /** 播放器關掉時拿掉 <audio> 上的監聽（聲音可能留在背景播）。 */
  const listening = new AbortController();
  let frame = 0;
  /** 第一次播放時才建立 <audio>：「音訊」頁面一次有很多列。背景有同一個檔在播就接過來。 */
  const ensureAudio = () => {
    if (audio || !playable) return audio;
    if (background?.path === opts.path) {
      audio = background.audio;
      background = null;
    } else {
      audio = new Audio(hoard.fileSrc(opts.path));
      audio.preload = "auto";
    }
    applySettings();
    const { signal } = listening;
    const tick = () => {
      redraw();
      showTime();
      frame = audio && !audio.paused ? requestAnimationFrame(tick) : 0;
    };
    audio.addEventListener(
      "loadedmetadata",
      () => {
        if (!(duration > 0) && audio) duration = audio.duration;
        showTime();
      },
      { signal },
    );
    audio.addEventListener(
      "play",
      () => {
        if (audio) claim(audio);
        showState();
        if (!frame) frame = requestAnimationFrame(tick);
      },
      { signal },
    );
    audio.addEventListener(
      "pause",
      () => {
        showState();
        redraw();
      },
      { signal },
    );
    audio.addEventListener(
      "ended",
      () => {
        // 播完回到開頭，下一次按播放從頭開始。
        if (audio) audio.currentTime = 0;
        showState();
        redraw();
        showTime();
      },
      { signal },
    );
    if (audio.readyState >= 1 && !(duration > 0)) duration = audio.duration;
    if (!audio.paused) frame = requestAnimationFrame(tick);
    return audio;
  };

  const toggle = () => {
    const a = ensureAudio();
    if (!a) return;
    if (a.paused) void a.play().catch((err) => hoard.toast(`無法播放：${err.message ?? err}`, { kind: "error" }));
    else a.pause();
  };

  playButton.addEventListener("click", (e) => {
    e.stopPropagation();
    toggle();
  });
  waveButton.addEventListener("click", (e) => {
    e.stopPropagation();
    if (!playable) return;
    const a = ensureAudio();
    if (!a) return;
    const rect = canvas.getBoundingClientRect();
    const at = Math.min(1, Math.max(0, (/** @type {MouseEvent} */ (e).clientX - rect.left) / rect.width));
    const seek = () => {
      a.currentTime = at * (duration || a.duration || 0);
      if (a.paused) void a.play().catch(() => {});
      redraw();
      showTime();
    };
    if (a.readyState >= 1) seek();
    else a.addEventListener("loadedmetadata", seek, { once: true });
  });
  loopButton.addEventListener("click", (e) => {
    e.stopPropagation();
    updateSettings({ loop: !settings.loop });
  });
  volume.addEventListener("input", () => updateSettings({ volume: Number(volume.value) }));
  volume.addEventListener("click", (e) => e.stopPropagation());
  settingListeners.add(applySettings);

  const resize = new ResizeObserver(redraw);
  resize.observe(canvas);
  showState();

  /** @type {Node[]} */
  const controls = [playButton, time];
  if (opts.full) controls.push(hoard.el("span", { class: "au-spacer" }), loopButton, hoard.icon("volume-2", { size: 14, class: "au-muted" }), volume);
  const el = hoard.el("div", { class: opts.full ? "au-player au-player-full" : "au-player" }, [
    waveButton,
    hoard.el("div", { class: "au-controls" }, controls),
  ]);
  if (!playable) {
    playButton.setAttribute("disabled", "");
    el.append(
      hoard.el("p", { class: "au-note" }, [
        opts.full ? "這個格式無法在 App 內播放，請用右鍵選單的「用預設程式開啟」。" : "無法在 App 內播放",
      ]),
    );
  }

  let alive = true;
  /** 讀波形與長度；「音訊」頁面等到這一列看得到時才呼叫。 */
  const load = () => {
    void infoOf(opts.path, opts.size).then((info) => {
      if (!alive) return;
      if (info.duration !== undefined && !(duration > 0)) duration = info.duration;
      showTime();
    });
    void peaksOf(opts.path, opts.size, opts.decodeLimit).then((value) => {
      if (!alive) return;
      peaks = value;
      el.classList.toggle("au-no-wave", !value);
      redraw();
    });
  };

  // 背景正在播這個檔：直接接回來，播放器顯示目前的進度。
  if (background?.path === opts.path) ensureAudio();
  if (opts.autoplay && playable) {
    const a = ensureAudio();
    void a?.play().catch(() => {});
  }

  return {
    el,
    load,
    toggle,
    playing: () => Boolean(audio && !audio.paused),
    /** @param {boolean} [keep] */
    destroy(keep = false) {
      alive = false;
      resize.disconnect();
      settingListeners.delete(applySettings);
      listening.abort();
      cancelAnimationFrame(frame);
      if (!audio) return;
      if ((keep || settings.background) && !audio.paused) {
        // 留在背景繼續播；播完（沒循環）就放掉。
        stopBackground();
        const kept = audio;
        background = { path: opts.path, audio: kept };
        kept.addEventListener("ended", () => background?.audio === kept && stopBackground(), { once: true });
      } else releaseAudio(audio);
    },
  };
}

// ---- 快速預覽 ----

/** @param {HTMLElement} root @param {HoardItemSummary} item @param {HoardQuickLookCtx} ctx */
function renderQuickLook(root, item, ctx) {
  let alive = true;
  /** @type {ReturnType<typeof createPlayer> | null} */
  let player = null;
  const name = typeof item.metadata.original_name === "string" ? item.metadata.original_name : item.title;
  const line = hoard.el("p", { class: "au-ql-line" });
  const stage = hoard.el("div", { class: "au-ql-stage" }, [hoard.el("p", { class: "au-ql-name" }, [name])]);
  const box = hoard.el(
    "div",
    {
      class: "au-ql",
      onclick: (event) => {
        if (event.target === box || event.target === stage) ctx.close();
      },
    },
    [stage],
  );
  root.append(box);
  ctx.onKey((event) => {
    if (event.ctrlKey || event.altKey || event.metaKey) return false;
    const key = event.key.toLowerCase();
    if (key === "p") player?.toggle();
    else if (key === "l") updateSettings({ loop: !settings.loop });
    else return false;
    return true;
  });

  void (async () => {
    await settingsLoaded;
    const detail = await detailOf(item.id);
    const file = audioFileOf(detail);
    if (!alive || !file) return;
    const size = file.size ?? 0;
    player = createPlayer({ path: file.path, size, ext: extOf(file.path), full: true, autoplay: settings.autoplay, decodeLimit: MAX_DECODE });
    player.load();
    stage.append(player.el, line, hoard.el("p", { class: "au-ql-hint" }, ["P 播放／暫停 · L 循環 · 點波形跳到那裡"]));
    const info = await infoOf(file.path, size);
    if (alive) line.textContent = summaryLine(info);
  })().catch((err) => console.warn("[audio] 快速預覽失敗：", err));

  return () => {
    alive = false;
    player?.destroy();
  };
}


// ---- 詳情頁 ----

/** @param {number} bytes */
function formatSize(bytes) {
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit++;
  }
  return `${unit === 0 ? value : value.toFixed(1)} ${units[unit]}`;
}

/** @param {Array<[string, string]>} rows */
function table(rows) {
  return hoard.el(
    "dl",
    { class: "au-table" },
    rows.flatMap(([label, value]) => [hoard.el("dt", {}, [label]), hoard.el("dd", {}, [value])]),
  );
}

/** @param {string} title @param {Node[]} children */
function section(title, children) {
  return hoard.el("section", { class: "au-section" }, [hoard.el("h3", { class: "au-heading" }, [title]), ...children]);
}

// 動畫（App 的 docs/conventions.md〈動畫〉：插件拿不到 App 的動畫程式，照同一組時長、曲線自己做）

/** 系統要求減少動態時不做動畫，直接換成結果。 */
const motionOn = () => typeof Element.prototype.animate === "function" && !matchMedia("(prefers-reduced-motion: reduce)").matches;
/** 進場、變大。 */
const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";
/** 離場。 */
const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

/**
 * 晚到的區塊換成內容：box 裡原本的骨架（.au-skeleton：等 200ms 才淡入，很快就到的看不到它）淡出、內容淡入
 * （骨架出現過時 160ms 交叉，沒出現過時內容直接淡入 120ms），高度從原本補間到內容的實際高度 200ms，下面的東西跟著滑，不是跳。
 * 沒有骨架的 box 就是從 0 長出來。
 * @param {HTMLElement} box @param {Node[]} content @param {number} since 開始等的時間（performance.now()）
 */
function settleLate(box, content, since) {
  if (!motionOn()) return void box.replaceChildren(...content);
  const seen = performance.now() - since >= 200;
  const skeleton = /** @type {HTMLElement[]} */ ([...box.children]);
  const from = box.getBoundingClientRect().height;
  for (const a of box.getAnimations()) a.cancel();
  // 骨架停在現在的樣子（搬進疊層時 CSS 動畫會重來），再疊到內容上面淡出。
  for (const el of skeleton) {
    el.style.opacity = getComputedStyle(el).opacity;
    el.style.animation = "none";
  }
  box.replaceChildren(...content);
  const to = box.getBoundingClientRect().height;
  if (Math.abs(to - from) > 0.5) {
    box.style.overflow = "clip";
    void box.animate([{ height: `${from}px` }, { height: `${to}px` }], { duration: 200, easing: EASE_OUT }).finished.then(
      () => (box.style.overflow = ""),
      () => {},
    );
  }
  for (const el of box.children) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: seen && skeleton.length > 0 ? 160 : 120, easing: EASE_OUT, fill: "backwards" });
  if (!seen || skeleton.length === 0) return;
  const ghost = hoard.el("div", { class: "au-late-ghost", "aria-hidden": "true" }, skeleton);
  box.prepend(ghost);
  void ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 160, easing: EASE_IN, fill: "forwards" }).finished.then(
    () => ghost.remove(),
    () => ghost.remove(),
  );
}

/** @param {HTMLElement} root @param {HoardItemDetail} item */
function renderDetail(root, item) {
  let alive = true;
  const file = audioFileOf(item);
  if (!file) return;
  const meta = item.metadata;
  const size = file.size ?? 0;
  const ext = extOf(file.path);
  const player = createPlayer({ path: file.path, size, ext, full: true, autoplay: false, decodeLimit: MAX_DECODE });
  player.load();

  // 「音訊」要讀檔頭才知道：先放表格形狀的骨架佔位置；「檔案內嵌的資訊」有才從 0 長出來。
  const since = performance.now();
  const audioInfo = hoard.el("div", { class: "au-late" }, [
    hoard.el("div", { class: "au-skeleton au-info-bones", role: "status", "aria-label": "讀取中" }, [
      hoard.el("span", { class: "au-info-bones-title" }),
      hoard.el("div", { class: "au-info-bones-table" }, Array.from({ length: 4 }, () => hoard.el("span"))),
    ]),
  ]);
  const embedded = hoard.el("div", { class: "au-late" });
  /** @type {Array<[string, string]>} */
  const fileRows = [];
  if (typeof meta.original_name === "string") fileRows.push(["檔名", meta.original_name]);
  if (size) fileRows.push(["大小", formatSize(size)]);
  fileRows.push(["加入時間", hoard.formatDate(item.added_at)]);
  if (file.original_path) fileRows.push(["原始位置", file.original_path]);
  fileRows.push(["存放", file.in_place ? "原地引用（檔案留在連結的資料夾裡）" : "在 vault 裡"]);

  root.append(
    hoard.el("div", { class: "au-page" }, [
      player.el,
      audioInfo,
      embedded,
      section("檔案", [table(fileRows), hoard.el("p", { class: "au-note" }, ["右鍵選單可以用預設程式開啟，或在檔案總管顯示。"])]),
    ]),
  );

  void infoOf(file.path, size).then((info) => {
    if (!alive) return;
    /** @type {Array<[string, string]>} */
    const rows = [["格式", `${ext.toUpperCase()}（${info.codec}）`]];
    if (info.duration !== undefined) rows.push(["長度", formatTime(info.duration)]);
    if (info.sampleRate) rows.push(["取樣率", `${info.sampleRate.toLocaleString()} Hz`]);
    if (info.bitDepth) rows.push(["位元深度", `${info.bitDepth}-bit`]);
    if (info.channels) rows.push(["聲道", formatChannels(info.channels)]);
    if (info.bitrate) rows.push(["位元率", `${Math.round(info.bitrate / 1000)} kbps`]);
    settleLate(audioInfo, [section("音訊", [table(rows)])], since);

    /** @type {Array<[string, string]>} */
    const tags = [];
    if (info.title) tags.push(["標題", info.title]);
    if (info.artist) tags.push(["演出者", info.artist]);
    /** @type {Node[]} */
    const body = tags.length > 0 ? [table(tags)] : [];
    for (const [label, value] of /** @type {Array<[string, string | undefined]>} */ ([
      ["描述", info.description],
      ["註解", info.comment],
    ])) {
      if (value) body.push(hoard.el("div", { class: "au-block" }, [hoard.el("span", { class: "au-label" }, [label]), hoard.el("p", { class: "au-text" }, [value])]));
    }
    if (body.length > 0) settleLate(embedded, [section("檔案內嵌的資訊", body)], since);
  }, () => {
    // 讀不到檔頭：骨架收起來。
    if (alive) settleLate(audioInfo, [], since);
  });

  return () => {
    alive = false;
    player.destroy();
  };
}

// 本機單一的音訊檔：快速預覽按空白鍵就播，詳情頁整頁畫播放器與資訊。
hoard.registerPresenter({
  sources: ["local"],
  accepts: (item) => item.file_count === 1 && isAudioItem(item),
  detail: renderDetail,
  quickLook: renderQuickLook,
});

// ---- 側欄的「音訊」頁面 ----

/**
 * 一列一件的清單（ctx.virtualList：只建出畫面上看得到的那幾列）：播放鍵、時間與波形，列畫出來時才讀波形與長度。
 * 畫的是 `items` 這個陣列：讀到下一頁就加進去再呼叫 `grew`（畫好的列不重畫）；`replace` 換成另一個陣列，畫面上的列重畫、
 * 捲動位置不變。列捲出畫面時拆掉它的播放器，正在播的留在背景，捲回來時接回去。
 * `destroy` 停掉所有播放器，`keep` 時正在播的留在背景，重讀後同一件的列出現時接回去。
 * @param {HTMLElement} container @param {HoardViewCtx} ctx @param {HoardItemSummary[]} first
 * @param {() => void} nearEnd 畫到快到底時呼叫
 */
function createSoundList(container, ctx, first, nearEnd) {
  let items = first;
  /** 畫面上那幾列的播放器，依作品 id。 @type {Map<number, ReturnType<typeof createPlayer>>} */
  const players = new Map();
  /** 建過播放器的作品的檔案：捲走之後還在背景播的認得出來。 @type {Map<number, string>} */
  const paths = new Map();
  const rem = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;

  const list = ctx.virtualList(container, {
    count: items.length,
    // .au-row 的最低高度加底線。
    estimateSize: () => Math.round(3.5 * rem) + 1,
    renderRow(row, index) {
      if (index >= items.length - VIEW_AHEAD) nearEnd();
      const item = items[index];
      const name = typeof item.metadata.original_name === "string" ? item.metadata.original_name : "";
      const titleBlock = hoard.el("div", { class: "au-row-title" }, [
        hoard.el("span", { class: "au-row-name" }, [item.title]),
        name ? hoard.el("span", { class: "au-row-file" }, [name]) : null,
      ]);
      const slot = hoard.el("div", { class: "au-row-player" });
      const el = hoard.el("div", { class: "au-row", role: "button", tabindex: "0" }, [titleBlock, slot]);
      ctx.bindItem(el, item);
      row.append(el);
      let alive = true;
      /** @type {ReturnType<typeof createPlayer> | null} */
      let player = null;
      void detailOf(item.id).then((detail) => {
        const file = audioFileOf(detail);
        if (!file || !alive) return;
        const size = file.size ?? 0;
        player = createPlayer({ path: file.path, size, ext: extOf(file.path), full: false, autoplay: false, decodeLimit: LIST_MAX_DECODE });
        player.load();
        slot.replaceChildren(player.el);
        players.set(item.id, player);
        paths.set(item.id, file.path);
      });
      return () => {
        alive = false;
        // 捲出畫面：正在播的留在背景繼續播。整份清單拆掉時 destroy 已經處理過了。
        if (player && players.get(item.id) === player) {
          players.delete(item.id);
          player.destroy(true);
        }
      };
    },
  });

  /** 拆掉所有播放器。 @param {boolean} keep 正在播的留在背景 */
  const release = (keep) => {
    players.forEach((player) => player.destroy(keep));
    players.clear();
    // 捲走後留在背景播的是這份清單的：一樣照 keep 與「背景播放」設定。
    if (!keep && !settings.background && background && [...paths.values()].includes(background.path)) stopBackground();
  };

  return {
    /** `items` 加了幾件在後面。 */
    grew: () => list.setCount(items.length),
    /**
     * 換成重讀的這份（收藏在背景變了）：畫面上的列重畫，捲動位置不變，正在播的照樣播。
     * @param {HoardItemSummary[]} next @param {boolean} stop 正在播的那件被移走了：停掉
     */
    replace(next, stop) {
      if (stop) release(false);
      items = next;
      list.redraw(items.length);
    },
    /** 這些作品裡有沒有正在播的（含捲走後留在背景播的）。 @param {number[]} ids */
    playingIn: (ids) => ids.some((id) => players.get(id)?.playing() || (background !== null && background.path === paths.get(id))),
    /** @param {boolean} [keep] */
    destroy(keep = false) {
      release(keep);
      list();
    },
  };
}

/** 一次向 App 要幾件（其他檔案裡挑出音訊）。 */
const VIEW_PAGE = 200;
/** 畫到離最後一列這麼近時讀下一頁。 */
const VIEW_AHEAD = 20;
/**
 * 換了清單（搜尋）時，舊的列留著等新的；超過這麼久還沒讀好才換成佔位，上面打的和下面的列才不會對不上太久
 * （docs/conventions.md〈回饋〉，跟 App 的收藏庫一樣）。
 */
const STALE_MS = 300;

/**
 * 讀好之前的佔位：列的形狀。
 * @param {boolean} now 已經等過了（換清單等超過 STALE_MS）就馬上淡入；否則自己等 200ms，很快讀完的什麼都不閃
 */
function soundSkeleton(now) {
  return hoard.el(
    "div",
    { class: now ? "au-list au-skeleton au-now" : "au-list au-skeleton", role: "status", "aria-label": "讀取中" },
    Array.from({ length: 8 }, () => hoard.el("div", { class: "au-bone" }, [hoard.el("span", { class: "au-bone-name" }), hoard.el("span", { class: "au-bone-wave" })])),
  );
}

/**
 * 音訊頁的一份清單：照哪個搜尋讀、讀到哪。
 * @typedef {{ filter: HoardItemFilter; narrowed: boolean; items: HoardItemSummary[]; offset: number; done: boolean; loading: boolean; wanted: number; error: string | null }} SoundListState
 */

hoard.registerView({
  id: "sounds",
  label: "音訊",
  icon: "audio-lines",
  render(el, ctx) {
    let search = "";
    /** 照現在的搜尋，一份還沒讀的清單。 @returns {SoundListState} */
    const soundList = () => ({
      filter: { source_type: "local", exts: [...AUDIO_EXTENSIONS], search: search || undefined },
      narrowed: Boolean(search),
      items: [],
      offset: 0,
      done: false,
      loading: false,
      /** 想要的列數：至少讀到這麼多才停（畫到快到底時加）。 */
      wanted: VIEW_AHEAD * 2,
      error: null,
    });
    /** 畫面上的清單。 */
    let shown = soundList();
    /** 換了搜尋：正在讀、讀好就換上的那份。 @type {SoundListState | null} */
    let next = null;
    /** 畫面上的列；換成佔位時是 null。 @type {ReturnType<typeof createSoundList> | null} */
    let sounds = null;
    /** @type {HTMLElement | null} */
    let skeleton = null;
    /** 正在播的那件被移走了：下一次拆掉或換掉清單時停掉，不留在背景播。 */
    let stopPlaying = false;

    const input = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "search", placeholder: "搜尋標題、檔名…" }));
    const listEl = hoard.el("div", { class: "au-list" });
    const note = hoard.el("div", { class: "hoard-empty" });
    note.hidden = true;
    // 名稱與件數由 App 的頁首顯示；搜尋放在頁首右側。
    ctx.header.actions.append(hoard.el("label", { class: "hoard-search" }, [hoard.icon("search", { size: 13 }), input]));
    el.append(hoard.el("div", { class: "au-view" }, [hoard.el("div", { class: "au-view-body" }, [listEl, note])]));

    const takeStop = () => {
      const stop = stopPlaying;
      stopPlaying = false;
      return stop;
    };

    /** 讀下一頁加進這份清單（「其他檔案」裡挑出音訊）。 @param {SoundListState} wall */
    const readPage = async (wall) => {
      const page = await ctx.listItems(wall.filter, { offset: wall.offset, limit: VIEW_PAGE });
      wall.offset += page.items.length;
      wall.done = page.items.length === 0 || wall.offset >= page.total;
      wall.items.push(...page.items.filter(isAudioItem));
    };

    /** 件數，以及空的、讀取失敗時的說明。enter：同一份清單剛剛還有東西（最後一件被拿掉），空狀態慢一拍淡入。 @param {boolean} [enter] */
    const showStatus = (enter = false) => {
      const { items, done, error, narrowed } = shown;
      ctx.header.setCount(items.length, { more: !done });
      const text = error
        ? `讀取失敗：${error}`
        : done && items.length === 0
          ? narrowed
            ? "沒有符合條件的音訊"
            : "還沒有音訊"
          : "";
      if (note.hidden && text) note.toggleAttribute("data-enter", enter);
      note.textContent = text;
      note.hidden = !text;
    };

    /** 畫到快到底：再讀幾頁加在後面（畫好的列不重畫）。用副檔名直接查；同一件作品裡還有別的檔案時照樣略過，所以讀到夠了為止。 */
    const loadMore = async () => {
      const wall = shown;
      if (wall.loading || wall.done) return;
      wall.loading = true;
      try {
        while (wall === shown && !wall.done && wall.items.length < wall.wanted) {
          await readPage(wall);
          if (wall === shown) sounds?.grew();
        }
      } catch (err) {
        wall.error = String(err);
        wall.done = true;
      } finally {
        wall.loading = false;
        if (wall === shown) showStatus();
      }
    };
    const nearEnd = () => {
      shown.wanted = shown.items.length + VIEW_AHEAD * 2;
      void loadMore();
    };

    /** 列拿掉（正在播的留在背景），換成佔位。 @param {boolean} now */
    const showSkeleton = (now) => {
      sounds?.destroy(!takeStop());
      sounds = null;
      note.hidden = true;
      skeleton?.remove();
      skeleton = soundSkeleton(now);
      listEl.before(skeleton);
    };

    /**
     * 從頭讀。換了搜尋：新的一份讀好之前，畫面上的列留著，讀好才一次換上、從頂端開始；超過 STALE_MS 還沒好才換成佔位。
     * 第一次打開直接放佔位（它自己等 200ms 才淡入）。正在播的音不會因為重讀而停（留在背景，那一列再出現時接回去），
     * 被移到垃圾桶的才停（stopPlaying）。
     * keep：收藏在背景變了（匯入、移到垃圾桶），還是同一份清單：讀到跟現在一樣多件，原地重畫，捲動位置不變；讀不到就留著現在的。
     * @param {boolean} [keep]
     */
    const reload = async (keep = false) => {
      // 正在換清單（或還沒有列）時，背景的變動也當成換清單：一樣照現在的搜尋讀。
      keep &&= sounds !== null && next === null;
      const wall = soundList();
      next = wall;
      /** @type {ReturnType<typeof setTimeout> | undefined} */
      let slow;
      if (!keep) {
        if (sounds) slow = setTimeout(() => next === wall && showSkeleton(true), STALE_MS);
        else if (!skeleton) showSkeleton(false);
      }
      const want = keep ? shown.items.length : wall.wanted;
      try {
        do {
          await readPage(wall);
        } while (next === wall && !wall.done && wall.items.length < want);
      } catch (err) {
        if (keep) {
          if (next === wall) next = null;
          console.warn("[audio] 重讀失敗：", err);
          return;
        }
        wall.error = String(err);
        wall.done = true;
      } finally {
        clearTimeout(slow);
      }
      if (next !== wall) return;
      next = null;
      skeleton?.remove();
      skeleton = null;
      shown = wall;
      if (keep && sounds) {
        sounds.replace(wall.items, takeStop());
      } else {
        // 舊的列拿掉後頁面只剩頁首，捲動位置跟著回到頂端，新的從那裡畫起。
        sounds?.destroy(!takeStop());
        sounds = createSoundList(listEl, ctx, wall.items, nearEnd);
      }
      showStatus(keep && want > 0);
    };

    /** @type {number | undefined} */
    let typing;
    input.addEventListener("input", () => {
      clearTimeout(typing);
      typing = window.setTimeout(() => {
        search = input.value.trim();
        void reload();
      }, 250);
    });

    // 收藏有變動時（匯入、移到垃圾桶…）稍等一下再重讀，一批匯入只重讀一次。
    /** @type {number | undefined} */
    let settle;
    const later = () => {
      clearTimeout(settle);
      settle = window.setTimeout(() => void reload(true), 600);
    };
    const offs = [
      hoard.on("items-added", later),
      hoard.on("items-removed", ({ ids }) => {
        // 正在播的那件被移走了：重讀時停掉它。
        if (sounds?.playingIn(ids)) stopPlaying = true;
        later();
      }),
    ];

    void reload();
    return () => {
      next = null;
      clearTimeout(typing);
      clearTimeout(settle);
      offs.forEach((off) => off());
      sounds?.destroy();
    };
  },
});

// ---- 卡片的波形封面 ----

/** 封面的樣子（尺寸、畫法）改了就加一，所有作品重做。 */
const COVER_VERSION = 1;
/**
 * 方形、透明底。網格卡片是 3:4、裁切置中，只看得到中間 3/4 寬，所以波形畫在中間 0.65 寬：
 * 裁掉的左右兩邊是空白，卡片裡左右還留一點邊。
 */
const COVER_SIZE = 600;
const COVER_WAVE_WIDTH = 0.65;
/** 中性灰：深色、淺色主題的卡片底上都看得清楚。 */
const COVER_COLOR = "#8a8a8a";

/** 波形畫成 PNG。 @param {Float32Array} peaks @returns {Promise<Blob>} */
function coverImage(peaks) {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = COVER_SIZE;
  const g = canvas.getContext("2d");
  if (!g) return Promise.reject(new Error("無法建立 canvas"));
  // 小聲的檔案也看得出形狀：放大到最大值頂到上下緣，但最多 8 倍，幾乎無聲的不要放大成一片雜訊。
  let peak = 0;
  for (const v of peaks) peak = Math.max(peak, Math.abs(v));
  const gain = peak > 0 ? Math.min(8, 1 / peak) : 1;
  const bar = 6;
  const gap = 3;
  const count = Math.floor((COVER_SIZE * COVER_WAVE_WIDTH + gap) / (bar + gap));
  const left = Math.round((COVER_SIZE - (count * (bar + gap) - gap)) / 2);
  const mid = COVER_SIZE / 2;
  const half = COVER_SIZE * 0.22;
  g.fillStyle = COVER_COLOR;
  for (let i = 0; i < count; i++) {
    const from = Math.floor((i / count) * BUCKETS);
    const to = Math.max(from + 1, Math.floor(((i + 1) / count) * BUCKETS));
    let min = 0;
    let max = 0;
    for (let b = from; b < to; b++) {
      min = Math.min(min, peaks[b * 2]);
      max = Math.max(max, peaks[b * 2 + 1]);
    }
    const top = Math.round(mid - Math.max(max * gain, 0.02) * half);
    const bottom = Math.round(mid - Math.min(min * gain, -0.02) * half);
    g.fillRect(left + i * (bar + gap), top, bar, bottom - top);
  }
  return new Promise((resolve, reject) =>
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("無法輸出 PNG"))), "image/png"),
  );
}

/**
 * 做過的作品：id → [封面版本, 音訊檔的 modified_at]。解不開、太大而沒有封面的也記，
 * 檔案改過或版本提高時才再試。
 * @type {Record<string, [number, string | null]>}
 */
let covered = {};
const coveredLoaded = hoard.storage.get("covers").then((saved) => {
  if (saved && typeof saved === "object") covered = /** @type {typeof covered} */ (saved);
});
/** 一次補很多件時不要每件都寫一次 storage。 */
let saveTimer = 0;
function saveCovered() {
  if (saveTimer) return;
  saveTimer = window.setTimeout(() => {
    saveTimer = 0;
    void hoard.storage.set("covers", covered);
  }, 2000);
}

/** 等著做封面的作品，先進先做。 @type {Set<number>} */
const coverQueue = new Set();
/** 這次載入後排進來過的作品（清掉已經不在收藏庫的紀錄時用）。 @type {Set<string>} */
const queuedOnce = new Set();
let coverRunning = false;
let unloaded = false;
hoard.onUnload(() => {
  unloaded = true;
  if (saveTimer) {
    clearTimeout(saveTimer);
    void hoard.storage.set("covers", covered);
  }
});

/** 讓出主執行緒：等瀏覽器有空（最多等 1 秒）。 */
const idle = () => new Promise((resolve) => requestIdleCallback(() => resolve(undefined), { timeout: 1000 }));

/** @param {number[]} ids */
function queueCovers(ids) {
  for (const id of ids) {
    coverQueue.add(id);
    queuedOnce.add(String(id));
  }
  if (!coverRunning) void runCovers();
}

/** 一次只做一件（解碼一次只解一個檔），件與件之間讓出主執行緒。 */
async function runCovers() {
  coverRunning = true;
  try {
    await coveredLoaded;
    while (!unloaded && coverQueue.size > 0) {
      const id = /** @type {number} */ (coverQueue.values().next().value);
      coverQueue.delete(id);
      await idle();
      await makeCover(id).catch((err) => console.warn("[audio] 做不出波形封面：", id, err));
    }
  } finally {
    coverRunning = false;
  }
}

/** @param {number} id */
async function makeCover(id) {
  const item = await hoard.items.get(id);
  const file = item.source_type === "local" ? audioFileOf(item) : null;
  // 找不到的檔案（外接硬碟沒接上）先跳過，下次載入再試。
  if (!file || file.missing) return;
  const key = String(id);
  const done = covered[key];
  if (done && done[0] === COVER_VERSION && done[1] === file.modified_at) return;
  const size = file.size || (await probeSize(hoard.fileSrc(file.path)));
  if (!size) return;
  // WebView 解不開的格式（AIFF）、超過 64 MB 的檔案沒有封面：背景一件一件解，沒有人在看，不冒撐爆記憶體的險。
  const peaks = UNPLAYABLE.has(extOf(file.path)) ? null : await peaksOf(file.path, size, LIST_MAX_DECODE);
  if (unloaded) return;
  if (peaks) await hoard.items.setCover(id, { image: await coverImage(peaks), format: true });
  covered[key] = [COVER_VERSION, file.modified_at];
  saveCovered();
}

/** 音訊副檔名的作品，一頁一頁讀。 @param {HoardItemFilter} filter @param {(ids: number[]) => void} onPage */
async function listAudio(filter, onPage) {
  for (let offset = 0; !unloaded; ) {
    const page = await hoard.items.list({ ...filter, source_type: "local", exts: [...AUDIO_EXTENSIONS] }, { offset, limit: 200 });
    offset += page.items.length;
    onPage(page.items.filter(isAudioItem).map((item) => item.id));
    if (page.items.length === 0 || offset >= page.total) return true;
    await idle();
  }
  return false;
}

// 新作品進來就做。
hoard.on("items-added", ({ ids }) => {
  void (async () => {
    for (let at = 0; at < ids.length && !unloaded; at += 200) {
      await listAudio({ ids: ids.slice(at, at + 200) }, queueCovers);
    }
  })().catch((err) => console.warn("[audio] 讀不到新作品：", err));
});

// 載入時補舊作品；讀完整個收藏庫後，清掉已經不在收藏庫裡（垃圾桶、永久刪除）的紀錄。
void (async () => {
  await coveredLoaded;
  await idle();
  if (!(await listAudio({}, queueCovers))) return;
  const stale = Object.keys(covered).filter((key) => !queuedOnce.has(key));
  if (stale.length === 0) return;
  stale.forEach((key) => delete covered[key]);
  saveCovered();
})().catch((err) => console.warn("[audio] 補波形封面失敗：", err));

// ---- 設定 ----

hoard.registerSettingTab({
  label: "播放",
  render(root) {
    /** @param {string} label @param {HTMLElement} control @param {string} [hint] */
    const field = (label, control, hint) =>
      hoard.el("label", { class: "au-field" }, [
        control,
        hoard.el("span", { class: "au-field-text" }, [
          hoard.el("span", {}, [label]),
          hint ? hoard.el("span", { class: "au-field-hint" }, [hint]) : null,
        ]),
      ]);
    const autoplay = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox" }));
    const loop = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox" }));
    const keepPlaying = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "checkbox" }));
    const volume = /** @type {HTMLInputElement} */ (hoard.el("input", { type: "range", min: "0", max: "1", step: "0.05", class: "au-volume" }));
    const show = () => {
      autoplay.checked = settings.autoplay;
      loop.checked = settings.loop;
      keepPlaying.checked = settings.background;
      volume.value = String(settings.volume);
    };
    autoplay.addEventListener("change", () => updateSettings({ autoplay: autoplay.checked }));
    loop.addEventListener("change", () => updateSettings({ loop: loop.checked }));
    keepPlaying.addEventListener("change", () => updateSettings({ background: keepPlaying.checked }));
    volume.addEventListener("input", () => updateSettings({ volume: Number(volume.value) }));
    settingListeners.add(show);
    void settingsLoaded.then(show);
    show();
    root.append(
      hoard.el("div", { class: "au-settings" }, [
        field("快速預覽打開時自動播放", autoplay, "按空白鍵看音效時直接開始播"),
        field("循環播放", loop, "播放器上的循環鍵也會改到這裡"),
        field("背景播放", keepPlaying, "離開詳情頁、關掉快速預覽或換頁時繼續播；再打開同一個音訊就接回播放器，播別的聲音或關掉這項時停止"),
        hoard.el("div", { class: "au-field" }, [hoard.el("span", {}, ["音量"]), volume]),
      ]),
    );
    return () => settingListeners.delete(show);
  },
});
