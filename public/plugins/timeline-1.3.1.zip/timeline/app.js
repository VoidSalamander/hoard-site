// @ts-check
/// <reference path="../hoard-app.d.ts" />
/*
 * 插件：時間軸版型。
 *
 * 一欄一篇完整貼文，像社群動態。貼文卡片由 ctx.mountFeedItem 掛入：來源插件有 renderFeedItem
 * 就用它（X.com 的仿推文），沒有就是 App 的通用卡片。資料夾用 ctx.mountFolder 排在 folder.index 指的
 * 那篇前面（平常都是 0，排在最前面；頁面用自訂排序時穿插在貼文之間）。
 * 點貼文開詳情頁、Ctrl／Shift 點選取、右鍵選單、拖進資料夾都交給 ctx.bindItem。
 *
 * 用 ctx.virtualList 只畫畫面上看得到的那幾篇（每篇量實際高度），捲到底再載入下一頁。
 */

/** 卡片還沒量過時先當它這麼高，捲軸才不會亂跳。 */
const ESTIMATED_HEIGHT = 420;
/** 資料夾卡片還沒量過時的高度。 */
const ESTIMATED_FOLDER_HEIGHT = 96;

hoard.registerLayout({
  id: "timeline",
  label: "時間軸",
  icon: "rows-3",
  drawsFolders: true,

  render(root, items, ctx) {
    const column = hoard.el("div", { class: "tl-feed" });

    // 資料夾照 index 排好了：每篇之前先放排在它前面的資料夾。
    /** @type {Array<{ folder: HoardLayoutFolder } | { item: HoardItemSummary }>} */
    const rows = [];
    let next = 0;
    for (let index = 0; index <= items.length; index++) {
      for (; next < ctx.folders.length && (ctx.folders[next].index <= index || index === items.length); next++) {
        rows.push({ folder: ctx.folders[next] });
      }
      if (index < items.length) rows.push({ item: items[index] });
    }
    root.append(column);

    ctx.virtualList(column, {
      count: rows.length,
      gap: 16,
      estimateSize: (i) => ("folder" in rows[i] ? ESTIMATED_FOLDER_HEIGHT : ESTIMATED_HEIGHT),
      renderRow(row, i) {
        const entry = rows[i];
        if ("folder" in entry) {
          ctx.mountFolder(row, entry.folder);
          return;
        }
        const { item } = entry;
        const body = hoard.el("div");
        ctx.mountFeedItem(body, item);
        const card = hoard.el(
          "article",
          {
            role: "button",
            tabindex: "0",
            class: "tl-post",
            onkeydown: (e) => /** @type {KeyboardEvent} */ (e).key === "Enter" && e.target === card && ctx.openItem(item.id),
          },
          [body],
        );
        ctx.bindItem(card, item);
        row.append(card);
      },
    });

    if (!ctx.hasMore) return;
    // 捲到底載入下一頁；App 重畫時會保留捲動位置。
    const sentinel = hoard.el("div", { class: "tl-sentinel" });
    root.append(sentinel);
    const observer = new IntersectionObserver((entries) => entries.some((e) => e.isIntersecting) && ctx.loadMore(), {
      root,
      rootMargin: "1200px",
    });
    observer.observe(sentinel);
    return () => observer.disconnect();
  },
});
